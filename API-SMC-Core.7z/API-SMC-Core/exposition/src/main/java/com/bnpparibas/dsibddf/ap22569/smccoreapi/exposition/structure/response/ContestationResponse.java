package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;
/**
 *
 *
 *
 */
public class ContestationResponse {

	/**
	 *
	 */
	private static final long serialVersionUID = 640519841876392536L;
	private RecapContestation recapContestation;
	/**
	 *
	 * @return
	 */
	public RecapContestation getRecapContestation() {
		return recapContestation;
	}
	/**
	 *
	 * @param recapContestation
	 */
	public void setRecapContestation(RecapContestation recapContestation) {
		this.recapContestation = recapContestation;
	}
}
