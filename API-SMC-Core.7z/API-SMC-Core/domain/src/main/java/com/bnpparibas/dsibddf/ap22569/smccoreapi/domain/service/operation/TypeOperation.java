package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

public enum TypeOperation {

    PAIEMENT, RETRAIT, LESDEUX
}
