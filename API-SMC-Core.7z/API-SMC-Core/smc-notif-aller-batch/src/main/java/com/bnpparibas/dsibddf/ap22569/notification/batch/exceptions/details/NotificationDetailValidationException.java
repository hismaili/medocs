package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.ErrorLevel;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;

public class NotificationDetailValidationException extends Exception {

    private final String invalidDataValue;
    private String errorCode;

    private ErrorLevel errorLevel;

    private String invalidData;

    private NotificationLine notificationLine;

    public NotificationDetailValidationException(String errorCode, ErrorLevel errorLevel, String invalidData, String invalidDataValue, NotificationLine notificationLine) {
        super(String.format("%s : %s : Invaid Data %s", errorCode, errorLevel, invalidData));
        this.errorCode = errorCode;
        this.errorLevel = errorLevel;
        this.invalidData = invalidData;
        this.notificationLine = notificationLine;
        this.invalidDataValue = invalidDataValue;

    }

    public String getInvalidData() {
        return invalidData;
    }

    public NotificationLine getNotificationLine() {
        return notificationLine;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public ErrorLevel getErrorLevel() {
        return errorLevel;
    }

    public String getInvalidDataValue() {
        return invalidDataValue;
    }
}
