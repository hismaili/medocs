package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;

public class HolderMail {
	private String mailId;
	private String mailUserName;

	private String mailDomain;

	public String getMailDomain() {
		return mailDomain;
	}

	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}

	public String getMailUserName() {
		return mailUserName;
	}

	public void setMailDomain(String mailDomain) {
		this.mailDomain = mailDomain;
	}

	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public void setMailUserName(String mailUserName) {
		this.mailUserName = mailUserName;
	}
}
