package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STATUT_DOSSIER_SMC")
public class StatutDossierSMCEntity {

	@Id
	@Column(length = 25)
	private String codeStatut;

	@Column
	private String libelleStatut;

	public StatutDossierSMCEntity() {
	}

	/**
	 * @param codeStatut
	 * @param libelleStatut
	 */
	public StatutDossierSMCEntity(String codeStatut, String libelleStatut) {
		this.codeStatut = codeStatut;
		this.libelleStatut = libelleStatut;
	}

	public String getCodeStatut() {
		return codeStatut;
	}

	public String getLibelleStatut() {
		return libelleStatut;
	}

	public void setCodeStatut(String codeStatut) {
		this.codeStatut = codeStatut;
	}

	public void setLibelleStatut(String libelleStatut) {
		this.libelleStatut = libelleStatut;
	}
}
