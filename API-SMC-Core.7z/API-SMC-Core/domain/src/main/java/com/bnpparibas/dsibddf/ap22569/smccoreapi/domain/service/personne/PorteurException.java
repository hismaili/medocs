package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcBusinessException;

public class PorteurException extends SmcBusinessException{


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public PorteurException() {
		super();

	}

	/**
	 * @param message
	 */
	public PorteurException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public PorteurException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param cause
	 */
	public PorteurException(Throwable cause) {
		super(cause);

	}

}
