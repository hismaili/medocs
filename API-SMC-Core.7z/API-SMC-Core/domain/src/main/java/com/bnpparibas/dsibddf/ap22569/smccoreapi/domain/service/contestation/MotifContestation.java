package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;

import java.util.List;
import java.util.Objects;

public class MotifContestation {

	private String code;

	private String libelle;

	private TypeOperation typeOperationApplicable;

	private Nature natureContestation;

	private Qualification qualificationContestation;

	private String disclaimerText;

	private Boolean topCardCancelled;

	private ExigenceAjoutInformation topMentionFactDescription;

	private Boolean topMentionRecognizedAmount;

	private List<DocumentJustificatif> documentAssocies;

	private ExigenceAjoutInformation exigenceAttachement;

	private Integer maxOperations;

	/**
	 * historique en jour. 13 mois = 13*30
	 */
	private Integer historique;

	private boolean appliedToOneOperation;

	private boolean appliedToCardLostOnly;

	private String description;

	public MotifContestation() {
	}

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		MotifContestation that = (MotifContestation) o;
		return Objects.equals(code, that.code);
	}

	public String getCode() {
		return code;
	}

	public String getDisclaimerText() {
		return disclaimerText;
	}

	public List<DocumentJustificatif> getDocumentAssocies() {
		return documentAssocies;
	}

	public ExigenceAjoutInformation getExigenceAttachement() {
		return exigenceAttachement;
	}

	public Integer getHistorique() {
		return historique;
	}

	public String getLibelle() {
		return libelle;
	}

	public Integer getMaxOperations() {
		return maxOperations;
	}

	public Nature getNatureContestation() {
		return natureContestation;
	}

	public Qualification getQualificationContestation() {
		return qualificationContestation;
	}

	public Boolean getTopCardCancelled() {
		return topCardCancelled;
	}

	public ExigenceAjoutInformation getTopMentionFactDescription() {
		return topMentionFactDescription;
	}

	public Boolean getTopMentionRecognizedAmount() {
		return topMentionRecognizedAmount;
	}

	public TypeOperation getTypeOperationApplicable() {
		return typeOperationApplicable;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	public boolean isAppliedToCardLostOnly() {
		return appliedToCardLostOnly;
	}

	public boolean isAppliedToOneOperation() {
		return appliedToOneOperation;
	}

	public void setAppliedToCardLostOnly(boolean appliedToCardLostOnly) {
		this.appliedToCardLostOnly = appliedToCardLostOnly;
	}

	public void setAppliedToOneOperation(boolean appliedToOneOperation) {
		this.appliedToOneOperation = appliedToOneOperation;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setDisclaimerText(String disclaimerText) {
		this.disclaimerText = disclaimerText;
	}

	public void setDocumentAssocies(List<DocumentJustificatif> documentAssocies) {
		this.documentAssocies = documentAssocies;
	}

	public void setExigenceAttachement(ExigenceAjoutInformation exigenceAttachement) {
		this.exigenceAttachement = exigenceAttachement;
	}

	public void setHistorique(Integer historique) {
		this.historique = historique;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public void setMaxOperations(Integer maxOperations) {
		this.maxOperations = maxOperations;
	}

	public void setNatureContestation(Nature natureContestation) {
		this.natureContestation = natureContestation;
	}

	public void setQualificationContestation(Qualification qualificationContestation) {
		this.qualificationContestation = qualificationContestation;
	}

	public void setTopCardCancelled(Boolean topCardCancelled) {
		this.topCardCancelled = topCardCancelled;
	}

	public void setTopMentionFactDescription(ExigenceAjoutInformation topMentionFactDescription) {
		this.topMentionFactDescription = topMentionFactDescription;
	}

	public void setTopMentionRecognizedAmount(Boolean topMentionRecognizedAmount) {
		this.topMentionRecognizedAmount = topMentionRecognizedAmount;
	}

	public void setTypeOperationApplicable(TypeOperation typeOperationApplicable) {
		this.typeOperationApplicable = typeOperationApplicable;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
