/**
 *
 * Classe représentant la réponse de la couche aux appels des services d'archivage
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.io.Serializable;

/**
 * @author c65344
 *
 */
public class ArchivageResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String identifier;

	//	private List<SmcApiError> errors;
	/**
	 *
	 */
	public ArchivageResponse() {
	}
	//	/**
	//	 *
	//	 * @param errors
	//	 */
	//	public ArchivageResponse(List<SmcApiError> errors) {
	//		this.errors = errors;
	//	}
	/**
	 *
	 * @param identifier
	 */
	public ArchivageResponse(String identifier) {
		this.identifier = identifier;
	}
	//	/**
	//	 *
	//	 * @return
	//	 */
	//	public List<SmcApiError> getErrors() {
	//		return errors;
	//	}
	/**
	 *
	 * @return
	 */
	public String getIdentifier() {
		return identifier;
	}
	//	/**
	//	 *
	//	 * @param errors
	//	 */
	//	public void setErrors(List<SmcApiError> errors) {
	//		this.errors = errors;
	//	}
	/**
	 *
	 * @param identifier
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
}
