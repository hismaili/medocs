package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

public enum OperationSign {
    PLUS("PLUS"),

    MOINS("MOINS");

    private String value;

    OperationSign(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static OperationSign fromValue(String text) {
        for (OperationSign b : OperationSign.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}