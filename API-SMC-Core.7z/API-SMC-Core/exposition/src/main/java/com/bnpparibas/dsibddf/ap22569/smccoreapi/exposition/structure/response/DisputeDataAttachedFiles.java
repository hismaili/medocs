package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;

/**
 * DisputeDataAttachedFiles
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-03-27T14:00:58.610Z")

public class DisputeDataAttachedFiles   {
	@JsonProperty("filetype")
	private String filetype;

	@JsonProperty("fileName")
	private String fileName;

	@JsonProperty("idGdn")
	private String idGdn;

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeDataAttachedFiles disputeDataAttachedFiles = (DisputeDataAttachedFiles) o;
		return Objects.equals(this.filetype, disputeDataAttachedFiles.filetype) &&
				Objects.equals(this.fileName, disputeDataAttachedFiles.fileName) &&
				Objects.equals(this.idGdn, disputeDataAttachedFiles.idGdn);
	}
	/**
	 *
	 * @param fileName
	 * @return
	 */
	public DisputeDataAttachedFiles fileName(String fileName) {
		this.fileName = fileName;
		return this;
	}
	/**
	 *
	 * @param filetype
	 * @return
	 */
	public DisputeDataAttachedFiles filetype(String filetype) {
		this.filetype = filetype;
		return this;
	}

	/**
	 * nom du document attaché
	 *
	 * @return fileName
	 **/
	@ApiModelProperty(value = "nom du document attaché")
	public String getFileName() {
		return fileName;
	}

	/**
	 * code du type GDN du document. Correspond au fileType envoyé dans la liste des documents à joindre par motif.
	 *
	 * @return filetype
	 **/
	@ApiModelProperty(value = "code du type GDN du document. Correspond au fileType envoyé dans la liste des documents à joindre par motif.")
	public String getFiletype() {
		return filetype;
	}

	/**
	 * identifiant GDN du document
	 *
	 * @return idGdn
	 **/
	@ApiModelProperty(value = "identifiant GDN du document")
	public String getIdGdn() {
		return idGdn;
	}

	@Override
	public int hashCode() {
		return Objects.hash(filetype, fileName, idGdn);
	}
	/**
	 *
	 * @param idGdn
	 * @return
	 */
	public DisputeDataAttachedFiles idGdn(String idGdn) {
		this.idGdn = idGdn;
		return this;
	}
	/**
	 *
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 *
	 * @param filetype
	 */
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	/**
	 *
	 * @param idGdn
	 */
	public void setIdGdn(String idGdn) {
		this.idGdn = idGdn;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeDataAttachedFiles {\n");

		sb.append("    filetype: ").append(toIndentedString(filetype)).append("\n");
		sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
		sb.append("    idGdn: ").append(toIndentedString(idGdn)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

