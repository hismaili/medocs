package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SMC_2_SLEFCARE_STATE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class StatutSMCToStatutSelfCareEntity extends AbstractEntity<DefaultEntityId> {

	@ManyToOne
	private StatutDossierContestationSelfCare  statutSelfCare;

	@ManyToOne
	private StatutDossierSMCEntity statutSMC;

	@ManyToOne
	private AvancementSMCEntity avancementSMC;

	public StatutSMCToStatutSelfCareEntity() {
	}

	/**
	 * @param statutSelfCare
	 * @param statutSMC
	 * @param avancementSMC
	 */
	public StatutSMCToStatutSelfCareEntity(
			StatutDossierContestationSelfCare statutSelfCare,
			StatutDossierSMCEntity statutSMC, AvancementSMCEntity avancementSMC) {
		this.statutSelfCare = statutSelfCare;
		this.statutSMC = statutSMC;
		this.avancementSMC = avancementSMC;
	}

	public AvancementSMCEntity getAvancementSMC() {
		return avancementSMC;
	}

	public StatutDossierContestationSelfCare getStatutSelfCare() {
		return statutSelfCare;
	}

	public StatutDossierSMCEntity getStatutSMC() {
		return statutSMC;
	}

	public void setStatutSelfCare(StatutDossierContestationSelfCare statutSelfCare) {
		this.statutSelfCare = statutSelfCare;
	}

	public void setStatutSMC(StatutDossierSMCEntity statutSMC) {
		this.statutSMC = statutSMC;
	}

    public void setAvancementSMC(AvancementSMCEntity avancementSMC) {
        this.avancementSMC = avancementSMC;
    }
}
