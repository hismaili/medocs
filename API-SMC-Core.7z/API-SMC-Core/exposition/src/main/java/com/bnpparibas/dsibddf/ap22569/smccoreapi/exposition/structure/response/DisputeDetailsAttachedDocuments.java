package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

/**
 * DisputeDetailsAttachedDocuments
 */
public class DisputeDetailsAttachedDocuments {
	@JsonProperty("idGed")
	private String idGed;

	@JsonProperty("formatDoc")
	private String formatDoc;

	@JsonProperty("fileName")
	private String fileName;

	@JsonProperty("typeDoc")
	private String typeDoc;

	@JsonProperty("isRecap")
	private Boolean recap = Boolean.FALSE;

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeDetailsAttachedDocuments disputeDetailsAttachedDocuments = (DisputeDetailsAttachedDocuments) o;
		return Objects.equals(this.idGed, disputeDetailsAttachedDocuments.idGed) &&
				Objects.equals(this.formatDoc, disputeDetailsAttachedDocuments.formatDoc) &&
				Objects.equals(this.fileName, disputeDetailsAttachedDocuments.fileName) &&
				Objects.equals(this.typeDoc, disputeDetailsAttachedDocuments.typeDoc);
	}
	/**
	 *
	 * @param fileName
	 * @return
	 */
	public DisputeDetailsAttachedDocuments fileName(String fileName) {
		this.fileName = fileName;
		return this;
	}
	/**
	 *
	 * @param formatDoc
	 * @return
	 */
	public DisputeDetailsAttachedDocuments formatDoc(String formatDoc) {
		this.formatDoc = formatDoc;
		return this;
	}

	/**
	 * nom du fichier
	 *
	 * @return fileName
	 **/
	@ApiModelProperty(value = "nom du fichier")
	public String getFileName() {
		return fileName;
	}

	/**
	 * pdf, doc
	 *
	 * @return formatDoc
	 **/
	@ApiModelProperty(value = "pdf, doc")
	public String getFormatDoc() {
		return formatDoc;
	}

	/**
	 * Get idGed
	 *
	 * @return idGed
	 **/
	@ApiModelProperty(value = "")
	public String getIdGed() {
		return idGed;
	}

	/**
	 * type document
	 *
	 * @return typeDoc
	 **/
	@ApiModelProperty(value = "type document")
	public String getTypeDoc() {
		return typeDoc;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idGed, formatDoc, fileName, typeDoc);
	}
	/**
	 *
	 * @param idGed
	 * @return
	 */
	public DisputeDetailsAttachedDocuments idGed(String idGed) {
		this.idGed = idGed;
		return this;
	}
	/**
	 *
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 *
	 * @param formatDoc
	 */
	public void setFormatDoc(String formatDoc) {
		this.formatDoc = formatDoc;
	}
	/**
	 *
	 * @param idGed
	 */
	public void setIdGed(String idGed) {
		this.idGed = idGed;
	}

	/**
	 *
	 * @param typeDoc
	 */
	public void setTypeDoc(String typeDoc) {
		this.typeDoc = typeDoc;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeDetailsAttachedDocuments {\n");

		sb.append("    idGed: ").append(toIndentedString(idGed)).append("\n");
		sb.append("    formatDoc: ").append(toIndentedString(formatDoc)).append("\n");
		sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
		sb.append("    typeDoc: ").append(toIndentedString(typeDoc)).append("\n");
		sb.append("}");
		return sb.toString();
	}
	/**
	 *
	 * @param typeDoc
	 * @return
	 */
	public DisputeDetailsAttachedDocuments typeDoc(String typeDoc) {
		this.typeDoc = typeDoc;
		return this;
	}

	public Boolean getRecap() {
		return recap;
	}

	public void setRecap(Boolean recap) {
		this.recap = recap;
	}
}

