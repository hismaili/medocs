package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.Map;

public class DetailCourrier {

	private Destinataire destinataire;

	private Emeteur emeteur;

	private String dateTraitement;

	private String maquetteId;

	private Map<String,String> sneMaquette;

	private String codeTypeDoc;

	private String libTypeDoc;

	private String dateCreationSmc;

	private String numDossier;

	private String nomPorteur;

	private String prenomPorteur;

	private LocalDate birthDay;

	private String	clientNatureId;


	private BigInteger  sirenNumber;

	private String ikpi;

	private String idContratMonetiquePorteur;

	private String ribOperation;

	private String ribCotisation;

	private String qualificationDossier;

	private String natureDossier;

	private String natureDossierLibelle;

	private String dateAppel;

	private int delaisReponse;

	private String dateOpposition;

	private int totalOperations;

	private String numCarteMasque;

	private String montantConteste;

	private int nombreOperations;

	private String topClientele;

	private String codePostale;

	private String codePays;

	private String idDocSmc;

	private String raisonSociale;

	/**
	 * @return the birthDay
	 */
	public LocalDate getBirthDay() {
		return birthDay;
	}

	/**
	 * @return the clientNatureId
	 */
	public String getClientNatureId() {
		return clientNatureId;
	}


	/**
	 * @return the codePays
	 */
	public String getCodePays() {
		return codePays;
	}

	/**
	 * @return the codePostale
	 */
	public String getCodePostale() {
		return codePostale;
	}

	/**
	 * @return the codeTypeDoc
	 */
	public String getCodeTypeDoc() {
		return codeTypeDoc;
	}

	/**
	 * @return the dateAppel
	 */
	public String getDateAppel() {
		return dateAppel;
	}

	/**
	 * @return the dateCreationSmc
	 */
	public String getDateCreationSmc() {
		return dateCreationSmc;
	}

	/**
	 * @return the dateOpposition
	 */
	public String getDateOpposition() {
		return dateOpposition;
	}

	/**
	 * @return the dateTraitement
	 */
	public String getDateTraitement() {
		return dateTraitement;
	}

	/**
	 * @return the delaisReponse
	 */
	public int getDelaisReponse() {
		return delaisReponse;
	}

	/**
	 * @return the destinataire
	 */
	public Destinataire getDestinataire() {
		return destinataire;
	}

	/**
	 * @return the emeteur
	 */
	public Emeteur getEmeteur() {
		return emeteur;
	}

	/**
	 * @return the idContratMonetiquePorteur
	 */
	public String getIdContratMonetiquePorteur() {
		return idContratMonetiquePorteur;
	}

	/**
	 * @return the idDocSmc
	 */
	public String getIdDocSmc() {
		return idDocSmc;
	}

	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}

	/**
	 * @return the libTypeDoc
	 */
	public String getLibTypeDoc() {
		return libTypeDoc;
	}

	/**
	 * @return the maquetteId
	 */
	public String getMaquetteId() {
		return maquetteId;
	}

	/**
	 * @return the montantConteste
	 */
	public String getMontantConteste() {
		return montantConteste;
	}

	/**
	 * @return the natureDossier
	 */
	public String getNatureDossier() {
		return natureDossier;
	}

	/**
	 * @return the natureDossierLibelle
	 */
	public String getNatureDossierLibelle() {
		return natureDossierLibelle;
	}

	/**
	 * @return the nombreOperations
	 */
	public int getNombreOperations() {
		return nombreOperations;
	}

	/**
	 * @return the nomPorteur
	 */
	public String getNomPorteur() {
		return nomPorteur;
	}

	/**
	 * @return the numCarteMasque
	 */
	public String getNumCarteMasque() {
		return numCarteMasque;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the prenomPorteur
	 */
	public String getPrenomPorteur() {
		return prenomPorteur;
	}

	/**
	 * @return the qualificationDossier
	 */
	public String getQualificationDossier() {
		return qualificationDossier;
	}

	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}

	/**
	 * @return the ribCotisation
	 */
	public String getRibCotisation() {
		return ribCotisation;
	}

	/**
	 * @return the ribOperation
	 */
	public String getRibOperation() {
		return ribOperation;
	}

	/**
	 * @return the sirenNumber
	 */
	public BigInteger getSirenNumber() {
		return sirenNumber;
	}

	/**
	 * @return the sneMaquette
	 */
	public Map<String, String> getSneMaquette() {
		return sneMaquette;
	}

	/**
	 * @return the topClientele
	 */
	public String getTopClientele() {
		return topClientele;
	}

	/**
	 * @return the totalOperations
	 */
	public int getTotalOperations() {
		return totalOperations;
	}

	/**
	 * @param birthDay the birthDay to set
	 */
	public void setBirthDay(LocalDate birthDay) {
		this.birthDay = birthDay;
	}

	/**
	 * @param clientNatureId the clientNatureId to set
	 */
	public void setClientNatureId(String clientNatureId) {
		this.clientNatureId = clientNatureId;
	}


	/**
	 * @param codePays the codePays to set
	 */
	public void setCodePays(String codePays) {
		this.codePays = codePays;
	}

	/**
	 * @param codePostale the codePostale to set
	 */
	public void setCodePostale(String codePostale) {
		this.codePostale = codePostale;
	}

	/**
	 * @param codeTypeDoc the codeTypeDoc to set
	 */
	public void setCodeTypeDoc(String codeTypeDoc) {
		this.codeTypeDoc = codeTypeDoc;
	}

	/**
	 * @param dateAppel the dateAppel to set
	 */
	public void setDateAppel(String dateAppel) {
		this.dateAppel = dateAppel;
	}

	/**
	 * @param dateCreationSmc the dateCreationSmc to set
	 */
	public void setDateCreationSmc(String dateCreationSmc) {
		this.dateCreationSmc = dateCreationSmc;
	}

	/**
	 * @param dateOpposition the dateOpposition to set
	 */
	public void setDateOpposition(String dateOpposition) {
		this.dateOpposition = dateOpposition;
	}

	/**
	 * @param dateTraitement the dateTraitement to set
	 */
	public void setDateTraitement(String dateTraitement) {
		this.dateTraitement = dateTraitement;
	}

	/**
	 * @param delaisReponse the delaisReponse to set
	 */
	public void setDelaisReponse(int delaisReponse) {
		this.delaisReponse = delaisReponse;
	}

	/**
	 * @param destinataire the destinataire to set
	 */
	public void setDestinataire(Destinataire destinataire) {
		this.destinataire = destinataire;
	}

	/**
	 * @param emeteur the emeteur to set
	 */
	public void setEmeteur(Emeteur emeteur) {
		this.emeteur = emeteur;
	}

	/**
	 * @param idContratMonetiquePorteur the idContratMonetiquePorteur to set
	 */
	public void setIdContratMonetiquePorteur(String idContratMonetiquePorteur) {
		this.idContratMonetiquePorteur = idContratMonetiquePorteur;
	}

	/**
	 * @param idDocSmc the idDocSmc to set
	 */
	public void setIdDocSmc(String idDocSmc) {
		this.idDocSmc = idDocSmc;
	}

	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}

	/**
	 * @param libTypeDoc the libTypeDoc to set
	 */
	public void setLibTypeDoc(String libTypeDoc) {
		this.libTypeDoc = libTypeDoc;
	}

	/**
	 * @param maquetteId the maquetteId to set
	 */
	public void setMaquetteId(String maquetteId) {
		this.maquetteId = maquetteId;
	}

	/**
	 * @param montantConteste the montantConteste to set
	 */
	public void setMontantConteste(String montantConteste) {
		this.montantConteste = montantConteste;
	}

	/**
	 * @param natureDossier the natureDossier to set
	 */
	public void setNatureDossier(String natureDossier) {
		this.natureDossier = natureDossier;
	}

	/**
	 * @param natureDossierLibelle the natureDossierLibelle to set
	 */
	public void setNatureDossierLibelle(String natureDossierLibelle) {
		this.natureDossierLibelle = natureDossierLibelle;
	}

	/**
	 * @param nombreOperations the nombreOperations to set
	 */
	public void setNombreOperations(int nombreOperations) {
		this.nombreOperations = nombreOperations;
	}

	/**
	 * @param nomPorteur the nomPorteur to set
	 */
	public void setNomPorteur(String nomPorteur) {
		this.nomPorteur = nomPorteur;
	}

	/**
	 * @param numCarteMasque the numCarteMasque to set
	 */
	public void setNumCarteMasque(String numCarteMasque) {
		this.numCarteMasque = numCarteMasque;
	}

	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}

	/**
	 * @param prenomPorteur the prenomPorteur to set
	 */
	public void setPrenomPorteur(String prenomPorteur) {
		this.prenomPorteur = prenomPorteur;
	}

	/**
	 * @param qualificationDossier the qualificationDossier to set
	 */
	public void setQualificationDossier(String qualificationDossier) {
		this.qualificationDossier = qualificationDossier;
	}

	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}

	/**
	 * @param ribCotisation the ribCotisation to set
	 */
	public void setRibCotisation(String ribCotisation) {
		this.ribCotisation = ribCotisation;
	}

	/**
	 * @param ribOperation the ribOperation to set
	 */
	public void setRibOperation(String ribOperation) {
		this.ribOperation = ribOperation;
	}

	/**
	 * @param sirenNumber the sirenNumber to set
	 */
	public void setSirenNumber(BigInteger sirenNumber) {
		this.sirenNumber = sirenNumber;
	}

	/**
	 * @param sneMaquette the sneMaquette to set
	 */
	public void setSneMaquette(Map<String, String> sneMaquette) {
		this.sneMaquette = sneMaquette;
	}

	/**
	 * @param topClientele the topClientele to set
	 */
	public void setTopClientele(String topClientele) {
		this.topClientele = topClientele;
	}

	/**
	 * @param totalOperations the totalOperations to set
	 */
	public void setTotalOperations(int totalOperations) {
		this.totalOperations = totalOperations;
	}



}
