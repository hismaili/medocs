/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import java.util.List;

/**
 * @author c65344
 *
 */
public class SmcEditionException extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	List<String> donnesIncorrect;
	List<String> donnesAbsentUI;
	List<String> donnesAbsentNoUI;
	List<String> formatIncorrect;
	/**
	 *
	 */
	public SmcEditionException() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param message
	 */
	public SmcEditionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param message
	 * @param cause
	 */
	public SmcEditionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public SmcEditionException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param cause
	 */
	public SmcEditionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the donnesAbsentNoUI
	 */
	public List<String> getDonnesAbsentNoUI() {
		return donnesAbsentNoUI;
	}
	/**
	 * @return the donnesAbsentUI
	 */
	public List<String> getDonnesAbsentUI() {
		return donnesAbsentUI;
	}
	/**
	 * @return the donnesIncorrect
	 */
	public List<String> getDonnesIncorrect() {
		return donnesIncorrect;
	}
	/**
	 * @return the formatIncorrect
	 */
	public List<String> getFormatIncorrect() {
		return formatIncorrect;
	}
	/**
	 * @param donnesAbsentNoUI the donnesAbsentNoUI to set
	 */
	public void setDonnesAbsentNoUI(List<String> donnesAbsentNoUI) {
		this.donnesAbsentNoUI = donnesAbsentNoUI;
	}
	/**
	 * @param donnesAbsentUI the donnesAbsentUI to set
	 */
	public void setDonnesAbsentUI(List<String> donnesAbsentUI) {
		this.donnesAbsentUI = donnesAbsentUI;
	}
	/**
	 * @param donnesIncorrect the donnesIncorrect to set
	 */
	public void setDonnesIncorrect(List<String> donnesIncorrect) {
		this.donnesIncorrect = donnesIncorrect;
	}
	/**
	 * @param formatIncorrect the formatIncorrect to set
	 */
	public void setFormatIncorrect(List<String> formatIncorrect) {
		this.formatIncorrect = formatIncorrect;
	}


}
