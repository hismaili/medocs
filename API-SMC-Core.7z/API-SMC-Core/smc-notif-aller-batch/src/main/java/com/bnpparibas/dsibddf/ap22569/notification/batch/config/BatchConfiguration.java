
package com.bnpparibas.dsibddf.ap22569.notification.batch.config;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.NotificationDetailValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEvent;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.helpers.NotificationLineMapper;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load.NotificationItemProcessor;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load.NotificationItemReader;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load.NotificationItemWriter;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import java.util.List;
import java.util.Random;


@Configuration
public class BatchConfiguration extends JobExecutionListenerSupport{

	private static final Logger LOG = LoggerFactory.getLogger(BatchConfiguration.class);
	public static final String FILE_INFO = "FILE_INFO";

	@Autowired
	private transient JobBuilderFactory jobBuilderFactory;
	@Autowired
	private transient StepBuilderFactory stepBuilderFactory;

	@Autowired
	private transient NotificationItemWriter writer;

	@Autowired
	private transient NotificationItemProcessor processor;

	@Autowired
	private transient RunIdIncrementer incrementer;

	@Autowired
	private transient NotificationItemReader notificationItemReader;

	@Value("${file.input}")
	private FileSystemResource inputResource;

	@Autowired
	@Qualifier("fileValidationTasklet")
	private Tasklet validationTasklet;
	private JobExecution jobExecution;

	@Autowired
	@Qualifier("sendMailTasklet")
	private Tasklet sendMailTasklet;

	@Autowired
	private ItemReader<? extends List<Notification>> notificationEventReader;

	@Autowired
	private ItemProcessor<? super List<Notification>, ? extends List<NotificationEvent>> notificationEventProcessor;

	@Autowired
	private ItemWriter<? super List<NotificationEvent>> notificationEventWriter;

	@Autowired
    private JobExecutionListener notificationJobListener;

    @Bean(name = "notifJob")
	public Job batchConfigJob() {

		notificationItemReader.setResource(inputResource);

		TaskletStep validationStep = stepBuilderFactory.get("validation-step").listener(this).tasklet(validationTasklet).build();

		Step loadFileStep = stepBuilderFactory.get("loadFileStep")
				.<NotificationLine, Notification> chunk(1)
				.reader(notificationItemReader)
				.processor(processor)
				.writer(writer)
				.faultTolerant().skip(NotificationDetailValidationException.class).skipLimit(50000)
				.build();

		TaskletStep sendMailStep = stepBuilderFactory.get("sendMailStep").tasklet(sendMailTasklet).build();

		Step sendNotifEventStep = stepBuilderFactory.get("notifEventStep")
				.<List<Notification>, List<NotificationEvent>> chunk(1)
				.reader(notificationEventReader)
				.processor(notificationEventProcessor)
				.writer(notificationEventWriter)
				.faultTolerant().skip(NotificationDetailValidationException.class).skipLimit(50000)
				.build();


		Job job = jobBuilderFactory.get("Notification-job")
				.incrementer(incrementer).listener(notificationJobListener)
				.start(validationStep).on(ExitStatus.COMPLETED.getExitCode()).to(loadFileStep)
				.from(validationStep).on(ExitStatus.FAILED.getExitCode()).to(sendMailStep)
				.from(loadFileStep).on("*").to(sendNotifEventStep)
				.from(loadFileStep).on(ExitStatus.FAILED.toString()).to(sendMailStep)
				.end()
				.build();
		LOG.info("Tout les steps se sont bien deroulés");

		return job;

	}

	@Bean
	public RunIdIncrementer incrementer() {
		return new RunIdIncrementer();
	}

	@BeforeStep
	public void saveStepExecution(StepExecution stepExecution) {
		NotificationLineMapper lineMapper = (NotificationLineMapper)this.notificationItemReader.getLineMapper();
		lineMapper.setStepExecution(stepExecution);
		lineMapper.setFileName(inputResource.getFilename());
		Random random = new Random();
		String idFileNotification = Integer.toString(random.nextInt());
		stepExecution.getExecutionContext().put("FileID", idFileNotification);

		this.jobExecution = stepExecution.getJobExecution();
		processor.setJobExecution(jobExecution);
	}


}
