package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.UUID;

@Service
public class JwtAuthorizationBuilder {


	class Signature{

		private Key key;

		private String Empreinte;

		/**
		 *
		 */
		public Signature() {
			super();
			// TODO Auto-generated constructor stub
		}

		/**
		 * @param key
		 * @param empreinte
		 */
		public Signature(Key key, String empreinte) {
			this.key = key;
			Empreinte = empreinte;
		}

		/**
		 * @return the empreinte
		 */
		public String getEmpreinte() {
			return Empreinte;
		}

		/**
		 * @return the key
		 */
		public Key getKey() {
			return key;
		}

		/**
		 * @param empreinte the empreinte to set
		 */
		public void setEmpreinte(String empreinte) {
			Empreinte = empreinte;
		}

		/**
		 * @param key the key to set
		 */
		public void setKey(Key key) {
			this.key = key;
		}

	}


	private  final Logger LOG = LoggerFactory
			.getLogger(JwtAuthorizationBuilder.class);

	@Autowired
	private transient ConfigInfrastructure conf;

	private Signature buildAuthorization(){

		Signature signature = null;

		try {

			/**
			 * chargement clé privé
			 */
			String alias = conf.getAliasKeystore();
			//ClassPathResource classpathFile = new ClassPathResource(conf.getPathKeyStore());

			FileInputStream is = new FileInputStream(conf.getPathKeyStore());
			//InputStream is = classpathFile.getInputStream();


			final KeyStore keystore = KeyStore.getInstance("JKS");


			String passwordKeyStore = conf.getPasswordKeyStore();
			char[] password = passwordKeyStore.toCharArray();

			keystore.load(is,password);



			//	Enumeration<String> aliases = keystore.aliases();

			//LOG.info("Cet alias est il dans le keystore ? : "+containsAlias);

			PrivateKey key = null;
			//			int i = 0;
			//			while (aliases.hasMoreElements()) {
			//				String aliasSigle = aliases.nextElement();
			//				boolean containsAlias = keystore.containsAlias(aliasSigle);
			//				key = (PrivateKey) keystore.getKey(aliasSigle, password);
			//				LOG.info("L'alias est :"+aliasSigle+"\n Le mot de passe est  : "+passwordKeyStore+" Le mot de passe encode en char est"+password);
			//			}

			LOG.info("L'alias est :"+alias+"\n Le mot de passe est  : "+passwordKeyStore+" Le mot de passe encode en char est"+password);

			key = (PrivateKey) keystore.getKey(alias, password);


			is.close();

			InputStream pathCertif =new FileInputStream(conf.getPathCertif());

			//InputStream pathCertif = classpathFile.getInputStream();

			final CertificateFactory certificateFactory = CertificateFactory.getInstance(conf.getInstanceXcertif());

			final X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(pathCertif);

			String empreinte = getEmpreinte(cert);

			signature = new Signature(key, empreinte);

			pathCertif.close();

		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}

		return signature;
	}




	public String getCompactJws() throws JwtSmcException {// throws SIException
		String compactJws = null;

		String empreinte = null;
		Key key = null;
		Signature authorization = buildAuthorization();

		if(authorization !=null){
			empreinte = authorization.getEmpreinte();
			key = authorization.getKey();
		}else{
			LOG.error("problème de generation du certificat et de la keyStore");
			throw new JwtSmcException("problème de generation du certificat et de la keyStore");
		}

		// Generation jeton
		final Calendar c = new GregorianCalendar();

		final Date dateValidite = c.getTime();
		final long validDate = dateValidite.getTime() / 1000;

		c.add(Calendar.MINUTE, conf.getMinuteLiveJwt());
		final Date dateExpiration = c.getTime();
		final long expirateDate = dateExpiration.getTime() / 1000;

		compactJws = Jwts.builder().setHeaderParam("typ", conf.getTypAuthorization()).setHeaderParam("alg", conf.getAlgJwt()).setHeaderParam("x5t", empreinte)
				.claim("jti", UUID.randomUUID().toString()).claim("vers", Integer.valueOf(conf.getVersionJwt())).claim("root", conf.getRootService()).claim("nbf", validDate)
				.claim("exp", expirateDate).claim("chan", conf.getChanJwt()).claim("appid", conf.getIdApplication()).setIssuedAt(dateValidite).setExpiration(dateExpiration)
				.signWith(SignatureAlgorithm.RS256, key).compact();

		LOG.info("Le token generé est : "+compactJws);

		return compactJws;
	}


	private String getEmpreinte(final X509Certificate cert) throws NoSuchAlgorithmException, CertificateEncodingException {
		final MessageDigest md = MessageDigest.getInstance("SHA-1");
		final byte[] der = cert.getEncoded();
		md.update(der);
		final byte[] digest = md.digest();
		Base64Utils.encodeToUrlSafeString(digest);
		final String digestHex = Base64Utils.encodeToUrlSafeString(digest);
		return digestHex;
	}


	//	@PostConstruct
	//	private  void init() {
	//
	//		try {
	//
	//			// chargement clé privé
	//
	//			final FileInputStream is = new FileInputStream("");
	//
	//			final KeyStore keystore = KeyStore.getInstance("PKCS12");
	//
	//			keystore.load(is, valuePassword.toCharArray());
	//
	//			Key key = (PrivateKey) keystore.getKey(valueAlias, valuePassword.toCharArray());
	//
	//			is.close();
	//
	//			// LOGGER.info("key==>" + key);
	//
	//			final FileInputStream path = new FileInputStream(valueCerFile);
	//
	//			final CertificateFactory certificateFactory = CertificateFactory.getInstance(SIConstant.INSTANCE_X);
	//
	//			final X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(path);
	//
	//			thumbprint = getEmpreinte(cert);
	//
	//			path.close();
	//
	//		} catch (final Exception e) {
	//
	//			LOG.error(e.getMessage(), e);
	//
	//		}
	//	}
}
