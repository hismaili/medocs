package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details;

public class RejectDetail {

    private String folderNumber;
    private String notificationCode;
    private String notificationType;
    private String wrongDataName;
    private String wrongDataValue;
    private String rejectReason;

    public RejectDetail(String folderNumber, String notificationCode, String notificationType, String wrongDataName, String wrongDataValue, String rejectReason) {
        this.folderNumber = folderNumber;
        this.notificationCode = notificationCode;
        this.notificationType = notificationType;
        this.wrongDataName = wrongDataName;
        this.wrongDataValue = wrongDataValue;
        this.rejectReason = rejectReason;
    }

    public String getFolderNumber() {
        return folderNumber;
    }

    public void setFolderNumber(String folderNumber) {
        this.folderNumber = folderNumber;
    }

    public String getNotificationCode() {
        return notificationCode;
    }

    public void setNotificationCode(String notificationCode) {
        this.notificationCode = notificationCode;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public String getWrongDataName() {
        return wrongDataName;
    }

    public void setWrongDataName(String wrongDataName) {
        this.wrongDataName = wrongDataName;
    }

    public String getWrongDataValue() {
        return wrongDataValue;
    }

    public void setWrongDataValue(String wrongDataValue) {
        this.wrongDataValue = wrongDataValue;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }
}
