/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;


/**
 * @author c65344
 *
 */
public class CloseFolderInput {
	private String callingUserCloseFolderInput;
	private String callingApplicationCloseFolderInput;
	private String localeCodeCloseFolderInput;
	private String countryCodeCloseFolderInput;

	private List<String> listedocumentId;

	private String numCarteBancaireCloseFolderInput;
	private String idContestationSmcCloseFolderInput;


	private String archivingReferenceDate;



	private String clientNatureIdCloseFolderInput;

	private String clientNameCloseFolderInput;
	private String clientFirstnameCloseFolderInput;
	private BigInteger sirenCloseFolderInput;
	private LocalDate birthDay;
	private String clientId;

	private String contractIDValue;
	private String contractIdTypeCodeValue;
	private String contractIdTypeLabelValue;



	private String documentTypeIdCloseFolderInput;
	private String mimeTypeCloseFolderInput;
	private String titreCloseFolderInput;


	private String fileNameCloseFolderInput;
	private String archiveFormatCloseFolderInput;
	private String compressCloseFolderInput;
	private String encodingCloseFolderInput;
	private String dataCloseFolderInput;
	/**
	 *
	 */
	public CloseFolderInput() {
		super();

	}
	/**
	 * @param callingUserCloseFolderInput
	 * @param callingApplicationCloseFolderInput
	 * @param localeCodeCloseFolderInput
	 * @param countryCodeCloseFolderInput
	 * @param listedocumentId
	 * @param numCarteBancaireCloseFolderInput
	 * @param idContestationSmcCloseFolderInput
	 * @param archivingReferenceDate
	 * @param clientNatureIdCloseFolderInput
	 * @param clientNameCloseFolderInput
	 * @param clientFirstnameCloseFolderInput
	 * @param sirenCloseFolderInput
	 * @param birthDay
	 * @param clientId
	 * @param contractIDValue
	 * @param contractIdTypeCodeValue
	 * @param contractIdTypeLabelValue
	 * @param documentTypeIdCloseFolderInput
	 * @param mimeTypeCloseFolderInput
	 * @param titreCloseFolderInput
	 * @param fileNameCloseFolderInput
	 * @param archiveFormatCloseFolderInput
	 * @param compressCloseFolderInput
	 * @param encodingCloseFolderInput
	 * @param dataCloseFolderInput
	 */
	public CloseFolderInput(String callingUserCloseFolderInput,
			String callingApplicationCloseFolderInput,
			String localeCodeCloseFolderInput,
			String countryCodeCloseFolderInput, List<String> listedocumentId,
			String numCarteBancaireCloseFolderInput,
			String idContestationSmcCloseFolderInput,
			String archivingReferenceDate,
			String clientNatureIdCloseFolderInput,
			String clientNameCloseFolderInput,
			String clientFirstnameCloseFolderInput,
			BigInteger sirenCloseFolderInput, LocalDate birthDay,
			String clientId, String contractIDValue,
			String contractIdTypeCodeValue, String contractIdTypeLabelValue,
			String documentTypeIdCloseFolderInput,
			String mimeTypeCloseFolderInput, String titreCloseFolderInput,
			String fileNameCloseFolderInput,
			String archiveFormatCloseFolderInput,
			String compressCloseFolderInput, String encodingCloseFolderInput,
			String dataCloseFolderInput) {
		this.callingUserCloseFolderInput = callingUserCloseFolderInput;
		this.callingApplicationCloseFolderInput = callingApplicationCloseFolderInput;
		this.localeCodeCloseFolderInput = localeCodeCloseFolderInput;
		this.countryCodeCloseFolderInput = countryCodeCloseFolderInput;
		this.listedocumentId = listedocumentId;
		this.numCarteBancaireCloseFolderInput = numCarteBancaireCloseFolderInput;
		this.idContestationSmcCloseFolderInput = idContestationSmcCloseFolderInput;
		this.archivingReferenceDate = archivingReferenceDate;
		this.clientNatureIdCloseFolderInput = clientNatureIdCloseFolderInput;
		this.clientNameCloseFolderInput = clientNameCloseFolderInput;
		this.clientFirstnameCloseFolderInput = clientFirstnameCloseFolderInput;
		this.sirenCloseFolderInput = sirenCloseFolderInput;
		this.birthDay = birthDay;
		this.clientId = clientId;
		this.contractIDValue = contractIDValue;
		this.contractIdTypeCodeValue = contractIdTypeCodeValue;
		this.contractIdTypeLabelValue = contractIdTypeLabelValue;
		this.documentTypeIdCloseFolderInput = documentTypeIdCloseFolderInput;
		this.mimeTypeCloseFolderInput = mimeTypeCloseFolderInput;
		this.titreCloseFolderInput = titreCloseFolderInput;
		this.fileNameCloseFolderInput = fileNameCloseFolderInput;
		this.archiveFormatCloseFolderInput = archiveFormatCloseFolderInput;
		this.compressCloseFolderInput = compressCloseFolderInput;
		this.encodingCloseFolderInput = encodingCloseFolderInput;
		this.dataCloseFolderInput = dataCloseFolderInput;
	}
	/**
	 * @return the archiveFormatCloseFolderInput
	 */
	public String getArchiveFormatCloseFolderInput() {
		return archiveFormatCloseFolderInput;
	}
	/**
	 * @return the archivingReferenceDate
	 */
	public String getArchivingReferenceDate() {
		return archivingReferenceDate;
	}
	/**
	 * @return the birthDay
	 */
	public LocalDate getBirthDay() {
		return birthDay;
	}
	/**
	 * @return the callingApplicationCloseFolderInput
	 */
	public String getCallingApplicationCloseFolderInput() {
		return callingApplicationCloseFolderInput;
	}
	/**
	 * @return the callingUserCloseFolderInput
	 */
	public String getCallingUserCloseFolderInput() {
		return callingUserCloseFolderInput;
	}
	/**
	 * @return the clientFirstnameCloseFolderInput
	 */
	public String getClientFirstnameCloseFolderInput() {
		return clientFirstnameCloseFolderInput;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @return the clientNameCloseFolderInput
	 */
	public String getClientNameCloseFolderInput() {
		return clientNameCloseFolderInput;
	}
	/**
	 * @return the clientNatureIdCloseFolderInput
	 */
	public String getClientNatureIdCloseFolderInput() {
		return clientNatureIdCloseFolderInput;
	}
	/**
	 * @return the compressCloseFolderInput
	 */
	public String getCompressCloseFolderInput() {
		return compressCloseFolderInput;
	}
	/**
	 * @return the contractIdTypeCodeValue
	 */
	public String getContractIdTypeCodeValue() {
		return contractIdTypeCodeValue;
	}
	/**
	 * @return the contractIdTypeLabelValue
	 */
	public String getContractIdTypeLabelValue() {
		return contractIdTypeLabelValue;
	}
	/**
	 * @return the contractIDValue
	 */
	public String getContractIDValue() {
		return contractIDValue;
	}
	/**
	 * @return the countryCodeCloseFolderInput
	 */
	public String getCountryCodeCloseFolderInput() {
		return countryCodeCloseFolderInput;
	}
	/**
	 * @return the dataCloseFolderInput
	 */
	public String getDataCloseFolderInput() {
		return dataCloseFolderInput;
	}
	/**
	 * @return the documentTypeIdCloseFolderInput
	 */
	public String getDocumentTypeIdCloseFolderInput() {
		return documentTypeIdCloseFolderInput;
	}
	/**
	 * @return the encodingCloseFolderInput
	 */
	public String getEncodingCloseFolderInput() {
		return encodingCloseFolderInput;
	}
	/**
	 * @return the fileNameCloseFolderInput
	 */
	public String getFileNameCloseFolderInput() {
		return fileNameCloseFolderInput;
	}
	/**
	 * @return the idContestationSmcCloseFolderInput
	 */
	public String getIdContestationSmcCloseFolderInput() {
		return idContestationSmcCloseFolderInput;
	}
	/**
	 * @return the listedocumentId
	 */
	public List<String> getListedocumentId() {
		return listedocumentId;
	}
	/**
	 * @return the localeCodeCloseFolderInput
	 */
	public String getLocaleCodeCloseFolderInput() {
		return localeCodeCloseFolderInput;
	}
	/**
	 * @return the mimeTypeCloseFolderInput
	 */
	public String getMimeTypeCloseFolderInput() {
		return mimeTypeCloseFolderInput;
	}
	/**
	 * @return the numCarteBancaireCloseFolderInput
	 */
	public String getNumCarteBancaireCloseFolderInput() {
		return numCarteBancaireCloseFolderInput;
	}
	/**
	 * @return the sirenCloseFolderInput
	 */
	public BigInteger getSirenCloseFolderInput() {
		return sirenCloseFolderInput;
	}
	/**
	 * @return the titreCloseFolderInput
	 */
	public String getTitreCloseFolderInput() {
		return titreCloseFolderInput;
	}
	/**
	 * @param archiveFormatCloseFolderInput the archiveFormatCloseFolderInput to set
	 */
	public void setArchiveFormatCloseFolderInput(
			String archiveFormatCloseFolderInput) {
		this.archiveFormatCloseFolderInput = archiveFormatCloseFolderInput;
	}
	/**
	 * @param archivingReferenceDate the archivingReferenceDate to set
	 */
	public void setArchivingReferenceDate(String archivingReferenceDate) {
		this.archivingReferenceDate = archivingReferenceDate;
	}
	/**
	 * @param birthDay the birthDay to set
	 */
	public void setBirthDay(LocalDate birthDay) {
		this.birthDay = birthDay;
	}
	/**
	 * @param callingApplicationCloseFolderInput the callingApplicationCloseFolderInput to set
	 */
	public void setCallingApplicationCloseFolderInput(
			String callingApplicationCloseFolderInput) {
		this.callingApplicationCloseFolderInput = callingApplicationCloseFolderInput;
	}
	/**
	 * @param callingUserCloseFolderInput the callingUserCloseFolderInput to set
	 */
	public void setCallingUserCloseFolderInput(String callingUserCloseFolderInput) {
		this.callingUserCloseFolderInput = callingUserCloseFolderInput;
	}
	/**
	 * @param clientFirstnameCloseFolderInput the clientFirstnameCloseFolderInput to set
	 */
	public void setClientFirstnameCloseFolderInput(
			String clientFirstnameCloseFolderInput) {
		this.clientFirstnameCloseFolderInput = clientFirstnameCloseFolderInput;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * @param clientNameCloseFolderInput the clientNameCloseFolderInput to set
	 */
	public void setClientNameCloseFolderInput(String clientNameCloseFolderInput) {
		this.clientNameCloseFolderInput = clientNameCloseFolderInput;
	}
	/**
	 * @param clientNatureIdCloseFolderInput the clientNatureIdCloseFolderInput to set
	 */
	public void setClientNatureIdCloseFolderInput(
			String clientNatureIdCloseFolderInput) {
		this.clientNatureIdCloseFolderInput = clientNatureIdCloseFolderInput;
	}
	/**
	 * @param compressCloseFolderInput the compressCloseFolderInput to set
	 */
	public void setCompressCloseFolderInput(String compressCloseFolderInput) {
		this.compressCloseFolderInput = compressCloseFolderInput;
	}
	/**
	 * @param contractIdTypeCodeValue the contractIdTypeCodeValue to set
	 */
	public void setContractIdTypeCodeValue(String contractIdTypeCodeValue) {
		this.contractIdTypeCodeValue = contractIdTypeCodeValue;
	}
	/**
	 * @param contractIdTypeLabelValue the contractIdTypeLabelValue to set
	 */
	public void setContractIdTypeLabelValue(String contractIdTypeLabelValue) {
		this.contractIdTypeLabelValue = contractIdTypeLabelValue;
	}
	/**
	 * @param contractIDValue the contractIDValue to set
	 */
	public void setContractIDValue(String contractIDValue) {
		this.contractIDValue = contractIDValue;
	}
	/**
	 * @param countryCodeCloseFolderInput the countryCodeCloseFolderInput to set
	 */
	public void setCountryCodeCloseFolderInput(String countryCodeCloseFolderInput) {
		this.countryCodeCloseFolderInput = countryCodeCloseFolderInput;
	}
	/**
	 * @param dataCloseFolderInput the dataCloseFolderInput to set
	 */
	public void setDataCloseFolderInput(String dataCloseFolderInput) {
		this.dataCloseFolderInput = dataCloseFolderInput;
	}
	/**
	 * @param documentTypeIdCloseFolderInput the documentTypeIdCloseFolderInput to set
	 */
	public void setDocumentTypeIdCloseFolderInput(
			String documentTypeIdCloseFolderInput) {
		this.documentTypeIdCloseFolderInput = documentTypeIdCloseFolderInput;
	}
	/**
	 * @param encodingCloseFolderInput the encodingCloseFolderInput to set
	 */
	public void setEncodingCloseFolderInput(String encodingCloseFolderInput) {
		this.encodingCloseFolderInput = encodingCloseFolderInput;
	}
	/**
	 * @param fileNameCloseFolderInput the fileNameCloseFolderInput to set
	 */
	public void setFileNameCloseFolderInput(String fileNameCloseFolderInput) {
		this.fileNameCloseFolderInput = fileNameCloseFolderInput;
	}
	/**
	 * @param idContestationSmcCloseFolderInput the idContestationSmcCloseFolderInput to set
	 */
	public void setIdContestationSmcCloseFolderInput(
			String idContestationSmcCloseFolderInput) {
		this.idContestationSmcCloseFolderInput = idContestationSmcCloseFolderInput;
	}
	/**
	 * @param listedocumentId the listedocumentId to set
	 */
	public void setListedocumentId(List<String> listedocumentId) {
		this.listedocumentId = listedocumentId;
	}
	/**
	 * @param localeCodeCloseFolderInput the localeCodeCloseFolderInput to set
	 */
	public void setLocaleCodeCloseFolderInput(String localeCodeCloseFolderInput) {
		this.localeCodeCloseFolderInput = localeCodeCloseFolderInput;
	}
	/**
	 * @param mimeTypeCloseFolderInput the mimeTypeCloseFolderInput to set
	 */
	public void setMimeTypeCloseFolderInput(String mimeTypeCloseFolderInput) {
		this.mimeTypeCloseFolderInput = mimeTypeCloseFolderInput;
	}
	/**
	 * @param numCarteBancaireCloseFolderInput the numCarteBancaireCloseFolderInput to set
	 */
	public void setNumCarteBancaireCloseFolderInput(
			String numCarteBancaireCloseFolderInput) {
		this.numCarteBancaireCloseFolderInput = numCarteBancaireCloseFolderInput;
	}
	/**
	 * @param sirenCloseFolderInput the sirenCloseFolderInput to set
	 */
	public void setSirenCloseFolderInput(BigInteger sirenCloseFolderInput) {
		this.sirenCloseFolderInput = sirenCloseFolderInput;
	}
	/**
	 * @param titreCloseFolderInput the titreCloseFolderInput to set
	 */
	public void setTitreCloseFolderInput(String titreCloseFolderInput) {
		this.titreCloseFolderInput = titreCloseFolderInput;
	}


}
