/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

/**
 * @author c65344
 *
 */
public enum StatusContestationSmc {
	SEND,TOSEND,REJECTED
}
