package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface SmcTraceJpaRepository extends JpaRepository<SmcTraceEntity, UUID> {
}
