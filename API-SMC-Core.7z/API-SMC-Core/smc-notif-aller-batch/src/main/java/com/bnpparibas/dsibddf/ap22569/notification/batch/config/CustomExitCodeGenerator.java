package com.bnpparibas.dsibddf.ap22569.notification.batch.config;

import org.springframework.batch.core.JobExecution;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.autoconfigure.batch.JobExecutionEvent;
import org.springframework.boot.autoconfigure.batch.JobExecutionExitCodeGenerator;
import org.springframework.context.ApplicationListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CustomExitCodeGenerator extends JobExecutionExitCodeGenerator implements ApplicationListener<JobExecutionEvent>, ExitCodeGenerator {

    private final List<JobExecution> executions = new ArrayList();


    public void onApplicationEvent(JobExecutionEvent event) {
        this.executions.add(event.getJobExecution());
    }

    public int getExitCode() {
        Iterator var1 = this.executions.iterator();

        JobExecution execution;
        do {
            if (!var1.hasNext()) {
                return 0;
            }

            execution = (JobExecution)var1.next();
        } while(execution.getStatus().ordinal() <= 0);

        return Integer.parseInt(execution.getExitStatus().getExitCode());
    }
}
