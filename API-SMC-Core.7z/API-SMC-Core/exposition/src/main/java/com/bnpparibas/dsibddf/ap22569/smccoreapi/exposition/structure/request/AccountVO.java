package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * AccountVO
 *
 */
public class AccountVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String accountId;

	private String maskedAccountNumber;
	/**
	 *
	 * @param accountId
	 * @param maskedAccountNumber
	 */
	public AccountVO(String accountId, String maskedAccountNumber) {
		this.accountId = accountId;
		this.maskedAccountNumber = maskedAccountNumber;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		AccountVO accountVO = (AccountVO) o;
		return Objects.equals(accountId, accountVO.accountId) &&
				Objects.equals(maskedAccountNumber, accountVO.maskedAccountNumber);
	}
	/**
	 *
	 * @return
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 *
	 * @return
	 */
	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountId, maskedAccountNumber);
	}
	/**
	 *
	 * @param accountId
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 *
	 * @param maskedAccountNumber
	 */
	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}
}
