package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;

public class PersonContactInfo {

    private HolderMail holderMail;

    private HolderPhoneNumber holderPhoneNumber;

    public HolderMail getHolderMail() {
        return holderMail;
    }

    public void setHolderMail(HolderMail holderMail) {
        this.holderMail = holderMail;
    }

    public HolderPhoneNumber getHolderPhoneNumber() {
        return holderPhoneNumber;
    }

    public void setHolderPhoneNumber(HolderPhoneNumber holderPhoneNumber) {
        this.holderPhoneNumber = holderPhoneNumber;
    }
}
