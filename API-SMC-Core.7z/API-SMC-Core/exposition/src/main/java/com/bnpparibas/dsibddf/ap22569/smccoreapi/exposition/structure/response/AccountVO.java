package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;

/**
 * AccountVO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-03-27T14:00:58.610Z")
public class AccountVO   {
	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("maskedAccountNumber")
	private String maskedAccountNumber;

	@JsonProperty("accountType")
	private String accountType;

	@JsonProperty("accountHolderName")
	private String accountHolderName;
	/**
	 *
	 * @param accountHolderName
	 * @return
	 */
	public AccountVO accountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
		return this;
	}
	/**
	 *
	 * @param accountId
	 * @return
	 */
	public AccountVO accountId(String accountId) {
		this.accountId = accountId;
		return this;
	}
	/**
	 *
	 * @param accountType
	 * @return
	 */
	public AccountVO accountType(String accountType) {
		this.accountType = accountType;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		AccountVO accountVO = (AccountVO) o;
		return Objects.equals(this.accountId, accountVO.accountId) &&
				Objects.equals(this.maskedAccountNumber, accountVO.maskedAccountNumber) &&
				Objects.equals(this.accountType, accountVO.accountType) &&
				Objects.equals(this.accountHolderName, accountVO.accountHolderName);
	}

	/**
	 * nom du titulaire du compte
	 *
	 * @return accountHolderName
	 **/
	@ApiModelProperty(value = "nom du titulaire du compte")


	public String getAccountHolderName() {
		return accountHolderName;
	}

	/**
	 * identifiant du compte dans le cadre de la transaction en cours
	 *
	 * @return accountId
	 **/
	@ApiModelProperty(value = "identifiant du compte dans le cadre de la transaction en cours")
	public String getAccountId() {
		return accountId;
	}

	/**
	 * type de compte
	 *
	 * @return accountType
	 **/
	@ApiModelProperty(value = "type de compte")
	public String getAccountType() {
		return accountType;
	}

	/**
	 * numéro de compte masqué
	 *
	 * @return maskedAccountNumber
	 **/
	@ApiModelProperty(value = "numéro de compte masqué")
	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountId, maskedAccountNumber, accountType, accountHolderName);
	}
	/**
	 *
	 * @param maskedAccountNumber
	 * @return
	 */
	public AccountVO maskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
		return this;
	}
	/**
	 *
	 * @param accountHolderName
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	/**
	 *
	 * @param accountId
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	/**
	 *
	 * @param accountType
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	/**
	 *
	 * @param maskedAccountNumber
	 */
	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class AccountVO {\n");

		sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
		sb.append("    maskedAccountNumber: ").append(toIndentedString(maskedAccountNumber)).append("\n");
		sb.append("    accountType: ").append(toIndentedString(accountType)).append("\n");
		sb.append("    accountHolderName: ").append(toIndentedString(accountHolderName)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

