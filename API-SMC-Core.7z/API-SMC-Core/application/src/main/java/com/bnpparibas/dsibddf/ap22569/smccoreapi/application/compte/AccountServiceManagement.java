package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.IAccountService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccount;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccountException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountServiceManagement implements IAccountServiceManagement {

	@Autowired
	private transient IAccountService accountService;


	@Override
	public List<AccountDTO> getUserAccounts(String telemeticId,String userId) throws UserAccountException {
		List<AccountDTO> accounts = null;
		List<UserAccount> userAccounts = accountService.getUserAccounts(telemeticId,userId);
		if(!CollectionUtils.isEmpty(userAccounts)) {
			accounts = userAccounts.stream().map(account -> {
				AccountDTO accountDTO = new AccountDTO();
				BeanUtils.copyProperties(account, accountDTO);
				return accountDTO;
			}).collect(Collectors.toList());
		}
		return accounts;
	}
}
