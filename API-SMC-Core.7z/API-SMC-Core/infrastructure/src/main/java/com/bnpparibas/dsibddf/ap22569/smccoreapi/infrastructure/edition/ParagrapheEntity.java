package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Set;

/**
 *
 * @author c65344
 *
 */
@Entity
@Table(name = "PARAGRAPHE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class ParagrapheEntity extends AbstractEntity<DefaultEntityId> {

	@Column(name="index_paragraphe")
	private Integer indexParagraphe;

	@OneToMany(fetch = FetchType.EAGER,cascade = {CascadeType.ALL}, targetEntity = PhraseEntity.class)
	@JoinColumn(name = "PARAGRAPHE_ID")
	private Set<PhraseEntity> phrases;


	/**
	 * @return the indexParagraphe
	 */
	public Integer getIndexParagraphe() {
		return indexParagraphe;
	}

	/**
	 * @return the phrases
	 */
	public Set<PhraseEntity> getPhrases() {
		return phrases;
	}

	/**
	 * @param indexParagraphe the indexParagraphe to set
	 */
	public void setIndexParagraphe(Integer indexParagraphe) {
		this.indexParagraphe = indexParagraphe;
	}

	/**
	 * @param phrases the phrases to set
	 */
	public void setPhrases(Set<PhraseEntity> phrases) {
		this.phrases = phrases;
	}

}
