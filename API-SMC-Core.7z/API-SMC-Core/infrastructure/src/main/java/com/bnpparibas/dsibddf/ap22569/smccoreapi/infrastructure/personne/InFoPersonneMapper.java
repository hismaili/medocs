package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.goal.AdresseMail;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.response.InfoPersonneGlobalResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author c65344
 *
 */

@Component
public class InFoPersonneMapper {

	private static final Logger LOG = LoggerFactory.getLogger(InFoPersonneMapper.class);

	private static boolean validMail(AdresseMail adresseMail) {
		return "O".equals(adresseMail.getIndiceValidite());//remplacement de 1 par 0 d'après la doc RP
	}
	@Autowired
	private transient PersonContactJpaRepository jpaPersonneContact;
	/**
	 *
	 */
	private InFoPersonneMapper(){

	}


	/**
	 * Transforme les Informations personne de RP en information personne smccore
	 * @param infoPersonne
	 * @return
	 */
	public InfoPersonneOutput mapInfoPersonneGlobalToInfoPersonneOutput(InfoPersonneGlobalResponse infoPersonne) {

		InfoPersonneOutput infoPersonneOutput = new InfoPersonneOutput();
		BeanUtils.copyProperties(infoPersonne, infoPersonneOutput);
		return infoPersonneOutput;
	}
	
}

