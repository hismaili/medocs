package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class SmcTrace {

	private String idContestation;
	@NotNull
	private String service;
	@NotNull
	private LocalDateTime dateAppel;
	private String applicationAppelante;
	private String paramIn;
	private String paramOut;
	private String sens;
	private int statusCode;
	private String traceId;

	public String getApplicationAppelante() {
		return applicationAppelante;
	}

	public LocalDateTime getDateAppel() {
		return dateAppel;
	}

	public String getIdContestation() {
		return idContestation;
	}

	public String getParamIn() {
		return paramIn;
	}

	public String getParamOut() {
		return paramOut;
	}

	public String getSens() {
		return sens;
	}

	public String getService() {
		return service;
	}

	public void setApplicationAppelante(String applicationAppelante) {
		this.applicationAppelante = applicationAppelante;
	}

	public void setDateAppel(LocalDateTime dateAppel) {
		this.dateAppel = dateAppel;
	}

	public void setIdContestation(String idContestation) {
		this.idContestation = idContestation;
	}

	public void setParamIn(String paramIn) {
		this.paramIn = paramIn;
	}

	public void setParamOut(String paramOut) {
		this.paramOut = paramOut;
	}

	public void setSens(String sens) {
		this.sens = sens;
	}

	public void setService(String service) {
		this.service = service;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
}
