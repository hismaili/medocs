package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StatutDossierContestationJpaRepository extends JpaRepository<StatutDossierContestationSelfCare, String> {

    StatutDossierContestationSelfCare findStatutDossierContestationByCodeStatut(String codeStatut);
}
