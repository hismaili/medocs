package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@EntityScan(basePackages = {
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons" })
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
@Ignore
public class ContestationRepositoryTest {

	private static byte[] toByteArray(UUID uuid) {
		byte[] byteArray = new byte[(Long.SIZE / Byte.SIZE) * 2];
		ByteBuffer buffer = ByteBuffer.wrap(byteArray);
		LongBuffer longBuffer = buffer.asLongBuffer();
		longBuffer.put(new long[] { uuid.getMostSignificantBits(),
				uuid.getLeastSignificantBits() });
		return byteArray;
	}

	@Autowired
	private IContestationRepository repository;

	@Autowired
	private transient ContestationJpaRepository repositoryHistorique;


	@Autowired
	private StatutDossierContestationJpaRepository  statutDossier;

	@Test
	public void isAuthorizedTest(){
		/**
		 * bon idGdn et idTelematic
		 */
		boolean authorized = repository.isAuthorized("GD11100jnlx2i0j000001m7", "3865814351");

		assertThat(authorized).isTrue();

		/**
		 * mauvais idGdn
		 */
		boolean authorizedFalse = repository.isAuthorized("GD11100jnlx", "3865814351");

		assertThat(authorizedFalse).isFalse();

		/**
		 * mauvais idTelematic
		 */
		boolean authorizedFalse2 = repository.isAuthorized("GD11100jnlx2i0j000001m7", "3");

		assertThat(authorizedFalse2).isFalse();



	}

	@Test
	public void testCreerContestation() {

		Contestation contestation = new Contestation();
		String numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);
		Operation operation = new Operation();
		operation.setCodeOperation("444");
		operation.setDateOperation(LocalDate.now());
		operation.setTypeOperation(TypeOperation.PAIEMENT);
		operation.setLibelleOperation("operation");
		operation.setMontantOperation(BigDecimal.valueOf(127.03));
		contestation.setOperations(Arrays.asList(operation));
		contestation.setNombreOperations(Integer.valueOf(1));
		contestation.setDescription("Contestation de vole de carte");
		contestation.setDocumentAttaches(Arrays.asList(new DocumentAttache(
				"GD11100jnlx2i0j000001mu", "perte de carte", "PDF", "20180110",
				numDossierSMC), new DocumentAttache("GD11100jnlx2i0j000001m5",
						"perte de carte", "PDF", "20180110", numDossierSMC)));
		contestation.setMontantConteste(new BigDecimal(1.1));
		contestation.setMontantReconnuPorteur(new BigDecimal(1.2));
		contestation.setPurged(false);
		contestation.setIdPorteur("1990");
		contestation.setIdTelematique("90");
		contestation.setTopNumeroTelModifie(new Boolean(true));
		contestation.setTopMailModifie(new Boolean(true));
		contestation.setNumeroTel("061244447");
		contestation.setMail("refda@gmail.com");

		contestation.setNumCarte("4979815236843969");
		StatutDossierContestation statutDossierContestation = new StatutDossierContestation();
		statutDossierContestation.setCodeStatut("SC002");
		contestation.setDernierStatutDossier(statutDossierContestation);
		MotifContestation motif = new MotifContestation();
		motif.setCode("M002");
		contestation.setMotif(motif);
		CartePorteur carte = new CartePorteur();
		carte.setDateFinValiditeInput(LocalDate.of(2022, 12, 31));
		carte.setIkpi("1990");
		carte.setNumCompte("30045");
		carte.setTypeProduit("PREMIUM");
		carte.setNumCarteInput("4979815236843969");
		contestation.setCarte(carte);

		Contestation contestation2 = repository.creerContestation(contestation);
		assertThat(contestation2).isNotNull();
		assertThat(contestation2.getIdContestation()).isNotNull();
		assertThat(contestation2.getMontantConteste()).isNotNull();
		assertThat(contestation2.getMontantReconnuPorteur()).isNotNull();
		assertThat(contestation2.isPurged()).isNotNull();
		assertThat(contestation2.getIdPorteur()).isNotNull();
		assertThat(contestation2.getIdTelematique()).isNotNull();
		assertThat(contestation2.getNumCarte()).isNotNull();
		assertThat(contestation2.getNumDossierSMC()).isNotNull();
		assertThat(contestation2.getOperations()).isNotNull();
		assertThat(contestation2.getOperations()).isNotEmpty();
		assertThat(contestation2.getDescription()).isNotNull();
		assertThat(contestation2.getDocumentAttaches()).isNotNull();
		assertThat(contestation2.getDocumentAttaches()).isNotEmpty();
		assertThat(contestation2.getDernierStatutDossier()).isNotNull();
		assertThat(contestation2.getNombreOperations()).isNotNull();
		assertThat(contestation2.getNombreOperations()).isEqualTo(Integer.valueOf(1));
	}

	@Test
	public void testRecupererContestation() throws ContestationException {
		Contestation contestation = new Contestation();
		String numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);
		Operation operation = new Operation();
		operation.setCodeOperation("444");
		operation.setDateOperation(LocalDate.now());
		operation.setTypeOperation(TypeOperation.PAIEMENT);
		operation.setLibelleOperation("operation");
		operation.setMontantOperation(BigDecimal.valueOf(127.03));
		contestation.setOperations(Arrays.asList(operation));
		contestation.setNombreOperations(Integer.valueOf(1));
		contestation.setDescription("Contestation de vole de carte");
		contestation.setDocumentAttaches(Arrays.asList(new DocumentAttache(
				"GD11100jnlx2i0j000001mu", "perte de carte", "PDF", "20180110",
				numDossierSMC), new DocumentAttache("GD11100jnlx2i0j000001m5",
						"perte de carte", "PDF", "20180110", numDossierSMC)));
		contestation.setMontantConteste(new BigDecimal(1.1));
		contestation.setMontantReconnuPorteur(new BigDecimal(1.2));
		contestation.setPurged(false);
		contestation.setIdPorteur("1990");
		contestation.setIdTelematique("90");
		contestation.setNumCarte("4979815236843969");
		contestation.setTopNumeroTelModifie(new Boolean(true));
		contestation.setTopMailModifie(new Boolean(true));
		contestation.setNumeroTel("061244447");
		contestation.setMail("refda@gmail.com");
		StatutDossierContestation statutDossierContestation = new StatutDossierContestation();
		statutDossierContestation.setCodeStatut("SC002");
		contestation.setDernierStatutDossier(statutDossierContestation);
		MotifContestation motif = new MotifContestation();
		motif.setCode("M002");
		contestation.setMotif(motif);
		CartePorteur carte = new CartePorteur();
		carte.setDateFinValiditeInput(LocalDate.of(2022, 12, 31));
		carte.setIkpi("1990");
		carte.setNumCompte("30045");
		carte.setTypeProduit("PREMIUM");
		carte.setNumCarteInput("4979815236843969");
		contestation.setCarte(carte);

		Contestation contestation2 = repository.creerContestation(contestation);
		/**
		 * recuperer contestation par numero de dossier
		 */
		Contestation savedContestation = repository
				.recupererContestation(numDossierSMC);
		assertThat(savedContestation).isNotNull();
		assertThat(savedContestation.getNumDossierSMC()).isEqualTo(
				numDossierSMC);
		assertThat(savedContestation.getOperations()).isNotNull();
		assertThat(savedContestation.getOperations()).isNotEmpty();
		assertThat(savedContestation.getOperations().get(0)).isNotNull();

		/**
		 * recuperer contestation par identifiant interne
		 *
		 */

		savedContestation = repository
				.recupererContestationByIdInterne(contestation2
						.getIdContestation());
		assertThat(savedContestation).isNotNull();
		assertThat(savedContestation.getNumDossierSMC()).isEqualTo(
				numDossierSMC);
		assertThat(savedContestation.getOperations()).isNotNull();
		assertThat(savedContestation.getOperations()).isNotEmpty();
		assertThat(savedContestation.getOperations().get(0)).isNotNull();
	}

	@Test
	public void testRecupererHistoriqueContestation() throws ContestationException{

		Contestation contestation = new Contestation();
		String numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);
		Operation operation = new Operation();
		operation.setCodeOperation("444");
		operation.setDateOperation(LocalDate.now());
		operation.setTypeOperation(TypeOperation.PAIEMENT);
		operation.setLibelleOperation("operation");
		operation.setMontantOperation(BigDecimal.valueOf(127.03));
		contestation.setOperations(Arrays.asList(operation));
		contestation.setNombreOperations(Integer.valueOf(1));
		contestation.setDescription("Contestation de vole de carte");
		contestation.setDocumentAttaches(Arrays.asList(new DocumentAttache(
				"GD11100jnlx2i0j000001mu", "perte de carte", "PDF", "20180110",
				numDossierSMC), new DocumentAttache("GD11100jnlx2i0j000001m5",
						"perte de carte", "PDF", "20180110", numDossierSMC)));
		contestation.setMontantConteste(new BigDecimal(1.1));
		contestation.setMontantReconnuPorteur(new BigDecimal(1.2));
		contestation.setPurged(false);
		contestation.setIdPorteur("1990");
		contestation.setIdTelematique("90");
		contestation.setNumCarte("4979815236843969");
		contestation.setTopNumeroTelModifie(new Boolean(true));
		contestation.setTopMailModifie(new Boolean(true));
		contestation.setNumeroTel("061244447");
		contestation.setMail("refda@gmail.com");
		StatutDossierContestation statutDossierContestation = new StatutDossierContestation();
		statutDossierContestation.setCodeStatut("SC002");
		contestation.setDernierStatutDossier(statutDossierContestation);
		MotifContestation motif = new MotifContestation();
		motif.setCode("M002");
		contestation.setMotif(motif);
		CartePorteur carte = new CartePorteur();
		carte.setDateFinValiditeInput(LocalDate.of(2022, 12, 31));
		carte.setIkpi("1990");
		carte.setNumCompte("30045");
		carte.setTypeProduit("PREMIUM");
		carte.setNumCarteInput("4979815236843969");
		contestation.setCarte(carte);

		repository.creerContestation(contestation);

		numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);

		repository.creerContestation(contestation);


		numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);

		repository.creerContestation(contestation);

		numDossierSMC = Base64.getEncoder().encodeToString(
				toByteArray(UUID.randomUUID()));
		contestation.setNumDossierSMC(numDossierSMC);
		contestation.setIdTelematique("28");
		repository.creerContestation(contestation);


		List<ContestationEntity> contestationEntities = repositoryHistorique.findByIdTelematiqueOrderByDateMajDesc("90");

		assertThat(contestationEntities).isNotNull();
		assertThat(contestationEntities).isNotEmpty();
		assertThat(contestationEntities.size()).isEqualTo(3);

		ContestationEntity contestation1 = contestationEntities.get(0);
		ContestationEntity contestation2 = contestationEntities.get(1);
		ContestationEntity contestation3 = contestationEntities.get(2);

		assertThat(contestation1.getDateMaj()).isAfter(contestation2.getDateMaj());
		assertThat(contestation2.getDateMaj()).isAfter(contestation3.getDateMaj());

		List<Contestation> contestations = repository.recupererContestationsClient("90",new Integer(1),new Integer(2)); //$NON-NLS-1$
		assertThat(contestations).isNotNull();
		assertThat(contestations).isNotEmpty();
		assertThat(contestations.size()).isEqualTo(2);

	}

	@Test
	public void testrecupererStatutDossier(){
		StatutDossierContestationSelfCare status = statutDossier.findStatutDossierContestationByCodeStatut("ID3");
		assertThat(status).isNotNull();
		assertThat(status.getLibelleStatut()).isNotEmpty();
	}
}