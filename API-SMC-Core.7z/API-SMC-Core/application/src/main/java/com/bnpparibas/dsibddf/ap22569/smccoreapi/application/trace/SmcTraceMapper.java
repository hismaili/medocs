package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import org.springframework.beans.BeanUtils;

/**
 *
 * SmcTraceMapper
 *
 */
public class SmcTraceMapper {
	/**
	 *
	 * @param traceDTO
	 * @return
	 */
	public static SmcTrace mapDTOToDomainDTO(TraceDTO traceDTO) {
		SmcTrace trace = null;
		if(traceDTO != null) {
			trace = new SmcTrace();
			BeanUtils.copyProperties(traceDTO, trace);
		}
		return trace;
	}
}
