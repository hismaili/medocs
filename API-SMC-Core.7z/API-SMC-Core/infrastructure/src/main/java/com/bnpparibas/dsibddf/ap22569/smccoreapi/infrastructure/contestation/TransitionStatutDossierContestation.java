package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "TRANSITION_STATUT")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class TransitionStatutDossierContestation extends AbstractEntity<DefaultEntityId> {


	@ManyToOne
	private ContestationEntity contestation;

	@ManyToOne
	private StatutSMCToStatutSelfCareEntity statutSMC;

	@Column
	private LocalDate dateChangemementStatut;

	public TransitionStatutDossierContestation() {
	}

	/**
	 * @param contestation
	 * @param statutSMC
	 * @param dateChangemementStatut
	 */
	public TransitionStatutDossierContestation(ContestationEntity contestation,
			StatutSMCToStatutSelfCareEntity statutSMC,
			LocalDate dateChangemementStatut) {
		this.contestation = contestation;
		this.statutSMC = statutSMC;
		this.dateChangemementStatut = dateChangemementStatut;
	}

    public ContestationEntity getContestation() {
		return contestation;
	}

    public LocalDate getDateChangemementStatut() {
		return dateChangemementStatut;
	}

    public StatutSMCToStatutSelfCareEntity getStatutSMC() {
		return statutSMC;
	}

    public void setContestation(ContestationEntity contestation) {
		this.contestation = contestation;
	}

    public void setStatutSMC(StatutSMCToStatutSelfCareEntity statutSMC) {
        this.statutSMC = statutSMC;
    }

	public void setDateChangemementStatut(LocalDate dateChangemementStatut) {
		this.dateChangemementStatut = dateChangemementStatut;
	}
}
