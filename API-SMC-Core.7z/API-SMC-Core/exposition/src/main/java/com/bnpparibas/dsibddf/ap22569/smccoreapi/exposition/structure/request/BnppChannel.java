package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

public enum BnppChannel {

    _04("04","BNP net"), _66("66", "Smartphones"), _72("72", "Tablette");

    private final String value;
    private final String code;

    BnppChannel(String code, String value) {
        this.code = code;
        this.value=value;
    }
}
