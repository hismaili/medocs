package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import java.util.List;

public class Qualification {

    private String qualificationLibelle;

    private List<Nature> natures;

    public String getQualificationLibelle() {
        return qualificationLibelle;
    }

    public void setQualificationLibelle(String qualificationLibelle) {
        this.qualificationLibelle = qualificationLibelle;
    }

    public List<Nature> getNatures() {
        return natures;
    }

    public void setNatures(List<Nature> natures) {
        this.natures = natures;
    }
}
