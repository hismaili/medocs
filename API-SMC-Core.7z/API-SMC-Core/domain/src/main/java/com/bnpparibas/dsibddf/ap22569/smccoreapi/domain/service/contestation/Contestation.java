package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
/**
 *
 *
 *
 */
public class Contestation {

	/** identifiant de la contestation dans la couche monétique */
	private String idContestation;
	/** Numéro de dossier SMC (Smart Contestation)*/
	private String numDossierSMC;
	/** 5 premiers chiffres du rib  */
	private String numCompte;
	/** Numéro de la carte bancaire : le PAN */
	private String numCarte;
	/** identifiant porteur : client de la banque */
	private String idPorteur;

	/** identifiant telematic : identifiant en rapport avec un compte bancaire*/
	private String idTelematique;
	/**
	 * date de creation dossier
	 */
	private LocalDateTime dateDeCreationDossier;
	/** montant remboursement */
	private BigDecimal montantRemboursement;

	/** montant reconnu porteur : montant reconnu par le porteur (dans le cas de contestation du nombre de billets distribués par un GAB) */
	private BigDecimal montantReconnuPorteur;

	/** statut dossier */
	private StatutDossierContestation dernierStatutDossier;
	/** Le client souhaite être notifié par SMS ou non */
	private Boolean notifSMS;
	/** Le client souhaite être notifié par Mail ou non */
	private Boolean notifMail;

	/** Le motif de rejet du dossier de contestation après son traitement */
	private String motifRejet;

	/** Nombre d'opérations contestées */
	private Integer nombreOperations;
	/** Le montant contesté */
	private BigDecimal montantConteste;
	/** La liste des operations contestées */
	private List<Operation> operations;
	/** List des identifiants documents */
	private List<DocumentAttache> documentAttaches;
	/** Etat de purge du dossier */
	private boolean isPurged;
	/** description des faits */
	private String description;
	/** motif de la contestation */
	private MotifContestation motif;
	private String numeroTel;
	private String phoneCountryCode;

	private String mail;

	private Boolean topNumeroTelModifie;

	private Boolean topMailModifie;


	private Boolean cardVoleePerdue;

	private CartePorteur carte;

	public Contestation() {
		isPurged = false;
	}

	public Boolean getCardVoleePerdue() {
		return cardVoleePerdue;
	}

	public CartePorteur getCarte() {
		return carte;
	}

	/**
	 * @return the dateDeCreationDossier
	 */
	public LocalDateTime getDateDeCreationDossier() {
		return dateDeCreationDossier;
	}

	public StatutDossierContestation getDernierStatutDossier() {
		return dernierStatutDossier;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	public List<DocumentAttache> getDocumentAttaches() {
		return documentAttaches;
	}



	public String getIdContestation() {
		return idContestation;
	}

	public String getIdPorteur() {
		return idPorteur;
	}

	/**
	 * @return the idTelematique
	 */
	public String getIdTelematique() {
		return idTelematique;
	}


	public String getMail() {
		return mail;
	}

	public BigDecimal getMontantConteste() {
		return montantConteste;
	}

	public BigDecimal getMontantReconnuPorteur() {
		return montantReconnuPorteur;
	}

	public BigDecimal getMontantRemboursement() {
		return montantRemboursement;
	}

	public MotifContestation getMotif() {
		return motif;
	}

	public String getMotifRejet() {
		return motifRejet;
	}

	public Integer getNombreOperations() {
		return nombreOperations;
	}

	public Boolean getNotifMail() {
		return notifMail;
	}

	public Boolean getNotifSMS() {
		return notifSMS;
	}

	public String getNumCarte() {
		return numCarte;
	}

	/**
	 * @return the numCompte
	 */
	public String getNumCompte() {
		return numCompte;
	}

	public String getNumDossierSMC() {
		return numDossierSMC;
	}

	public String getNumeroTel() {
		return numeroTel;
	}

	public List<Operation> getOperations() {
		return operations;
	}

	/**
	 * @return the phoneCountryCode
	 */
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}

	public Boolean getTopMailModifie() {
		return topMailModifie;
	}

	public Boolean getTopNumeroTelModifie() {
		return topNumeroTelModifie;
	}

	/**
	 * @return the isPurged
	 */
	public boolean isPurged() {
		return isPurged;
	}

	public void setCardVoleePerdue(Boolean cardVoleePerdue) {
		this.cardVoleePerdue = cardVoleePerdue;
	}

	public void setCarte(CartePorteur carte) {
		this.carte = carte;
	}

	/**
	 * @param dateDeCreationDossier the dateDeCreationDossier to set
	 */
	public void setDateDeCreationDossier(LocalDateTime dateDeCreationDossier) {
		this.dateDeCreationDossier = dateDeCreationDossier;
	}

	public void setDernierStatutDossier(StatutDossierContestation dernierStatutDossier) {
		this.dernierStatutDossier = dernierStatutDossier;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	public void setDocumentAttaches(List<DocumentAttache> documentAttaches) {
		this.documentAttaches = documentAttaches;
	}


	public void setIdContestation(String idContestation) {
		this.idContestation = idContestation;
	}

	public void setIdPorteur(String idPorteur) {
		this.idPorteur = idPorteur;
	}

	/**
	 * @param idTelematique the idTelematique to set
	 */
	public void setIdTelematique(String idTelematique) {
		this.idTelematique = idTelematique;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setMontantConteste(BigDecimal montantConteste) {
		this.montantConteste = montantConteste;
	}

	public void setMontantReconnuPorteur(BigDecimal montantReconnuPorteur) {
		this.montantReconnuPorteur = montantReconnuPorteur;
	}

	public void setMontantRemboursement(BigDecimal montantRemboursement) {
		this.montantRemboursement = montantRemboursement;
	}

	public void setMotif(MotifContestation motif) {
		this.motif = motif;
	}

	public void setMotifRejet(String motifRejet) {
		this.motifRejet = motifRejet;
	}

	public void setNombreOperations(Integer nombreOperations) {
		this.nombreOperations = nombreOperations;
	}

	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}

	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}

	public void setNumCarte(String numCarte) {
		this.numCarte = numCarte;
	}

	/**
	 * @param numCompte the numCompte to set
	 */
	public void setNumCompte(String numCompte) {
		this.numCompte = numCompte;
	}

	public void setNumDossierSMC(String numDossierSMC) {
		this.numDossierSMC = numDossierSMC;
	}

	public void setNumeroTel(String numeroTel) {
		this.numeroTel = numeroTel;
	}

	public void setOperations(List<Operation> operations) {
		this.operations = operations;
	}

	/**
	 * @param phoneCountryCode the phoneCountryCode to set
	 */
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}

	/**
	 * @param isPurged the isPurged to set
	 */
	public void setPurged(boolean isPurged) {
		this.isPurged = isPurged;
	}

	public void setTopMailModifie(Boolean topMailModifie) {
		this.topMailModifie = topMailModifie;
	}

	public void setTopNumeroTelModifie(Boolean topNumeroTelModifie) {
		this.topNumeroTelModifie = topNumeroTelModifie;
	}
}
