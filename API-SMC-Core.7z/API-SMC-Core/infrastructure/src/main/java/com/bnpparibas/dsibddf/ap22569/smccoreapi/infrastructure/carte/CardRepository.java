package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smctobcmp.BCMPApiException;
import com.bnpparibas.dsibddf.ap22569.smctobcmp.ICardServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * @recuperation des informations cartes dans Infrastructure de Smccore
 *
 */
@Repository
public class CardRepository implements ICardRepository {

	private static final Logger LOG = LoggerFactory.getLogger(CardRepository.class);
	//service de récupération des cartes dans le référentiel carte
	@Autowired(required=false)
	private transient ICardServices cardServices;

	@Autowired(required=false)
	private transient ConfigInfrastructure conf;

	@Autowired(required=false)
	private transient CardJpaRepository cardJpaRepository;


	@Override
	public List<AnonymizedCard> getAnonymizedCards(List<String> ribs)  throws CardException{
		if(CollectionUtils.isEmpty(ribs)) {
			throw new CardException("La liste des ribs ne peut être vide!!");
		}
		List<AnonymizedCard> result = null;
		List<AnonymizedCardEntity> anonymizedCards = this.cardJpaRepository.findByRibs(ribs, LocalDateTime.now().minusDays(1));
		if(!CollectionUtils.isEmpty(anonymizedCards)) {
			result = anonymizedCards.stream().map(CardMapper::mapAnonymizedCardEntity2AnonymizedCard).collect(Collectors.toList());
		}

		return result;
	}


	@Override
	public AnonymizedCard getCardByCardId(String cardId) throws CardException {
		AnonymizedCard anonymizedCard = null;
		if(StringUtils.isEmpty(cardId)){
			throw new CardException("L'id de la carte ne peut etre vide");
		}

		try{
			AnonymizedCardEntity anonymizedCardEntity = cardJpaRepository.findByCardId(cardId);

			if(anonymizedCardEntity !=null){
				anonymizedCard = new AnonymizedCard();
				anonymizedCard = CardMapper.mapAnonymizedCardEntity2AnonymizedCard(anonymizedCardEntity);
			}
		}catch(Exception e){
			LOG.error(e.getMessage());
			throw new CardException("Problème technique lors de la recupération de la carte ayant l'id :"+cardId);
		}


		return anonymizedCard;
	}

	@Override
	public List<CartePorteur> getCartesPorteur(String iKpi) throws CardException {
		Map<String,List<String>> errors = new HashMap<String,List<String>>();
		List<CartePorteur> listeCarteInput = null;

		if(iKpi !=null && !(iKpi.isEmpty())){
			try {

				List<com.bnpparibas.dsibddf.ap22569.smctobcmp.CartePorteur> listecarte =	cardServices.getCartesPorteur(iKpi);
				if(CollectionUtils.isEmpty(listecarte)) {
					throw new CardException(String.format("No card found for user %s", iKpi));
				}
				listeCarteInput = listecarte.stream()
						.map(carte -> new CartePorteur(carte.getNumCarte(),carte.getDateFinValidite(),carte.getStatutCarte().name(),carte.getDatOpposition()))
						.collect(Collectors.toList());

			} catch (BCMPApiException e) {
				LOG.info(e.getMessage(),e);
				throw new CardException(conf.getMessageErrorTechnique());
			}
			return listeCarteInput;
		}else{
			LOG.error(conf.getMessageIkpiAbsent());
			throw new CardException(conf.getMessageErrorTechnique());
		}

	}

	@Override
	public List<CartePorteur> getCartesPourComptes(List<String> ribs) throws CardException {

		List<CartePorteur> listeCarte = null;

		if(!CollectionUtils.isEmpty(ribs)) {
			List<com.bnpparibas.dsibddf.ap22569.smctobcmp.CartePorteur> listeCarteRef = new ArrayList<>();

			ribs.stream().forEach(rib -> {
				try {
					final List<com.bnpparibas.dsibddf.ap22569.smctobcmp.CartePorteur> cartesComptes = cardServices.getCartesComptes(Arrays.asList(rib));
					if(CollectionUtils.isEmpty(cartesComptes)) {
						LOG.warn("Aucune carte trouvée pour le compte "+rib);
					} else {
						listeCarteRef.addAll(cartesComptes);
					}
				} catch (BCMPApiException e) {
					LOG.error("Une erreur est survenue lors de la récupération des cartes du compte "+rib, e);
				}
			});

			if(!CollectionUtils.isEmpty(listeCarteRef)) {
				listeCarte = listeCarteRef.stream()
						.map(carte -> {
							CartePorteur cartePorteur = new CartePorteur(carte.getNumCarte(), carte.getDateFinValidite(), carte.getStatutCarte().name(), carte.getDatOpposition());
							cartePorteur.setNumCompte(carte.getNumCompte());
							cartePorteur.setTypeProduit(carte.getProductType());
							cartePorteur.setCodeMotifOpposition(carte.getCodeMotifOpposition());
							//TODO cartePorteur.setLibelleMotifOpposition(carte.get);
							cartePorteur.setDateColture(carte.getClosureDate());
							cartePorteur.setNomPorteur(carte.getNomPorteur());
							return cartePorteur;
						})
						.collect(Collectors.toList());
			}

		}
		return listeCarte;

	}

	@Override
	public InfoCarte getInfoCard(String pan) throws CardException {

		/**
		 *
		 * TODO lorsque cette methode ne reçoit pas le pan on renvoi cette erreur à l'utilistateur ?
		 */
		Map<String,List<String>> errors = new HashMap<String,List<String>>();
		if(pan !=null && (!pan.isEmpty())){

			InfoCarte infoCarteInput = new InfoCarte();

			try {
				com.bnpparibas.dsibddf.ap22569.smctobcmp.InfoCarte infoCarte	= cardServices.getInfosCarte(pan);

				infoCarteInput.setCodeAgenceRattachementInput(infoCarte.getCodeAgenceRattachement());
				infoCarteInput.setCodeTypContratInput(infoCarte.getCodeTypContrat());
				infoCarteInput.setIdContratMonetiquePorteurInput(infoCarte.getIdContratMonetiquePorteur());
				infoCarteInput.setIdUniqueClientInput(infoCarte.getIdUniqueClient());
				infoCarteInput.setRibCotisationInput(infoCarte.getRibCotisation());
				infoCarteInput.setRibOperationInput(infoCarte.getRibOperation());


			} catch (BCMPApiException e) {
				LOG.error(e.getMessage(), e);
				throw new CardException(conf.getMessageErrorTechnique(), e);
			}
			return infoCarteInput;

		}else{
			LOG.error(conf.getMessageNumeroPanAbsent());
			throw new CardException(conf.getMessageErrorTechnique());
		}
	}


	@Override
	public void saveAnonymizedCards(List<AnonymizedCard> anonymizedCards) {

		if(!CollectionUtils.isEmpty(anonymizedCards)) {
			List<AnonymizedCardEntity> result = anonymizedCards.stream().map(CardMapper::mapAnonymizedCard2Entity).collect(Collectors.toList());
			this.cardJpaRepository.saveAll(result);
		}
	}




}
