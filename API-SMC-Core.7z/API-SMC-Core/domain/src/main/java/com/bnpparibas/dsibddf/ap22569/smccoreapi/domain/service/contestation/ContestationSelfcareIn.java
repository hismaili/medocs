package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ContestationSelfcareIn {

	/** Le numero de la carte bancaire (PAN) */
	private String numeroCarte;

	/** L'identifiant iKpi du client */
	private String ikpiClient;

	/** L'identifiant télématique du client */
	private String idTelematiqueClient;

	/** La liste des opérations contestées */
	private List<Operation> operations;

	/** Le montant reconnu par le client dans le cas de billets partiellement délivrées (DAB)
	 * ou montant erroné (achat) */
	private BigDecimal montantReconnu;

	/** Le client souhaite être notifié par SMS ou non */
	private Boolean notifSMS;

	/** Le client souhaite être notifié par mail */
	private Boolean notifMail;

	/** Le client souhaite être notifié par mail */
	private Boolean notifPush;

	/** Motif de la contestation */
	private MotifContestation motif;

	/** description des faits */
	private String description;

	private String numeroTel;

	private String mail;

	private Boolean topNumeroTelModifie;

	private Boolean topMailModifie;

	private List<DocumentAttache> documentsAttaches;

	private Boolean cardVoleePerdue;

	private transient String cardId;

	public ContestationSelfcareIn() {
		this.notifMail = Boolean.FALSE;
		this.notifSMS = Boolean.FALSE;
		this.notifPush = Boolean.FALSE;
	}

	public ContestationSelfcareIn document(DocumentAttache document) {
		if (this.documentsAttaches == null) {
			this.documentsAttaches = new ArrayList<>();
		}
		this.documentsAttaches.add(document);
		return this;
	}

	/**
	 *
	 */
	@Override
	public boolean equals(Object o) {

		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ContestationSelfcareIn that = (ContestationSelfcareIn) o;
		return Objects.equals(numeroCarte, that.numeroCarte) &&
				Objects.equals(ikpiClient, that.ikpiClient) &&
				Objects.equals(idTelematiqueClient, that.idTelematiqueClient) &&
				Objects.equals(operations, that.operations) &&
				Objects.equals(montantReconnu, that.montantReconnu) &&
				Objects.equals(notifSMS, that.notifSMS) &&
				Objects.equals(notifMail, that.notifMail) &&
				Objects.equals(notifPush, that.notifPush) &&
				Objects.equals(motif, that.motif) &&
				Objects.equals(description, that.description);
	}
	/**
	 *
	 * @return
	 */
	public String getCardId() {
		return cardId;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getCardVoleePerdue() {
		return cardVoleePerdue;
	}

	public String getDescription() {
		return description;
	}
	/**
	 *
	 * @return
	 */
	public List<DocumentAttache> getDocumentsAttaches() {
		return documentsAttaches;
	}
	/**
	 *
	 * @return
	 */
	public String getIdTelematiqueClient() {
		return idTelematiqueClient;
	}
	/**
	 *
	 * @return
	 */
	public String getIkpiClient() {
		return ikpiClient;
	}
	/**
	 *
	 * @return
	 */
	public String getMail() {
		return mail;
	}
	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantReconnu() {
		return montantReconnu;
	}

	/**
	 *
	 * @return
	 */
	public MotifContestation getMotif() {
		return motif;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifMail() {
		return notifMail;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifPush() {
		return notifPush;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifSMS() {
		return notifSMS;
	}
	/**
	 *
	 * @return
	 */
	public String getNumeroCarte() {
		return numeroCarte;
	}
	/**
	 *
	 * @return
	 */
	public String getNumeroTel() {
		return numeroTel;
	}
	/**
	 *
	 * @return
	 */
	public List<Operation> getOperations() {
		return operations;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getTopMailModifie() {
		return topMailModifie;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getTopNumeroTelModifie() {
		return topNumeroTelModifie;
	}

	@Override
	public int hashCode() {
		return Objects.hash(numeroCarte, ikpiClient, idTelematiqueClient, operations, montantReconnu, notifSMS, notifMail, notifPush, motif, description);
	}
	/**
	 *
	 * @param operation
	 * @return
	 */
	public ContestationSelfcareIn operation(Operation operation) {
		if (this.operations == null) {
			this.operations = new ArrayList<>();
		}
		this.operations.add(operation);
		return this;
	}
	/**
	 *
	 * @param operations
	 * @return
	 */
	public ContestationSelfcareIn operations(List<Operation> operations) {
		this.operations = operations;
		return this;
	}
	/**
	 *
	 * @param cardId
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	/**
	 *
	 * @param cardVoleePerdue
	 */
	public void setCardVoleePerdue(Boolean cardVoleePerdue) {
		this.cardVoleePerdue = cardVoleePerdue;
	}
	/**
	 *
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 *
	 * @param documentsAttaches
	 */
	public void setDocumentsAttaches(List<DocumentAttache> documentsAttaches) {
		this.documentsAttaches = documentsAttaches;
	}
	/**
	 *
	 * @param idTelematiqueClient
	 */
	public void setIdTelematiqueClient(String idTelematiqueClient) {
		this.idTelematiqueClient = idTelematiqueClient;
	}
	/**
	 *
	 * @param ikpiClient
	 */
	public void setIkpiClient(String ikpiClient) {
		this.ikpiClient = ikpiClient;
	}
	/**
	 *
	 * @param mail
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 *
	 * @param montantReconnu
	 */
	public void setMontantReconnu(BigDecimal montantReconnu) {
		this.montantReconnu = montantReconnu;
	}
	/**
	 *
	 * @param motif
	 */
	public void setMotif(MotifContestation motif) {
		this.motif = motif;
	}
	/**
	 *
	 * @param notifMail
	 */
	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}
	/**
	 *
	 * @param notifPush
	 */
	public void setNotifPush(Boolean notifPush) {
		this.notifPush = notifPush;
	}
	/**
	 *
	 * @param notifSMS
	 */
	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}
	/**
	 *
	 * @param numeroCarte
	 */
	public void setNumeroCarte(String numeroCarte) {
		this.numeroCarte = numeroCarte;
	}
	/**
	 *
	 * @param numeroTel
	 */
	public void setNumeroTel(String numeroTel) {
		this.numeroTel = numeroTel;
	}
	/**
	 *
	 * @param operations
	 */
	public void setOperations(List<Operation> operations) {
		this.operations = operations;
	}
	/**
	 *
	 * @param topMailModifie
	 */
	public void setTopMailModifie(Boolean topMailModifie) {
		this.topMailModifie = topMailModifie;
	}
	/**
	 *
	 * @param topNumeroTelModifie
	 */
	public void setTopNumeroTelModifie(Boolean topNumeroTelModifie) {
		this.topNumeroTelModifie = topNumeroTelModifie;
	}
}
