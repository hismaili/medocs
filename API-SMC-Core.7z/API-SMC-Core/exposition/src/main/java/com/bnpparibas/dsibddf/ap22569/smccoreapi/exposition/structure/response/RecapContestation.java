package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import io.swagger.annotations.ApiModelProperty;

import java.time.LocalDateTime;
import java.util.Objects;
/**
 *
 *
 *
 */
public class RecapContestation {

	@ApiModelProperty(value = "Réfèrence du dossier de contestation dans le système", required = true)
	private String referenceContestation;

	@ApiModelProperty(value = "date de création du dossier dans le système.", required = true)
	private LocalDateTime dateCreationDossier;

	@ApiModelProperty(value = "Motif de la contestation", required = true)
	private String motifContestation;

	@ApiModelProperty(value = "Nombre d'opérations contestées", required = true)
	private Integer nombreOperations;

	@ApiModelProperty(value = "le montant total des opérations contestées", required = true)
	private Amount montantConteste;

	@ApiModelProperty(value = "le montant reconnu par le porteur pour les contestations pour motif : montant erroné")
	private Amount montantReconnu;

	@ApiModelProperty(value = "la lettre récapitulative de la contestation", required = true)
	private byte[] documentRecapitulatif;

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		RecapContestation that = (RecapContestation) o;
		return Objects.equals(referenceContestation, that.referenceContestation) &&
				Objects.equals(dateCreationDossier, that.dateCreationDossier) &&
				Objects.equals(motifContestation, that.motifContestation) &&
				Objects.equals(nombreOperations, that.nombreOperations) &&
				Objects.equals(montantConteste, that.montantConteste) &&
				Objects.equals(montantReconnu, that.montantReconnu);
	}

	public LocalDateTime getDateCreationDossier() {
		return dateCreationDossier;
	}

	public byte[] getDocumentRecapitulatif() {
		byte[] documentRecap = null;
		if(documentRecapitulatif !=null){
			documentRecap = documentRecapitulatif.clone();
		}
		return documentRecap;
	}

	public Amount getMontantConteste() {
		return montantConteste;
	}

	public Amount getMontantReconnu() {
		return montantReconnu;
	}

	public String getMotifContestation() {
		return motifContestation;
	}

	public Integer getNombreOperations() {
		return nombreOperations;
	}

	public String getReferenceContestation() {
		return referenceContestation;
	}

	@Override
	public int hashCode() {
		int result = Objects.hash(referenceContestation, dateCreationDossier, motifContestation, nombreOperations, montantConteste, montantReconnu);
		result = 31 * result;
		return result;
	}

	public void setDateCreationDossier(LocalDateTime dateCreationDossier) {
		this.dateCreationDossier = dateCreationDossier;
	}

	public void setDocumentRecapitulatif(byte[] documentRecapitulatif) {

		byte[] documentRecapitulatiF = null;

		if(documentRecapitulatif !=null){
			documentRecapitulatiF = documentRecapitulatif.clone();
		}

		this.documentRecapitulatif = documentRecapitulatiF;
	}

	public void setMontantConteste(Amount montantConteste) {
		this.montantConteste = montantConteste;
	}

	public void setMontantReconnu(Amount montantReconnu) {
		this.montantReconnu = montantReconnu;
	}

	public void setMotifContestation(String motifContestation) {
		this.motifContestation = motifContestation;
	}

	public void setNombreOperations(Integer nombreOperations) {
		this.nombreOperations = nombreOperations;
	}

	public void setReferenceContestation(String referenceContestation) {
		this.referenceContestation = referenceContestation;
	}

	@Override
	public String toString() {
		return "RecapContestation{" +
				"referenceContestation='" + referenceContestation + '\'' +
				", dateCreationDossier=" + dateCreationDossier +
				", motifContestation='" + motifContestation + '\'' +
				", nombreOperations=" + nombreOperations +
				", montantConteste=" + montantConteste +
				", montantReconnu=" + montantReconnu +
				'}';
	}
}
