package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;



/**
 * Operation
 */
public class OperationInput   {

	private String coidop;


	private String bankNumber;


	private AmountInput acknowledgedAmount;

	/**
	 * @return the acknowledgedAmount
	 */
	public AmountInput getAcknowledgedAmount() {
		return acknowledgedAmount;
	}

	/**
	 * @return the bankNumber
	 */
	public String getBankNumber() {
		return bankNumber;
	}

	/**
	 * @return the coidop
	 */
	public String getCoidop() {
		return coidop;
	}

	/**
	 * @param acknowledgedAmount the acknowledgedAmount to set
	 */
	public void setAcknowledgedAmount(AmountInput acknowledgedAmount) {
		this.acknowledgedAmount = acknowledgedAmount;
	}

	/**
	 * @param bankNumber the bankNumber to set
	 */
	public void setBankNumber(String bankNumber) {
		this.bankNumber = bankNumber;
	}

	/**
	 * @param coidop the coidop to set
	 */
	public void setCoidop(String coidop) {
		this.coidop = coidop;
	}


}

