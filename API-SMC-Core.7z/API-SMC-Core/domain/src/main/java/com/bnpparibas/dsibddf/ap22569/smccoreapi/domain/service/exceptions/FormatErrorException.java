/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.List;

/**
 * @author c65344
 *
 */
public class FormatErrorException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private List<String> errors;

	/**
	 *
	 */
	public FormatErrorException() {
		super();

	}

	/**
	 * @param errors
	 */
	public FormatErrorException(List<String> errors) {
		this.errors = errors;
	}

	/**
	 * @param message
	 */
	public FormatErrorException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public FormatErrorException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public FormatErrorException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public FormatErrorException(Throwable cause) {
		super(cause);

	}

	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}


}
