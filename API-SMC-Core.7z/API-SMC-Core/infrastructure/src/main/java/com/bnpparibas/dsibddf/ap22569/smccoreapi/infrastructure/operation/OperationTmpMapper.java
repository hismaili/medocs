/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationSign;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.OperationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.SensOperation;
import com.bnpparibas.dsibddf.ap22569.smctohmp.response.OperationResult;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * @author c65344
 *
 */
@Service
public class OperationTmpMapper {

	/**
	 * map OperationEntity to operation
	 *
	 * @param operationEntity
	 * @return
	 */
	public Operation mapOperationEntityToOperation(OperationEntity operationEntity){//TODO doit etre utiliser lors de la cration de la contestation
		Operation operation = null;

		if(operationEntity !=null){
			operation = new Operation();

			BeanUtils.copyProperties(operationEntity, operation);

			SensOperation sensOperation = operationEntity.getSensOperation();

			switch (sensOperation) {
			case DEBIT:
				operation.setSigneOperation(OperationSign.MOINS);
				break;
			case CREDIT:
				operation.setSigneOperation(OperationSign.PLUS);
				break;
			default:
				break;
			}

			TypeOperation typeOperation = operationEntity.getTypeOperation();

			switch (typeOperation) {
			case PAIEMENT:
				operation.setTypeOperation(TypeOperation.PAIEMENT);
				break;
			case RETRAIT:
				operation.setTypeOperation(TypeOperation.RETRAIT);
				break;
			default:
				break;
			}

		}
		return operation;
	}

	/**
	 *
	 * @param operationHmp
	 * @return
	 */
	protected Operation mapOperationHmpToOperation(OperationResult operationHmp){//USED
		Operation operation = null;
		if(operationHmp !=null){

			operation = new Operation();
			BeanUtils.copyProperties(operationHmp, operation);

			String signeOperation = operationHmp.getSigneOperation();

			if("+".equals(signeOperation)){
				operation.setSigneOperation(OperationSign.PLUS);
			}else if("-".equals(signeOperation)){
				operation.setSigneOperation(OperationSign.MOINS);
			}

			String typeOperation = operationHmp.getTypeOperation();
			if(!StringUtils.isEmpty(typeOperation)){
				switch (typeOperation) {
				case "TRINFA":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "TRINRD":
					operation.setTypeOperation(TypeOperation.RETRAIT);
					break;
				case "TRINRG":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "TRINFC":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRFA":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRRD":
					operation.setTypeOperation(TypeOperation.RETRAIT);
					break;
				case "ANTRRG":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRFC":
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				default:
					break;
				}
			}


		}

		return operation;
	}

	/**
	 *
	 * @param operationHmp
	 * @return
	 */
	protected OperationTmpEntity mapOperationHmpToOperationTmp(OperationResult operationHmp,String idTelematic,String ikpi){//USED

		OperationTmpEntity operationTmpEntity = null;

		if(operationHmp !=null){

			operationTmpEntity = new OperationTmpEntity();
			BeanUtils.copyProperties(operationHmp, operationTmpEntity);
			operationTmpEntity.setIdTelematic(idTelematic);
			operationTmpEntity.setUserId(ikpi);
			String signeOperation = operationHmp.getSigneOperation();

			if("+".equals(signeOperation)){
				operationTmpEntity.setSensOperation(SensOperation.CREDIT);
			}else if("-".equals(signeOperation)){
				operationTmpEntity.setSensOperation(SensOperation.DEBIT);
			}

			operationTmpEntity.setDeviseOperation(operationHmp.getDeviseOperation());

			String typeOperation = operationHmp.getTypeOperation();


			if(!StringUtils.isEmpty(typeOperation)){
				switch (typeOperation) {
				case "TRINFA":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "TRINRD":
					operationTmpEntity.setTypeOperation(TypeOperation.RETRAIT);
					break;
				case "TRINRG":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "TRINFC":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRFA":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRRD":
					operationTmpEntity.setTypeOperation(TypeOperation.RETRAIT);
					break;
				case "ANTRRG":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case "ANTRFC":
					operationTmpEntity.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				default:
					break;
				}

			}

		}

		return operationTmpEntity;
	}


	/**
	 *
	 * @param operationTmp
	 * @return
	 */
	protected Operation mapOperationTmpToOperation(OperationTmpEntity operationTmp){

		Operation operation = null;


		if(operationTmp !=null){
			operation = new Operation();

			BeanUtils.copyProperties(operationTmp, operation);

			SensOperation sensOperation = operationTmp.getSensOperation();
			if(sensOperation !=null){
				switch (sensOperation) {
				case DEBIT:
					operation.setSigneOperation(OperationSign.MOINS);
					break;
				case CREDIT:
					operation.setSigneOperation(OperationSign.PLUS);
					break;
				default:
					break;
				}
			}

			TypeOperation typeOperation = operationTmp.getTypeOperation();
			if(typeOperation !=null){
				switch (typeOperation) {
				case PAIEMENT:
					operation.setTypeOperation(TypeOperation.PAIEMENT);
					break;
				case RETRAIT:
					operation.setTypeOperation(TypeOperation.RETRAIT);
					break;
				default:
					break;
				}

			}

			operation.setDeviseOperation(operationTmp.getDeviseOperation());

		}

		return operation;
	}
}
