package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions;

public class WrongRecordNumberException extends Exception {

    public WrongRecordNumberException() {
    }

    public WrongRecordNumberException(String message) {
        super(message);
    }

    public WrongRecordNumberException(String message, Throwable cause) {
        super(message, cause);
    }

    public WrongRecordNumberException(Throwable cause) {
        super(cause);
    }
}
