package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.IAccountRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccount;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccountException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.fail;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootApp.class)
//@EntityScan(basePackages = {
//		"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
//"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons" })
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles({"test"})
public class AccountRepositoryTest {

	private static final Logger LOG = LoggerFactory.getLogger(AccountRepositoryTest.class);
	@Autowired
	private IAccountRepository accountRepository;

	@Test
	public void getUserAccounts() {
		try {
			List<UserAccount> userAccounts = this.accountRepository.getUserAccounts("3742002574","");
			LOG.info(""+userAccounts);
			Assertions.assertThat(userAccounts).isNotEmpty();
			Assertions.assertThat(userAccounts.size()).isEqualTo(1);
		} catch (UserAccountException e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}
}