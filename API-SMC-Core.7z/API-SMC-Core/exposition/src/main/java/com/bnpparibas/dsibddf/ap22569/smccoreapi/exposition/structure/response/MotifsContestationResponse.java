package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.MotifVO;

import java.util.List;

public class MotifsContestationResponse {

	/**
	 *
	 */
	private static final long serialVersionUID = -6142066644150499384L;
	private List<MotifVO> motifs;
	/**
	 *
	 * @return
	 */
	public List<MotifVO> getMotifs() {
		return motifs;
	}
	/**
	 *
	 * @param motifs
	 */
	public void setMotifs(List<MotifVO> motifs) {
		this.motifs = motifs;
	}
}
