package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.porteur;

public interface IPorteurService {


    /**
     * Récupérer les informations porteur depuis RP en utilisant son identifiant iKpi
     *
     * @param iKpi
     * @return
     */
    Porteur recupererInformationsPorteur(String iKpi);
}
