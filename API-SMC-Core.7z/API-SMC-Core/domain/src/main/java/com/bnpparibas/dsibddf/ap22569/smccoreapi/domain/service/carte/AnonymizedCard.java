package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

public class AnonymizedCard {

    private String cardId;

    private String maskedPan;

    private CartePorteur carte;

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getMaskedPan() {
        return maskedPan;
    }

    public void setMaskedPan(String maskedPan) {
        this.maskedPan = maskedPan;
    }

    public CartePorteur getCarte() {
        return carte;
    }

    public void setCarte(CartePorteur carte) {
        this.carte = carte;
    }
}
