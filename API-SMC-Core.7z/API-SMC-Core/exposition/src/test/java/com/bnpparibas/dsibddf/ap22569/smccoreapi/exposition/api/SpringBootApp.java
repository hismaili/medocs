package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage.IArchivageManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace.ITraceManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.ArchivingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.DeleteDocInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.NewFolderInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcTechnicalException;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Profile;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author 472957
 *
 */
@SpringBootConfiguration
@EnableAspectJAutoProxy
@ComponentScan(basePackages = { "com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition"}, lazyInit = true)
@Profile("test")
public class SpringBootApp {

	/**
	 * @param args
	 */
	/*public static void main(final String[] args) {

		SpringApplication.run(SpringBootApp.class, args);
	}*/

	@Bean
	public IArchivageManagement archivageManagementMock() throws ArchivingException, SmcTechnicalException, MandatoryException {
		Map map = new HashMap<String, String>();
		map.put("error1", "mauvais identifiant");

		IArchivageManagement archivageManagementMock = Mockito.mock(IArchivageManagement.class);
		Mockito.when(archivageManagementMock.newFolder(Mockito.any(NewFolderInput.class))).thenReturn(UUID.randomUUID().toString());
		Mockito.when(archivageManagementMock.newFolder(Mockito.argThat(new ArgumentMatcher<NewFolderInput>() {
			@Override
			public boolean matches(NewFolderInput newFolderInput) {
				return "456215".equals(newFolderInput.getCallingUser());
			}
		}))).thenThrow(new ArchivingException("Test jeton Erreur d'archivage"));


		Mockito.when(archivageManagementMock.deleteDoc(Mockito.argThat(new ArgumentMatcher<DeleteDocInput>() {
			@Override
			public boolean matches(DeleteDocInput deleteDocInput) {

				return  "GD11100jnl".equals(deleteDocInput.getDocumentIdDeleteInput());
			}
		}))).thenThrow(new ArchivingException("Test jeton Erreur d'archivage", null));

		return archivageManagementMock;
	}

	@Bean
	public ITraceManagement traceManagementMock() {
		ITraceManagement traceManagementMock = Mockito.mock(ITraceManagement.class);
		//		try {
		//			Mockito.when(traceManagementMock.trace(Mockito.any(TraceDTO.class)));
		//		} catch (SmcTraceException e) {
		//			e.printStackTrace();
		//		}
		return traceManagementMock;
	}
}
