package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.UUID;

public class ExceptionHelper {

    public static String getMessageWithToken(String message) {
        return new StringBuilder().append(UUID.randomUUID().toString()).append(" ").append(message).toString();
    }
}
