/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @author c65344
 *
 */
public class DeleteDocDTO implements Serializable {

	private static final long serialVersionUID = 5258362106227742886L;


	@ApiModelProperty(value = "Identifiant du document à supprimer",required = true)
	private String documentId;


	/**
	 *
	 */
	public DeleteDocDTO() {
		super();

	}


	/**
	 * @param documentId
	 */
	public DeleteDocDTO(String documentId) {
		this.documentId = documentId;
	}


	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}


	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}




}
