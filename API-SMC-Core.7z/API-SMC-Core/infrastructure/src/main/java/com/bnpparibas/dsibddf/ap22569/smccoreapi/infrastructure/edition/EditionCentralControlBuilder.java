/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.Destinataire;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.Emeteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class EditionCentralControlBuilder {

	class DataTocheck{

		private String data;
		private int length;
		private String libelle;
		/**
		 *
		 */
		public DataTocheck() {
			super();
			// TODO Auto-generated constructor stub
		}
		/**
		 * @param data
		 * @param length
		 * @param libelle
		 */
		public DataTocheck(String data, int length, String libelle) {
			this.data = data;
			this.length = length;
			this.libelle = libelle;
		}
		/**
		 * @return the data
		 */
		public String getData() {
			return data;
		}
		/**
		 * @return the length
		 */
		public int getLength() {
			return length;
		}
		/**
		 * @return the libelle
		 */
		public String getLibelle() {
			return libelle;
		}
		/**
		 * @param data the data to set
		 */
		public void setData(String data) {
			this.data = data;
		}
		/**
		 * @param length the length to set
		 */
		public void setLength(int length) {
			this.length = length;
		}
		/**
		 * @param libelle the libelle to set
		 */
		public void setLibelle(String libelle) {
			this.libelle = libelle;
		}



	}
	private static final  String  PERSONNEPHYSIQUE = "01"; //$NON-NLS-1$

	private static final  String  PERSONNEMORALE = "02"; //$NON-NLS-1$

	@Autowired
	private transient ConfigInfrastructure conf;

	/**
	 * check if data is null or empty
	 *
	 * @param data
	 * @param libelle
	 * @param listToadd
	 */
	protected String addError(String data, String libelle){

		if(StringUtils.isEmpty(data)){
			return libelle;
		}else{
			return null;
		}

	}


	/**
	 * verifie la taille des données provenant de BCMP RP ou REFO dans l'editique centrale
	 * @param request
	 * @return
	 */
	List<String> checkDataCorrectEditionCentral(RequestEditiqueInput request){

		List<String> errors = new ArrayList<>();

		if(request !=null){
			String codeUOAgence = null;
			String codeUoSur =null;
			final Emeteur emeteur = request.getEmeteur();
			String adresse1=null;
			String adresse2=null;
			String adresse3=null;
			String adresse4=null;
			String adresse5=null;

			if(emeteur !=null){
				codeUOAgence = emeteur.getCodeUoAgence();
				codeUoSur = emeteur.getCodeUoSur();

				adresse1 = emeteur.getAdresse1();
				adresse2 = emeteur.getAdresse2();
				adresse3 = emeteur.getAdresse3();
				adresse4 = emeteur.getAdresse4();
				adresse5 = emeteur.getAdresse5();
			}

			final Destinataire destinataire = request.getDestinataire();
			String civilite = null;
			if(destinataire !=null){
				civilite = destinataire.getCivilite();
			}



			List<DataTocheck> dataTochecks = Arrays.asList(

					new DataTocheck(request.getIkpi(), 17, conf.getIkpiIncorrect()),
					new DataTocheck(codeUOAgence,5, conf.getCodeUoAgenceIncorrect()),
					new DataTocheck(codeUoSur,5, conf.getCodeUoSurIncorrect()),
					new DataTocheck(request.getTopClientele(),1, conf.getTopClientIncorrect()),
					new DataTocheck(request.getIdContratMonetiquePorteur(),17, conf.getIdContratMonetiquePorteurIncorrect()),

					new DataTocheck(request.getRibOperation(),23, conf.getRibOperationIncorrect()),
					new DataTocheck(request.getRibCotisation(),23, conf.getRibCotisationIncorrect()),

					new DataTocheck(request.getPrenomPorteur(),32, conf.getClientFirstnameIncorrect()),
					new DataTocheck(request.getNomPorteur(),32, conf.getClientNameIncorrect()),

					new DataTocheck(request.getClientNatureId(),2, conf.getClientNatureId()),

					new DataTocheck(request.getCodePays(),2, conf.getCodePaysIncorrect()),
					new DataTocheck(request.getCodePostal(),5, conf.getCodePostalIncorrect()),
					new DataTocheck(adresse1,38, conf.getAdresseEmeteurIncorrect()),
					new DataTocheck(adresse2,38, conf.getAdresseEmeteurIncorrect()),
					new DataTocheck(adresse3,38, conf.getAdresseEmeteurIncorrect()),
					new DataTocheck(adresse4,38, conf.getAdresseEmeteurIncorrect()),
					new DataTocheck(adresse5,38, conf.getAdresseEmeteurIncorrect()),
					new DataTocheck(civilite,1, conf.getAdresseEmeteurIncorrect()));

			errors = dataTochecks.stream().
					filter(obj -> !StringUtils.isEmpty(obj.getData()) &&  !(obj.getData().length() <= obj.getLength())).
					map(obj -> obj.getLibelle())
					.collect(Collectors.toList());

			final LocalDate birthDay = request.getBirthDay();
			final BigInteger sirenNumber = request.getSirenNumber();

			if(birthDay !=null){

				final String birth = birthDay.toString();
				if(birth !=null && !(birth.length()<=10)){
					errors.add(conf.getBirthDayIncorrect());
				}
			}
			if(sirenNumber !=null){
				final String siren = sirenNumber.toString();
				if(siren !=null && !(siren.length() <= 9)){
					errors.add(conf.getSirenIncorrect());
				}
			}




		}



		return errors;
	}

	/**
	 * verifie la présence des données provenant de BCMP RP ou REFO dans l'editique centrale
	 *
	 * @return
	 */
	List<String> checkMandatoryEditiquecentrale(RequestEditiqueInput request){
		String codeUOAgence = null;
		String codeUoSur =null;
		final Emeteur emeteur = request.getEmeteur();

		if(emeteur !=null){
			codeUOAgence = emeteur.getCodeUoAgence();
			codeUoSur = emeteur.getCodeUoSur();
		}

		final Destinataire destinataire = request.getDestinataire();
		String civilite = null;
		if(destinataire !=null){
			civilite = destinataire.getCivilite();
		}

		List<String> missingDatas = new ArrayList<String>();

		final String clientNatureId = request.getClientNatureId();
		Arrays.asList(addError(request.getIkpi(),conf.getIkpiAbsent()),
				addError(codeUOAgence,conf.getMessageCodeUOAbsent()),
				addError(codeUoSur,conf.getMessageCodeUOAbsent()),
				addError(request.getTopClientele(),conf.getTopClientAbsent()),
				addError(request.getIdContratMonetiquePorteur(),conf.getIdContratMonetiquePorteurAbsent()),
				addError(request.getRibOperation(),conf.getRibOperationAbsent()),
				addError(request.getRibCotisation(),conf.getRibCotisationAbsent()),
				addError(request.getPrenomPorteur(),conf.getClientFirstnameAbsent()),
				addError(request.getNomPorteur(), conf.getClientNameAbsent()),
				addError(clientNatureId,conf.getClientNatureId()),
				addError(civilite,conf.getCiviliteAbsent()),
				addError(request.getCodePays(),conf.getCodePaysAbsent()),
				addError(request.getCodePostal(),conf.getCodePostalAbsent()))
				.stream().filter(value -> !StringUtils.isEmpty(value))
				.forEach(error -> missingDatas.add(error));

		final LocalDate birthDay = request.getBirthDay();
		final BigInteger sirenNumber = request.getSirenNumber();


		if(PERSONNEPHYSIQUE.equals(clientNatureId)){
			if(birthDay == null){
				missingDatas.add(conf.getBirthDayAbsent());
			}
		}

		if(PERSONNEMORALE.equals(clientNatureId)){
			if(sirenNumber !=null){
				missingDatas.add(conf.getSirenIncorrect());
			}

		}
		return missingDatas;
	}

}
