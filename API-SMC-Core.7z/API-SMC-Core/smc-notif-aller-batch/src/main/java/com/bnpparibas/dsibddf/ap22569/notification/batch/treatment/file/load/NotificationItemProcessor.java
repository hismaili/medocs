/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.ErrorCode;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.ErrorLevel;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.NotificationDetailValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;

/**
 * @author c65344
 *
 */
@Component
public class NotificationItemProcessor implements ItemProcessor<NotificationLine, Notification> {
	private static final Logger LOG = LoggerFactory.getLogger(NotificationItemProcessor.class);

	private JobExecution jobExecution;

	@Override
	public Notification process(NotificationLine notificationLine) {
		System.out.println(notificationLine.getOriginalLine());
		try {
			validateNotification(notificationLine);
			Notification notification = null;
			NotificationInfoFile fileInfo = new NotificationInfoFile();

			if (notificationLine != null && "05".equals(notificationLine.getCodeEnregistrement())) {
				notification = new Notification();
				BeanUtils.copyProperties(notificationLine, notification, "fileInfo");


				if (notificationLine.getFileInfo() != null) {
					BeanUtils.copyProperties(notificationLine.getFileInfo(), fileInfo);
					notification.setInfoFile(fileInfo);
				}

			}

			return notification;
		} catch (NotificationDetailValidationException e) {
			LOG.error(e.getMessage());
			jobExecution.getFailureExceptions().add(e);
			return null;
		}

	}

	private void validateNotification(NotificationLine notificationLine) throws NotificationDetailValidationException {

		if(!Arrays.asList("01", "05", "99").contains(notificationLine.getCodeEnregistrement())) {
			throw new NotificationDetailValidationException(ErrorCode.UNEXPECTED_RECORD_CODE, ErrorLevel.ERROR, "Code Enregistrement", notificationLine.getCodeEnregistrement(), notificationLine);
		}

		if("05".equals(notificationLine.getCodeEnregistrement())) {
			if(!checkFolderKnown(notificationLine.getDossierSmc())){
				throw new NotificationDetailValidationException(ErrorCode.UNKOWN_DISPUTE_FOLDER_NUMBER, ErrorLevel.ERROR, "Numero de dossier" ,notificationLine.getDossierSmc(), notificationLine);

			}
			if(StringUtils.isEmpty(notificationLine.getCodeAgence()) || StringUtils.isEmpty(notificationLine.getCodeAgence().trim())) {
				throw new NotificationDetailValidationException(ErrorCode.AGENCY_CODE_NOT_PROVIDED, ErrorLevel.ERROR, "Code Agence", notificationLine.getCodeAgence(), notificationLine);
			}

			if(StringUtils.isEmpty(notificationLine.getCodeNotif()) || !Arrays.asList("10", "20", "30", "40", "50", "60", "70").contains(notificationLine.getCodeNotif())) {
				throw new NotificationDetailValidationException(ErrorCode.UNEXPECTED_NOTIF_CODE, ErrorLevel.ERROR, "Code notification", notificationLine.getCodeNotif(), notificationLine);
			}

			if(StringUtils.isEmpty(notificationLine.getDateAppel()) || StringUtils.isEmpty(notificationLine.getDateAppel().trim()) || !stringMatchesDateFormat(notificationLine.getDateAppel(), "ddMMyyy")) {
				throw new NotificationDetailValidationException(ErrorCode.CALL_DATE_INCORRECT, ErrorLevel.ERROR, "Date Appel",notificationLine.getDateAppel(), notificationLine);
			}
			if(StringUtils.isEmpty(notificationLine.getDateCreationDossier()) || StringUtils.isEmpty(notificationLine.getDateCreationDossier().trim()) || !stringMatchesDateFormat(notificationLine.getDateCreationDossier(), "ddMMyyy")) {
				throw new NotificationDetailValidationException(ErrorCode.FOLDER_CREATION_DATE_INCORRECT, ErrorLevel.ERROR, "Date Creation Dossier", notificationLine.getDateCreationDossier(), notificationLine);
			}

			if("1".equals(notificationLine.getNotifMail()) && StringUtils.isEmpty(notificationLine.getMailClient())) {
				throw new NotificationDetailValidationException(ErrorCode.NO_MAIL_ADRESS_PROVIDED, ErrorLevel.WARN, "Mail Client", notificationLine.getMailClient(), notificationLine);
			}
			if("1".equals(notificationLine.getNotifMail()) && !StringUtils.isEmpty(notificationLine.getMailClient()) && !notificationLine.getMailClient().contains("@")) {
				throw new NotificationDetailValidationException(ErrorCode.WRONG_MAIL_ADRESS_PROVIDED, ErrorLevel.WARN,  "Mail Client", notificationLine.getMailClient(), notificationLine);
			}


			if("1".equals(notificationLine.getNotifSms()) && StringUtils.isEmpty(notificationLine.getNumTel())) {
				throw new NotificationDetailValidationException(ErrorCode.NO_PHONE_NUMBER_PROVIDED, ErrorLevel.WARN, "Numero de telephone", notificationLine.getNumTel(), notificationLine);
			}
			//TODO check phone 000000

			if(!"1".equals(notificationLine.getNotifMail()) && !"1".equals(notificationLine.getNotifSms())) {
				throw new NotificationDetailValidationException(ErrorCode.NO_NOTIFICATION_CHANNEL_PROVIDED, ErrorLevel.WARN, "Canal de notification",null, notificationLine);
			}
		}

	}

	private boolean stringMatchesDateFormat(String strDate, String pattern) {
		boolean result = true;
		try {
			DateTimeFormatter.ofPattern(pattern).parse(strDate);
		} catch(Exception ex) {
			result = false;
		}
		return result;
	}

	private boolean checkFolderKnown(String dossierSmc) {
		//TODO to implement
		return true;
	}

	public JobExecution getJobExecution() {
		return jobExecution;
	}

	public void setJobExecution(JobExecution jobExecution) {
		this.jobExecution = jobExecution;
	}
}
