package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AliasedAccountJpaRepository extends JpaRepository<AliasedAccountEntity, DefaultEntityId> {

	AliasedAccountEntity findByAccountId(String alias);

	@Query("from AliasedAccountEntity where telematicId=?1 and ikpi=?2 and dateMaj<CURRENT_DATE - 1")
	List<AliasedAccountEntity> findByTelematicIdAndIkpi(String telematicId,String ikpi);
}
