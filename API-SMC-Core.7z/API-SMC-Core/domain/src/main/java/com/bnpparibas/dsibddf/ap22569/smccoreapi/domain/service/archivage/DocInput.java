/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;

/**
 * @author c65344
 *
 */
public class DocInput {
	private String callingUserInput;
	private String documentIdInput;
	private String userTypeInput;
	private String idContestationSmcInput;

	/**
	 *
	 */
	public DocInput() {
		super();

	}
	/**
	 * @param callingUserInput
	 * @param documentIdInput
	 * @param userTypeInput
	 */
	public DocInput(String callingUserInput, String documentIdInput,
			String userTypeInput) {
		this.callingUserInput = callingUserInput;
		this.documentIdInput = documentIdInput;
		this.userTypeInput = userTypeInput;
	}
	/**
	 * @param callingUserInput
	 * @param documentIdInput
	 * @param userTypeInput
	 * @param idContestationSmcInput
	 * @param numCarteBancaireInput
	 */
	public DocInput(String callingUserInput, String documentIdInput,
			String userTypeInput, String idContestationSmcInput) {
		this.callingUserInput = callingUserInput;
		this.documentIdInput = documentIdInput;
		this.userTypeInput = userTypeInput;
		this.idContestationSmcInput = idContestationSmcInput;

	}
	/**
	 * @return the callingUserInput
	 */
	public String getCallingUserInput() {
		return callingUserInput;
	}
	/**
	 * @return the documentIdInput
	 */
	public String getDocumentIdInput() {
		return documentIdInput;
	}
	/**
	 * @return the idContestationSmcInput
	 */
	public String getIdContestationSmcInput() {
		return idContestationSmcInput;
	}

	/**
	 * @return the userTypeInput
	 */
	public String getUserTypeInput() {
		return userTypeInput;
	}
	/**
	 * @param callingUserInput the callingUserInput to set
	 */
	public void setCallingUserInput(String callingUserInput) {
		this.callingUserInput = callingUserInput;
	}
	/**
	 * @param documentIdInput the documentIdInput to set
	 */
	public void setDocumentIdInput(String documentIdInput) {
		this.documentIdInput = documentIdInput;
	}
	/**
	 * @param idContestationSmcInput the idContestationSmcInput to set
	 */
	public void setIdContestationSmcInput(String idContestationSmcInput) {
		this.idContestationSmcInput = idContestationSmcInput;
	}

	/**
	 * @param userTypeInput the userTypeInput to set
	 */
	public void setUserTypeInput(String userTypeInput) {
		this.userTypeInput = userTypeInput;
	}

}
