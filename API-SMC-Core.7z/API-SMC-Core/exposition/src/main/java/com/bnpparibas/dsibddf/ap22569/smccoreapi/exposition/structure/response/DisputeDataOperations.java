package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * DisputeDataOperations
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-03-27T14:00:58.610Z")
public class DisputeDataOperations   {
	@JsonProperty("codeOperation")
	private String codeOperation;

	@JsonProperty("recognizedAmount")
	private BigDecimal recognizedAmount;
	/**
	 *
	 * @param codeOperation
	 * @return
	 */
	public DisputeDataOperations codeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeDataOperations disputeDataOperations = (DisputeDataOperations) o;
		return Objects.equals(this.codeOperation, disputeDataOperations.codeOperation) &&
				Objects.equals(this.recognizedAmount, disputeDataOperations.recognizedAmount);
	}

	/**
	 * code opération. Correpond au champ operationCode de l'opération.
	 *
	 * @return codeOperation
	 **/
	@ApiModelProperty(value = "code opération. Correpond au champ operationCode de l'opération.")
	public String getCodeOperation() {
		return codeOperation;
	}

	/**
	 * montant reconnu
	 *
	 * @return recognizedAmount
	 **/
	@ApiModelProperty(value = "montant reconnu")
	@Valid
	public BigDecimal getRecognizedAmount() {
		return recognizedAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codeOperation, recognizedAmount);
	}
	/**
	 *
	 * @param recognizedAmount
	 * @return
	 */
	public DisputeDataOperations recognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
		return this;
	}

	/**
	 *
	 * @param codeOperation
	 */
	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}
	/**
	 *
	 * @param recognizedAmount
	 */
	public void setRecognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeDataOperations {\n");

		sb.append("    codeOperation: ").append(toIndentedString(codeOperation)).append("\n");
		sb.append("    recognizedAmount: ").append(toIndentedString(recognizedAmount)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

