package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.IinfoPersonne;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;


@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
@SpringBootTest
@ActiveProfiles({"local", "test"})
public class InfoPersonneTest {
	@Configuration
	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne",
			"com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.goal",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration",
			"com.bnpparibas.dsibddf.ap22569.smctocontacts.goal"
	})
	static class TestConfig{
		@Bean("simpleresttemplate")
		public RestTemplate restTemplate() {
			return new RestTemplate();
		}
	}

	private static final Logger LOG = LoggerFactory.getLogger(InfoPersonneTest.class);
	@Autowired(required=false)
	private transient IinfoPersonne infoPersonne ;

	@Test
	public void testGetInfoPersonneRPBadRequest(){


		try {
			infoPersonne.getInfoPersonneRP("01");
		} catch (PorteurException e) {
			LOG.error(e.getMessage(),e);
			Assertions.assertThat(e.getMessage()).isNotNull();
		}

	}

	@Test
	public void testGetInfoPersonneRPSuccess() throws PorteurException {

		InfoPersonneOutput infoPersonneOutput = infoPersonne.getInfoPersonneRP("01000002676300000"); //$NON-NLS-1$
		Assertions.assertThat(infoPersonneOutput.getSirenNumber()).isNotNull();
	}

}
