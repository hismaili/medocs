package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;


import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.ICardRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.IOperationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.matches;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@Ignore
@RunWith(SpringRunner.class)
public class ContestationServiceTest {

	@Configuration
	@ComponentScan(basePackages = {
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte",
			"com.bnpparibas.dsibddf.ap22569.smctobcmp",
			"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration"
	})
	static class TestConfig {

		@Bean
		public ICardRepository mockCardRepository() {

			ICardRepository cardRepository = mock(ICardRepository.class);


			//List<CartePorteur> getCartesPourComptes(List<String> ribs) throws CardException;
			//final CartePorteur cartePorteur = any(CartePorteur.class);
			try {
				when(cardRepository.getCartesPorteur(any(String.class))).thenAnswer(new Answer<List<CartePorteur>>() {

					@Override
					public List<CartePorteur> answer(InvocationOnMock invocationOnMock) throws Throwable {
						return Arrays.asList(new CartePorteur("01000002676300000",LocalDate.now(),"OK",LocalDate.now()));
					}
				});


				when(cardRepository.getCartesPourComptes(any(List.class))).thenAnswer(new Answer<List<CartePorteur>>() {

					@Override
					public List<CartePorteur> answer(InvocationOnMock invocationOnMock) throws Throwable {
						return Arrays.asList(new CartePorteur("01000002676300000",LocalDate.now(),"OK",LocalDate.now()));
					}
				});

			} catch (CardException e) {
				LOG.error(e.getMessage(), e);
			}
			return cardRepository;
		}


		@Bean
		public IContestationRepository mockContestationRepository() {
			IContestationRepository contestationRepository = mock(IContestationRepository.class);

			final Contestation any = any(Contestation.class);
			when(contestationRepository.creerContestation(any)).thenAnswer(new Answer<Contestation>() {
				@Override
				public Contestation answer(InvocationOnMock invocationOnMock) throws Throwable {
					final Contestation argument = invocationOnMock.getArgument(0);
					argument.setIdContestation(UUID.randomUUID().toString());
					return argument;
				}
			});
			return contestationRepository;
		}

		@Bean
		public IMotifRepository mockMotifRepository() {
			IMotifRepository motifRepository = mock(IMotifRepository.class);
			MotifContestation motif = new MotifContestation();
			motif.setDisclaimerText("Test contestation disclaimer");
			motif.setTypeOperationApplicable(TypeOperation.PAIEMENT);
			motif.setLibelle("Test Contestation");
			when(motifRepository.getMotif(Mockito.matches("M003"))).thenReturn(motif);
			return motifRepository;
		}

		@Bean
		public IOperationRepository mockOperationRepository() {
			IOperationRepository operationRepository = mock(IOperationRepository.class);
			Operation operation = new Operation();
			operation.setCodeOperation("444");
			operation.setDateOperation(LocalDate.now());
			operation.setTypeOperation(TypeOperation.PAIEMENT);
			operation.setLibelleOperation("operation");
			operation.setMontantOperation(BigDecimal.valueOf(127.03));
			try {
				when(operationRepository.getOperationByCodeOpe(matches("444"),"","")).thenReturn(operation);
			} catch (OperationException e) {
				LOG.error(e.getMessage(), e);
			}
			return operationRepository;
		}

		@Bean
		public IStatutDossierContestationRepository mockStatutRepository() {
			IStatutDossierContestationRepository statutDossierContestationRepository = mock(IStatutDossierContestationRepository.class);
			StatutDossierContestation statutDossier = new StatutDossierContestation();
			statutDossier.setCodeStatut("SC002");
			statutDossier.setLibelleStatut("CREE");
			try {
				when(statutDossierContestationRepository.recupererStatutDossier(matches("SC002"))).thenReturn(statutDossier);
			} catch (ContestationException e) {
				LOG.error(e.getMessage(), e);
			} catch (DonneIncorectException e) {
				LOG.error(e.getMessage(), e);
			} catch (MandatoryException e) {
				LOG.error(e.getMessage(), e);
			}
			return statutDossierContestationRepository;
		}

	}

	private static final Logger LOG = LoggerFactory.getLogger(ContestationServiceTest.class);

	private static byte[] toByteArray(UUID uuid) {
		byte[] byteArray = new byte[(Long.SIZE / Byte.SIZE) * 2];
		ByteBuffer buffer = ByteBuffer.wrap(byteArray);
		LongBuffer longBuffer = buffer.asLongBuffer();
		longBuffer.put(new long[] { uuid.getMostSignificantBits(),
				uuid.getLeastSignificantBits() });
		return byteArray;
	}


	@Autowired
	private IContestationService contestationService;

	@Test
	//TODO failure sur le mapping des opérations ContestationService.java:292
	public void testCreerContestation() {

		ContestationSelfcareIn contestationSelfcare = new ContestationSelfcareIn();
		Operation operation = new Operation();
		operation.setCodeOperation("444");
		//        operation.setDateOperation(LocalDate.now());
		//        operation.setTypeOperation(TypeOperation.PAIEMENT);
		//        operation.setLibelleOperation("operation");
		//        operation.setMontantOperation(BigDecimal.valueOf(127.03));
		contestationSelfcare.setOperations(Arrays.asList(operation));
		contestationSelfcare.setDescription("Contestation de vole de carte");
		contestationSelfcare.setDocumentsAttaches(Arrays.asList(new DocumentAttache(
				"GD11100jnlx2i0j000001mu", "perte de carte", "PDF", "20180110"), new DocumentAttache("GD11100jnlx2i0j000001m5",
						"perte de carte", "PDF", "20180110")));
		contestationSelfcare.setMontantReconnu(new BigDecimal(1.2));
		contestationSelfcare.setIkpiClient("1990");
		contestationSelfcare.setIdTelematiqueClient("90");
		contestationSelfcare.setNumeroCarte("4979815236843969");
		contestationSelfcare.setCardId("CA10928309835");
		MotifContestation motif = new MotifContestation();
		motif.setCode("M003");
		motif.setDisclaimerText("Test contestation disclaimer");
		motif.setTypeOperationApplicable(TypeOperation.PAIEMENT);
		motif.setLibelle("Test Contestation");
		contestationSelfcare.setMotif(motif);
		try {
			Contestation contestation = contestationService.creerDossierContestation(contestationSelfcare);
			assertThat(contestation).isNotNull();
			assertThat(contestation.getIdContestation()).isNotNull();
			assertThat(contestation.getMontantConteste()).isNotNull();
			assertThat(contestation.getMontantReconnuPorteur()).isNotNull();
			assertThat(contestation.isPurged()).isNotNull();
			assertThat(contestation.getIdPorteur()).isNotNull();
			assertThat(contestation.getIdTelematique()).isNotNull();
			assertThat(contestation.getNumCarte()).isNotNull();
			assertThat(contestation.getOperations()).isNotNull();
			assertThat(contestation.getOperations()).isNotEmpty();
			assertThat(contestation.getDescription()).isNotNull();
			assertThat(contestation.getDernierStatutDossier()).isNotNull();
			assertThat(contestation.getDocumentAttaches()).isNotNull();
			assertThat(contestation.getDocumentAttaches()).isNotEmpty();
			assertThat(contestation.getNombreOperations()).isNotNull();
			assertThat(contestation.getNombreOperations()).isEqualTo(Integer.valueOf(1));
			assertThat(contestation.getMotif()).isNotNull();
		} catch (ContestationValidationException e) {
			LOG.error(e.getMessage(), e);
			if(!CollectionUtils.isEmpty(e.getErrors())){
				e.getErrors().stream().forEach(err ->{
					LOG.error(err.getCode() +" : "+err.getLibelle());
				});
			}
			fail(e.getMessage());
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			fail(e.getMessage());
		}
	}

}