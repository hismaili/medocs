package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage.IArchivageManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.commons.MapperEditionSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte.AccountDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte.IAccountServiceManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edoc.IAttachmentManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation.IOperationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccountException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.AttachmentDataInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DocumentInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.IDisputeSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.ArchivingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.NewDocInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.AnonymizedCard;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons.MaskUtils;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.ContestationSelfcareIn;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.DocumentAttache;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IContestationService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IMotifService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatutDossierContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.EditingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.IEditionDocument;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.HolderMail;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.HolderPhoneNumber;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.IinfoPersonne;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PersonContactInfo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;

@Component
@Lazy
public class ContestationManagement implements IContestationManagement {

	private static final Logger LOG = LoggerFactory.getLogger(ContestationManagement.class);

	private static final String BROUILLON = "SC001"; //$NON-NLS-1$
	private static final String CREER = "SC002"; //$NON-NLS-1$
	private static final String ERRORINTERNE = "La donnée status est incorect";
	private static final String TITRE = "Document recapitulatif";
	private static final String FILENAME = "DossierRecapitulatif";
	private static final String ENCODING = "BASE64";
	private static final String FORMAT = "PDF";
	private static final String COMPRESS = "none";
	private static final String DOCUMENTTYPEID = "20180110";
	private static final String MIMETYPE = "application/pdf";
	private static final String ADMINCALLINGUSER = "410285";
	private static final Locale ADEFAULT = Locale.getDefault();

	@Autowired(required = false)
	private transient IContestationService contestationService;

	@Autowired(required = false)
	private transient IMotifService motifService;
	@Autowired(required=false)
	private transient IOperationManagement operationManagement;

	@Autowired(required=false)
	private transient ICardServicesManagement cardServicesManagement;

	@Autowired(required = false)
	private transient IAccountServiceManagement accountServiceManagement;

	@Autowired(required = false)
	private transient IinfoPersonne personneService;

	@Autowired(required = false)
	private transient IArchivageManagement archivage;

	@Autowired(required=false)
	private transient IEditionDocument document;

	@Autowired(required=false)
	private transient MapperEditionSelfCare map;
	@Autowired
	private transient IDisputeSelfCare disputeSelf;
	@Autowired(required=false)
	private transient IAttachmentManagement edoc;


	@Autowired(required=false)
	private transient IDisputeSelfCareManagement disputeSelfCareManagement;




	private List<AccountWithCardsDTO> attachCardToAccounts(List<AccountDTO> userAccounts, List<AnonymizedCard> cards) {
		AtomicInteger i = new AtomicInteger();
		return userAccounts.stream().peek(account -> account.setIndex(i.getAndIncrement())).map(account -> {
			List<CardDTO> accountCards = null;
			if (!CollectionUtils.isEmpty(cards)) {
				accountCards = cards.stream()
						.filter(carte -> carte.getCarte().getNumCompte().equals(account.getRib()))
						.map(cartePorteur -> mapCartePorteurToCardDTO(cartePorteur))
						.collect(Collectors.toList());
			}

			if(CollectionUtils.isEmpty(accountCards)){
				LOG.error("Le compte "+account.getRib()+" n'a pas de carte");
			}

			return new AccountWithCardsDTO(account, accountCards);
		}).collect(Collectors.toList());
	}

	/**
	 * @param disputeData
	 * @throws MandatoryException
	 */
	private void checkMandatory(DisputeDataDTO disputeData)
			throws MandatoryException {
		List<String> mandatoryFields = new ArrayList<>();
		if (StringUtils.isEmpty(disputeData.getReason())) {
			LOG.error("La donnée motif est obligatoire mais n'est pas renseignée");
			mandatoryFields.add("Reason");
		}
		if (disputeData.getNotifMail() != null && disputeData.getNotifMail() && StringUtils.isEmpty(disputeData.getMail())) {
			LOG.error("Le client a choisi d'être notifié par mail mais l'adresse mail n'est pas renseignée");
			mandatoryFields.add("Mail");
		}
		if (disputeData.getNotifSMS() != null && disputeData.getNotifSMS() && StringUtils.isEmpty(disputeData.getPhoneNumber())) {
			LOG.error("Le client a choisi d'être notifié par SMS mais le numéro de téléphone n'est pas renseigné");
			mandatoryFields.add("PhoneNumber");
		}
		if (StringUtils.isEmpty(disputeData.getCardId())) {
			LOG.error("La donnée CardId est obligatoire mais n'est pas renseignée");
			mandatoryFields.add("CardId");
		}

		if (!CollectionUtils.isEmpty(mandatoryFields)) {
			throw new MandatoryException(mandatoryFields);
		}
	}

	@Override
	public Contestation consulterContestation(String referenceDossier,String codeStatus) throws ContestationException,MandatoryException, DonneIncorectException{

		if(codeStatus !=null && !codeStatus.isEmpty()){

			StatutDossierContestation statutDossierContestation =contestationService.recupererStatutDossier(codeStatus);
			/**
			 * si la contestation est a l'état brouillon ou creer on recherche par id interne
			 */
			if((statutDossierContestation == null)){
				throw new ContestationException(ERRORINTERNE);
			}else{
				return contestationService.consulterContestation(referenceDossier);
			}
		}else{
			return contestationService.consulterContestation(referenceDossier);
		}

	}



	@Override
	public Contestation consulterContestationParIdInterne(
			String identifiantInterne) throws ContestationException{

		return  contestationService.recupererContestationByIdInterne(identifiantInterne);
	}

	@Override
	@Transactional(transactionManager="transactionManager")
	public DisputeSummaryDTO createDispute(DisputeDataDTO disputeData) throws ContestationException,ContestationValidationException {
		//input data validation
		//check reason isNotEmpty and motif exist in database

		String idTelematique = disputeData.getTelematicId();
		String idPorteur = disputeData.getCustomerIKpi();
		MotifContestation motif = null;
		CardDTO card = null;
		try {
			/**
			 * check mandatory data
			 */
			checkMandatory(disputeData);

			//validate data
			motif = this.motifService.getMotif(disputeData.getReason());
			if (motif == null) {
				LOG.error("Aucun motif ne correspond au code motif renseigné " + disputeData.getReason());
				throw new DonneIncorectException("Reason");
			}
			card = this.cardServicesManagement.getCardInfosWithMask(disputeData.getCardId());
			if (card == null) {
				LOG.error("Aucune carte ne correspond à celle demandée : " + disputeData.getCardId());
				throw new DonneIncorectException("CardId");
			}

			ContestationSelfcareIn contestationSelfCare = getContestationSelfcareIn(disputeData, motif, card);



			Contestation contestation = this.contestationService.creerDossierContestation(contestationSelfCare);


			if(!StringUtils.isEmpty(contestation.getNumDossierSMC())){

				disputeSelfCareManagement.generateAndSaveRecap(contestation);
			}

			return getDisputeSummaryDTO(card, contestation);
		}catch(MandatoryException | DonneIncorectException e) {
			throw new ContestationValidationException(e);
		} catch (CardException e) {
			throw new ContestationValidationException(e);
		} finally {
			operationManagement.deleteOperationsTmp(idTelematique, idPorteur);
		}


	}



	@Override
	public List<MotifContestation> getAllMotifs() {
		return contestationService.recupererMotifsContestation();
	}


	private ContestationSelfcareIn getContestationSelfcareIn(DisputeDataDTO disputeData, MotifContestation motif, CardDTO card) {
		ContestationSelfcareIn contestationSelfCare = new ContestationSelfcareIn();
		contestationSelfCare.setIdTelematiqueClient(disputeData.getTelematicId());

		contestationSelfCare.setMotif(motif);
		contestationSelfCare.setIkpiClient(disputeData.getCustomerIKpi());

		contestationSelfCare.setNumeroCarte(card.getPan());
		contestationSelfCare.setCardId(disputeData.getCardId());

		contestationSelfCare.setNotifMail(disputeData.getNotifMail());
		contestationSelfCare.setMail(disputeData.getMail());
		contestationSelfCare.setTopMailModifie(disputeData.getTopMailModified());
		contestationSelfCare.setNotifPush(disputeData.getNotifPush());
		contestationSelfCare.setNotifSMS(disputeData.getNotifSMS());
		contestationSelfCare.setNumeroTel(disputeData.getPhoneNumber());
		contestationSelfCare.setTopNumeroTelModifie(disputeData.getTopPhoneNumberModified());
		contestationSelfCare.setDescription(disputeData.getFactsSummary());

		List<DisputeDataOperationDTO> operations = disputeData.getOperations();
		if(!CollectionUtils.isEmpty(operations)) {
			operations.stream().forEach(ope -> {
				Operation op = new Operation();
				op.setCodeOperation(ope.getCodeOperation());
				op.setMontantReconnu(ope.getRecognizedAmount());
				contestationSelfCare.operation(op);
			});
		}

		contestationSelfCare.setCardVoleePerdue(disputeData.getCardLost());

		List<DisputeDataAttachedFileDTO> attachedFiles = disputeData.getAttachedFiles();
		if(!CollectionUtils.isEmpty(attachedFiles)) {
			attachedFiles.stream().forEach(file -> {
				DocumentAttache documentAttach = new DocumentAttache();
				documentAttach.setFormatDocument(file.getFiletype());
				documentAttach.setNomDocument(file.getFileName());
				documentAttach.setRecap(Boolean.FALSE);
				//documentAttach.setSendToSmc(Boolean.FALSE);

				/**
				 * on recupère les ids attchment de edoc et on appel edoc pour les convertir en idGdn
				 */
				String idAttachment = file.getIdGdn();
				String idGn = edoc.getIdGn(idAttachment);
				documentAttach.setIdAttachment(idAttachment);
				if(!StringUtils.isEmpty(idGn)){
					documentAttach.setIdGDN(idGn);
					contestationSelfCare.document(documentAttach);
				}else{
					/**
					 * si edoc ne remet pas le document alors on l'enregistre quand meme pour le renvoyer à EDOC DANS LE BATCH DE REPRISE document
					 */
					contestationSelfCare.document(documentAttach);
					LOG.error("Le idAttachment : "+idAttachment+" de edoc ne correspond à aucun id_GDN ");
				}
			});
		}
		return contestationSelfCare;
	}


	@Override
	public CustomerContactInfos getCustomerContactInfos(String telematicId, String userId) throws ContestationException, ContestationValidationException {
		CustomerContactInfos customerContacts = null;
		try {
			PersonContactInfo contactsPersonne = this.personneService.getPersonContactInfos(userId,telematicId);
			if(contactsPersonne != null) {
				HolderMail holderMail = contactsPersonne.getHolderMail();
				customerContacts = new CustomerContactInfos();
				if(holderMail != null) {
					customerContacts.setMailId(holderMail.getMailId());
					customerContacts.setMaskedMail(MaskUtils.maskMail(holderMail));
				}
				HolderPhoneNumber holderPhoneNumber = contactsPersonne.getHolderPhoneNumber();
				if(holderPhoneNumber != null) {
					customerContacts.setPhoneNumberId(holderPhoneNumber.getPhoneNumberId());
					customerContacts.setMaskedPhoneNumber(MaskUtils.maskPhoneNumber(holderPhoneNumber));
				}
				customerContacts.setTelematicId(telematicId);
			} else {
				LOG.error("Aucun contact trouvé pour l'utilisateur "+userId);
			}
		} catch (final PorteurException e) {
			LOG.error(e.getMessage(), e);
			throw new ContestationException(e.getMessage(), e);
		}

		return customerContacts;
	}

	private DisputeSummaryDTO getDisputeSummaryDTO(CardDTO card, Contestation contestation) {
		DisputeSummaryDTO summaryDTO = new DisputeSummaryDTO();
		summaryDTO.setCardType(card.getCardProductType());
		summaryDTO.setMaskedPan(card.getMaskedPan());
		summaryDTO.setFactsSummary(contestation.getDescription());
		summaryDTO.setIdentifiantInterne(contestation.getIdContestation());
		summaryDTO.setDisputedAmount(contestation.getMontantConteste());
		summaryDTO.setRecognizedAmount(contestation.getMontantReconnuPorteur());
		summaryDTO.setReason(contestation.getMotif().getLibelle());
		summaryDTO.setNumberOfOperations(contestation.getNombreOperations());
		summaryDTO.setDisputeFolderReference(contestation.getNumDossierSMC());
		summaryDTO.setCurrentStatus(contestation.getDernierStatutDossier().getLibelleStatut());
		summaryDTO.setDisputeFolderCreationDate(contestation.getDateDeCreationDossier());
		summaryDTO.setDateOpposition(contestation.getCarte().getDatOppositionInput());
		return summaryDTO;
	}

	@Override
	public List<Contestation> getHistoriqueContestations(String identifiant,Integer offset,Integer limit) throws ContestationException {

		return contestationService.recupererContestationsClient(identifiant,offset,limit);
	}

	@Override
	public List<MotifContestation> getMotifsApplicables(TypeOperation operationType, Boolean cardLost, Integer numberOfOperations) throws Exception {
		return contestationService.recupererMotifsContestation(operationType, cardLost, numberOfOperations);
	}

	@Override
	public List<MotifContestation> getMotifsForOperationType(TypeOperation operationType) {
		return contestationService.recupererMotifsContestation(operationType);
	}

	@Override
	public List<AccountWithCardsDTO> getUserAccountsAndCard(String telematicId,String userId) throws ContestationException, ContestationValidationException {
		try {
			List<AccountDTO> userAccounts = this.accountServiceManagement.getUserAccounts(telematicId,userId);
			if(!CollectionUtils.isEmpty(userAccounts)) {
				List<String> ribs = userAccounts.stream().map(AccountDTO::getRib).collect(Collectors.toList());
				List<AnonymizedCard> cards = this.cardServicesManagement.getCartesPorteur(ribs);

				return attachCardToAccounts(userAccounts, cards);
			}

		} catch (UserAccountException e) {
			LOG.error(e.getMessage(), e);
			throw new ContestationException(e.getMessage(), e);
		} catch (CardException e) {
			LOG.error(e.getMessage(), e);
			throw new ContestationException(e.getMessage(), e);
		}
		return null;
	}

	@Override
	public boolean isAuthorized(String idGdn, String idTelematic) {
		return contestationService.isAuthorized(idGdn, idTelematic);
	}



	private CardDTO mapCartePorteurToCardDTO(AnonymizedCard cartePorteur) {
		CardDTO cardDTO = new CardDTO();
		//TODO complete the mapping
		final CartePorteur carte = cartePorteur.getCarte();
		cardDTO.setPan(carte.getNumCarteInput());
		cardDTO.setMaskedPan(cartePorteur.getMaskedPan());
		cardDTO.setCardState(carte.getStatutCarteInput());
		cardDTO.setCardProductType(carte.getTypeProduit());
		//TODO get from ikpi cardDTO.setCardHolderName(cartePorteur);
		cardDTO.setCardExpirationDate(carte.getDateFinValiditeInput());
		cardDTO.setCardCancellationDate(carte.getDatOppositionInput());
		cardDTO.setCancellationReason(carte.getLibelleMotifOpposition());
		cardDTO.setCardId(cartePorteur.getCardId());
		cardDTO.setCardHolderName(carte.getNomPorteur());
		return cardDTO;
	}












	private String saveRecapInGDN(RequestEditiqueOutput recapitulatifSelfCarePDF) throws ArchivingException, MandatoryException, FormatErrorException {
		NewDocInput newDocInput = new NewDocInput();

		newDocInput.setCallingUserNewDocInput(ADMINCALLINGUSER);
		newDocInput.setCountryCodeNewDocInput(ADEFAULT.getCountry());
		newDocInput.setLocaleCodeNewDocInput(ADEFAULT.getLanguage());
		newDocInput.setDocumentTypeIdNewDocInput(DOCUMENTTYPEID);
		newDocInput.setMimeTypeNewDocInput(MIMETYPE);
		newDocInput.setTitreNewDocInput(TITRE);
		newDocInput.setFileNameNewDocInput(FILENAME);
		newDocInput.setEncodingNewDocInput(ENCODING);
		newDocInput.setDataNewDocInput(recapitulatifSelfCarePDF.getPdfresult());
		newDocInput.setArchiveFormatNewDocInput(FORMAT);
		newDocInput.setCompressNewDocInput(COMPRESS);

		return archivage.newDoc(newDocInput);
	}



	/**
	 * @param contestation
	 * @param requestEditique
	 * @throws ContestationValidationException
	 * @throws ContestationException
	 */
	public void saveRecapitulatif(Contestation contestation,
			RequestEditiqueInput requestEditique)
					throws ContestationValidationException, ContestationException {
		try {

			RequestEditiqueOutput recapitulatifSelfCarePDF = document.creerRecapitulatifSelfCarePDF(requestEditique);

			String idGDN = saveRecapInGDN(recapitulatifSelfCarePDF);

			List<DocumentAttache> documentAttaches = contestation.getDocumentAttaches();

			if(!CollectionUtils.isEmpty(documentAttaches)  && contestation !=null && !StringUtils.isEmpty(idGDN)){
				DocumentAttache documentRecap = new DocumentAttache(idGDN, FILENAME, FORMAT, DOCUMENTTYPEID, contestation.getNumDossierSMC(),new Boolean(true));
				documentAttaches.add(documentRecap);
				contestation.setDocumentAttaches(documentAttaches);


				/**
				 * mis à jour de la contestation pour y attacher le document recapitulatif selfcare
				 */
				Contestation contestationUpdated = contestationService.updateContestation(contestation);



				List<DocumentAttache> documentAttachesUpdated = contestationUpdated.getDocumentAttaches();

				/**
				 * Recupération de l'id technique du document récapitulatif, néccessaire pour passer son état d'envoi à smc à SEND
				 */
				if(!CollectionUtils.isEmpty(documentAttachesUpdated)){
					LOG.info("Document joints :");
					documentAttachesUpdated.stream()
					.filter(doc ->  documentRecap.getIdGDN().equals(doc.getIdGDN()))
					.forEach(doc ->{
						LOG.info(doc.getNomDocument());
						documentRecap.setId(doc.getId());
					});
				}

				sendRecapToSMC(documentRecap);
			}

		} catch (EditingException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationValidationException(e);

		} catch (MandatoryException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationValidationException(e);
		} catch (FormatErrorException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationValidationException(e);
		} catch (DonneIncorectException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationValidationException(e);
		} catch (ArchivingException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationException(e);
		}
	}


	/**
	 * Envoi le document à SMC et change le status d'envoi à SMC à SEND
	 *
	 * @param documentRecap
	 * @throws MandatoryException
	 */
	private void sendRecapToSMC(DocumentAttache documentRecap) throws MandatoryException {


		AttachmentDataInput attach = new  AttachmentDataInput();

		/**
		 * On joint le numéro de dossier
		 */
		attach.setFileIdSMC(documentRecap.getReferenceDossierSMC());


		/**
		 * On attache le document
		 */
		DocumentInput documentInput = new DocumentInput();
		documentInput.setDocumentName(documentRecap.getNomDocument());
		documentInput.setDocumentType(documentRecap.getTypeDocGDN());
		documentInput.setIdGed(documentRecap.getIdGDN());

		attach.setDocuments(Arrays.asList(documentInput));

		/**
		 * On joint les documents en les envoyant à SMC
		 */
		DisputeResponse attachedDocuments = disputeSelf.attachedDocuments(attach);

		//		/**
		//		 * Le document envoyé à smc prend le status SEND dans la base de donnée COSMO
		//		 */
		//		if(attachedDocuments !=null && !StringUtils.isEmpty(attachedDocuments.getFileIdSMC())){
		//
		//			documentRecap.setSendToSmc(Boolean.TRUE);
		//
		//
		//		}

	}
}


