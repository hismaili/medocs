package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte;

/**
 *
 *
 *
 */
public class UserAccount {

	private String accountId;

	private String maskedAccountNumber;

	private String rib;

	private String accountType;

	private String accountHolderName;

	private String telematicId;

	private String ikpi;

	/**
	 *
	 * @return
	 */
	public String getAccountHolderName() {
		return accountHolderName;
	}

	public String getAccountId() {
		return accountId;
	}

	/**
	 *
	 * @return
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}
	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}
	/**
	 *
	 * @return
	 */
	public String getRib() {
		return rib;
	}
	public String getTelematicId() {
		return telematicId;
	}
	/**
	 *
	 * @param accountHolderName
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 *
	 * @param accountType
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}

	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}

	/**
	 *
	 * @param rib
	 */
	public void setRib(String rib) {
		this.rib = rib;
	}

	public void setTelematicId(String telematicId) {
		this.telematicId = telematicId;
	}

	@Override
	public String toString() {
		return "UserAccount{" +
				"accountId='" + accountId + '\'' +
				", maskedAccountNumber='" + maskedAccountNumber + '\'' +
				", rib='" + rib + '\'' +
				", accountType='" + accountType + '\'' +
				", accountHolderName='" + accountHolderName + '\'' +
				", telematicId='" + telematicId + '\'' +
				", ikpi='" + ikpi + '\'' +
				'}';
	}
}
