package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;
/**
 *
 * @author c65344
 *
 */
public class NewDocInput {
	private String callingUserNewDocInput;
	private String callingApplicationNewDocInput;
	private String localeCodeNewDocInput;
	private String countryCodeNewDocInput;
	private String numCarteBancaireNewDocInput;
	private String idContestationSmcNewDocInput;
	private String documentTypeIdNewDocInput;
	private String mimeTypeNewDocInput;
	private String titreNewDocInput;

	private String fileNameNewDocInput;
	private String archiveFormatNewDocInput;
	private String compressNewDocInput;
	private String encodingNewDocInput;
	private String dataNewDocInput;
	/**
	 *
	 */
	public NewDocInput() {
		super();
	}
	/**
	 * @param callingUserNewDocInput
	 * @param callingApplicationNewDocInput
	 * @param localeCodeNewDocInput
	 * @param countryCodeNewDocInput
	 * @param numCarteBancaireNewDocInput
	 * @param idContestationSmcNewDocInput
	 * @param documentTypeIdNewDocInput
	 * @param mimeTypeNewDocInput
	 * @param titreNewDocInput
	 * @param fileNameNewDocInput
	 * @param archiveFormatNewDocInput
	 * @param compressNewDocInput
	 * @param encodingNewDocInput
	 * @param dataNewDocInput
	 */
	public NewDocInput(String callingUserNewDocInput,
			String callingApplicationNewDocInput, String localeCodeNewDocInput,
			String countryCodeNewDocInput, String numCarteBancaireNewDocInput,
			String idContestationSmcNewDocInput,
			String documentTypeIdNewDocInput, String mimeTypeNewDocInput,
			String titreNewDocInput, String fileNameNewDocInput,
			String archiveFormatNewDocInput, String compressNewDocInput,
			String encodingNewDocInput, String dataNewDocInput) {
		this.callingUserNewDocInput = callingUserNewDocInput;
		this.callingApplicationNewDocInput = callingApplicationNewDocInput;
		this.localeCodeNewDocInput = localeCodeNewDocInput;
		this.countryCodeNewDocInput = countryCodeNewDocInput;
		this.numCarteBancaireNewDocInput = numCarteBancaireNewDocInput;
		this.idContestationSmcNewDocInput = idContestationSmcNewDocInput;
		this.documentTypeIdNewDocInput = documentTypeIdNewDocInput;
		this.mimeTypeNewDocInput = mimeTypeNewDocInput;
		this.titreNewDocInput = titreNewDocInput;
		this.fileNameNewDocInput = fileNameNewDocInput;
		this.archiveFormatNewDocInput = archiveFormatNewDocInput;
		this.compressNewDocInput = compressNewDocInput;
		this.encodingNewDocInput = encodingNewDocInput;
		this.dataNewDocInput = dataNewDocInput;
	}
	/**
	 * @return the archiveFormatNewDocInput
	 */
	public String getArchiveFormatNewDocInput() {
		return archiveFormatNewDocInput;
	}
	/**
	 * @return the callingApplicationNewDocInput
	 */
	public String getCallingApplicationNewDocInput() {
		return callingApplicationNewDocInput;
	}
	/**
	 * @return the callingUserNewDocInput
	 */
	public String getCallingUserNewDocInput() {
		return callingUserNewDocInput;
	}
	/**
	 * @return the compressNewDocInput
	 */
	public String getCompressNewDocInput() {
		return compressNewDocInput;
	}
	/**
	 * @return the countryCodeNewDocInput
	 */
	public String getCountryCodeNewDocInput() {
		return countryCodeNewDocInput;
	}
	/**
	 * @return the dataNewDocInput
	 */
	public String getDataNewDocInput() {
		return dataNewDocInput;
	}
	/**
	 * @return the documentTypeIdNewDocInput
	 */
	public String getDocumentTypeIdNewDocInput() {
		return documentTypeIdNewDocInput;
	}
	/**
	 * @return the encodingNewDocInput
	 */
	public String getEncodingNewDocInput() {
		return encodingNewDocInput;
	}
	/**
	 * @return the fileNameNewDocInput
	 */
	public String getFileNameNewDocInput() {
		return fileNameNewDocInput;
	}
	/**
	 * @return the idContestationSmcNewDocInput
	 */
	public String getIdContestationSmcNewDocInput() {
		return idContestationSmcNewDocInput;
	}
	/**
	 * @return the localeCodeNewDocInput
	 */
	public String getLocaleCodeNewDocInput() {
		return localeCodeNewDocInput;
	}
	/**
	 * @return the mimeTypeNewDocInput
	 */
	public String getMimeTypeNewDocInput() {
		return mimeTypeNewDocInput;
	}
	/**
	 * @return the numCarteBancaireNewDocInput
	 */
	public String getNumCarteBancaireNewDocInput() {
		return numCarteBancaireNewDocInput;
	}
	/**
	 * @return the titreNewDocInput
	 */
	public String getTitreNewDocInput() {
		return titreNewDocInput;
	}
	/**
	 * @param archiveFormatNewDocInput the archiveFormatNewDocInput to set
	 */
	public void setArchiveFormatNewDocInput(String archiveFormatNewDocInput) {
		this.archiveFormatNewDocInput = archiveFormatNewDocInput;
	}
	/**
	 * @param callingApplicationNewDocInput the callingApplicationNewDocInput to set
	 */
	public void setCallingApplicationNewDocInput(
			String callingApplicationNewDocInput) {
		this.callingApplicationNewDocInput = callingApplicationNewDocInput;
	}
	/**
	 * @param callingUserNewDocInput the callingUserNewDocInput to set
	 */
	public void setCallingUserNewDocInput(String callingUserNewDocInput) {
		this.callingUserNewDocInput = callingUserNewDocInput;
	}
	/**
	 * @param compressNewDocInput the compressNewDocInput to set
	 */
	public void setCompressNewDocInput(String compressNewDocInput) {
		this.compressNewDocInput = compressNewDocInput;
	}
	/**
	 * @param countryCodeNewDocInput the countryCodeNewDocInput to set
	 */
	public void setCountryCodeNewDocInput(String countryCodeNewDocInput) {
		this.countryCodeNewDocInput = countryCodeNewDocInput;
	}
	/**
	 * @param dataNewDocInput the dataNewDocInput to set
	 */
	public void setDataNewDocInput(String dataNewDocInput) {
		this.dataNewDocInput = dataNewDocInput;
	}
	/**
	 * @param documentTypeIdNewDocInput the documentTypeIdNewDocInput to set
	 */
	public void setDocumentTypeIdNewDocInput(String documentTypeIdNewDocInput) {
		this.documentTypeIdNewDocInput = documentTypeIdNewDocInput;
	}
	/**
	 * @param encodingNewDocInput the encodingNewDocInput to set
	 */
	public void setEncodingNewDocInput(String encodingNewDocInput) {
		this.encodingNewDocInput = encodingNewDocInput;
	}
	/**
	 * @param fileNameNewDocInput the fileNameNewDocInput to set
	 */
	public void setFileNameNewDocInput(String fileNameNewDocInput) {
		this.fileNameNewDocInput = fileNameNewDocInput;
	}
	/**
	 * @param idContestationSmcNewDocInput the idContestationSmcNewDocInput to set
	 */
	public void setIdContestationSmcNewDocInput(String idContestationSmcNewDocInput) {
		this.idContestationSmcNewDocInput = idContestationSmcNewDocInput;
	}
	/**
	 * @param localeCodeNewDocInput the localeCodeNewDocInput to set
	 */
	public void setLocaleCodeNewDocInput(String localeCodeNewDocInput) {
		this.localeCodeNewDocInput = localeCodeNewDocInput;
	}
	/**
	 * @param mimeTypeNewDocInput the mimeTypeNewDocInput to set
	 */
	public void setMimeTypeNewDocInput(String mimeTypeNewDocInput) {
		this.mimeTypeNewDocInput = mimeTypeNewDocInput;
	}
	/**
	 * @param numCarteBancaireNewDocInput the numCarteBancaireNewDocInput to set
	 */
	public void setNumCarteBancaireNewDocInput(String numCarteBancaireNewDocInput) {
		this.numCarteBancaireNewDocInput = numCarteBancaireNewDocInput;
	}
	/**
	 * @param titreNewDocInput the titreNewDocInput to set
	 */
	public void setTitreNewDocInput(String titreNewDocInput) {
		this.titreNewDocInput = titreNewDocInput;
	}

}
