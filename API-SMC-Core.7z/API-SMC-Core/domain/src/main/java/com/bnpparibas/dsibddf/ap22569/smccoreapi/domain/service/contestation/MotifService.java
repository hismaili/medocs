package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MotifService implements IMotifService {

    private IMotifRepository motifRepository;

    @Lazy
    public MotifService(IMotifRepository motifRepository) {
        this.motifRepository = motifRepository;
    }

    @Override
    public List<MotifContestation> getAllMotifs() {
        return motifRepository.getAllMotifs();
    }

    /**
	 * @return the motifRepository
	 */
	public IMotifRepository getMotifRepository() {
		return motifRepository;
	}

	/**
	 * @param motifRepository the motifRepository to set
	 */
	public void setMotifRepository(IMotifRepository motifRepository) {
		this.motifRepository = motifRepository;
	}

	@Override
    public List<MotifContestation> getMotifsByOperationType(TypeOperation operationType) {
        return motifRepository.getMotifsByOperationType(operationType);
    }

    @Override
    public MotifContestation getMotif(String code) {
        return motifRepository.getMotif(code);
    }

 }
