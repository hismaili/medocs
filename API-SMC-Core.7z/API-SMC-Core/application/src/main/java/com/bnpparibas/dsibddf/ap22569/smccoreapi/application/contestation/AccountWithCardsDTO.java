package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte.AccountDTO;

import java.util.List;

/**
 *
 * AccountWithCardsDTO
 *
 */
public class AccountWithCardsDTO implements Comparable<AccountWithCardsDTO> {

	private AccountDTO account;

	private List<CardDTO> cards;

	public AccountWithCardsDTO() {
	}
	/**
	 *
	 * @param account
	 * @param cards
	 */
	public AccountWithCardsDTO(AccountDTO account, List<CardDTO> cards) {
		this.account = account;
		this.cards = cards;
	}

	@Override
	public int compareTo(AccountWithCardsDTO o) {
		if(o == null) {
			return 1;
		}
		final AccountDTO accountDto = this.getAccount();
		final AccountDTO oAccount = o.getAccount();
		if(accountDto == null && oAccount == null) {
			return 0;
		} else if(accountDto != null && oAccount == null) {
			return 1;
		} else if(accountDto == null && oAccount != null) {
			return -1;
		} else {
			final Integer index = accountDto.getIndex();
			final Integer index1 = oAccount.getIndex();
			if(index == null && index1 == null) {
				return 0;
			} else if(index != null && index1 == null) {
				return 1;
			} else if(index == null && index1 != null) {
				return -1;
			}
			return index.compareTo(index1);
		}

	}
	/**
	 *
	 * @return
	 */
	public AccountDTO getAccount() {
		return account;
	}
	/**
	 *
	 * @return
	 */
	public List<CardDTO> getCards() {
		return cards;
	}
	/**
	 *
	 * @param account
	 */
	public void setAccount(AccountDTO account) {
		this.account = account;
	}
	/**
	 *
	 * @param cards
	 */
	public void setCards(List<CardDTO> cards) {
		this.cards = cards;
	}
}
