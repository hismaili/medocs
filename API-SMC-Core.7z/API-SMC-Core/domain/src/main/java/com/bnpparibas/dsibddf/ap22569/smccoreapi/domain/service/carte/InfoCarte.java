/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

/**
 * @author c65344
 *
 */
public class InfoCarte {
	private String idUniqueClientInput;

	private String idContratMonetiquePorteurInput;

	private String ribOperationInput;

	private String ribCotisationInput;

	private String codeAgenceRattachementInput;

	private String codeTypContratInput;

	/**
	 * @return the codeAgenceRattachementInput
	 */
	public String getCodeAgenceRattachementInput() {
		return codeAgenceRattachementInput;
	}

	/**
	 * @return the codeTypContratInput
	 */
	public String getCodeTypContratInput() {
		return codeTypContratInput;
	}

	/**
	 * @return the idContratMonetiquePorteurInput
	 */
	public String getIdContratMonetiquePorteurInput() {
		return idContratMonetiquePorteurInput;
	}

	/**
	 * @return the idUniqueClientInput
	 */
	public String getIdUniqueClientInput() {
		return idUniqueClientInput;
	}

	/**
	 * @return the ribCotisationInput
	 */
	public String getRibCotisationInput() {
		return ribCotisationInput;
	}

	/**
	 * @return the ribOperationInput
	 */
	public String getRibOperationInput() {
		return ribOperationInput;
	}

	/**
	 * @param codeAgenceRattachementInput the codeAgenceRattachementInput to set
	 */
	public void setCodeAgenceRattachementInput(String codeAgenceRattachementInput) {
		this.codeAgenceRattachementInput = codeAgenceRattachementInput;
	}

	/**
	 * @param codeTypContratInput the codeTypContratInput to set
	 */
	public void setCodeTypContratInput(String codeTypContratInput) {
		this.codeTypContratInput = codeTypContratInput;
	}

	/**
	 * @param idContratMonetiquePorteurInput the idContratMonetiquePorteurInput to set
	 */
	public void setIdContratMonetiquePorteurInput(
			String idContratMonetiquePorteurInput) {
		this.idContratMonetiquePorteurInput = idContratMonetiquePorteurInput;
	}

	/**
	 * @param idUniqueClientInput the idUniqueClientInput to set
	 */
	public void setIdUniqueClientInput(String idUniqueClientInput) {
		this.idUniqueClientInput = idUniqueClientInput;
	}

	/**
	 * @param ribCotisationInput the ribCotisationInput to set
	 */
	public void setRibCotisationInput(String ribCotisationInput) {
		this.ribCotisationInput = ribCotisationInput;
	}

	/**
	 * @param ribOperationInput the ribOperationInput to set
	 */
	public void setRibOperationInput(String ribOperationInput) {
		this.ribOperationInput = ribOperationInput;
	}

}
