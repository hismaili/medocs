package com.bnpparibas.dsibddf.ap22569.notification.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.List;

@XStreamAlias("message")
public class NotificationEvent {

        private String eventId;
        private String receiverAddress;
        private String receiverAddressType;
        private String receiverId;
        private String receiverIdType;
        private String receiverNature;
        private String applicationId;
        private String customerJourneyId;
        private String applicationUseCase;
        private String msgReference;
        private String startDiffusionDate;
        private String receiverPreferences;
        private String multiChannel;

        @XStreamAlias("variablesList")
        private List<NotificationEventVariable> variablesList;
        private String channelsList;

        @XStreamOmitField
        private boolean secureMessage;

        @XStreamOmitField
        private String notificationInternalId;

        public NotificationEvent() {

        }

        public String getEventId() {
            return eventId;
        }

        public void setEventId(String eventId) {
            this.eventId = eventId;
        }

        public String getReceiverAddress() {
            return receiverAddress;
        }

        public void setReceiverAddress(String receiverAddress) {
            this.receiverAddress = receiverAddress;
        }

        public String getReceiverAddressType() {
            return receiverAddressType;
        }

        public void setReceiverAddressType(String receiverAddressType) {
            this.receiverAddressType = receiverAddressType;
        }

        public String getReceiverId() {
            return receiverId;
        }

        public void setReceiverId(String receiverId) {
            this.receiverId = receiverId;
        }

        public String getReceiverIdType() {
            return receiverIdType;
        }

        public void setReceiverIdType(String receiverIdType) {
            this.receiverIdType = receiverIdType;
        }

        public String getReceiverNature() {
            return receiverNature;
        }

        public void setReceiverNature(String receiverNature) {
            this.receiverNature = receiverNature;
        }

        public String getApplicationId() {
            return applicationId;
        }

        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }

        public String getCustomerJourneyId() {
            return customerJourneyId;
        }

        public void setCustomerJourneyId(String customerJourneyId) {
            this.customerJourneyId = customerJourneyId;
        }

        public String getApplicationUseCase() {
            return applicationUseCase;
        }

        public void setApplicationUseCase(String applicationUseCase) {
            this.applicationUseCase = applicationUseCase;
        }

        public String getMsgReference() {
            return msgReference;
        }

        public void setMsgReference(String msgReference) {
            this.msgReference = msgReference;
        }

        public String getStartDiffusionDate() {
            return startDiffusionDate;
        }

        public void setStartDiffusionDate(String startDiffusionDate) {
            this.startDiffusionDate = startDiffusionDate;
        }

        public String getReceiverPreferences() {
            return receiverPreferences;
        }

        public void setReceiverPreferences(String receiverPreferences) {
            this.receiverPreferences = receiverPreferences;
        }

        public String getMultiChannel() {
            return multiChannel;
        }

        public void setMultiChannel(String multiChannel) {
            this.multiChannel = multiChannel;
        }

        public List<NotificationEventVariable> getVariablesList() {
            return variablesList;
        }

        public void setVariablesList(List<NotificationEventVariable> variablesList) {
            this.variablesList = variablesList;
        }

        public String getChannelsList() {
            return channelsList;
        }

        public void setChannelsList(String channelsList) {
            this.channelsList = channelsList;
        }

        public boolean isSecureMessage() {
            return secureMessage;
        }

        public void setSecureMessage(boolean secureMessage) {
            this.secureMessage = secureMessage;
        }

        public String getNotificationInternalId() {
            return notificationInternalId;
        }

        public void setNotificationInternalId(String notificationInternalId) {
            this.notificationInternalId = notificationInternalId;
        }

}
