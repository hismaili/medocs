/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification;

/**
 * @author c65344
 *
 */
public class NotificationException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public NotificationException() {
		super();

	}

	/**
	 * @param message
	 */
	public NotificationException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public NotificationException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public NotificationException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public NotificationException(Throwable cause) {
		super(cause);

	}

}
