package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file;

import java.time.LocalDate;

public class IncorrectHeaderException extends FileValidationException {

    private String code;

    public IncorrectHeaderException(String code, String message, String fileName, LocalDate fileDate, String errorMessage) {
        super(message, code, fileName, fileDate, errorMessage);
        this.code = code;
    }
}
