/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcApiError;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcResponseError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @author c65344
 *
 */
@Component
public class BuilderResponseSmc {

	private static final Logger LOG = LoggerFactory.getLogger(BuilderResponseSmc.class);
	private static final String STRING = " : ";
	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$

	private static final String ERROR = "ERREUR INTERNE DU SERVEUR"; //$NON-NLS-1$

	private static final String NULLVALUE = null;
	private static final String FORMATINCORRECT = "FORMAT INCORRECTE";



	@Autowired
	private transient ControlBuilder control;

	@Autowired
	private transient ConfigExposition conf;

	/**
	 * renvoie la liste des données absent lorque le corps de l'editique est null
	 *
	 * @param headers
	 * @return
	 */
	public ResponseEntity getErrorBodyAbsentEditique(HttpHeaders headers,List<String> missingDatasNoUI){
		List<String> missingDatasUI = new ArrayList<String>();

		missingDatasNoUI.addAll(control.checkMandatoryNoUI(NULLVALUE, NULLVALUE, NULLVALUE, NULLVALUE, NULLVALUE, NULLVALUE, NULLVALUE));
		missingDatasUI.addAll(control.checkMandatoryUI(NULLVALUE, NULLVALUE, NULLVALUE, null));

		if(headers !=null && !headers.isEmpty()){
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatasNoUI),
					new SmcApiError(conf.getCodeAbsentDonneUI(), conf.getErrorGeneriqueAbsent(), missingDatasUI))
					),headers,HttpStatus.BAD_REQUEST);
		}else{
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatasNoUI),
					new SmcApiError(conf.getCodeAbsentDonneUI(), conf.getErrorGeneriqueAbsent(), missingDatasUI))
					),HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 *
	 * Verifie la liste des erreurs et renvoi l'erreur correspondante
	 *
	 * @param formatErrors
	 * @param missingDatasUI
	 * @param missingDatasNoUI
	 * @return
	 */
	public SmcResponseError getResponseSmcError(List<String> formatErrors,List<String> missingDatasUI,List<String> missingDatasNoUI,List<String> dataIncorrect){

		SmcResponseError smcResponseError = new SmcResponseError();
		List<SmcApiError> errorSmc = new ArrayList<>();

		Map<String,List<String>> errors = new HashMap<String,List<String>>();

		errors.put(conf.getCodeFormatIncorrect(), formatErrors);
		errors.put(conf.getCodeAbsentDonne(), missingDatasNoUI);
		errors.put(conf.getCodeAbsentDonneUI(), missingDatasUI);
		errors.put(conf.getCodeDonneIncorrect(), dataIncorrect);


		errors.entrySet().stream().filter(error -> !CollectionUtils.isEmpty(error.getValue())).forEach(obj -> {


			if(obj.getKey().equals(conf.getCodeFormatIncorrect())){


				errorSmc.add(new SmcApiError(conf.getCodeFormatIncorrect(), FORMATINCORRECT, obj.getValue()));
			}

			if(obj.getKey().equals(conf.getCodeAbsentDonne())){
				errorSmc.add(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), obj.getValue()));
			}

			if(obj.getKey().equals(conf.getCodeAbsentDonneUI())){
				errorSmc.add(new SmcApiError(conf.getCodeAbsentDonneUI(), conf.getErrorGeneriqueAbsent(), obj.getValue()));
			}

			if(obj.getKey().equals(conf.getCodeDonneIncorrect())){
				errorSmc.add(new SmcApiError(conf.getCodeDonneIncorrect(), conf.getErrorGeneriqueIncorect(), obj.getValue()));
			}
		});

		if(!CollectionUtils.isEmpty(errorSmc)){
			smcResponseError.setErrors(errorSmc);
		}
		return smcResponseError;

	}




	/**
	 * recupère L'id ou l'identifiant de la reponse du système d'archivage
	 * @param documentId
	 * @return
	 */
	public ResponseEntity responseSuccess(String documentId){

		return new ResponseEntity(new ArchivageResponse(documentId), HttpStatus.OK);
	}
}
