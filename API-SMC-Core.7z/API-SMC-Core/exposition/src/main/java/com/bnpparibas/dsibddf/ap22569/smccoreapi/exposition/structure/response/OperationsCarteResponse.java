package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.util.List;
/**
 *
 *
 *
 */
public class OperationsCarteResponse {

	/**
	 *
	 */
	private static final long serialVersionUID = -2795942589131905384L;
	private List<OperationVO> operations;
	/**
	 *
	 * @return
	 */
	public List<OperationVO> getOperations() {
		return operations;
	}
	/**
	 *
	 * @param operations
	 */
	public void setOperations(List<OperationVO> operations) {
		this.operations = operations;
	}
}
