package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Contenu du message recu en REST au format Json pour le service de generation du PDF
 */
@ApiModel(description = "Contenu du message recu en REST au format Json pour le service de generation du PDF")
public class GeneratePDFRequest   {
	@ApiModelProperty(required = true, value = "maquette")
	private GeneratePDFRequestMaquetteDef maquette;

	/**
	 *
	 */
	public GeneratePDFRequest() {
		super();

	}

	/**
	 * @param maquette
	 */
	public GeneratePDFRequest(GeneratePDFRequestMaquetteDef maquette) {
		this.maquette = maquette;
	}

	/**
	 * @return the maquette
	 */
	public GeneratePDFRequestMaquetteDef getMaquette() {
		return maquette;
	}

	/**
	 * @param maquette the maquette to set
	 */
	public void setMaquette(GeneratePDFRequestMaquetteDef maquette) {
		this.maquette = maquette;
	}


}

