package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.ICardRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

import static org.junit.Assert.fail;


@RunWith(SpringRunner.class)
@EntityScan(basePackages = {
        "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
        "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons" })
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
public class CardRepositoryTest {

    private static final Logger LOG = LoggerFactory.getLogger(CardRepositoryTest.class);

    @Autowired
    private ICardRepository cardRepository;

    @Test
    public void testGetAnonymizedCards() {
        try {
            this.cardRepository.getAnonymizedCards(Arrays.asList("300040128400001237118", "300040112500000720183", "300040083200003375429"));
        } catch (CardException e) {
            LOG.error(e.getMessage(),e);
            fail();
        }
    }
}