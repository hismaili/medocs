package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureDataJpa;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author 472957
 *
 */
@SpringBootConfiguration
@EnableAspectJAutoProxy
@AutoConfigureDataJpa
@EnableJpaRepositories("com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.*")
@EntityScan("com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.*")
@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.application",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.domain"}, lazyInit = true)
@EnableTransactionManagement
@Profile("test-int")
public class IntegrationTestConf {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		SpringApplication.run(IntegrationTestConf.class, args);
	}

	@Bean(name="transactionManager")
	public PlatformTransactionManager jpaTransactionManager() {
		return new JpaTransactionManager();
	}
}
