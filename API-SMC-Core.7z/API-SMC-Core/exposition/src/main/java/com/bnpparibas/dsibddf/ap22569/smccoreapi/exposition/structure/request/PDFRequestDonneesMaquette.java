package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * les données qui vont constituer le courrier. Selon le modèle courrier certaines données peuvent être obligatoires ou non. Les champs spécifiés required doivent toujours être renseignés.
 */
@ApiModel(description = "les données qui vont constituer le courrier. Selon le modèle courrier certaines données peuvent être obligatoires ou non. Les champs spécifiés required doivent toujours être renseignés.")
public class PDFRequestDonneesMaquette   {

	@ApiModelProperty(required = true)
	@JsonProperty("numeroCarte")
	private String numeroCarte;

	@JsonProperty("dateTraitement")
	private String dateTraitement;

	@JsonProperty("iup")
	private String idUser;

	@JsonProperty("qualificationDossier")
	private String qualificationDossier;

	@JsonProperty("natureDossier")
	private String natureDossier;

	@JsonProperty("libNatureDossier")
	private String natureDossierLibelle;


	@JsonProperty("numDossier")
	private String numDossier;

	@JsonProperty("dateAppel")
	private String dateAppel;

	@JsonProperty("numeroTelEmetteur")
	private String telephoneEmet;

	@JsonProperty("raisonSociale")
	private String raisonSociale;

	@JsonProperty("emailEmetteur")
	private String emailEmet;

	@JsonProperty("delaisReponse")
	private int delaisReponse;

	@JsonProperty("dateMiseOpposition")
	private String dateOpposition;

	@JsonProperty("totalOperations")
	private int totalOperations;

	@JsonProperty("codChefFileEmetteur")
	private String codeChefdefileemet;

	@JsonProperty("cntctEmetteur")
	private String contactEmet;

	@JsonProperty("faxEmetteur")
	private String faxEmet;

	@JsonProperty("codChefFileDest")
	private String codeChefdefiledest;

	@JsonProperty("cntctDest")
	private String contactDest;

	@JsonProperty("telDestntr")
	private String telephoneDest;

	@JsonProperty("faxDestntr")
	private String faxDest;

	@JsonProperty("emailDestntr")
	private String emailDest;

	@JsonProperty("typOpeContest")
	private String typeOperation;

	@JsonProperty("codeBanqueMmbrPrincipActr")
	private String codebanqueMempracc;

	@JsonProperty("codeBanqueDomiciliatr")
	private String codebanqueDom;

	@JsonProperty("numDistributr")
	private String numDistributeur;

	@JsonProperty("locDeptmt")
	private String locDepart;

	@JsonProperty("codeBanqueMmbrPrincipTitulr")
	private String codebanqueMemprtit;

	@JsonProperty("numCarteMask")
	private String numCarteMasque;

	@JsonProperty("codMotifImpay")
	private String codeMotifipaye;

	@JsonProperty("mntCmpnse")
	private String montantCompense;

	@JsonProperty("datHrTrnsct")
	private String dateheureTransaction;

	@JsonProperty("datRgltInitial")
	private String dateReglmntinitial;

	@JsonProperty("Autres")
	private String autresDonnees;

	@JsonProperty("typRglmntSouhait")
	private String typeReglmntsouhaite;

	@JsonProperty("numSiret")
	private String numSiret;

	@JsonProperty("codApe")
	private String codeApe;

	@JsonProperty("datRglmntImpay")
	private String dateRglmntimpaye;

	@JsonProperty("datRglmntRepres")
	private String dateRglmntrepres;

	@JsonProperty("refArchvg")
	private String referenceArchivage;

	@JsonProperty("Montantbrut")
	private String montantBrut;

	@JsonProperty("numClient")
	private String numClient;

	@JsonProperty("dtRefArchiv")
	private String dateCreationSmc;

	@JsonProperty("montantContest")
	private String montantConteste;

	@JsonProperty("nbOperations")
	private int nombreOperations;

	@ApiModelProperty(required = true)
	@JsonProperty("adrRetour")
	private String adrRetour;

	@JsonProperty("nomService")
	private String nomService;

	@JsonProperty("libTypeDoc")
	private String libTypeDoc;

	@JsonProperty("codeTypeDoc")
	private String codeTypeDoc;

	@JsonProperty("Coment")
	private List<String> coment;

	@JsonProperty("postScriptum")
	private List<String> postScriptum;

	@JsonProperty("detailsOperations")
	private List<DetailOperation> detailsOperations;

	@JsonProperty("champsLibres")
	private List<PDFRequestDonneesMaquetteChampsLibres> champsLibres;

	/**
	 * @return the adrRetour
	 */
	public String getAdrRetour() {
		return adrRetour;
	}

	/**
	 * @return the autresDonnees
	 */
	public String getAutresDonnees() {
		return autresDonnees;
	}

	/**
	 * @return the champsLibres
	 */
	public List<PDFRequestDonneesMaquetteChampsLibres> getChampsLibres() {
		return champsLibres;
	}

	/**
	 * @return the codeApe
	 */
	public String getCodeApe() {
		return codeApe;
	}

	/**
	 * @return the codebanqueDom
	 */
	public String getCodebanqueDom() {
		return codebanqueDom;
	}

	/**
	 * @return the codebanqueMempracc
	 */
	public String getCodebanqueMempracc() {
		return codebanqueMempracc;
	}

	/**
	 * @return the codebanqueMemprtit
	 */
	public String getCodebanqueMemprtit() {
		return codebanqueMemprtit;
	}

	/**
	 * @return the codeChefdefiledest
	 */
	public String getCodeChefdefiledest() {
		return codeChefdefiledest;
	}

	/**
	 * @return the codeChefdefileemet
	 */
	public String getCodeChefdefileemet() {
		return codeChefdefileemet;
	}

	/**
	 * @return the codeMotifipaye
	 */
	public String getCodeMotifipaye() {
		return codeMotifipaye;
	}

	/**
	 * @return the codeTypeDoc
	 */
	public String getCodeTypeDoc() {
		return codeTypeDoc;
	}

	/**
	 * @return the coment
	 */
	public List<String> getComent() {
		return coment;
	}

	/**
	 * @return the contactDest
	 */
	public String getContactDest() {
		return contactDest;
	}

	/**
	 * @return the contactEmet
	 */
	public String getContactEmet() {
		return contactEmet;
	}

	/**
	 * @return the dateAppel
	 */
	public String getDateAppel() {
		return dateAppel;
	}



	/**
	 * @return the dateCreationSmc
	 */
	public String getDateCreationSmc() {
		return dateCreationSmc;
	}

	/**
	 * @return the dateheureTransaction
	 */
	public String getDateheureTransaction() {
		return dateheureTransaction;
	}

	/**
	 * @return the dateOpposition
	 */
	public String getDateOpposition() {
		return dateOpposition;
	}

	/**
	 * @return the dateReglmntinitial
	 */
	public String getDateReglmntinitial() {
		return dateReglmntinitial;
	}

	/**
	 * @return the dateRglmntimpaye
	 */
	public String getDateRglmntimpaye() {
		return dateRglmntimpaye;
	}

	/**
	 * @return the dateRglmntrepres
	 */
	public String getDateRglmntrepres() {
		return dateRglmntrepres;
	}

	/**
	 * @return the dateTraitement
	 */
	public String getDateTraitement() {
		return dateTraitement;
	}

	/**
	 * @return the delaisReponse
	 */
	public int getDelaisReponse() {
		return delaisReponse;
	}

	/**
	 * @return the detailsOperations
	 */
	public List<DetailOperation> getDetailsOperations() {
		return detailsOperations;
	}

	/**
	 * @return the emailDest
	 */
	public String getEmailDest() {
		return emailDest;
	}

	/**
	 * @return the emailEmet
	 */
	public String getEmailEmet() {
		return emailEmet;
	}

	/**
	 * @return the faxDest
	 */
	public String getFaxDest() {
		return faxDest;
	}

	/**
	 * @return the faxEmet
	 */
	public String getFaxEmet() {
		return faxEmet;
	}

	/**
	 * @return the idUser
	 */
	public String getIdUser() {
		return idUser;
	}

	/**
	 * @return the libTypeDoc
	 */
	public String getLibTypeDoc() {
		return libTypeDoc;
	}

	/**
	 * @return the locDepart
	 */
	public String getLocDepart() {
		return locDepart;
	}

	/**
	 * @return the montantBrut
	 */
	public String getMontantBrut() {
		return montantBrut;
	}

	/**
	 * @return the montantCompense
	 */
	public String getMontantCompense() {
		return montantCompense;
	}

	/**
	 * @return the montantConteste
	 */
	public String getMontantConteste() {
		return montantConteste;
	}

	/**
	 * @return the natureDossier
	 */
	public String getNatureDossier() {
		return natureDossier;
	}

	/**
	 * @return the natureDossierLibelle
	 */
	public String getNatureDossierLibelle() {
		return natureDossierLibelle;
	}

	/**
	 * @return the nombreOperations
	 */
	public int getNombreOperations() {
		return nombreOperations;
	}

	/**
	 * @return the nomService
	 */
	public String getNomService() {
		return nomService;
	}

	/**
	 * @return the numCarteMasque
	 */
	public String getNumCarteMasque() {
		return numCarteMasque;
	}

	/**
	 * @return the numClient
	 */
	public String getNumClient() {
		return numClient;
	}

	/**
	 * @return the numDistributeur
	 */
	public String getNumDistributeur() {
		return numDistributeur;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the numeroCarte
	 */
	public String getNumeroCarte() {
		return numeroCarte;
	}

	/**
	 * @return the numSiret
	 */
	public String getNumSiret() {
		return numSiret;
	}

	/**
	 * @return the postScriptum
	 */
	public List<String> getPostScriptum() {
		return postScriptum;
	}

	/**
	 * @return the qualificationDossier
	 */
	public String getQualificationDossier() {
		return qualificationDossier;
	}

	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}

	/**
	 * @return the referenceArchivage
	 */
	public String getReferenceArchivage() {
		return referenceArchivage;
	}

	/**
	 * @return the telephoneDest
	 */
	public String getTelephoneDest() {
		return telephoneDest;
	}

	/**
	 * @return the telephoneEmet
	 */
	public String getTelephoneEmet() {
		return telephoneEmet;
	}

	/**
	 * @return the totalOperations
	 */
	public int getTotalOperations() {
		return totalOperations;
	}

	/**
	 * @return the typeOperation
	 */
	public String getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @return the typeReglmntsouhaite
	 */
	public String getTypeReglmntsouhaite() {
		return typeReglmntsouhaite;
	}

	/**
	 * @param adrRetour the adrRetour to set
	 */
	public void setAdrRetour(String adrRetour) {
		this.adrRetour = adrRetour;
	}

	/**
	 * @param autresDonnees the autresDonnees to set
	 */
	public void setAutresDonnees(String autresDonnees) {
		this.autresDonnees = autresDonnees;
	}

	/**
	 * @param champsLibres the champsLibres to set
	 */
	public void setChampsLibres(
			List<PDFRequestDonneesMaquetteChampsLibres> champsLibres) {
		this.champsLibres = champsLibres;
	}

	/**
	 * @param codeApe the codeApe to set
	 */
	public void setCodeApe(String codeApe) {
		this.codeApe = codeApe;
	}

	/**
	 * @param codebanqueDom the codebanqueDom to set
	 */
	public void setCodebanqueDom(String codebanqueDom) {
		this.codebanqueDom = codebanqueDom;
	}

	/**
	 * @param codebanqueMempracc the codebanqueMempracc to set
	 */
	public void setCodebanqueMempracc(String codebanqueMempracc) {
		this.codebanqueMempracc = codebanqueMempracc;
	}

	/**
	 * @param codebanqueMemprtit the codebanqueMemprtit to set
	 */
	public void setCodebanqueMemprtit(String codebanqueMemprtit) {
		this.codebanqueMemprtit = codebanqueMemprtit;
	}

	/**
	 * @param codeChefdefiledest the codeChefdefiledest to set
	 */
	public void setCodeChefdefiledest(String codeChefdefiledest) {
		this.codeChefdefiledest = codeChefdefiledest;
	}

	/**
	 * @param codeChefdefileemet the codeChefdefileemet to set
	 */
	public void setCodeChefdefileemet(String codeChefdefileemet) {
		this.codeChefdefileemet = codeChefdefileemet;
	}

	/**
	 * @param codeMotifipaye the codeMotifipaye to set
	 */
	public void setCodeMotifipaye(String codeMotifipaye) {
		this.codeMotifipaye = codeMotifipaye;
	}

	/**
	 * @param codeTypeDoc the codeTypeDoc to set
	 */
	public void setCodeTypeDoc(String codeTypeDoc) {
		this.codeTypeDoc = codeTypeDoc;
	}

	/**
	 * @param coment the coment to set
	 */
	public void setComent(List<String> coment) {
		this.coment = coment;
	}

	/**
	 * @param contactDest the contactDest to set
	 */
	public void setContactDest(String contactDest) {
		this.contactDest = contactDest;
	}

	/**
	 * @param contactEmet the contactEmet to set
	 */
	public void setContactEmet(String contactEmet) {
		this.contactEmet = contactEmet;
	}



	/**
	 * @param dateAppel the dateAppel to set
	 */
	public void setDateAppel(String dateAppel) {
		this.dateAppel = dateAppel;
	}

	/**
	 * @param dateCreationSmc the dateCreationSmc to set
	 */
	public void setDateCreationSmc(String dateCreationSmc) {
		this.dateCreationSmc = dateCreationSmc;
	}

	/**
	 * @param dateheureTransaction the dateheureTransaction to set
	 */
	public void setDateheureTransaction(String dateheureTransaction) {
		this.dateheureTransaction = dateheureTransaction;
	}

	/**
	 * @param dateOpposition the dateOpposition to set
	 */
	public void setDateOpposition(String dateOpposition) {
		this.dateOpposition = dateOpposition;
	}

	/**
	 * @param dateReglmntinitial the dateReglmntinitial to set
	 */
	public void setDateReglmntinitial(String dateReglmntinitial) {
		this.dateReglmntinitial = dateReglmntinitial;
	}

	/**
	 * @param dateRglmntimpaye the dateRglmntimpaye to set
	 */
	public void setDateRglmntimpaye(String dateRglmntimpaye) {
		this.dateRglmntimpaye = dateRglmntimpaye;
	}

	/**
	 * @param dateRglmntrepres the dateRglmntrepres to set
	 */
	public void setDateRglmntrepres(String dateRglmntrepres) {
		this.dateRglmntrepres = dateRglmntrepres;
	}

	/**
	 * @param dateTraitement the dateTraitement to set
	 */
	public void setDateTraitement(String dateTraitement) {
		this.dateTraitement = dateTraitement;
	}

	/**
	 * @param delaisReponse the delaisReponse to set
	 */
	public void setDelaisReponse(int delaisReponse) {
		this.delaisReponse = delaisReponse;
	}

	/**
	 * @param detailsOperations the detailsOperations to set
	 */
	public void setDetailsOperations(List<DetailOperation> detailsOperations) {
		this.detailsOperations = detailsOperations;
	}

	/**
	 * @param emailDest the emailDest to set
	 */
	public void setEmailDest(String emailDest) {
		this.emailDest = emailDest;
	}

	/**
	 * @param emailEmet the emailEmet to set
	 */
	public void setEmailEmet(String emailEmet) {
		this.emailEmet = emailEmet;
	}

	/**
	 * @param faxDest the faxDest to set
	 */
	public void setFaxDest(String faxDest) {
		this.faxDest = faxDest;
	}

	/**
	 * @param faxEmet the faxEmet to set
	 */
	public void setFaxEmet(String faxEmet) {
		this.faxEmet = faxEmet;
	}

	/**
	 * @param idUser the idUser to set
	 */
	public void setIdUser(String idUser) {
		this.idUser = idUser;
	}

	/**
	 * @param libTypeDoc the libTypeDoc to set
	 */
	public void setLibTypeDoc(String libTypeDoc) {
		this.libTypeDoc = libTypeDoc;
	}

	/**
	 * @param locDepart the locDepart to set
	 */
	public void setLocDepart(String locDepart) {
		this.locDepart = locDepart;
	}

	/**
	 * @param montantBrut the montantBrut to set
	 */
	public void setMontantBrut(String montantBrut) {
		this.montantBrut = montantBrut;
	}

	/**
	 * @param montantCompense the montantCompense to set
	 */
	public void setMontantCompense(String montantCompense) {
		this.montantCompense = montantCompense;
	}

	/**
	 * @param montantConteste the montantConteste to set
	 */
	public void setMontantConteste(String montantConteste) {
		this.montantConteste = montantConteste;
	}

	/**
	 * @param natureDossier the natureDossier to set
	 */
	public void setNatureDossier(String natureDossier) {
		this.natureDossier = natureDossier;
	}

	/**
	 * @param natureDossierLibelle the natureDossierLibelle to set
	 */
	public void setNatureDossierLibelle(String natureDossierLibelle) {
		this.natureDossierLibelle = natureDossierLibelle;
	}

	/**
	 * @param nombreOperations the nombreOperations to set
	 */
	public void setNombreOperations(int nombreOperations) {
		this.nombreOperations = nombreOperations;
	}

	/**
	 * @param nomService the nomService to set
	 */
	public void setNomService(String nomService) {
		this.nomService = nomService;
	}

	/**
	 * @param numCarteMasque the numCarteMasque to set
	 */
	public void setNumCarteMasque(String numCarteMasque) {
		this.numCarteMasque = numCarteMasque;
	}

	/**
	 * @param numClient the numClient to set
	 */
	public void setNumClient(String numClient) {
		this.numClient = numClient;
	}

	/**
	 * @param numDistributeur the numDistributeur to set
	 */
	public void setNumDistributeur(String numDistributeur) {
		this.numDistributeur = numDistributeur;
	}

	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}

	/**
	 * @param numeroCarte the numeroCarte to set
	 */
	public void setNumeroCarte(String numeroCarte) {
		this.numeroCarte = numeroCarte;
	}

	/**
	 * @param numSiret the numSiret to set
	 */
	public void setNumSiret(String numSiret) {
		this.numSiret = numSiret;
	}

	/**
	 * @param postScriptum the postScriptum to set
	 */
	public void setPostScriptum(List<String> postScriptum) {
		this.postScriptum = postScriptum;
	}



	/**
	 * @param qualificationDossier the qualificationDossier to set
	 */
	public void setQualificationDossier(String qualificationDossier) {
		this.qualificationDossier = qualificationDossier;
	}

	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}

	/**
	 * @param referenceArchivage the referenceArchivage to set
	 */
	public void setReferenceArchivage(String referenceArchivage) {
		this.referenceArchivage = referenceArchivage;
	}

	/**
	 * @param telephoneDest the telephoneDest to set
	 */
	public void setTelephoneDest(String telephoneDest) {
		this.telephoneDest = telephoneDest;
	}


	/**
	 * @param telephoneEmet the telephoneEmet to set
	 */
	public void setTelephoneEmet(String telephoneEmet) {
		this.telephoneEmet = telephoneEmet;
	}


	/**
	 * @param totalOperations the totalOperations to set
	 */
	public void setTotalOperations(int totalOperations) {
		this.totalOperations = totalOperations;
	}

	/**
	 * @param typeOperation the typeOperation to set
	 */
	public void setTypeOperation(String typeOperation) {
		this.typeOperation = typeOperation;
	}

	/**
	 * @param typeReglmntsouhaite the typeReglmntsouhaite to set
	 */
	public void setTypeReglmntsouhaite(String typeReglmntsouhaite) {
		this.typeReglmntsouhaite = typeReglmntsouhaite;
	}




}

