package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.util.List;

public class HistoriqueContestationsResponse {

	/**
	 *
	 */
	private static final long serialVersionUID = 1496447940305121292L;
	private List<DisputeDetails> contestations;

	/**
	 *
	 */
	public HistoriqueContestationsResponse() {
		super();

	}

	/**
	 *
	 * @return
	 */
	public List<DisputeDetails> getContestations() {
		return contestations;
	}

	/**
	 *
	 * @param contestations
	 */
	public void setContestations(List<DisputeDetails> contestations) {
		this.contestations = contestations;
	}

}
