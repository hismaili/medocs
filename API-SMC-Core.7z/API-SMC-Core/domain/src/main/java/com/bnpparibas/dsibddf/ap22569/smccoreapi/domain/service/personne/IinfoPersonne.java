package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;




public interface IinfoPersonne {
	InfoPersonneOutput getInfoPersonneRP(String iKpi) throws PorteurException;

	PersonContactInfo getPersonContactInfos(String iKpi,String telematicId) throws PorteurException;
}
