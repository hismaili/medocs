/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * @author c65344
 *
 */
//@Transactional
@Repository
public interface OperationJpaRepository extends JpaRepository<OperationTmpEntity, String> {
	/**
	 * supprime les opérations par l' idTelematic et l'ikpi
	 *
	 * @param idTelematic
	 */
	@Transactional
	List<OperationTmpEntity> deleteByIdTelematicAndUserId(String idTelematic,String userId);

	/**
	 * suppression des opérations par numéro de carte
	 * @param numCarte
	 * @return
	 */
	@Transactional
	List<OperationTmpEntity> deleteByNumCarte(String numCarte);
	/**
	 * recupère une opération temporaire par son code
	 *
	 * @param codeOperation
	 * @return
	 */
	OperationTmpEntity findByCodeOperationAndUserIdAndIdTelematic(String codeOperation,String userId,String idTelematic);


	/**
	 * retrouve des opérations par son idTelematic et son IKPI
	 *
	 * @param idTelematic
	 */
	List<OperationTmpEntity> findByIdTelematicAndUserIdAndNumCarte(String idTelematic,String userId,String numCarte);
}
