/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

/**
 * @author c65344
 *
 */
public class ErrorInterneSmcException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String error;

	/**
	 *
	 */
	public ErrorInterneSmcException() {
		super();

	}

	/**
	 * @param error
	 */
	public ErrorInterneSmcException(String error) {
		this.error = error;
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ErrorInterneSmcException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ErrorInterneSmcException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public ErrorInterneSmcException(Throwable cause) {
		super(cause);

	}

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}
}
