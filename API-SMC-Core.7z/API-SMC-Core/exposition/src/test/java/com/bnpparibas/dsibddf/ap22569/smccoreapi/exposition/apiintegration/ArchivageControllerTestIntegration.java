package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.apiintegration;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IContestationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.ContestationMonetiqueApplication;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api.ArchivageController;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponseGetDoc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcResponseError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.tomcat.util.codec.binary.Base64;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;

/**
 *
 * @author c65344
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ContestationMonetiqueApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Profile("test-int")
public class ArchivageControllerTestIntegration {

	private static final Logger LOG = LoggerFactory.getLogger(ArchivageController.class);


	private static String dataPdfInBase64() {

		File file =  new File("src/test/resources/Test.pdf");

		String encodstring = encodeFileToBase64Binary(file);
		return encodstring;

	}

	private static String encodeFileToBase64Binary(File file){
		String encodedfile = null;
		try {
			FileInputStream fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int)file.length()];
			fileInputStreamReader.read(bytes);
			encodedfile = new String(Base64.encodeBase64(bytes), StandardCharsets.UTF_8);

		} catch (FileNotFoundException e) {
			LOG.error(e.getMessage(),e);
		} catch (IOException e) {
			LOG.error(e.getMessage(),e);
		}

		return encodedfile;
	}

	@Autowired
	private transient IContestationRepository contestationImpl;
	@Mock
	private transient ICardServicesManagement cardServicesManagement;


	@LocalServerPort
	private int port = 8080;

	@Autowired
	private TestRestTemplate restTemplate;



	@Test
	public void badRequestInCloseFolder(){

		String url = "http://localhost:" + port + "/v1/smc/archivage/folder/close";


		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");


		CloseFolderDTO closeFolderDTO = new CloseFolderDTO();
		closeFolderDTO.setDocsIdsGDN(Arrays.asList("GD11100jnlx2i0j000001mu","GD11100jnlx2i0j000001m5","GD11100jnlx2i0j000001m7"));
		closeFolderDTO.setArchivingReferenceDate("11/10/2018");
		closeFolderDTO.setTitre("Perte de carte");
		closeFolderDTO.setCallingUser("c65344");
		closeFolderDTO.setMimeType("application/pdf");
		closeFolderDTO.setDocumentTypeId("20180110");
		closeFolderDTO.setIdContestationSmc("29");


		Document document = new Document("Fichier", "PDF", new Objectsmc("none", "Base64", "xxxx"));

		closeFolderDTO.setDocument(document);
		ResponseEntity<SmcResponseError> response = null;
		HttpEntity<CloseFolderDTO> request = null;


		/**
		 * Liste des idDocuments absent
		 *
		 */
		closeFolderDTO.setDocsIdsGDN(null);


		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors().size()).isEqualTo(1);
		/**
		 * ArchivingReferenceDate Absent
		 */
		closeFolderDTO.setDocsIdsGDN(Arrays.asList("GD11100jnlx2i0j000001mu","GD11100jnlx2i0j000001m5","GD11100jnlx2i0j000001m7"));

		closeFolderDTO.setArchivingReferenceDate(null);

		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);

		/**
		 * ArchivingReferenceDate mauvais format
		 */
		closeFolderDTO.setDocsIdsGDN(Arrays.asList("GD11100jnlx2i0j000001mu","GD11100jnlx2i0j000001m5","GD11100jnlx2i0j000001m7"));

		closeFolderDTO.setArchivingReferenceDate("11-12-2018");

		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);

		/**
		 *
		 * Titre absent
		 *
		 */
		closeFolderDTO.setArchivingReferenceDate("11/10/2018");
		closeFolderDTO.setTitre(null);
		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);



		/**
		 * MimeType Absent
		 */
		closeFolderDTO.setTitre("Document a imprimer");
		closeFolderDTO.setMimeType(null);
		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);

		/**
		 * MimeType mauvais format
		 */
		closeFolderDTO.setCallingUser("c65344");
		closeFolderDTO.setMimeType("pdf");
		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);


		/**
		 *
		 * DocumentTypeId Absent
		 */
		closeFolderDTO.setMimeType("application/pdf");
		closeFolderDTO.setDocumentTypeId(null);

		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);


		/**
		 * DocumentTypeId mauvaise donnée
		 *
		 */
		closeFolderDTO.setDocumentTypeId("gsgshhjds");

		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);

		/**
		 * filename,archive-format,compress, encoding, data absent
		 *
		 */
		closeFolderDTO.setDocumentTypeId("20180110");
		document = null;
		closeFolderDTO.setDocument(document);

		request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() ==1);
		assertTrue(response.getBody().getErrors().get(0).getDetails().size() ==5);

	}

	/**
	 *
	 * @return
	 */
	public String  getDocumentID(){
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/new";

		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");

		Document document = new Document();

		document.setArchiveFormat("PDF");
		document.setFileName("Document Acrobat.");

		Objectsmc objectsmc = new Objectsmc();

		objectsmc.setCompress("none");
		objectsmc.setData(dataPdfInBase64());
		objectsmc.setEncoding("BASE64");

		document.setObject(objectsmc);


		NewDocDTO newDocDTO = new NewDocDTO();
		newDocDTO.setDocumentTypeId("20180110");
		newDocDTO.setMimeType("application/pdf");
		newDocDTO.setTitre("Test enreg puis modif");
		newDocDTO.setDocument(document);
		newDocDTO.setCallingUser("c65344");
		newDocDTO.setIdContestationSmc("01000002676300000");

		HttpEntity<NewDocDTO> request = new HttpEntity<NewDocDTO>(newDocDTO, header);

		ResponseEntity<ArchivageResponse> response = restTemplate.exchange(url, HttpMethod.POST, request, ArchivageResponse.class);


		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(response.getBody().getIdentifier()).isNotNull();

		return response.getBody().getIdentifier();
	}



	/**
	 *
	 *Bad request in deleteDoc but success
	 *
	 */
	@Test
	public void testBadRequestInDeleteDocSuccess() {
		String idDoc = "qdlgh";
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/delete/"+idDoc;


		/**
		 * calling user absent
		 */
		HttpHeaders header = new HttpHeaders();
		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");
		header.add("idContestationSmc", "255456");


		HttpEntity<String> request = new HttpEntity<String>(header);

		ResponseEntity<SmcResponseError> response = restTemplate.exchange(url, HttpMethod.DELETE, request, SmcResponseError.class);


		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getBody()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		Assertions.assertThat(response.getBody().getErrors().get(0)).isNotNull();
		assertTrue(response.getBody().getErrors().get(0).getDetails().size() == 1);

		/**
		 * canal ,codeApplication,idContestationSmc absent
		 */
		HttpHeaders header2 = new HttpHeaders();
		request = new HttpEntity<String>(header2);

		response = restTemplate.exchange(url, HttpMethod.DELETE, request, SmcResponseError.class);

		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getBody()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		Assertions.assertThat(response.getBody().getErrors().get(0)).isNotNull();
		assertTrue(response.getBody().getErrors().get(0).getDetails().size() == 4);

	}

	/**
	 *
	 */
	@Test
	public void testBadRequestInGetDoc(){

		/**
		 *  userType,callingUser absent
		 */
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/xxxxx?idContestationSmc=fgmmk14785";
		HeaderSmc headerSmc =  new HeaderSmc("code application appelante", " canal web");
		ObjectMapper mapper = new ObjectMapper();
		HttpHeaders header = new HttpHeaders();


		try {

			header.set("headerSmc", mapper.writeValueAsString(headerSmc));
			header.set("Accept", "application/json");

		} catch (JsonProcessingException e) {
			LOG.error(e.getMessage(), e);
			Assert.fail(e.getMessage());
		}


		HttpEntity<String> request = new HttpEntity<String>(header);

		ResponseEntity<SmcResponseError> response = restTemplate.exchange(url, HttpMethod.GET, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();

		Assertions.assertThat(response.getBody().getErrors().size() == 1).isTrue();
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 2 ).isTrue();


		/**
		 * userType,callingUser,canal, code application absent
		 */
		HeaderSmc headerSmc2 =  null;
		HttpHeaders header2 = new HttpHeaders();
		try {

			header2.set("head", mapper.writeValueAsString(headerSmc2));
			header2.set("Accept", "application/json");

		} catch (JsonProcessingException e) {
			LOG.error(e.getMessage(), e);
			Assert.fail(e.getMessage());
		}

		request = new HttpEntity<String>(header2);
		response = restTemplate.exchange(url, HttpMethod.GET, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors().size() == 1).isTrue();
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 4 ).isTrue();


	}

	@Test
	public void testBadRequestInNewDoc1(){
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/new";

		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");

		Document document = new Document();

		document.setArchiveFormat("PDF");
		document.setFileName("Document Acrobat.");

		Objectsmc objectsmc = new Objectsmc();

		objectsmc.setCompress("none");
		objectsmc.setData("xxxx");
		objectsmc.setEncoding("BASE64");

		document.setObject(objectsmc);

		ResponseEntity<SmcResponseError> response;
		HttpEntity<NewDocDTO> request ;
		NewDocDTO newDocDTO = new NewDocDTO();
		newDocDTO.setCallingUser("c65344");
		newDocDTO.setDocumentTypeId("20180110");
		newDocDTO.setMimeType("application/pdf");
		newDocDTO.setTitre("Test enreg puis modif");
		newDocDTO.setDocument(document);
		newDocDTO.setIdContestationSmc("84559");


		/**
		 * compress et encoding absent
		 */
		document.setFileName("Document Acrobat.");


		objectsmc.setCompress(null);
		objectsmc.setEncoding(null);
		document.setObject(objectsmc);

		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 2 ).isTrue();


		/**
		 * compress Absent
		 */
		objectsmc.setCompress(null);
		objectsmc.setEncoding("BASE64");
		document.setObject(objectsmc);
		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 1 ).isTrue();




		/**
		 * Encoding Absent
		 */
		objectsmc.setCompress("none");
		objectsmc.setEncoding(null);
		document.setObject(objectsmc);
		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 1).isTrue();





		/**
		 * Document physique Absent
		 */
		objectsmc.setEncoding("BASE64");
		objectsmc.setData(null);

		document.setObject(objectsmc);
		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() == 1 ).isTrue();

	}


	@Test
	public void testBadRequestInNewDoc2(){
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/new";

		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");

		Document document = new Document();

		document.setArchiveFormat("PDF");
		document.setFileName("Document Acrobat.");

		Objectsmc objectsmc = new Objectsmc();

		objectsmc.setCompress("none");
		objectsmc.setData("xxxxx");
		objectsmc.setEncoding("BASE64");

		document.setObject(objectsmc);

		ResponseEntity<SmcResponseError> response;
		HttpEntity<NewDocDTO> request ;
		NewDocDTO newDocDTO = new NewDocDTO();
		newDocDTO.setCallingUser("c65344");
		newDocDTO.setDocumentTypeId("20180110");
		newDocDTO.setMimeType("application/pdf");
		newDocDTO.setTitre("Test enreg puis modif");
		newDocDTO.setDocument(document);
		newDocDTO.setIdContestationSmc("84559");





		/**
		 * All Data absent
		 */

		request = new HttpEntity<NewDocDTO>(new NewDocDTO(), header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0) !=null);
		assertTrue(response.getBody().getErrors().get(0).getDetails() !=null);
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size() >= 2).isTrue();


		/**
		 * MimeType Absent
		 */
		newDocDTO.setMimeType(null);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);




		/**
		 * Titre Absent
		 */
		newDocDTO.setMimeType("application/pdf");
		newDocDTO.setTitre(null);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);




		/**
		 * DocumentTypeId Absent
		 */
		newDocDTO.setTitre("Test enreg puis modif");
		newDocDTO.setDocumentTypeId(null);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);



		/**
		 * Bad DocumentTypeId{Value Allowed : (20180110:Lettre Contestation monétique, 20180111:Justificatifs client)}
		 */
		newDocDTO.setDocumentTypeId("8888");
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);




		/**
		 * archive-format absent
		 */
		newDocDTO.setDocumentTypeId("20180110");

		document.setArchiveFormat(null);

		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);





		/**
		 * FileName absent
		 */
		document.setArchiveFormat("PDF");
		document.setFileName(null);
		newDocDTO.setDocument(document);
		request = new HttpEntity<NewDocDTO>(newDocDTO, header);
		response = restTemplate.exchange(url, HttpMethod.POST, request, SmcResponseError.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotEmpty();
		assertTrue(response.getBody().getErrors().size() == 1);

	}



	/**
	 *
	 */
	@Test
	public void testCloseFolderSuccess() {

		String url = "http://localhost:" + port + "/v1/smc/archivage/folder/close";

		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");

		CloseFolderDTO closeFolderDTO = new CloseFolderDTO();
		closeFolderDTO.setDocsIdsGDN(Arrays.asList("GD11100jnlx2i0j000001mu","GD11100jnlx2i0j000001m5","GD11100jnlx2i0j000001m7"));

		closeFolderDTO.setArchivingReferenceDate("11/10/2018");
		closeFolderDTO.setCallingUser("c65344");

		closeFolderDTO.setIdContestationSmc("NUMDOSSIER044");

		Document document = new Document();

		document.setArchiveFormat("PDF");
		document.setFileName("Document Acrobat.");

		Objectsmc objectsmc = new Objectsmc();

		objectsmc.setCompress("none");
		objectsmc.setData(dataPdfInBase64());
		objectsmc.setEncoding("BASE64");

		document.setObject(objectsmc);



		closeFolderDTO.setDocumentTypeId("20180110");
		closeFolderDTO.setMimeType("application/pdf");
		closeFolderDTO.setTitre("Test enreg puis modif");
		closeFolderDTO.setDocument(document);
		closeFolderDTO.setCallingUser("c65344");

		HttpEntity<CloseFolderDTO> request = new HttpEntity<CloseFolderDTO>(closeFolderDTO, header);
		ResponseEntity<ArchivageResponse> response = restTemplate.exchange(url, HttpMethod.POST, request, ArchivageResponse.class);

		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getStatusCode()).isNotNull();
		assertTrue(response.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(response.getBody().getIdentifier()).isNotNull();


	}

	/**
	 *
	 * @param documentId
	 */
	private void testDeleteDocSuccess(String documentId) {

		HttpHeaders header = new HttpHeaders();
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/delete/"+documentId;


		/**
		 * calling user absent
		 */
		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");
		header.add("idContestationSmc", "255456");
		header.add("callingUser", "c65344");


		HttpEntity<String> request = new HttpEntity<String>(header);

		ResponseEntity<ArchivageResponse> response = restTemplate.exchange(url, HttpMethod.DELETE, request, ArchivageResponse.class);


		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getIdentifier()).isNotNull();
		assertTrue(response.getStatusCode().is2xxSuccessful());
	}




	/**
	 *
	 * @param documentId
	 */
	private void testGetDocSuccess(String documentId) {
		/**
		 *  userType,callingUser absent
		 */
		String url = "http://localhost:" + port + "/v1/smc/archivage/document/"+documentId+"?idContestationSmc=fgmmk14785";
		HeaderSmc headerSmc =  new HeaderSmc("code application appelante", " canal web");
		ObjectMapper mapper = new ObjectMapper();
		HttpHeaders header = new HttpHeaders();
		header.add("callingUser", "c65344");
		header.add("userType", "c65344");




		try {

			header.set("headerSmc", mapper.writeValueAsString(headerSmc));
			header.set("Accept", "application/json");

		} catch (JsonProcessingException e) {
			LOG.error(e.getMessage(), e);
			Assert.fail(e.getMessage());
		}


		HttpEntity<String> request = new HttpEntity<String>(header);

		ResponseEntity<ArchivageResponseGetDoc> response = restTemplate.exchange(url, HttpMethod.GET, request, ArchivageResponseGetDoc.class);
		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getBody().getDocument()).isNotNull();
		Assertions.assertThat(response.getBody().getDocument().getObject()).isNotNull();
		Assertions.assertThat(response.getBody().getDocument().getObject().getData()).isNotNull();
		assertTrue(response.getStatusCode().is2xxSuccessful());
	}

	/**
	 *
	 * @param idDocument
	 */
	private void testNewDocSuccess(String idDocument) {

		Assertions.assertThat(idDocument).isNotNull();
	}


	@Test
	public void testPugeFolderSuccess() throws ContestationException{
		String url = "http://localhost:" + port + "/v1/smc/archivage/folder/purge";

		HttpHeaders header = new HttpHeaders();

		header.add("canal", "canal web");
		header.add("codeApplication", "ap22569");

		PurgeFolderDTO purgeFolderDTO = new PurgeFolderDTO();

		purgeFolderDTO.setListeIdContestations(Arrays.asList("NUMDOSSIER045","NUMDOSSIER044"));

		HttpEntity<PurgeFolderDTO> request = new HttpEntity<PurgeFolderDTO>(purgeFolderDTO, header);

		ResponseEntity<ArchivageResponse> response = restTemplate.exchange(url, HttpMethod.POST, request, ArchivageResponse.class);

		Assertions.assertThat(response).isNotNull();
		Assertions.assertThat(response.getBody().getIdentifier()).isNotNull();
		assertTrue(response.getStatusCode().is2xxSuccessful());



	}

	/**
	 *
	 */
	@Test
	public void testScenarioNewDocGetDocDeleteDocSuccess(){
		String idDocument =  getDocumentID();
		testNewDocSuccess(idDocument);
		testGetDocSuccess(idDocument);
		testDeleteDocSuccess(idDocument);
	}



}
