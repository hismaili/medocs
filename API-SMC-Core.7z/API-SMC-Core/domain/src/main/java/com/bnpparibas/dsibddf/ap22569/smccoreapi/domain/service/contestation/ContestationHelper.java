package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;


import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcError;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Component
public final class ContestationHelper {

    /**
     * Validation des inputs nécessaire à la création d'une contestation
     *
     * @param input
     * @return
     */
    public boolean isValidInput(ContestationSelfcareIn input) throws ContestationValidationException {


        //TODO : traiter le cas des whitespaces
        List<SmcError> errors = new ArrayList<>();
        // Validation des champs obligatoires
        if(input == null) {
            errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[paramètres d'entrée]")));
        } else {
            if (StringUtils.isEmpty(input.getNumeroCarte())) {
                errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[Numéro de carte]")));
            }
            if (input.getMotif() == null || StringUtils.isEmpty(input.getMotif().getCode())) {
                errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[Motif]")));
            } else {
                //Vérifier que le montant reconnu est présent pour les motifs montant erroné
                if(isMontantErrone(input.getMotif())) {
                    if(input.getOperations().size() > 1) {
                        errors.add(new SmcError(SmcErrorMessage.ONE_OPERATION_REQUIRED_CODE, String.format(SmcErrorMessage.ONE_OPERATION_REQUIRED_LABEL,"[Montant erroné, billets partiellement délivrés]")));
                    } else {
                        Operation ope = input.getOperations().get(0);
                        if(ope.getMontantReconnu() == null){
                            errors.add(new SmcError(SmcErrorMessage.RECOGNIZED_AMOUNT_REQUIRED_CODE, String.format(SmcErrorMessage.RECOGNIZED_AMOUNT_REQUIRED_LABEL,"[Montant erroné, billets partiellement délivrés]")));
                        }
                    }
                }
            }
            if (StringUtils.isEmpty(input.getIkpiClient())) {
                errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[iKpi]")));
            }
            if (StringUtils.isEmpty(input.getIdTelematiqueClient())) {
                errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[idTelematique]")));
            }
            if (CollectionUtils.isEmpty(input.getOperations())) {
                errors.add(new SmcError(SmcErrorMessage.MANDATORY_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_FIELD_MISSED_LABEL, "[Tableau des opérations]")));
            } else {
                input.getOperations().stream().forEach(o -> {
                    if(o.getCodeOperation() == null) {
                        errors.add(new SmcError(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_LABEL, "[Code Opération]")));
                    }
/*                    if(o.getTypeOperation() == null) {
                        errors.add(new SmcError(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_LABEL, "[Type Opération]")));
                    }
                    if(o.getMontantOperation() == null) {
                        errors.add(new SmcError(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_LABEL, "[Montant Opération]")));
                    }
                    if(o.getDateOperation() == null) {
                        errors.add(new SmcError(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_CODE, String.format(SmcErrorMessage.MANDATORY_OPE_FIELD_MISSED_LABEL, "[Date Opération]")));
                    }*/
                });
            }


        }

        if (!CollectionUtils.isEmpty(errors)) {
            throw new ContestationValidationException(errors);
        }

        return true;
    }

    private boolean isMontantErrone(MotifContestation motif) {
        return motif.getTopMentionRecognizedAmount() != null && motif.getTopMentionRecognizedAmount();
    }
}
