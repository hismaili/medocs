--QUALIFICATION
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q001','Perte-Vol');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q002','Contrefaçon');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q099','Autres');

--Nature
---- perte-vol
---INSERT INTO NATURE_CONTESTATION VALUES('N001','Carte Perdue', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N002','Carte Volée Sans violence', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N003','Carte extorquée avec violence', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N004','Carte non parvenue au porteur', 'Q001');
---- Contrefaçon
INSERT INTO NATURE_CONTESTATION VALUES('N005','Carte Contrefaite', 'Q002');
INSERT INTO NATURE_CONTESTATION VALUES('N006','Facture contestée', 'Q002');
INSERT INTO NATURE_CONTESTATION VALUES('N007','Traitement en double', 'Q002');
----Autres (Contestation)
INSERT INTO NATURE_CONTESTATION VALUES('N008','Service non rendu ou marchandise non reçue ou défectueuse', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N009','DAB billets non délivrés', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N010','DAB billets partiellement délivrés', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N011','Montant erroné', 'Q099');



--Motif
-- Motifs
---- perte-vol
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M001','M001.label',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'M001.DISCLAIMER', 'LESDEUX','N001','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M002','M002.label',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'M002.DISCLAIMER', 'LESDEUX','N002','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M003','M003.label',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'M003.DISCLAIMER', 'LESDEUX','N003','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M004','M004.label',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'M004.DISCLAIMER', 'LESDEUX','N004','Q001');
--Contrefaçon
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M005','M005.label',FALSE,FALSE, FALSE,'facultatif',FAlSE,'facultatif',390, 100, 'M005.DISCLAIMER', 'LESDEUX','N005','Q002');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M006','M006.label',FALSE,FALSE, FALSE,'obligatoire',FAlSE,'facultatif',390, 100, 'M006.DISCLAIMER', 'PAIEMENT','N006','Q002');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M007','M007.label',FALSE,FALSE, FALSE,'facultatif',FAlSE,'facultatif',390, 100, 'M007.DISCLAIMER', 'LESDEUX','N007','Q002');
-- Autres
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M008','M008.label',FALSE,FALSE, FALSE,'facultatif',FALSE,'obligatoire',70, 100, 'M008.DISCLAIMER', 'PAIEMENT','N008','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M009','M009.label',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'M009.DISCLAIMER', 'RETRAIT','N009','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M010','M010.label',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'M010.DISCLAIMER', 'RETRAIT','N010','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M011','M011.label',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'M011.DISCLAIMER', 'LESDEUX','N011','Q099');



----Insertion des statuts de dossier
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC001',1,'BROUILLON');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC002',2,'CREE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC003',3,'En Cours');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC004',4,'TRAITE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC005',5,'CLOTURE');

--Etat des cartes
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'BLOQUE');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'EN COURS');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'DISPONIBLE');
  
--Toutes les CARTES

INSERT INTO CARTE(ID, DATE_CREATION, DATE_MAJ, DATE_EXPIR, DATE_OPPO, MOTIF_OPPO, NOM_ESTAMPE, PAN, TYPE_CARTE, ETAT_CARTE)  VALUES
('CA001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'VOL DE CARTE','PIERRE','01000002676300000','VISA','ETAT001');
INSERT INTO CARTE(ID, DATE_CREATION, DATE_MAJ, DATE_EXPIR, DATE_OPPO, MOTIF_OPPO, NOM_ESTAMPE, PAN, TYPE_CARTE, ETAT_CARTE)  VALUES
('CA002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'PERTE DE CARTE','PIERRE','01000002676300001','MASTER CARD','ETAT002');

---Toutes les contestations
INSERT INTO CONTESTATION VALUES('C0001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TRUE,'Contestation de vole de carte','123456','345615789521','bnp1@pbpparispas.com','50.000', 3.0,3.0,'Inconnu',3,FALSE,FALSE,FALSE,'01000002676300000','29',FALSE,'061252','CA001','SC001','M001');
INSERT INTO CONTESTATION VALUES('C0002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TRUE,'Contestation de disparition','123457','345615789529','bnp2@pbpparispas.com','50.000', 3.0,3.0,'Inconnu',3,FALSE,FALSE,FALSE,'01000002676300001','27',FALSE,'061252','CA002','SC002','M002');


--- Attribution des idDocuments aux contestation

INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001mu','PAYEMENT','29','20180110','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m5','ACHAT','29','20180110','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m8','PAYEMENT','29','20180111','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC004',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m9','CONTESTATION','27','20180111','C0002');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC005',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m7','PAYEMENT','27','20180111','C0002');

----création des opération
INSERT INTO OPERATION VALUES('OP001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0001');
INSERT INTO OPERATION VALUES('OP002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0001');
INSERT INTO OPERATION VALUES('OP003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0002');

--1 JDD avec 1 contestation historisée sur 1 opération
INSERT INTO CARTE(ID, DATE_CREATION, DATE_MAJ, DATE_EXPIR, DATE_OPPO, MOTIF_OPPO, NOM_ESTAMPE, PAN, TYPE_CARTE, ETAT_CARTE) VALUES
('CAT001',TO_TIMESTAMP('15/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('15/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2020','dd/mm/yyyy'),null, null,'PIERRE lefevre','4974013792774124','VISA CLASSIC','ETAT002');
insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id)
values (TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),'CAT001',TRUE,'SC001','Contestation de vole de carte','01630005685900000','2289627126','l.pierre@wooow.com', 100.00, 20.00 , null ,'M001',null,1, TRUE, FALSE, FALSE,'4974013792774124','S456210545007',FALSE,'0612525744', 'CT0013');
insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id)
values (TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),'op5632',TO_TIMESTAMP('25/09/2018','dd/mm/yyyy'),TO_TIMESTAMP('25/09/2018','dd/mm/yyyy'),'EUR','Retrait en banque',100.0, 20.0,'GRAND Hotel','DEBIT',1,'CT0013','OP010');