package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public enum StatusAttachment {
	SEND,TOSEND,REJECTED
}
