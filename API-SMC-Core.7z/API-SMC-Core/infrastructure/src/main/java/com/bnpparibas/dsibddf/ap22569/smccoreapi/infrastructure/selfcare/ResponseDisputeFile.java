package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * DisputeFile
 */
public class ResponseDisputeFile   {
	@JsonProperty("transactionsDisputeFolderId")
	private String fileIdSMC;

	@JsonProperty("statusCode")
	private StatusCode statusCode;

	@JsonProperty("errors")
	private List<Errors> errors;

	/**
	 * @return the errors
	 */
	public List<Errors> getErrors() {
		return errors;
	}

	/**
	 * @return the fileIdSMC
	 */
	public String getFileIdSMC() {
		return fileIdSMC;
	}

	/**
	 * @return the statusCode
	 */
	public StatusCode getStatusCode() {
		return statusCode;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<Errors> errors) {
		this.errors = errors;
	}

	/**
	 * @param fileIdSMC the fileIdSMC to set
	 */
	public void setFileIdSMC(String fileIdSMC) {
		this.fileIdSMC = fileIdSMC;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(StatusCode statusCode) {
		this.statusCode = statusCode;
	}



}

