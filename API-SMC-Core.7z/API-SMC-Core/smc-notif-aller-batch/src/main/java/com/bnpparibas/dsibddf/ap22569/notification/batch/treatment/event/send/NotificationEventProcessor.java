package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.event.send;

import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEvent;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class NotificationEventProcessor implements ItemProcessor<List<Notification>, List<NotificationEvent>> {

    @Autowired
    private NotificationEventBuilder notificationEventBuilder;

    @Override
    public List<NotificationEvent> process(List<Notification> notifications) throws Exception {
        List<NotificationEvent> notificationEvents = null;
        if(!CollectionUtils.isEmpty(notifications)) {
            notificationEvents = notifications.stream().map(this::buildSimpleMessage).collect(Collectors.toList());

        }
        if(!CollectionUtils.isEmpty(notifications)) {
            if(CollectionUtils.isEmpty(notificationEvents)) {
                notificationEvents = new ArrayList<>();
            }
            notificationEvents.addAll(notifications.stream().map(this::buildSecureMessage).collect(Collectors.toList()));

        }
        return notificationEvents;
    }

    private NotificationEvent buildSimpleMessage(Notification notif) {
        return notificationEventBuilder.buildSimpleMessage(notif);
    }
    private NotificationEvent buildSecureMessage(Notification notif) {
        return notificationEventBuilder.buildSecureMessage(notif);
    }
}
