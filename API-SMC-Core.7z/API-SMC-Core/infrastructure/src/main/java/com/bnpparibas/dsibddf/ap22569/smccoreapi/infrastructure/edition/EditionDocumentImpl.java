package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.model.structure.request.RequestEditique;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.model.structure.response.ResponseGlobal;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.service.DonneIncorectEditionException;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.service.EditionTechniqueException;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.service.FormatEditionException;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.service.MandatoryEditionException;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.service.builder.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;


/**
 *
 * @author c65344
 *
 *
 *
 *
 */
@Component
public class EditionDocumentImpl implements IEditionDocument {
	private static final Logger LOG = LoggerFactory.getLogger(EditionDocumentImpl.class);

	@Autowired
	private transient EditionMapper editionLocal;
	@Autowired
	private transient EditionMapperCentral editionCentral;
	@Autowired
	private transient IEditionRepository repo;

	@Autowired
	private transient ConfigInfrastructure conf;

	@Autowired(required = false)
	private transient BuilderCardContestationPdf cardContest;

	@Autowired(required = false)
	private transient BuilderGenericPdf genericMail;
	@Autowired(required = false)
	private transient BuilderFomrPayPdf formpay;
	@Autowired(required = false)
	private transient BuilderFomrRetraitPdf retrait;

	@Autowired(required = false)
	private transient BuilderFicheDeLiaisonPdf liaisonPdf;

	@Autowired(required = false)
	private transient BuilderRecapSelfCarePdf selfCare;

	@Autowired(required = false)
	private transient EditionCentralControlBuilder editionControl;

	@Autowired(required = false)
	private transient EditionCentralRetourJpaRepository jpaEditionRetour;
	@Autowired(required = false)
	private transient EditionCentralFileRetourJpaRepository jpaEditionFile;

	@Autowired
	private transient SmcDocumentBuilder smc;

	@Override
	public RequestEditiqueOutput creerCloturePDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {
		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		snemaquettes.put(conf.getMaquetteClo(),conf.getDataMatrixClo());
		request.setSneMaquette(snemaquettes);

		final List<String> mandatories = editionControl.checkMandatoryEditiquecentrale(request);

		if(!CollectionUtils.isEmpty(mandatories)){
			LOG.error("Une ou Plusieurs données obligatoire provenant de BCMP RP ou REFO sont absents");
			mandatories.forEach(err -> {
				LOG.error(err);
			});
			throw new EditingException();
		}

		final List<String> errors = editionControl.checkDataCorrectEditionCentral(request);

		if(!CollectionUtils.isEmpty(errors)){
			LOG.error("Une ou Plusieurs données provenant de BCMP RP ou REFO sont incorrectes");
			errors.forEach(err -> {
				LOG.error(err);
			});

			throw new EditingException();
		}

		try {
			repo.save(editionCentral.map(request));
			return reponse;

		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}
	}

	@Override
	public RequestEditiqueOutput creerContestationCartePDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {

		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		try {



			if(request.isEditiqueCentral()){
				final List<String> mandatories = editionControl.checkMandatoryEditiquecentrale(request);

				if(!CollectionUtils.isEmpty(mandatories)){
					LOG.error("Une ou Plusieurs données obligatoire provenant de BCMP RP ou REFO sont absents");
					mandatories.forEach(err -> {
						LOG.error(err);
					});
					throw new EditingException();
				}

				final List<String> errors = editionControl.checkDataCorrectEditionCentral(request);

				if(!CollectionUtils.isEmpty(errors)){
					LOG.error("Une ou Plusieurs données provenant de BCMP RP ou REFO sont incorrectes");
					errors.forEach(err -> {
						LOG.error(err);
					});

					throw new EditingException();
				}
				snemaquettes.put(conf.getMaquette1ContestationCarteCentral(),conf.getDatamatrix1ContestationCarteCentral());
				snemaquettes.put(conf.getMaquette2ContestationCarteCentral(), conf.getDatamatrix2ContestationCarteCentral());
				request.setSneMaquette(snemaquettes);
				repo.save(editionCentral.map(request));
			}else{
				snemaquettes.put(conf.getMaquette1ContestationCarte(),conf.getDatamatrix1ContestationCarte());
				snemaquettes.put(conf.getMaquette2ContestationCarte(), conf.getDatamatrix2ContestationCarte());
				request.setSneMaquette(snemaquettes);
				RequestEditique edition = editionLocal.map(request);
				ResponseGlobal reponseGlobal = cardContest.generatePdf(edition);

				reponse = getPDF(reponseGlobal, reponse);
			}

			return reponse;

		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}
	}
	@Override
	public RequestEditiqueOutput creerCourrierGenericPDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {

		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();


		try {

			final List<String> mandatories = editionControl.checkMandatoryEditiquecentrale(request);


			if(request.isEditiqueCentral()){
				if(!CollectionUtils.isEmpty(mandatories)){
					LOG.error("Une ou Plusieurs données obligatoire provenant de BCMP RP ou REFO sont absents");
					mandatories.forEach(err -> {
						LOG.error(err);
					});
					throw new EditingException();
				}
				final List<String> errors = editionControl.checkDataCorrectEditionCentral(request);

				if(!CollectionUtils.isEmpty(errors)){
					LOG.error("Une ou Plusieurs données provenant de BCMP RP ou REFO sont incorrectes");
					errors.forEach(err -> {
						LOG.error(err);
					});

					throw new EditingException();
				}

				snemaquettes.put(conf.getMaquetteCourrierGeneriqueCentral(), conf.getDatamatrixCourrierGeneriqueCentral());
				request.setSneMaquette(snemaquettes);
				repo.save(editionCentral.map(request));
			}else{
				snemaquettes.put(conf.getMaquetteCourrierGenerique(), conf.getDatamatrixCourrierGenerique());
				request.setSneMaquette(snemaquettes);
				RequestEditique edition = editionLocal.map(request);
				ResponseGlobal reponseGlobal = genericMail.generatePdf(edition);
				reponse = getPDF(reponseGlobal, reponse);
			}

			return reponse;

		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}catch (Exception e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}
	}


	@Override
	public RequestEditiqueOutput creerFicheDeLiaisonPDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {


		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		try {
			snemaquettes.put(conf.getMaquetteDeliaison(), conf.getDatamatrixDeLiaison());
			request.setSneMaquette(snemaquettes);
			RequestEditique edition = editionLocal.map(request);
			ResponseGlobal reponseGlobal = liaisonPdf.generatePdf(edition);
			reponse = getPDF(reponseGlobal, reponse);
			return reponse;
		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}

	}

	@Override
	public RequestEditiqueOutput creerFormPayPDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {



		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		try {
			snemaquettes.put(conf.getMaquetteFormPay(),conf.getDatamatrixFormPay());
			request.setSneMaquette(snemaquettes);
			RequestEditique edition = editionLocal.map(request);
			ResponseGlobal reponseGlobal = formpay.generatePdf(edition);
			reponse = getPDF(reponseGlobal, reponse);
			return reponse;
		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}


	}

	@Override
	public RequestEditiqueOutput creerFormRetraitPDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {

		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		try {
			snemaquettes.put(conf.getMaquetteFormRetrait(),conf.getDatamatrixRetrait());
			request.setSneMaquette(snemaquettes);
			RequestEditique edition = editionLocal.map(request);
			ResponseGlobal reponseGlobal = retrait.generatePdf(edition);
			reponse = getPDF(reponseGlobal, reponse);
			return reponse;
		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}
	}

	@Override
	public RequestEditiqueOutput creerRecapitulatifSelfCarePDF(
			RequestEditiqueInput request) throws EditingException,
			MandatoryException, FormatErrorException, DonneIncorectException {

		Map<String,String> snemaquettes = new HashMap<>();
		RequestEditiqueOutput reponse = new RequestEditiqueOutput();

		try {
			snemaquettes.put("S-MON-SMC-DC-RE-TPC01_01",conf.getDataMatrixSelfCare());
			request.setSneMaquette(snemaquettes);
			RequestEditique edition = editionLocal.map(request);
			ResponseGlobal reponseGlobal = selfCare.generatePdf(edition);
			reponse = getPDF(reponseGlobal, reponse);
			return reponse;
		} catch (MandatoryEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new MandatoryException(e.getErrors());
		} catch (FormatEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new FormatErrorException(e.getErrors());
		} catch (DonneIncorectEditionException e) {
			LOG.error(e.getMessage(),e);
			e.getErrors().forEach(err -> LOG.error(err));
			throw new DonneIncorectException(e.getErrors());
		} catch (EditionTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new EditingException(e.getMessage());
		}

	}

	/**
	 * @return
	 */
	private LocalDateTime getdateTraitement(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
		return dateTime;
	}


	@Override
	public EditionRecording getEditionRecording() {

		List<EditionEntity> editionEntities = repo.findByStatus(Status.NONTRAITE);
		if(!CollectionUtils.isEmpty(editionEntities)){
			final EditionEntity editionEntity = editionEntities.get(0);
			editionEntity.setStatus(Status.ENCOURS);
			repo.save(editionEntity);
			LOG.info("Nombre de courriers non traités : "+repo.findByStatus(Status.NONTRAITE).size());
			LOG.info("Nombre de courriers en cours de traitement : "+repo.findByStatus(Status.ENCOURS).size());
			LOG.info("Nombre de courriers rejeté : "+repo.findByStatus(Status.REJETER).size());
			return editionCentral.mapToEditionRecording(editionEntity);
		}else{
			return null;

		}
	}

	@Override
	public int getLastNumSeqEditiqueToSmc() {
		int max= 0;
		try {
			max = jpaEditionFile.getMaxNumSequence();
		} catch (Exception e) {
			LOG.error("Aucun numéro de sequence de courrier trouvé en base de donnée");
		}
		return max;
	}

	@Override
	public int getLastNumSequence() {
		int max= 0;
		try {
			max = repo.getMaxNumSequence();
		} catch (Exception e) {
			LOG.error("Aucun numéro de sequence de courrier trouvé en base de donnée");
		}
		return max;
	}



	/**
	 * recupère le pdf et le fileType de l'edition
	 * @param reponseGlobal
	 * @param reponse
	 * @return
	 * @throws EditingException
	 */
	private RequestEditiqueOutput getPDF(ResponseGlobal reponseGlobal,RequestEditiqueOutput reponse) throws EditingException{

		if(reponseGlobal !=null){
			if(reponseGlobal.getException() !=null && !("0".equals(reponseGlobal.getException()))){
				LOG.error("Exception From Editique : "+reponseGlobal.getException()+" , LOG EDITION : "+reponseGlobal.getLog());
				throw new EditingException(conf.getMessageErrorTechnique());

			}else if(reponseGlobal !=null && "0".equals(reponseGlobal.getException())){

				BeanUtils.copyProperties(reponseGlobal, reponse,"exception","log");

				reponse.setFileType(conf.getEditiqueFileType());

				return reponse;

			}else{
				LOG.debug(conf.getReponseIncorect()+" "+reponseGlobal.getLog());
				throw new EditingException(conf.getMessageErrorTechnique());
			}
		}else{
			throw new EditingException(conf.getMessageErrorTechnique());
		}
	}

	@Override
	public List<EditionRecording> getRecordingEditionTreated(boolean istreated) {
		List<EditionEntity> editionEntities = null;

		if(istreated){
			final List<EditionEntity> editions = repo.findByStatus(Status.TRAITE);

			if(!CollectionUtils.isEmpty(editions)){
				editionEntities = editions.stream()
						.filter(edition -> LocalDate.now().isEqual(edition.getTreatedDate()))
						.map(edition -> edition).collect(Collectors.toList());
			}
			printState("après");

		}else{
			printState("avant");
			editionEntities = repo.findByStatus(Status.NONTRAITE);
		}

		List<EditionRecording> editionRecordings = null;

		if(!CollectionUtils.isEmpty(editionEntities)){
			editionRecordings = editionEntities.stream().filter(editionEntity -> editionEntity !=null).map(editionEntity -> {
				return editionCentral.mapToEditionRecording(editionEntity);
			}).collect(Collectors.toList());
		}

		return editionRecordings;
	}

	@Override
	public String getXmlFileSmcFromEditique() {

		return smc.buildResponseSmc();
	}

	@Override
	public void isTreated(int numSequence) {
		final List<EditionEntity> editionEntities = repo.findByStatus(Status.ENCOURS);

		if(!CollectionUtils.isEmpty(editionEntities)){
			final EditionEntity editionEntity = editionEntities.get(0);
			editionEntity.setStatus(Status.TRAITE);
			editionEntity.setNumSequence(numSequence);
			editionEntity.setTreatedDate(LocalDate.now());
			final EditionEntity saveAndFlush = repo.saveAndFlush(editionEntity);
		}

	}

	/**
	 * @param periode
	 */
	private void printState(String periode) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		Date d;
		try {
			d = sdf.parse(LocalDateTime.now().toString());
			String date = output.format(d);
			LOG.info("Etat des courriers "+periode+" le traitement Le "+date);
		} catch (ParseException e) {
			LOG.error(e.getMessage(),e);
		}
		LOG.info("Nombre de courriers non traités : "+repo.findByStatus(Status.NONTRAITE).size());
		LOG.info("Nombre de courriers traités : "+repo.findByStatus(Status.TRAITE).size());
		LOG.info("Nombre de courriers rejeté : "+repo.findByStatus(Status.REJETER).size());
	}

	@Override
	public void saveDocumentReturnCentral(DocumentRetour document) {

		if(document !=null){
			DocumentGdnReturnEntity documentEntity = new DocumentGdnReturnEntity();
			BeanUtils.copyProperties(document, documentEntity);

			InfoFileReturnCentraleEntity infoFileEntity = null;

			InfoFileArchivage infoFile = document.getInfo();
			if(infoFile !=null){
				Optional<InfoFileReturnCentraleEntity> findById = jpaEditionFile.findById(infoFile.getIdFileArchivage());

				if(findById !=null && findById.isPresent()){
					infoFileEntity = findById.get();
					documentEntity.setInfo(infoFileEntity);
					documentEntity.setSend(false);
				}else{
					infoFileEntity = new InfoFileReturnCentraleEntity();
					BeanUtils.copyProperties(infoFile, infoFileEntity);
					documentEntity.setInfo(infoFileEntity);
					documentEntity.setSend(false);
				}
			}

			jpaEditionRetour.save(documentEntity);
		}


	}

	@Override
	public void saveInfoFileReturnCentral(InfoFileArchivage infoFile) {

		InfoFileReturnCentraleEntity infoFileEntity = new InfoFileReturnCentraleEntity();

		if(infoFile !=null){

			Optional<InfoFileReturnCentraleEntity> result = jpaEditionFile.findById(infoFile.getIdFileArchivage());

			if(result.isPresent()){
				InfoFileReturnCentraleEntity infoFileReturnEntity = result.get();

				infoFileReturnEntity.setRecordNumber(infoFile.getRecordNumber());
				jpaEditionFile.save(infoFileReturnEntity);
			}else{
				BeanUtils.copyProperties(infoFile, infoFileEntity);

				try {
					infoFileEntity.setDateFlux(getdateTraitement(infoFile.getFluxDate()));
				} catch (Exception e) {
					LOG.warn("La date du flux editique retour n'est pas au format attendu",e);
				}


				jpaEditionFile.save(infoFileEntity);
			}


		}

	}

}
