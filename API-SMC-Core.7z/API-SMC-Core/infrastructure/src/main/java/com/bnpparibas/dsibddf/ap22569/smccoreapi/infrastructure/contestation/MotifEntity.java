package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="MOTIF")
public class MotifEntity {

    @Id
    @Column(length = 25)
    private String code;

    @Column(length = 60)
    private String libelle;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private TypeOperationEntity typeOperationApplicable;

    @OneToOne
    @JoinColumn(name = "code_nature")
    private NatureEntity natureContestation;

    @ManyToOne
    @JoinColumn(name = "code_qualif")
    private QualificationEntity qualificationContestation;

    /**
     * texte d'avertissement à valider par le client
     */
    @Column
    private String texteAvertissement;

    /**
     * exigence de la saisie du montant reconnu porteur
     */
    @Column
    private boolean ecartMontant;

    /**
     * Exigence de la saisie de la description des faits
     */
    @Column(name = "EXIG_DESCRIPTION_FAITS", length = 20)
    @Enumerated(EnumType.STRING)
    private ExigenceAjoutInformation exigenceSaisieDescription;

    /**
     * Exigence de l'opposition de la carte pour ce motif
     */
    private boolean exigenceOppositionCarte;

    /**
     * Le motif s'applique à une seule opération
     */
    private boolean appliedToOneOperation;

    private boolean appliedToCardLostOnly;

    @ManyToMany
    private List<DocumentJustificatifEntity> documentAssocies;

    @Column(name = "EXIG_JUSTIF", length = 20)
    @Enumerated(EnumType.STRING)
    private ExigenceAjoutInformation exigenceAttachement;

    private Integer maxOperations;

    /**
     * historique en jour. 13 mois = 13*30
     */
    private Integer historique;

    @Column(length = 60)
    private String description;

    @Column
    private boolean withEcartMnt;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public TypeOperationEntity getTypeOperationApplicable() {
        return typeOperationApplicable;
    }

    public void setTypeOperationApplicable(TypeOperationEntity typeOperationApplicable) {
        this.typeOperationApplicable = typeOperationApplicable;
    }

    public NatureEntity getNatureContestation() {
        return natureContestation;
    }

    public void setNatureContestation(NatureEntity natureContestation) {
        this.natureContestation = natureContestation;
    }

    public QualificationEntity getQualificationContestation() {
        return qualificationContestation;
    }

    public void setQualificationContestation(QualificationEntity qualificationContestation) {
        this.qualificationContestation = qualificationContestation;
    }

    public boolean isEcartMontant() {
        return ecartMontant;
    }

    public void setEcartMontant(boolean ecartMontant) {
        this.ecartMontant = ecartMontant;
    }

    public String getTexteAvertissement() {
        return texteAvertissement;
    }

    public void setTexteAvertissement(String texteAvertissement) {
        this.texteAvertissement = texteAvertissement;
    }

    public ExigenceAjoutInformation getExigenceSaisieDescription() {
        return exigenceSaisieDescription;
    }

    public void setExigenceSaisieDescription(ExigenceAjoutInformation exigenceSaisieDescription) {
        this.exigenceSaisieDescription = exigenceSaisieDescription;
    }

    public boolean isExigenceOppositionCarte() {
        return exigenceOppositionCarte;
    }

    public void setExigenceOppositionCarte(boolean exigenceOppositionCarte) {
        this.exigenceOppositionCarte = exigenceOppositionCarte;
    }

    public boolean isAppliedToOneOperation() {
        return appliedToOneOperation;
    }

    public void setAppliedToOneOperation(boolean appliedToOneOperation) {
        this.appliedToOneOperation = appliedToOneOperation;
    }

    public List<DocumentJustificatifEntity> getDocumentAssocies() {
        return documentAssocies;
    }

    public void setDocumentAssocies(List<DocumentJustificatifEntity> documentAssocies) {
        this.documentAssocies = documentAssocies;
    }

    public boolean isAppliedToCardLostOnly() {
        return appliedToCardLostOnly;
    }

    public void setAppliedToCardLostOnly(boolean appliedToCardLostOnly) {
        this.appliedToCardLostOnly = appliedToCardLostOnly;
    }

    public ExigenceAjoutInformation getExigenceAttachement() {
        return exigenceAttachement;
    }

    public void setExigenceAttachement(ExigenceAjoutInformation exigenceAttachement) {
        this.exigenceAttachement = exigenceAttachement;
    }

    public Integer getMaxOperations() {
        return maxOperations;
    }

    public void setMaxOperations(Integer maxOperations) {
        this.maxOperations = maxOperations;
    }

    public Integer getHistorique() {
        return historique;
    }

    public void setHistorique(Integer historique) {
        this.historique = historique;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isWithEcartMnt() {
        return withEcartMnt;
    }

    public void setWithEcartMnt(boolean withEcartMnt) {
        this.withEcartMnt = withEcartMnt;
    }
}
