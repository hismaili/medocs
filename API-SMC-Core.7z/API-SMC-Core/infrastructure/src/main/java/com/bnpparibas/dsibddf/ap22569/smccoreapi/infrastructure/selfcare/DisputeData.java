package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * DisputeInputData
 */
public class DisputeData   {

	@JsonProperty("bankId")
	private String bankId;

	@JsonProperty("cardId")
	private String cardId;



	/**
	 * qualification du dossier de contestation <br/>* `P` - Carte perdue <br/>* `F` - Contrefaçon <br/>* `C` - Contestation
	 */
	@JsonProperty("disputeReasonQualification")
	private String qualification;

	/**
	 * nature du dossier de contestation <br/>* `PER` - Carte perdue <br/>* `VOL`   - Carte volée sans violence <br/>* `VEM`   - Carte extorquée avec menace <br/>* `NPA`   - Carte non parvenue au porteur <br/>* `FAL`   - Carte contrefaite <br/>* `FCT`   - Facture contestée <br/>* `DDJ`   - DDJ <br/>* `DOU`   - Traitement en double <br/>* `SNR`   - Service non rendu ou marchandise non reçue ou défectueuse <br/>* `BND`   - Billet non délivrés <br/>* `MER`   - Montant erroné <br/>* `BDP`   - Billets partiellement délivrés
	 */
	@JsonProperty("disputeReasonNature")
	private String nature;

	@JsonProperty("disputeComment")
	private String disputeComment;

	@JsonProperty("claimer")
	private Claimer claimer;

	@JsonProperty("transactionItems")
	private List<TransactionItem> transactionItems;

	/**
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * @return the cardId
	 */
	public String getCardId() {
		return cardId;
	}

	/**
	 * @return the claimer
	 */
	public Claimer getClaimer() {
		return claimer;
	}

	/**
	 * @return the disputeComment
	 */
	public String getDisputeComment() {
		return disputeComment;
	}

	/**
	 * @return the nature
	 */
	public String getNature() {
		return nature;
	}

	/**
	 * @return the qualification
	 */
	public String getQualification() {
		return qualification;
	}

	/**
	 * @return the transactionItems
	 */
	public List<TransactionItem> getTransactionItems() {
		return transactionItems;
	}

	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * @param cardId the cardId to set
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	/**
	 * @param claimer the claimer to set
	 */
	public void setClaimer(Claimer claimer) {
		this.claimer = claimer;
	}

	/**
	 * @param disputeComment the disputeComment to set
	 */
	public void setDisputeComment(String disputeComment) {
		this.disputeComment = disputeComment;
	}

	/**
	 * @param nature the nature to set
	 */
	public void setNature(String nature) {
		this.nature = nature;
	}

	/**
	 * @param qualification the qualification to set
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	/**
	 * @param transactionItems the transactionItems to set
	 */
	public void setTransactionItems(List<TransactionItem> transactionItems) {
		this.transactionItems = transactionItems;
	}




}

