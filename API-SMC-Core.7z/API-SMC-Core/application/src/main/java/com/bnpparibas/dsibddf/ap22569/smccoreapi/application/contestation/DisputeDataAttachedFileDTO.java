package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

public class DisputeDataAttachedFileDTO {

    private String filetype;

    private String fileName;

    private String idGdn;

    public DisputeDataAttachedFileDTO() {
    }

    public DisputeDataAttachedFileDTO(String filetype, String fileName, String idGdn) {
        this.filetype = filetype;
        this.fileName = fileName;
        this.idGdn = idGdn;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getIdGdn() {
        return idGdn;
    }

    public void setIdGdn(String idGdn) {
        this.idGdn = idGdn;
    }
}
