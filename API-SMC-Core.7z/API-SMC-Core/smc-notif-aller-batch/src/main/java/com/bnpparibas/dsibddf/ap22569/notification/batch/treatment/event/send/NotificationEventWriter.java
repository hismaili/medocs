package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.event.send;

import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEvent;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEventMessages;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEventVariable;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.annotation.AfterWrite;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;

@Component
public class NotificationEventWriter implements ItemWriter<List<NotificationEvent>> {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationEventWriter.class);

    @Autowired
    private INotificationManagement notificationManagement;

    @Autowired
    private MQConfiguration mqConfig;

    @Override
    public void write(List<? extends List<NotificationEvent>> notificationEvents) throws Exception {
        if(!CollectionUtils.isEmpty(notificationEvents)) {
            XStream stream = new XStream(new StaxDriver());
            stream.processAnnotations(new Class[]{NotificationEventMessages.class, NotificationEvent.class, NotificationEventVariable.class});

            StringWriter out = new StringWriter();
            notificationEvents.stream().forEach(notifications-> {
                if(!CollectionUtils.isEmpty(notifications)) {
                    notifications.stream().forEach(notification -> {

                        NotificationEventMessages messages = new NotificationEventMessages(Arrays.asList(notification));

                        stream.toXML(messages, out);
                        String s = out.toString();
                        System.out.println("xml = "+ s);

                        LOG.info(s);
                        mqConfig.sendNotificationEvent(s);
                    });
                }
            });

        }

    }

    @AfterWrite
    public void afterWrite(List<? extends List<NotificationEvent>> notificationEvents) {
        if(!CollectionUtils.isEmpty(notificationEvents)) {
            notificationEvents.stream().forEach(notifications-> {
                if(!CollectionUtils.isEmpty(notifications)) {
                    notifications.stream().forEach(notification -> {
                        try {
                            this.notificationManagement.flagEventAsSucceeded(notification.getNotificationInternalId());
                        } catch (NotificationException e) {
                            e.printStackTrace();
                        }
                    });
                }
            });

        }

    }
}
