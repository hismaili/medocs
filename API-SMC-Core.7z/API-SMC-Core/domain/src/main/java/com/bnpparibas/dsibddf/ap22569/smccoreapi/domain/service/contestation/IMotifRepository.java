package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;

import java.util.List;

public interface IMotifRepository {

    List<MotifContestation> getAllMotifs();

    List<MotifContestation> getMotifsByOperationType(TypeOperation operationType);

    MotifContestation getMotif(String code);

    List<MotifContestation> getAppliedReasons(TypeOperation operationType, Boolean cardLost, Integer numberOfOperations) throws Exception;
}
