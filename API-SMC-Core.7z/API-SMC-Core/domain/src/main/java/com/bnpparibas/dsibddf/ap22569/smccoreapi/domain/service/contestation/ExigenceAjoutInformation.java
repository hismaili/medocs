package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public enum ExigenceAjoutInformation {

    obligatoire, recommande, facultatif
}
