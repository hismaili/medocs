/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;


import java.io.Serializable;
import java.util.List;

/**
 * @author c65344
 *
 */

public class SmcApiError implements Serializable {

	public static final String DEFAULT_BIZ_ERR_CODE = "ERR.CMC.BIZ.DEFAULT";

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String code;
	private String message;
	private List<String> details;


	public SmcApiError() {
	}

	/**
	 * @param code : code erreur
	 * @param message : message d'erreur
	 */
	public SmcApiError(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public SmcApiError(String code, String message, List<String> details) {
		this.code = code;
		this.message = message;
		this.details = details;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	public List<String> getDetails() {
		return details;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	public void setDetails(List<String> details) {
		this.details = details;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
