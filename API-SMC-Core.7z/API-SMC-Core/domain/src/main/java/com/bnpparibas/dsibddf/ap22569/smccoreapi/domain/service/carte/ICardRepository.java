package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

import java.util.List;

public interface ICardRepository {

	List<AnonymizedCard> getAnonymizedCards(List<String> ribs) throws CardException;

	/**
	 * recupère une carte à partir de son id
	 * @param cardId
	 * @return
	 */
	AnonymizedCard getCardByCardId(String cardId) throws CardException;

	/**
	 * recupère la Liste des cartes d'un utilisateur
	 * @param iKpi
	 * @return
	 */
	List<CartePorteur> getCartesPorteur(String iKpi) throws CardException;

	/**
	 *  Récupérer la liste des cartes rattachés à un rib
	 *
	 * @param ribs
	 * @return
	 * @throws CardException
	 */
	List<CartePorteur> getCartesPourComptes(List<String> ribs) throws CardException;

	/**
	 * recupère les informations de la carte
	 * @param pan
	 * @return
	 */
	InfoCarte getInfoCard(String pan) throws CardException;

	void saveAnonymizedCards(List<AnonymizedCard> anonymizedCards) throws CardException;
}
