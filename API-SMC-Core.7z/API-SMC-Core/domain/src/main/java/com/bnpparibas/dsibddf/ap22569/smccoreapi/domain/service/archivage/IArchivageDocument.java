package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import org.springframework.stereotype.Component;

/**
 *
 * Interface des methodes d'archivage Domain
 *
 */
@Component
public interface IArchivageDocument {

	/**
	 * Cloture un dossier
	 * @param closeFolderInput
	 * @return
	 * @throws ArchivingException
	 */
	String closeFolder(CloseFolderInput closeFolderInput) throws ArchivingException,MandatoryException, FormatErrorException,DonneIncorectException;

	/**
	 * Supprime un document
	 * @param deleteDocInput
	 * @return
	 * @throws ArchivingException
	 */
	String deleteDoc(DeleteDocInput deleteDocInput) throws ArchivingException, MandatoryException;

	/**
	 * Recupère un document
	 * @param getDocInput
	 * @return
	 * @throws ArchivingException
	 */
	DocOutput getDoc(DocInput getDocInput) throws MandatoryException, ArchivingException;

	/**
	 * Enregistre un document dans la GDN
	 * @param newDocInput
	 * @return
	 * @throws ArchivingException
	 */
	String newDoc(NewDocInput newDocInput)  throws ArchivingException, MandatoryException, FormatErrorException ;

	/**
	 * Cree un nouveau dossier dans la GDN
	 * @param newFolderInput
	 * @return
	 * @throws ArchivingException
	 */
	String newFolder(NewFolderInput newFolderInput) throws   MandatoryException, ArchivingException;

	/**
	 * purge un dossier
	 * @return
	 * @throws ArchivingException
	 */
	String purgeFolder(PurgeFolderInput purgeFolderInput) throws ContestationException;
}
