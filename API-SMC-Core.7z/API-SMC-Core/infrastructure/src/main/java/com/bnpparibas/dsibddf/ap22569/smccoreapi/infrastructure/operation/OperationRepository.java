package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.IOperationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationTop;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.OperationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.StatusTopOperation;
import com.bnpparibas.dsibddf.ap22569.smctohmp.goal.ConfigHmp;
import com.bnpparibas.dsibddf.ap22569.smctohmp.goal.OperationHmpException;
import com.bnpparibas.dsibddf.ap22569.smctohmp.goal.OperationWs;
import com.bnpparibas.dsibddf.ap22569.smctohmp.response.OperationResult;

@Service
public class OperationRepository implements IOperationRepository {

	private static final Logger LOG = LoggerFactory.getLogger(OperationRepository.class);

	public static final String ZEROS = "000";

	@Autowired(required=false)
	private transient OperationWs operationWs;

	@Autowired
	private transient OperationTmpMapper map;

	@Autowired
	private transient OperationJpaRepository operationJpa;

	@Autowired
	private transient ConfigHmp configZosOperation;

	@Autowired
	private transient OperationTopJpaRepository operationTopJpa;

	@Autowired
	private transient OperationTopMapper operationTopMapper;

	@Override
	public void deleteOperationsTmp(String idTelematic,String userId) {

		try{
			if(!StringUtils.isEmpty(idTelematic)){
				List<OperationTmpEntity> operations = operationJpa.deleteByIdTelematicAndUserId(idTelematic,userId);

				if(!CollectionUtils.isEmpty(operations)){
					LOG.info("Suppression en base des opérations temporaires présentées à l'utilisateur ayant l'idTelematic : "+idTelematic);
					operations.stream().forEach(ope -> {
						LOG.info("L'opération ayant le code opération :"+ope.getCodeOperation()+" a été supprimée");
					});
				}
			}
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
			LOG.error("erreur technique lors de la suppression des opérations temporaire ayant L'idTelematic :"+idTelematic+" et l'ikpi :"+userId);
		}

	}

	@Override
	public List<Operation> getCardOperations(String pan,String idTelematic,String userId) throws OperationException {

		List<Operation> operations = null;

		try {


			operationJpa.deleteByNumCarte(getPanNiceFormat(pan));
			List<OperationResult> operationHmp = operationWs.getOperations(pan,9,18);

			if(!CollectionUtils.isEmpty(operationHmp)){
				operations = operationHmp.stream()
						.filter(ope -> ope !=null && !StringUtils.isEmpty(ope.getCodeOperation()))
						.map(ope -> {
							/**
							 * enregistrement des opérations temporairement en base de donné
							 */
							operationJpa.save(map.mapOperationHmpToOperationTmp(ope,idTelematic,userId));

							/**
							 * mappage des opération de hmp en opérations metier
							 */
							return map.mapOperationHmpToOperation(ope);
						})
						.collect(Collectors.toList());
			}


		} catch (OperationHmpException e) {
			LOG.error(e.getMessage(),e);
			throw new OperationException(e.getMessage(),e);
		}catch (Exception e) {
			LOG.error("erreur technique lors de la purge des opérations en base de donnée");
			LOG.error(e.getMessage(),e);
		}

		return operations;
	}

	@Override
	public int getLastNumSeqTopHmp() {

		Integer max= 0;
		try {
			max = operationTopJpa.getMaxNumSequenceOperation();
		} catch (Exception e) {
			LOG.error("Aucun numéro de sequence de top-Hmp trouvé en base de donnée");
		}

		if(max == null){
			return 0;
		}
		return max.intValue();
	}



	@Override
	public Operation getOperationByCodeOpe(String codeOpe,String idTelematic,String userId) throws OperationException {
		Operation operation = null;
		try{
			OperationTmpEntity operationTmp = operationJpa.findByCodeOperationAndUserIdAndIdTelematic(codeOpe, userId, idTelematic);

			if(operationTmp !=null){
				operation = map.mapOperationTmpToOperation(operationTmp);
			}

			if(operation == null){
				LOG.error("L'opération "+codeOpe+" n’a pas été trouvée en base de donnée temporaire");
				throw new OperationException();
			}
			return operation;
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
			LOG.error("erreur technique lors de la recupération en base de donnée de l'opération ayant le code opération "+codeOpe+" appartenant à l'utilisateur ayant L'idTelematic :"+idTelematic+" et le userId :"+userId);
			throw new OperationException(e.getMessage(),e);
		}

	}

	@Override
	public OperationTop getOperationTopHmp() {

		List<OperationEntity> operationEntities = operationTopJpa.findByStatusTop(StatusTopOperation.TOSEND);

		if(!CollectionUtils.isEmpty(operationEntities)){

			OperationEntity operationEntity = operationEntities.get(0);
			operationEntity.setStatusTop(StatusTopOperation.INPROGRESS);
			operationTopJpa.save(operationEntity);

			return operationTopMapper.mapOperationEntityToOperationTop(operationEntity);
		}else{
			return null;
		}

	}


	@Override
	public List<OperationTop> getOperationTopHmps(boolean isTop) {


		List<OperationEntity> OperationEntitiesOfDay = null;

		if(isTop){
			List<OperationEntity> operationsEntities = operationTopJpa.findByStatusTop(StatusTopOperation.SEND);

			if(!CollectionUtils.isEmpty(operationsEntities)){

				OperationEntitiesOfDay = operationsEntities.stream()
						.filter(operation -> LocalDate.now().isEqual(operation.getTreatedDate()))
						.collect(Collectors.toList());
			}

			printState("après");
		}else{
			printState("avant");
			OperationEntitiesOfDay = operationTopJpa.findByStatusTop(StatusTopOperation.TOSEND);
		}

		List<OperationTop> operationTops = null;

		if(!CollectionUtils.isEmpty(OperationEntitiesOfDay)){
			operationTops = OperationEntitiesOfDay.stream().filter(operation -> operation !=null).map(operation -> {
				return operationTopMapper.mapOperationEntityToOperationTop(operation);
			}).collect(Collectors.toList());
		}

		return operationTops;

	}

	/**
	 * @param pan
	 * @return
	 */
	public String getPanNiceFormat(String pan) {
		String numCarte = null;
		if (pan.length() == 16) {
			numCarte = pan + ZEROS;
		} else {

			if(pan.length() == 19 && pan.startsWith(ZEROS)) {

				numCarte = pan.substring(3).concat(ZEROS);
			}else{
				numCarte = pan;
			}

		}
		return numCarte;
	}

	@Override
	public void isTreated(int numSequence) {

		List<OperationEntity> operationEntities = operationTopJpa.findByStatusTop(StatusTopOperation.INPROGRESS);

		if(!CollectionUtils.isEmpty(operationEntities)){
			OperationEntity OperationEntity = operationEntities.get(0);
			OperationEntity.setStatusTop(StatusTopOperation.SEND);
			OperationEntity.setNumSequence(new Integer(numSequence));
			OperationEntity.setTreatedDate(LocalDate.now());

			operationTopJpa.saveAndFlush(OperationEntity);
		}
	}

	/**
	 * @param periode
	 */
	private void printState(String periode) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		Date d;
		try {
			d = sdf.parse(LocalDateTime.now().toString());
			String date = output.format(d);
			LOG.info("Etat des courriers "+periode+" le traitement Le "+date);
		} catch (ParseException e) {
			LOG.error(e.getMessage(),e);
		}
		LOG.info("Nombre d'opérations à envoyer : "+operationTopJpa.findByStatusTop(StatusTopOperation.TOSEND).size());
		List<OperationEntity> findByStatusTopOperation = operationTopJpa.findByStatusTop(StatusTopOperation.SEND);

		long operationsend = 0;

		if(!CollectionUtils.isEmpty(findByStatusTopOperation)){
			operationsend = findByStatusTopOperation.stream()
					.filter(operation -> LocalDate.now().equals(operation.getTreatedDate()))
					.count();
		}

		LOG.info("Nombre d'opérations envoyer : "+operationsend);
	}

}
