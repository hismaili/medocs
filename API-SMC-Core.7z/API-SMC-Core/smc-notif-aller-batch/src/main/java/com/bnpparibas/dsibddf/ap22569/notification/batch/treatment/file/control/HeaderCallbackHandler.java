package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control;

import com.bnpparibas.dsibddf.ap22569.notification.batch.config.BatchConfiguration;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component("HeaderCallbackHandler")
public class HeaderCallbackHandler implements LineCallbackHandler {
	private static final Logger LOG = LoggerFactory.getLogger(HeaderCallbackHandler.class);

	private StepExecution stepExecution;

	@Autowired
	private transient INotificationManagement notificationManagement;
	public StepExecution getStepExecution() {
		return stepExecution;
	}

	@Override
	public void handleLine(String line) {
		LOG.info("Processing header "+line);
		String[] informationFile = line.split(";"); //$NON-NLS-1$
		String dateFluxHeader = informationFile[1];
		String numSeqHeader = informationFile[3];
		Random random = new Random();
		String idFileNotification = Integer.toString(random.nextInt());
		NotificationInfoFile fileInfo = new NotificationInfoFile();
		fileInfo.setIdFileNotification(idFileNotification);
		fileInfo.setNumSeqHeader(numSeqHeader);
		fileInfo.setDateFluxHeader(dateFluxHeader);
		try {
			this.notificationManagement.saveNotificationFileHeader(fileInfo);
			stepExecution.getExecutionContext().put(BatchConfiguration.FILE_INFO, fileInfo);
			stepExecution.getJobExecution().getExecutionContext().put(BatchConfiguration.FILE_INFO, fileInfo);
		} catch (NotificationException e) {
			LOG.error(e.getMessage(), e);
		}
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}
}
