package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition;


import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 *
 *
 */
//@WebFilter("/v1/*")
@Component
public class SmcApiTraceIdHeaderFilter implements Filter {

	private static final Logger LOG = LoggerFactory.getLogger(SmcApiTraceIdHeaderFilter.class);

	private static final String X_B_3_TRACE_ID = "X-B3-TraceId";
	private static final String X_B_3_SPAN_ID = "X-B3-SpanId";
	@Autowired
	private transient Tracer tracer;

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
		try {
			if (tracer == null) {
				LOG.error("No Sleuth tracer available");
			} else {
				Span span = tracer.currentSpan();
				if (span == null) {
					span = tracer.newTrace();
				}
				final TraceContext context = span.context();
				HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
				String traceId = null;
				String spanId = null;
				if (!StringUtils.isEmpty(httpServletRequest.getHeader(X_B_3_TRACE_ID))) {
					traceId = httpServletRequest.getHeader(X_B_3_TRACE_ID);
				} else {
					traceId = context.traceIdString();
				}
				if (!StringUtils.isEmpty(httpServletRequest.getHeader(X_B_3_SPAN_ID))) {
					spanId = httpServletRequest.getHeader(X_B_3_SPAN_ID);
				} else {
					spanId = String.valueOf(context.spanId());
				}
				HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
				httpServletResponse.setHeader(X_B_3_TRACE_ID, traceId);
				httpServletResponse.setHeader(X_B_3_SPAN_ID, String.valueOf(spanId));
			}
		} catch(Exception e) {
			LOG.error(e.getMessage(), e);
		} finally {
			chain.doFilter(servletRequest, servletResponse);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}
}
