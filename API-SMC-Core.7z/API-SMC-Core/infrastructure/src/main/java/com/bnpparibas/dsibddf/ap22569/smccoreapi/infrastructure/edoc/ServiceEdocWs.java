/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.edoc.IserviceEdoc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URLDecoder;
import java.util.List;

/**
 * @author c65344
 *
 */
@Service
public class ServiceEdocWs implements IserviceEdoc {
	private static final Logger LOG = LoggerFactory.getLogger(ServiceEdocWs.class);
	@Autowired
	@Qualifier("simpleresttemplate")
	private RestTemplate restTemplate;

	@Autowired
	private ConfigInfrastructure conf;

	@Override
	public String getIdGn(String idAttachment){


		HttpHeaders header = new HttpHeaders();

		header.set("Accept", "application/json");
		header.add("Content-Type", "application/json");
		header.add("media", conf.getMediaEdoc());
		header.add("channel", conf.getChannelEdoc());
		header.add("userId", conf.getUserIdEdoc());
		String idGdn = null;

		HttpEntity<String> request = new HttpEntity<String>(header);
		try{
			String url =conf.getUrlPutEdoc()+"/"+idAttachment+"/validate";

			ResponseEntity<ResponseEdocOutput> response = restTemplate.exchange(
					URLDecoder.decode( url, "UTF-8" ), HttpMethod.PUT, request,
					ResponseEdocOutput.class);

			ResponseEdocOutput responseBody = response.getBody();

			if(response !=null){
				HttpStatus statusCode = response.getStatusCode();
				if(statusCode.is2xxSuccessful()){
					idGdn = responseBody.getIdGDN();
				}else{

					LOG.error("message :"+responseBody.getMessage()+" description :"+responseBody.getDescription());

					List<GlobalErrors> globalErrors = responseBody.getGlobalErrors();
					List<FieldErrors> fieldErrors = responseBody.getFieldErrors();

					if(!CollectionUtils.isEmpty(globalErrors)){
						globalErrors.stream().forEach(err -> LOG.error("message :"+err.getMessage()+" objectName : "+err.getObjectName()));
					}

					if(!CollectionUtils.isEmpty(fieldErrors)){
						fieldErrors.stream().forEach(err -> LOG.error("field : "+err.getField()+" message :"+err.getMessage()+" objectName : "+err.getObjectName()));
					}
					LOG.error("message :"+responseBody.getMessage()+" description :"+responseBody.getDescription());

				}
			}else{
				LOG.error("Aucunne reponse du service edoc pour cet id d'attachement : "+idAttachment);
			}
		}catch(HttpClientErrorException e){
			String responseBodyAsString = e.getResponseBodyAsString();

			LOG.error(e.getMessage(),e);
			LOG.error(responseBodyAsString);
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
		}
		return idGdn;
	}



}
