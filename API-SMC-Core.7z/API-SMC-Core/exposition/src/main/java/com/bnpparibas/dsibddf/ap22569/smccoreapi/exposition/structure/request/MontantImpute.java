package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;
/**
 *
 * @author c65344
 *
 */
public class MontantImpute {
	@ApiModelProperty(value = "la partie entière du montant")
	private float amount;
	@ApiModelProperty(value = "les cents du montant")
	private float cents;
	@ApiModelProperty(value = "la devise")
	private String currency;
	/**
	 *
	 */
	public MontantImpute() {
		super();

	}
	/**
	 * @param amount
	 * @param cents
	 * @param currency
	 */
	public MontantImpute(float amount, float cents, String currency) {
		this.amount = amount;
		this.cents = cents;
		this.currency = currency;
	}
	/**
	 * @return the amount
	 */
	public float getAmount() {
		return amount;
	}
	/**
	 * @return the cents
	 */
	public float getCents() {
		return cents;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(float amount) {
		this.amount = amount;
	}
	/**
	 * @param cents the cents to set
	 */
	public void setCents(float cents) {
		this.cents = cents;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
}
