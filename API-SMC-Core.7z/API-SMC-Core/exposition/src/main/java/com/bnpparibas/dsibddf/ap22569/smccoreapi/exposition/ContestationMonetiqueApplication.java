package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.HeaderGetDoc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.HeaderSmc;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

/**
 *
 *
 *
 */
@ServletComponentScan
@SpringBootApplication
@EnableSwagger2
@EnableTransactionManagement
@EnableAspectJAutoProxy
@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi",
		"com.bnpparibas.dsibddf.ap22569.smctogdnapi",
		"com.bnpparibas.dsibddf.ap22569.smctoeditique.commons",
		"com.bnpparibas.dsibddf.ap22569.smctobcmp",
		"com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm",
		"com.bnpparibas.dsibddf.ap22569.smctobcmp",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.swagger",
		"com.bnpparibas.dsibddf.ap22569.smctoeditique.service",
		"com.bnpparibas.dsibddf.ap22569.smctoeditique.model.conf",
		"com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal",
		"com.bnpparibas.dsibddf.ap22569.smctocontacts",
		"com.bnpparibas.dsibddf.ap22569.accounts",
"com.bnpparibas.dsibddf.ap22569.smctohmp.goal"}, lazyInit = true)
public class ContestationMonetiqueApplication extends SpringBootServletInitializer {

	@Value("${PASSWORD.HMP}")
	private String password;
	@Value("${USERNAME.HMP}")
	private String username;


	private static final Logger LOG = LoggerFactory.getLogger(ContestationMonetiqueApplication.class);

	//@Autowired
	/**
	 * Main method used to launch Application with Embeded Tomcat
	 *
	 * @param args
	 * @throws Exception
	 */
	public static void main(final String[] args) throws Exception {
		SpringApplication.run(ContestationMonetiqueApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(ContestationMonetiqueApplication.class);
	}

	@Bean
	public Converter<String, HeaderSmc> headerConverter() {
		final Converter<String, HeaderSmc> converter = new Converter<String, HeaderSmc>() {
			@Override
			public HeaderSmc convert(String json) {
				ObjectMapper jsonMapper = new ObjectMapper();

				HeaderSmc header = null;
				try {
					header = jsonMapper.readValue(json, HeaderSmc.class);
				} catch (IOException e) {
					LOG.error(e.getMessage(),e);
				}
				return header;
			}
		};
		return converter;
	}

	@Bean
	public Converter<String, HeaderGetDoc> headersmcConverter() {
		final Converter<String, HeaderGetDoc> converter = new Converter<String, HeaderGetDoc>() {
			@Override
			public HeaderGetDoc convert(String json) {
				ObjectMapper jsonMapper = new ObjectMapper();

				HeaderGetDoc header = null;
				try {
					header = jsonMapper.readValue(json, HeaderGetDoc.class);
				} catch (IOException e) {
					LOG.error(e.getMessage(),e);
				}
				return header;
			}
		};
		return converter;
	}

	@Bean("i18nMessages")
	public MessageSource messageSource() {
		ResourceBundleMessageSource rbms = new ResourceBundleMessageSource();
		rbms.setBasename("messages");
		return rbms;
	}



	@Bean("simpleresttemplate")
	@Profile({"local", "dev"})
	public RestTemplate restTemplate() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();

		SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build();
		final SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
		Registry socketFactoryRegistry = RegistryBuilder.create().register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", socketFactory).build();
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		clientBuilder.setConnectionManager(connectionManager).setSSLContext(sslContext).disableCookieManagement();

		HttpClient httpClient = clientBuilder.build();
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setHttpClient(httpClient);

		final RestTemplate restTemplate = new RestTemplate(factory);
		restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(username, password));
		return restTemplate;
	}
	@Bean("simpleresttemplate")
	@Profile({"qua", "prd"})
	public RestTemplate simpleRestTemplate() {
		return new RestTemplate();
	}


}
