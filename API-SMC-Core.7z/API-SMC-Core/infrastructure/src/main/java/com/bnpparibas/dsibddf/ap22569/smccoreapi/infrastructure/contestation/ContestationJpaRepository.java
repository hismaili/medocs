package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
/**
 *
 *
 *
 */

public interface ContestationJpaRepository extends JpaRepository<ContestationEntity, DefaultEntityId> {

	@Query("SELECT c from ContestationEntity c JOIN c.listeOperation l WHERE l.codeOperation = :codeOperation")
	ContestationEntity findByCodeOperation(@Param(value = "codeOperation") String codeOperation);


	@Query("SELECT c from ContestationEntity c JOIN c.documentsAttaches d WHERE d.idGDN = :idGdn AND c.idTelematique = :idTelematic")
	List<ContestationEntity> findByIdTelematicAndIdGdn(@Param(value = "idTelematic") String idTelematic,@Param(value = "idGdn") String idGdn);


	/**
	 * recupère les contestations d'un utilisateur par date décroissante
	 * @param idTelematique
	 * @return
	 */
	List<ContestationEntity> findByIdTelematiqueOrderByDateMajDesc(String idTelematique);


	/**
	 *
	 * @param numDossierSMC
	 * @return
	 */
	ContestationEntity findByNumDossierSMC(@Param("numDossierSMC") String numDossierSMC);



	/**
	 *
	 * @param statusSmc
	 * @return
	 */
	@Query("SELECT c from ContestationEntity c  WHERE c.statusSmc = 'TOSEND' OR c.statusSmc = 'REJECTED'")
	Page<ContestationEntity> findByStatusToSend( Pageable pageable);


	/**** recherche des contestation n'ayant pas de recap ************/

	//TODO A REVOIR POUR GERVAIS
	@Query("SELECT c from ContestationEntity c JOIN  c.documentsAttaches d on ( d.recap = 'FALSE')")
	Page<ContestationEntity> findContestationWithNoRecap(Pageable pageable);



	/**
	 *
	 * @return
	 */
	@Query("SELECT COUNT(*) from ContestationEntity c  WHERE c.statusSmc = 'TOSEND' OR c.statusSmc = 'REJECTED'")
	Integer getNumberOfContestationToSend();

	/**
	 *
	 * @return
	 */  //TODO A REVOIR POUR GERVAIS
	@Query("SELECT COUNT(*) from ContestationEntity c JOIN  c.documentsAttaches d on ( d.recap = 'FALSE')")
	Integer getNumberOfContestationWithNoRecap();


}
