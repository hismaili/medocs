package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.StatusCodeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MapperBuilderDispute {
	private static final Logger LOG = LoggerFactory
			.getLogger(MapperBuilderDispute.class);

	/**
	 * get and map response of service SMC
	 *
	 * @param statusCode
	 * @param respDispute
	 * @return
	 */
	protected DisputeResponse getResponseSmc(ResponseEntity<ResponseDisputeFile> response) {
		DisputeResponse dispute  =null;

		HttpStatus statusCode = response.getStatusCode();

		ResponseDisputeFile respDispute = response.getBody();

		if(statusCode !=null){
			switch (statusCode) {

			case BAD_REQUEST:
				dispute = mapToDisputeResponse(respDispute, "Transaction Invalide");
				break;
			case UNAUTHORIZED:
				dispute = mapToDisputeResponse(respDispute,
						"Authentification Invalide");
				break;
			case NOT_FOUND:
				dispute = mapToDisputeResponse(respDispute,
						"Numéro de dossier inconnu");
				break;
			case INTERNAL_SERVER_ERROR:
				dispute = mapToDisputeResponse(respDispute, "Service indisponible");
				break;
			case BAD_GATEWAY:
				dispute = mapToDisputeResponse(respDispute, "Transaction Refusée");
				break;
			case SERVICE_UNAVAILABLE:
				dispute = mapToDisputeResponse(respDispute, "Incident Technique");
				break;
			case GATEWAY_TIMEOUT:
				dispute = mapToDisputeResponse(respDispute,
						"Transaction abandonnée");
				break;
			case OK:
				dispute = mapToDisputeResponse(respDispute,
						"success");
				break;

			default:
				break;
			}

		}

		return dispute;
	}

	/**
	 * map DisputeDataInput to DisputeData
	 *
	 * @param dispute
	 * @return
	 */
	protected DisputeData mapContestationToDisputeData(Contestation dispute) {
		DisputeData disputeData = null;
		if (dispute != null) {

			disputeData = new DisputeData();

			disputeData.setBankId(dispute.getNumCompte());
			disputeData.setCardId(dispute.getNumCarte());
			disputeData.setDisputeComment(dispute.getDescription());
			List<Operation> operations = dispute.getOperations();

			if (!CollectionUtils.isEmpty(operations)) {

				disputeData.setTransactionItems(operations.stream()
						.filter(oper -> oper != null&& !StringUtils.isEmpty(oper.getCodeOperation()))
						.map(oper -> {
							TransactionItem transactionItem = new TransactionItem();

							transactionItem.setBankId(dispute
									.getNumCompte());
							transactionItem.setCoidop(oper
									.getCodeOperation());
							Amount amount = new Amount();

							amount.setValue(oper.getMontantOperation());
							amount.setCurrency(oper
									.getDeviseOperation());
							transactionItem
							.setAcknowledgedAmount(amount);
							return transactionItem;
						}).collect(Collectors.toList()));
			}

		}

		return disputeData;
	}

	/**
	 * map to DisputeResponse Or LOG Errors
	 *
	 * @param respDispute
	 * @param label
	 * @return
	 */
	protected DisputeResponse mapToDisputeResponse(
			ResponseDisputeFile respDispute, String label) {
		DisputeResponse disputeResponse = null;

		List<Errors> errors = respDispute.getErrors();

		if (!CollectionUtils.isEmpty(errors)) {

			errors.stream()
			.filter(err -> err != null && !StringUtils.isEmpty(err))
			.forEach(
					err -> LOG.error("cause : " + label + ", code :"
							+ err.getCode() + ", message : "
							+ err.getMessage() + ", attribute :"
							+ err.getAttribute()));
		} else {
			if(respDispute !=null){
				disputeResponse = new DisputeResponse();
				StatusCodeResponse status = new StatusCodeResponse();
				disputeResponse.setFileIdSMC(respDispute.getFileIdSMC());
				BeanUtils.copyProperties(respDispute.getStatusCode(), status);
				disputeResponse.setStatusCodeResponse(status);
			}
		}

		return disputeResponse;
	}
}
