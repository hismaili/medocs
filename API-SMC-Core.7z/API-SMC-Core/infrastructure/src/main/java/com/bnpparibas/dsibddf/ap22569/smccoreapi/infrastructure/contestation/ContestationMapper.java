package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons.MaskUtils;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.DocumentAttache;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatutDossierContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationSign;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte.CarteEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 *
 *
 *
 */
public final class ContestationMapper {

	/**
	 *
	 * @param contestationEntity
	 * @return
	 */
	public static Contestation mapJpaEntityToModelEntity(ContestationEntity contestationEntity) {
		Contestation contestation = new Contestation();

		if(contestationEntity != null){

			BeanUtils.copyProperties(contestationEntity, contestation, "id"); //$NON-NLS-1$
			contestation.setDescription(contestationEntity.getDescriptionFaits());
			contestation.setMotif(MotifMapper.mapEntityToDomainBean(contestationEntity.getMotifContestation()));

			final List<DocumentAttacheEntity> documentsAttaches = contestationEntity.getDocumentsAttaches();
			if(!CollectionUtils.isEmpty(documentsAttaches)) {
				contestation.setDocumentAttaches(
						documentsAttaches.stream().map(documentAttacheEntity -> {
							DocumentAttache attachment = new DocumentAttache();
							BeanUtils.copyProperties(documentAttacheEntity, attachment);

							String referenceDossierSMC = documentAttacheEntity.getReferenceDossierSMC();
							if(!StringUtils.isEmpty(referenceDossierSMC)){
								attachment.setReferenceDossierSMC(referenceDossierSMC);
							}

							return attachment;
						}).collect(Collectors.toList()));
			}

			final List<OperationEntity> listeOperation = contestationEntity.getListeOperation();
			if(!CollectionUtils.isEmpty(listeOperation)){
				contestation.setOperations(listeOperation.stream().map(operationEntity -> {
					Operation operation = new Operation();
					BeanUtils.copyProperties(operationEntity,operation );

					SensOperation sensOperation = operationEntity.getSensOperation();

					if (sensOperation != null) {
						switch (sensOperation) {
						case CREDIT:
							operation
							.setSigneOperation(OperationSign.PLUS);

							break;
						case DEBIT:
							operation
							.setSigneOperation(OperationSign.MOINS);

							break;

						default:
							break;
						}
					}


					return operation;

				}).collect(Collectors.toList()));
			}
			contestation.setDateDeCreationDossier(contestationEntity.getDateCreation());
			StatutDossierContestation dernierStatutDossier = new StatutDossierContestation();
			final StatutDossierContestationSelfCare dernierStatutDossier1 = contestationEntity.getDernierStatutDossier();
			if(dernierStatutDossier1 != null){
				BeanUtils.copyProperties(dernierStatutDossier1, dernierStatutDossier);
				contestation.setDernierStatutDossier(dernierStatutDossier);
			}
			contestation.setIdContestation(contestationEntity.getEntityId().getId());

			//map card
			CarteEntity carte = contestationEntity.getCarte();

			//FIXME
			if(carte != null) {
				CartePorteur cartePorteur = new CartePorteur();
				cartePorteur.setNumCarteInput(MaskUtils.maskPan(carte.getNumeroCarte()));
				cartePorteur.setTypeProduit(carte.getTypeCarte());
				cartePorteur.setDateFinValiditeInput(carte.getDateExpiration());
				//TODO cartePorteur.setNumCompte(carte.get);
				final EtatCarteEntity etatCarte = carte.getEtatCarte();
				if (etatCarte != null) {
					cartePorteur.setStatutCarteInput(etatCarte.getLibelleEtat());
				}
				cartePorteur.setDatOppositionInput(carte.getDateOpposition());
				cartePorteur.setLibelleMotifOpposition(carte.getMotifOpposition());
				contestation.setCarte(cartePorteur);
			}

			/**
			 * ajout du numéro de telephone
			 */
			String telephone = contestationEntity.getTelephone();
			if(!StringUtils.isEmpty(telephone)) {
				String maskedPhoneNumber = new StringBuilder(" ** ** ** ")
				.append(telephone.subSequence(telephone.length() - 4, telephone.length())).toString();
				contestation.setNumeroTel(maskedPhoneNumber);
			}

		}

		return contestation;
	}
	/**
	 *
	 * @param contestation
	 * @return
	 */
	public static ContestationEntity mapModelEntityToJpaEntity(Contestation contestation) {
		ContestationEntity contestationEntity = new ContestationEntity();


		if(contestation !=null){
			BeanUtils.copyProperties(contestation, contestationEntity, "idContestation"); //$NON-NLS-1$
			contestationEntity.setDescriptionFaits(contestation.getDescription());
			StatutDossierContestationSelfCare dernierStatut = null;
			StatutDossierContestation dernierStatutDossier = contestation.getDernierStatutDossier();
			if(dernierStatutDossier != null) {
				dernierStatut = new StatutDossierContestationSelfCare();
				dernierStatut.setCodeStatut(dernierStatutDossier.getCodeStatut());
				//dernierStatut.setLibelleStatut(dernierStatutDossier.getLibelleStatut());
			}
			contestationEntity.setDernierStatutDossier(dernierStatut);

			final List<DocumentAttache> documentsAttaches = contestation.getDocumentAttaches();
			if(!CollectionUtils.isEmpty(documentsAttaches)) {
				contestationEntity.setDocumentsAttaches(
						documentsAttaches.stream().map(documentAttache -> {
							DocumentAttacheEntity attachment = new DocumentAttacheEntity();
							BeanUtils.copyProperties(documentAttache, attachment);
							//attachment.setRecap(documentAttache.isRecap());
							return attachment;
						}).collect(Collectors.toList()));
			}

			List<OperationEntity> operationEntities = null;

			List<Operation> operations = contestation.getOperations();
			if(!CollectionUtils.isEmpty(operations)){
				operationEntities = operations.stream().map(operation -> {
					OperationEntity operationentity = new OperationEntity();
					BeanUtils.copyProperties(operation, operationentity);
					OperationSign signeOperation = operation.getSigneOperation();

					if(signeOperation !=null){
						switch (signeOperation) {
						case PLUS:
							operationentity
							.setSensOperation(SensOperation.CREDIT);

							break;
						case MOINS:
							operationentity
							.setSensOperation(SensOperation.DEBIT);

							break;

						default:
							break;
						}
					}


					return operationentity;

				})
				.collect(Collectors.toList());
			}
			contestationEntity.setListeOperation(operationEntities);


			if(!StringUtils.isEmpty(contestation.getIdContestation())) {
				DefaultEntityId entityId = new DefaultEntityId(Objects.requireNonNull(contestation.getIdContestation()));
				contestationEntity.setEntityId(entityId);
			}

			MotifEntity motif = new MotifEntity();
			final MotifContestation motif1 = contestation.getMotif();
			if(motif1 != null){
				motif.setCode(motif1.getCode());
				contestationEntity.setMotifContestation(motif);
			}
		}



		return contestationEntity;
	}

}
