
package com.bnpparibas.dsibddf.ap22569.notification.batch;

import com.bnpparibas.dsibddf.ap22569.notification.batch.config.CustomExitCodeGenerator;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.Banner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.batch.JobExecutionEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.MessageSourceResourceBundle;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

import java.util.ResourceBundle;

@SpringBootApplication
@EnableAutoConfiguration
@EnableJms
@EnableBatchProcessing
@ComponentScan(basePackages = { "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.domain",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.application",
		"com.bnpparibas.dsibddf.ap22569.notification.batch"}, lazyInit = true)
public class SmcNotificationBatchApplication {

	@Value("${mail.templates.location}")
	private String mailTemplatesLocation;

	@Value("${mail.smtp.host}")
	private String mailSmtpHost;

	@Value("${mail.smtp.port}")
	private Integer mailSmtpPort;

	@Value("${mail.smtp.username}")
	private String mailSmtpUserName;

	@Value("${mail.smtp.password}")
	private String mailSmtpPassword;

	public static void main(final String[] args) {

		SpringApplication app = new SpringApplication(SmcNotificationBatchApplication.class);
		app.setBannerMode(Banner.Mode.OFF);

		ExitCodeGenerator exitCodeGenrator = new CustomExitCodeGenerator();
		app.addListeners((ApplicationListener<JobExecutionEvent>)exitCodeGenrator);
		System.exit(SpringApplication.exit(app.run(args), exitCodeGenrator));

	}

	@Bean
	public TemplateEngine emailTemplateEngine() {
		final SpringTemplateEngine templateEngine = new SpringTemplateEngine();
		// Resolver for TEXT emails
		templateEngine.addTemplateResolver(textTemplateResolver());
		// Resolver for HTML emails (except the editable one)
		templateEngine.addTemplateResolver(htmlTemplateResolver());

		return templateEngine;
	}

	private ITemplateResolver textTemplateResolver() {
		final ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
		templateResolver.setOrder(Integer.valueOf(1));
		//templateResolver.setResolvablePatterns(Collections.singleton(mailTemplatesLocation+"/text/*"));
		//templateResolver.setPrefix(mailTemplatesLocation);
		templateResolver.setSuffix(".txt");
		templateResolver.setTemplateMode(TemplateMode.TEXT);
		templateResolver.setCacheable(false);
		return templateResolver;
	}

	private ITemplateResolver htmlTemplateResolver() {
		final ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
		templateResolver.setOrder(Integer.valueOf(2));
		//templateResolver.setResolvablePatterns(Collections.singleton("*/html/*"));
//		templateResolver.setPrefix(mailTemplatesLocation);
		templateResolver.setSuffix(".html");
		templateResolver.setTemplateMode(TemplateMode.HTML);
		templateResolver.setCheckExistence(Boolean.TRUE);
		//templateResolver.setCharacterEncoding();
		templateResolver.setCacheable(false);
		return templateResolver;
	}


	@Bean(name = "errorMessageResourceBundle")
	public ResourceBundle errorMessageResourceBundle() {
		ResourceBundle bundle = MessageSourceResourceBundle.getBundle("errorMessages");
		return bundle;
	}

	@Bean
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(mailSmtpHost);
		mailSender.setPort(mailSmtpPort);
		mailSender.setUsername(mailSmtpUserName);
		mailSender.setPassword(mailSmtpPassword);
		return mailSender;
	}

}