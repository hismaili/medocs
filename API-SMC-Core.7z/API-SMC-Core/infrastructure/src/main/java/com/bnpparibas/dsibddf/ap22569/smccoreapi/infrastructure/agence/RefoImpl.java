package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.agence;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.IRefo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.RefoException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.ResponseRefo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal.MandatoryRefoException;
import com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal.RefoWs;
import com.bnpparibas.dsibddf.ap22569.smctorefoapi.model.response.ResponseRefoGlobal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 *
 * @author c65344
 *
 */
@Component
public class RefoImpl implements IRefo {
	private static final Logger LOG = LoggerFactory.getLogger(RefoImpl.class);

	private static final String HELLOBANK = "HB"; //$NON-NLS-1$
	private static final String BDDF = "BDDF"; //$NON-NLS-1$

	@Autowired(required=false)
	private transient RefoWs refo;

	@Autowired(required=false)
	private transient ConfigInfrastructure conf;

	@Override
	public ResponseRefo getTypeBank(String codeUO) throws RefoException{
		ResponseRefoGlobal responseRefoGlobal;

		try {
			if (!StringUtils.isEmpty(codeUO)) {


				responseRefoGlobal = refo.getTypeBankReFO(codeUO);

				if (responseRefoGlobal.getError() != null
						&& responseRefoGlobal.getError().getCode() != 0) {
					LOG.error("CodeRefo :"+responseRefoGlobal.getError().getCode()+" , MessageRefo : "+responseRefoGlobal.getError().getMessage());
					throw new RefoException(conf.getMessageErrorTechnique());
				} else {

					return new ResponseRefo(responseRefoGlobal.isHelloBank(),responseRefoGlobal.isUoMonagasque());
				}

			} else {
				LOG.error(conf.getMessageCodeUOAbsent());
				throw new RefoException(conf.getMessageErrorTechnique());
			}
		} catch (com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal.RefoException e) {
			LOG.error(e.getMessage(), e);
			throw new RefoException(conf.getMessageErrorTechnique());
		}catch (MandatoryRefoException e) {
			LOG.error(e.getMessage(), e);
			throw new RefoException(conf.getMessageErrorTechnique());
		}
	}

}
