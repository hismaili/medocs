package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file;

import java.time.LocalDate;

public class FileValidationException extends Exception {

    private String errorCode;
    private String fileName;
    private LocalDate fileDate;
    private String errorMessage;

    public FileValidationException(String message, String errorCode, String fileName, LocalDate fileDate, String errorMessage) {
        super(message);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
        this.fileName = fileName;
        this.fileDate = fileDate;
    }



    /*public FileValidationException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }*/

    public String getErrorCode() {
        return errorCode;
    }

    public String getFileName() {
        return fileName;
    }

    public LocalDate getFileDate() {
        return fileDate;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
