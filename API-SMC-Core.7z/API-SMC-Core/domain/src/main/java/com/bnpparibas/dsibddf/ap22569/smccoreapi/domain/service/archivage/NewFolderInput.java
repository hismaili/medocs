package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;


/**
 *
 * @author c65344
 *
 */
public class NewFolderInput {

	private String callingUser;
	private String numCarteBancaireNewFolderInput;
	private String idContestationSmcNewFolderInput;
	private String callingApplication;
	private String localeCode;
	private String countryCode;
	/**
	 * @return the callingApplication
	 */
	public String getCallingApplication() {
		return callingApplication;
	}
	/**
	 * @return the callingUser
	 */
	public String getCallingUser() {
		return callingUser;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @return the idContestationSmcNewFolderInput
	 */
	public String getIdContestationSmcNewFolderInput() {
		return idContestationSmcNewFolderInput;
	}
	/**
	 * @return the localeCode
	 */
	public String getLocaleCode() {
		return localeCode;
	}
	/**
	 * @return the numCarteBancaireNewFolderInput
	 */
	public String getNumCarteBancaireNewFolderInput() {
		return numCarteBancaireNewFolderInput;
	}
	/**
	 * @param callingApplication the callingApplication to set
	 */
	public void setCallingApplication(String callingApplication) {
		this.callingApplication = callingApplication;
	}
	/**
	 * @param callingUser the callingUser to set
	 */
	public void setCallingUser(String callingUser) {
		this.callingUser = callingUser;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @param idContestationSmcNewFolderInput the idContestationSmcNewFolderInput to set
	 */
	public void setIdContestationSmcNewFolderInput(
			String idContestationSmcNewFolderInput) {
		this.idContestationSmcNewFolderInput = idContestationSmcNewFolderInput;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(String localeCode) {
		this.localeCode = localeCode;
	}
	/**
	 * @param numCarteBancaireNewFolderInput the numCarteBancaireNewFolderInput to set
	 */
	public void setNumCarteBancaireNewFolderInput(
			String numCarteBancaireNewFolderInput) {
		this.numCarteBancaireNewFolderInput = numCarteBancaireNewFolderInput;
	}


}
