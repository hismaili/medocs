package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;

import java.util.List;

/**
 *
 *
 *
 */
public interface IContestationRepository {

	/** Creer une contestation dans la couche monétique */
	Contestation creerContestation(Contestation contestation);

	boolean isAuthorized(String idGdn,String idTelematic);

	/**
	 * purge Tout les documents dont les numeros de dossiers sont joints
	 * @param numeroDossiers
	 * @return
	 * @throws ContestationException
	 */
	boolean isPurged(List<String> numeroDossiers) throws ContestationException;

	/** recuperer une contestation identifiée par sa référence dossier SMC */
	Contestation recupererContestation(String referenceDossier) throws ContestationException;

	/**
	 * recuperer une contestation par l'id interne
	 * @param idContestation
	 * @return
	 * @throws ContestationException
	 */
	Contestation recupererContestationByIdInterne(String idContestation) throws ContestationException;

	/**
	 * recuperer l'historique des contestations par identifiant telematique
	 *
	 * @param identifiant
	 * @return
	 * @throws ContestationException
	 *
	 */
	List<Contestation> recupererContestationsClient(String identifiant,Integer offset,Integer limit
			) throws ContestationException;

	/** Creer une contestation dans la couche monétique */
	Contestation updateContestation(Contestation contestation);
}
