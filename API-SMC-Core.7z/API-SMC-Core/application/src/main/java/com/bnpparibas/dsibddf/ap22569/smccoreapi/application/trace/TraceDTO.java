package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace;

import java.time.LocalDateTime;

/**
 *
 *
 *
 */
public class TraceDTO {

	private String idContestation;
	private String service;
	private LocalDateTime dateAppel;
	private String applicationAppelante;
	private String paramIn;
	private String paramOut;
	private String sens;
	private int statusCode;
	private String traceId;

	/**
	 * @return the applicationAppelante
	 */
	public String getApplicationAppelante() {
		return applicationAppelante;
	}
	/**
	 * @return the dateAppel
	 */
	public LocalDateTime getDateAppel() {
		return dateAppel;
	}
	/**
	 * @return the idContestation
	 */
	public String getIdContestation() {
		return idContestation;
	}
	/**
	 * @return the paramIn
	 */
	public String getParamIn() {
		return paramIn;
	}
	/**
	 * @return the paramOut
	 */
	public String getParamOut() {
		return paramOut;
	}
	/**
	 * @return the sens
	 */
	public String getSens() {
		return sens;
	}
	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}
	/**
	 * @param applicationAppelante the applicationAppelante to set
	 */
	public void setApplicationAppelante(String applicationAppelante) {
		this.applicationAppelante = applicationAppelante;
	}
	/**
	 * @param dateAppel the dateAppel to set
	 */
	public void setDateAppel(LocalDateTime dateAppel) {

		this.dateAppel = dateAppel;

	}
	/**
	 * @param idContestation the idContestation to set
	 */
	public void setIdContestation(String idContestation) {
		this.idContestation = idContestation;
	}
	/**
	 * @param paramIn the paramIn to set
	 */
	public void setParamIn(String paramIn) {
		this.paramIn = paramIn;
	}
	/**
	 * @param paramOut the paramOut to set
	 */
	public void setParamOut(String paramOut) {
		this.paramOut = paramOut;
	}
	/**
	 * @param sens the sens to set
	 */
	public void setSens(String sens) {
		this.sens = sens;
	}
	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
}
