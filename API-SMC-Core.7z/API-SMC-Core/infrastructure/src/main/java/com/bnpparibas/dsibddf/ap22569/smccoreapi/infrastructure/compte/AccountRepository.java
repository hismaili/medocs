package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.compte;

import com.bnpparibas.dsibddf.ap22569.accounts.api.HolderAccountsApi;
import com.bnpparibas.dsibddf.ap22569.accounts.api.HolderAccountsException;
import com.bnpparibas.dsibddf.ap22569.accounts.model.HolderAccount;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.IAccountRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccount;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccountException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons.MaskUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Repository
public class AccountRepository implements IAccountRepository {

	@Autowired
	private transient AliasedAccountJpaRepository aliasedAccountJpaRepository;

	@Autowired(required=false)
	private transient HolderAccountsApi holderAccountsApi;

	private Map<String, List<UserAccount>> mockUserAccounts = new HashMap<>();

	{
		//plusieurs comptes : 2289627126 --> 300040128400001237118, 300040112500000720183, 30004000580000675018886
		List<UserAccount> accounts = new ArrayList<>();
		UserAccount userAccount = new UserAccount();
		userAccount.setAccountHolderName("Pierre Dupont");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("2289627126");
		userAccount.setIkpi("01630005685900000");
		userAccount.setRib("300040128400001237118");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("300040128400001237118"));
		accounts.add(userAccount);

		userAccount = new UserAccount();
		userAccount.setAccountHolderName("Pierre Dupont");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("2289627126");
		userAccount.setIkpi("01630005685900000");
		userAccount.setRib("300040112500000720183");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("300040112500000720183"));
		accounts.add(userAccount);

		userAccount = new UserAccount();
		userAccount.setAccountHolderName("Pierre Dupont");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("2289627126");
		userAccount.setIkpi("01630005685900000");
		userAccount.setRib("30004000580000675018886");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("30004000580000675018886"));
		accounts.add(userAccount);
		mockUserAccounts.put("2289627126", accounts);

		//Un seul compte : 3865814351 --> 300040158400000549338
		accounts = new ArrayList<>();
		userAccount = new UserAccount();
		userAccount.setAccountHolderName("Marie Lefevre");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("3865814351");
		userAccount.setIkpi("01700021073900000");
		userAccount.setRib("300040158400000549338");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("300040158400000549338"));
		accounts.add(userAccount);
		mockUserAccounts.put("3865814351", accounts);

		//Un seul compte : 3865814351 --> 300040137900001528280
		accounts = new ArrayList<>();
		userAccount = new UserAccount();
		userAccount.setAccountHolderName("Alain Robert");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("3610838481");
		userAccount.setIkpi("01260016662400000");
		userAccount.setRib("300040137900001528280");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("300040137900001528280"));
		accounts.add(userAccount);
		mockUserAccounts.put("3610838481", accounts);

		accounts = new ArrayList<>();
		userAccount = new UserAccount();
		userAccount.setAccountHolderName("Romain Joe");
		userAccount.setAccountId(UUID.randomUUID().toString());
		userAccount.setAccountType("Compte Chèque");
		userAccount.setTelematicId("3612124416");
		userAccount.setIkpi("01380010166600000");
		userAccount.setRib("300040149600000922835");
		userAccount.setMaskedAccountNumber(MaskUtils.maskRib("300040149600000922835"));
		accounts.add(userAccount);
		mockUserAccounts.put("3612124416", accounts);

	}

	@Override
	public UserAccount getAccountByAlias(String alias) throws UserAccountException {
		AliasedAccountEntity aliasedAccount = this.aliasedAccountJpaRepository.findByAccountId(alias);
		UserAccount userAccount = new UserAccount();
		BeanUtils.copyProperties(aliasedAccount, userAccount);
		return userAccount;
	}

	@Override
	public List<UserAccount> getUserAccounts(String telemeticId,String userId) throws UserAccountException {
		List<UserAccount> result = null;
		List<AliasedAccountEntity> accounts = this.aliasedAccountJpaRepository.findByTelematicIdAndIkpi(telemeticId,userId);
		if(!CollectionUtils.isEmpty(accounts)) {
			result = accounts.stream().map(alias -> {
				UserAccount account = new UserAccount();
				BeanUtils.copyProperties(alias, account);
				return account;
			}).collect(Collectors.toList());
		} else {
			List<UserAccount> userAccounts = null;
			try {
				List<HolderAccount> holderAccounts = this.holderAccountsApi.getHolderAccounts(Long.valueOf(telemeticId));
				//TODO throw exception if no account found
				if(CollectionUtils.isEmpty(holderAccounts)) {
					throw new UserAccountException("No Account found for user "+telemeticId);
				} else {
					userAccounts = holderAccounts.stream().map(account -> {
						UserAccount userAccount = new UserAccount();
						userAccount.setRib(account.getAccountId());
						userAccount.setTelematicId(telemeticId);
						userAccount.setAccountType(account.getAccountType());
						userAccount.setMaskedAccountNumber(MaskUtils.maskRib(account.getAccountId()));
						userAccount.setAccountId(UUID.randomUUID().toString());
						userAccount.setIkpi(userId);

						//TODO userAccount.setAccountHolderName();userAccount.setIkpi();
						return userAccount;
					}).collect(Collectors.toList());
				}
			} catch (HolderAccountsException e) {
				UserAccountException exception = new UserAccountException(e);
				throw exception;
			}
			//mockUserAccounts.get(telemeticId);
			if(!CollectionUtils.isEmpty(userAccounts)) {
				userAccounts.stream().forEach(ac -> {
					AliasedAccountEntity aliasedAccount = new AliasedAccountEntity();
					BeanUtils.copyProperties(ac, aliasedAccount);
					this.aliasedAccountJpaRepository.saveAndFlush(aliasedAccount);
				});
				result = userAccounts;
			}

		}
		return result;
	}

	/**
	 * @param mockUserAccounts the mockUserAccounts to set
	 */
	public void setMockUserAccounts(Map<String, List<UserAccount>> mockUserAccounts) {
		this.mockUserAccounts = mockUserAccounts;
	}
}
