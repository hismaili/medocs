package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.archivage;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IContestationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ContestationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ContestationJpaRepository;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


@SpringBootTest(classes = SpringBootApp.class)
@RunWith(SpringRunner.class)
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
public class ArchivageDocumentImplTest {

	private static final Logger LOG = LoggerFactory.getLogger(ArchivageDocumentImplTest.class);

	private static String dataPdfInBase64() {

		File file =  new File("src/test/resources/Test.pdf");

		String encodstring = encodeFileToBase64Binary(file);
		return encodstring;

	}

	private static String encodeFileToBase64Binary(File file){
		String encodedfile = null;
		try {
			FileInputStream fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int)file.length()];
			fileInputStreamReader.read(bytes);
			encodedfile = new String(Base64.encodeBase64(bytes), StandardCharsets.UTF_8);
		} catch (FileNotFoundException e) {
			LOG.error(e.getMessage(), e);
		} catch (IOException e) {
			LOG.error(e.getMessage(), e);
		}

		return encodedfile;
	}
	@Autowired
	private transient ContestationJpaRepository contestationjpa;

	@Autowired
	private transient ArchivageDocumentImpl archivageDocumentImpl;

	@Autowired
	private transient IContestationRepository contestationImpl;



	private String getDocumentID() throws ArchivingException, SmcTechnicalException, MandatoryException, FormatErrorException{

		NewDocInput newDocInput = new NewDocInput();

		newDocInput.setCallingUserNewDocInput("c65344");
		newDocInput.setCountryCodeNewDocInput("FRA");
		newDocInput.setLocaleCodeNewDocInput("FRA");


		newDocInput.setDocumentTypeIdNewDocInput("20180110");
		newDocInput.setMimeTypeNewDocInput("application/pdf");
		newDocInput.setTitreNewDocInput("Test enreg puis modif");




		newDocInput.setFileNameNewDocInput("Document Acrobat.");
		newDocInput.setEncodingNewDocInput("BASE64");
		newDocInput.setDataNewDocInput(dataPdfInBase64());
		newDocInput.setArchiveFormatNewDocInput("PDF");
		newDocInput.setCompressNewDocInput("none");

		return archivageDocumentImpl.newDoc(newDocInput);

	}

	@Test
	public void scenarioNewDocGetDoCDeleteDoc() throws ArchivingException,SmcTechnicalException, MandatoryException, FormatErrorException{
		String documentId = getDocumentID();
		testNewDoc(documentId);
		testGetDoc(documentId);
		testDeleteDoc(documentId);


	}


	@Test
	public void testCloseFolder() throws ArchivingException, SmcTechnicalException, MandatoryException, FormatErrorException, DonneIncorectException {
		BigInteger bigInteger = new BigInteger("444");

		Date input = new Date();
		LocalDate localDate = input.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		CloseFolderInput closeFolderInput = new CloseFolderInput();


		closeFolderInput.setCallingUserCloseFolderInput("c65344");
		closeFolderInput.setCountryCodeCloseFolderInput("FRA");
		closeFolderInput.setLocaleCodeCloseFolderInput("FRA");

		closeFolderInput.setListedocumentId(Arrays.asList("GD11100jnlx2i0j000001mu","GD11100jnlx2i0j000001m5","GD11100jnlx2i0j000001m7"));

		closeFolderInput.setClientFirstnameCloseFolderInput("APUYH");
		closeFolderInput.setClientNameCloseFolderInput("SYJHO");
		closeFolderInput.setBirthDay(localDate);
		closeFolderInput.setSirenCloseFolderInput(bigInteger);
		closeFolderInput.setClientNatureIdCloseFolderInput("01");
		closeFolderInput.setArchivingReferenceDate("11/02/2019");


		closeFolderInput.setDocumentTypeIdCloseFolderInput("20180110");
		closeFolderInput.setMimeTypeCloseFolderInput("application/pdf");
		closeFolderInput.setTitreCloseFolderInput("Test enreg puis modif");




		closeFolderInput.setFileNameCloseFolderInput("Document Acrobat.");
		closeFolderInput.setEncodingCloseFolderInput("BASE64");
		closeFolderInput.setDataCloseFolderInput(dataPdfInBase64());
		closeFolderInput.setArchiveFormatCloseFolderInput("PDF");
		closeFolderInput.setCompressCloseFolderInput("none");

		String message = archivageDocumentImpl.closeFolder(closeFolderInput);
		assertTrue(message !=null);
		assertTrue(!message.isEmpty());

	}
	public void testDeleteDoc(String documentID) throws ArchivingException, SmcTechnicalException, MandatoryException {
		DeleteDocInput deleteDocInput = new DeleteDocInput();
		deleteDocInput.setCallingUserDeleteInput("c65344");
		deleteDocInput.setCountryCodeDeleteInput("FRA");
		deleteDocInput.setLocaleCodeDeleteInput("FRA");
		deleteDocInput.setDocumentIdDeleteInput(documentID);

		String documentId = archivageDocumentImpl.deleteDoc(deleteDocInput);
		assertTrue(documentId !=null);

	}


	public void testGetDoc(String documentID ) throws ArchivingException, SmcTechnicalException, MandatoryException {
		DocInput documentToget = new DocInput("c65344",
				documentID,
				"collab",
				"4444");
		DocOutput response = archivageDocumentImpl.getDoc(documentToget);

		assertTrue(response.getDataOutputOutput() !=null);
		assertTrue(!response.getDataOutputOutput().isEmpty());
	}


	public void testNewDoc(String documentID) throws ArchivingException {
		assertTrue(documentID !=null);
	}

	@Test
	public void testNewFolder() throws ArchivingException,MandatoryException {
		NewFolderInput newFolderInput = new NewFolderInput();
		newFolderInput.setCallingUser("c65344");
		newFolderInput.setCountryCode("FRA");
		newFolderInput.setLocaleCode("FRA");
		String identifier = archivageDocumentImpl.newFolder(newFolderInput);
		assertTrue(identifier !=null);
		assertTrue(!identifier.isEmpty());
	}


	@Test
	@Ignore
	//FIXME test à corriger
	public void testPurgeFolder() throws ArchivingException, ContestationException {


		Contestation contestation1 = new Contestation();
		contestation1.setNumDossierSMC("4589");
		contestation1.setPurged(false);

		Contestation contestation2 = new Contestation();
		contestation2.setNumDossierSMC("4590");
		contestation2.setPurged(false);


		Contestation contestation3 = new Contestation();
		contestation3.setNumDossierSMC("4591");
		contestation3.setPurged(false);


		contestationImpl.creerContestation(contestation1);
		contestationImpl.creerContestation(contestation2);
		contestationImpl.creerContestation(contestation3);

		PurgeFolderInput purgeFolderInput = new PurgeFolderInput();

		purgeFolderInput.setListeIdContestationPurgeFolderInput(Arrays.asList("4589","4590")); //$NON-NLS-1$ //$NON-NLS-2$

		archivageDocumentImpl.purgeFolder(purgeFolderInput);

		ContestationEntity resultTrue = contestationjpa.findByNumDossierSMC("4589"); //$NON-NLS-1$
		ContestationEntity resultFalse = contestationjpa.findByNumDossierSMC("4591"); //$NON-NLS-1$

		assertTrue(resultTrue.getPurged() !=null );
		assertTrue(resultFalse.getPurged() !=null);

		assertTrue(resultTrue.getPurged().booleanValue());
		assertFalse(resultFalse.getPurged().booleanValue());
	}
}
