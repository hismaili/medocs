/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.commons;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcTechnicalException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author c65344
 *
 */
@Service
public class MappingExceptionApp {

	/**
	 * converti les erreurs Detaillés en erreurs technique
	 *
	 * @param errors
	 * @return
	 */
	public SmcTechnicalException mappingDetailsExceptionToTechincal(Map<List<String>,List<String>> errors){
		Map<String,List<String>> errorFinal = new HashMap<>();
		if( errors !=null){
			Set<Entry<List<String>, List<String>>> errosEntrySet = errors.entrySet();
			if(errosEntrySet !=null){
				errosEntrySet.stream().forEach(err -> {
					errorFinal.put(err.getKey().get(0), err.getValue());

				});
			}
		}
		return new SmcTechnicalException(errorFinal);
	}
}
