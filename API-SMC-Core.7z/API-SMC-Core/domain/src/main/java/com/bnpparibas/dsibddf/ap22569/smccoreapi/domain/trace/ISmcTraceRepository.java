package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace;

import org.springframework.stereotype.Component;

@Component
public interface ISmcTraceRepository {

	void createTrace(SmcTrace trace);
}
