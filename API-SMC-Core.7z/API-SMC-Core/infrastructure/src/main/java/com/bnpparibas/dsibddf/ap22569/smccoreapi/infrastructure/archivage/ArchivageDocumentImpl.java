package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.archivage;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IContestationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.InfoPersonneImpl;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.model.structure.request.*;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.model.structure.response.ResponseFromGdn;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.model.structure.response.ResponseGetFromGdn;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.model.structure.responsexml.JdfError;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.model.structure.responsexml.JdfErrorDetail;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.service.ws.ArchivageTechniqueException;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.service.ws.FormatGdnException;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.service.ws.MandatoryGdnException;
import com.bnpparibas.dsibddf.ap22569.smctogdnapi.infrastructure.service.ws.ServicesGdn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.*;


@Component
public class ArchivageDocumentImpl implements IArchivageDocument {

	private static final Logger LOG = LoggerFactory.getLogger(ArchivageDocumentImpl.class);

	private static ResponseFromGdn response;

	private static String folderId;

	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$
	private static final String NULLVALUE = null;

	@Autowired
	private transient ConfigInfrastructure conf;
	@Autowired(required=false)
	private transient ServicesGdn servicesGdn;
	@Autowired
	private transient InfoPersonneImpl infoPersonneWS ;
	@Autowired
	private transient IContestationRepository contestationRepositoryImpl;


	private boolean checkDate(String valeur){
		Date date = null;
		boolean  value = false;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); //$NON-NLS-1$
		try{
			date = sdf.parse(valeur);

			if(valeur.equals(sdf.format(date))){
				value =true;
			}
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
			value = false;
		}

		return value;
	}

	/**
	 *
	 * @param mimeType
	 * @param listFormat
	 */
	private void checkFormat(String mimeType,String date,List<String> listFormat){
		if(!mimeType.equals(conf.getMimeTypeformat1()) && !mimeType.equals(conf.getMimeTypeformat2())){
			listFormat.add(conf.getMimeTypeErrorFormat());
		}
		if(!checkDate(date)){
			listFormat.add(conf.getFormatDateError());
		}
	}

	/**
	 *
	 * @param fiel
	 * @param libelleErreur
	 * @param listToAdd
	 */
	private void checkMandatoryField(String fiel,String libelleErreur, List<String> listToAdd){
		if(fiel == null || fiel.isEmpty()){
			listToAdd.add(libelleErreur);

		}
	}

	/**
	 *
	 * @param callingUser
	 * @param docsIdsGDN
	 * @param documentTypeId
	 * @param archivingReferenceDate
	 * @param titre
	 * @param fileName
	 * @param archiveFormat
	 * @param mimeType
	 * @param compress
	 * @param encoding
	 * @param data
	 * @param idDocument
	 * @return
	 */
	private List<String> checkMandatoryFields(String callingUser,List<String> docsIdsGDN,
			String documentTypeId,String archivingReferenceDate,String titre,String fileName,String archiveFormat,
			String mimeType,String compress,String encoding,String data,String idDocument
			){

		List<String> errors = new ArrayList<>();
		checkMandatoryField(archiveFormat,conf.getArchiveformatAbsent(), errors);
		checkMandatoryField(titre,conf.getTitreAbsent(), errors);

		checkMandatoryField(callingUser, conf.getCallingUserAbsent(), errors);
		checkMandatoryField(documentTypeId,conf.getDocumentTypeIdAbsent(), errors);
		checkMandatoryField(archivingReferenceDate,conf.getArchivingreferencedateAbsent(), errors);
		checkMandatoryField(fileName,conf.getFilenameAbsent(), errors);

		checkMandatoryField(mimeType,conf.getMimetypeAbsent(), errors);
		checkMandatoryField(compress,conf.getCompressAbsent(), errors);
		checkMandatoryField(encoding,conf.getEncodingAbsent(), errors);

		checkMandatoryField(idDocument,conf.getDocumentIdAbsent(), errors);
		checkMandatoryField(data,conf.getDataAbsent(), errors);

		if(docsIdsGDN == null || docsIdsGDN.isEmpty()) {
			errors.add(conf.getListeIdDocsAbsent());
		}

		return errors;
	}


	private List<String> checkMandatoryOfGetDoc(String callingUser,String userType,String documentId){
		List<String> errors = new ArrayList<>();

		checkMandatoryField(callingUser, conf.getCallingUserAbsent(),errors);
		checkMandatoryField(userType,conf.getUsertypeAbsent(),errors);
		checkMandatoryField(documentId,conf.getDocumentIdAbsent(),errors);


		return errors;
	}

	/**
	 * Fait passer un dossier contenant plusieurs documents à l'etat securisé en enregistrant un document recapitulatif
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 * @throws ArchivageTechniqueException
	 */
	@Override
	public String closeFolder(CloseFolderInput closeFolderInput) throws ArchivingException,MandatoryException, FormatErrorException, DonneIncorectException {
		List<String> errors = new ArrayList<String>();

		List<String> listErrorFormat = new ArrayList<String>();

		try {
			if(closeFolderInput !=null ){
				HeaderRequest headerRequestcloseFolderInput = new HeaderRequest(
						closeFolderInput.getCallingUserCloseFolderInput(),
						conf.getCallingApplication(),
						closeFolderInput.getLocaleCodeCloseFolderInput(),
						closeFolderInput.getCountryCodeCloseFolderInput(), null);


				BodyRequestCommon bodyRequestCommonCloseFolder = new BodyRequestCommon();

				bodyRequestCommonCloseFolder.setNormLevel(conf.getNormLevel());
				bodyRequestCommonCloseFolder.setOwningApplication(conf.getOwningApplication());
				bodyRequestCommonCloseFolder.setStorageLevel(conf.getStorageLevel());
				bodyRequestCommonCloseFolder.setClassificationNatureId(conf.getClassificationNatureId());


				RequestArchivingContext requestArchivingContextSecureDoc = new RequestArchivingContext();
				requestArchivingContextSecureDoc.setArchivingReferenceDate(closeFolderInput.getArchivingReferenceDate());

				requestArchivingContextSecureDoc.setPublicationTop(conf.getPublicationTop());

				ArrayList<IndexRequest> listIndexArchivingContextsecure = new ArrayList<>();

				listIndexArchivingContextsecure.add(new IndexRequest(conf.getClientNatureId(),closeFolderInput.getClientNatureIdCloseFolderInput() ));

				listIndexArchivingContextsecure.add(new IndexRequest(conf.getClientName(),closeFolderInput.getClientNameCloseFolderInput() ));

				listIndexArchivingContextsecure.add(new IndexRequest(conf.getClientFirstname(),closeFolderInput.getClientFirstnameCloseFolderInput()));

				if(closeFolderInput.getBirthDay() !=null){
					listIndexArchivingContextsecure.add(new IndexRequest(conf.getBirthDate(),closeFolderInput.getBirthDay().toString()  ));
				}

				if(closeFolderInput.getSirenCloseFolderInput() !=null){
					listIndexArchivingContextsecure.add(new IndexRequest(conf.getSirenNumber(),closeFolderInput.getSirenCloseFolderInput().toString() ));
				}

				listIndexArchivingContextsecure.add(new IndexRequest(conf.getClientId(),closeFolderInput.getClientId()));
				listIndexArchivingContextsecure.add(new IndexRequest(conf.getContractId(),closeFolderInput.getContractIDValue()));
				listIndexArchivingContextsecure.add(new IndexRequest(conf.getContractIdTypeCode(),closeFolderInput.getContractIdTypeCodeValue()));

				listIndexArchivingContextsecure.add(new IndexRequest(conf.getContractIdTypeLabel(),closeFolderInput.getContractIdTypeLabelValue()));


				requestArchivingContextSecureDoc.setListIndexArchivingContext(listIndexArchivingContextsecure);


				RequestSecureDoc requestSecureDoc = new RequestSecureDoc();
				requestSecureDoc.setHeaderRequestSecureDoc(headerRequestcloseFolderInput);
				requestSecureDoc.setRequestArchivingContextSecureDoc(requestArchivingContextSecureDoc);
				requestSecureDoc.setBodyRequestCommonSecureDoc(bodyRequestCommonCloseFolder);


				RequestDocumentData requestDocumentDataArchiveDoc = new RequestDocumentData();
				requestDocumentDataArchiveDoc.setArchiveFormat(closeFolderInput.getArchiveFormatCloseFolderInput());
				requestDocumentDataArchiveDoc.setCompress(closeFolderInput.getCompressCloseFolderInput());
				requestDocumentDataArchiveDoc.setFileName(closeFolderInput.getFileNameCloseFolderInput());
				requestDocumentDataArchiveDoc.setObject(closeFolderInput.getDataCloseFolderInput());
				requestDocumentDataArchiveDoc.setEncoding(closeFolderInput.getEncodingCloseFolderInput());


				ArrayList<IndexRequest> listIndex = new ArrayList<>();
				if(closeFolderInput.getTitreCloseFolderInput() !=null){
					listIndex.add(new IndexRequest(conf.getIndexname2(),closeFolderInput.getTitreCloseFolderInput()));
				}
				if(closeFolderInput.getMimeTypeCloseFolderInput() !=null){
					listIndex.add(new IndexRequest(conf.getIndexname3(),closeFolderInput.getMimeTypeCloseFolderInput()));
				}

				listIndex.add(new IndexRequest(conf.getIndexname1(),conf.getIndexvalue1()));

				/**
				 * verification des données obligatoires
				 */
				errors = checkMandatoryFields(VALUE,
						closeFolderInput.getListedocumentId(), closeFolderInput.getDocumentTypeIdCloseFolderInput(),
						closeFolderInput.getArchivingReferenceDate(), closeFolderInput.getTitreCloseFolderInput(), closeFolderInput.getFileNameCloseFolderInput(),
						closeFolderInput.getArchiveFormatCloseFolderInput(), closeFolderInput.getMimeTypeCloseFolderInput(), closeFolderInput.getCompressCloseFolderInput(),
						closeFolderInput.getEncodingCloseFolderInput(), closeFolderInput.getDataCloseFolderInput(), VALUE);


				if(!CollectionUtils.isEmpty(errors)){
					throw new MandatoryException(errors);
				}


				/**
				 * verification des formats des données
				 */
				checkFormat(closeFolderInput.getMimeTypeCloseFolderInput(),closeFolderInput.getArchivingReferenceDate(), listErrorFormat);

				if(!CollectionUtils.isEmpty(listErrorFormat)){
					throw new FormatErrorException(errors);
				}


				boolean isDocumentSecurised = true;
				String message = null;
				try {


					/**
					 * TODO  Lorsque le JMS sera dispo : Requête acceptée, mais des rejets ont eu lieu. Typiquement si un des documents transmis n'a pas pu être sécurisé. Une liste de rejets sera retournée.
					 */

					/**
					 * On sécurise ici chaque document de la liste
					 */
					for(String idDoc : closeFolderInput.getListedocumentId()){
						bodyRequestCommonCloseFolder.setDocumentId(idDoc);
						requestSecureDoc.setBodyRequestCommonSecureDoc(bodyRequestCommonCloseFolder);
						response = servicesGdn.secureDoc(requestSecureDoc);

						if(response == null || response.getDocumentId() ==null ){
							isDocumentSecurised = false;
						}
					}

					/**
					 * si tout les documents sont securisés on securise et enregistre le document récapitulatif
					 */
					if(isDocumentSecurised) {

						RequestDescriptiveContext  requestDescriptiveContextCloseFolderInput = new RequestDescriptiveContext(closeFolderInput.getDocumentTypeIdCloseFolderInput(),conf.getLotId(),conf.getLotLabel(), listIndex);
						RequestArchiveDoc requestArchiveDoc = new RequestArchiveDoc(headerRequestcloseFolderInput, bodyRequestCommonCloseFolder, requestDescriptiveContextCloseFolderInput, requestArchivingContextSecureDoc, requestDocumentDataArchiveDoc);

						/**
						 * On verifie que le DocumentTypeId est de type contestation ou justificatif
						 */
						if(closeFolderInput.getDocumentTypeIdCloseFolderInput() != null &&
								(closeFolderInput.getDocumentTypeIdCloseFolderInput().equals(conf.getCodeTypeDocumentContestation()) || closeFolderInput.getDocumentTypeIdCloseFolderInput().equals(conf.getCodeTypeDocumentJustificatif()))){



							response = servicesGdn.archiveDoc(requestArchiveDoc);

							folderId = getIdDocumentGdn(response);

							/**
							 * Verifie si le document recapitulatif a bien été archivé
							 */
							if(response != null && folderId !=null) {

								message = conf.getReponseSuccessSecureDoc();
							}
						}else{
							throw new DonneIncorectException(conf.getMessageErrorIdTypeDocument());
						}

					} else {
						LOG.error(conf.getNoSecurised());
						throw new ArchivingException(conf.getMessageErrorTechnique());
					}

				} catch (ArchivageTechniqueException e) {

					LOG.error(e.getMessage(),e);
					throw new ArchivingException(e.getMessage());
				}

				return message;

			}else{

				errors = checkMandatoryFields(NULLVALUE,
						null, NULLVALUE,
						NULLVALUE,NULLVALUE,NULLVALUE,
						NULLVALUE,NULLVALUE, NULLVALUE,
						NULLVALUE,NULLVALUE, VALUE);
				throw new MandatoryException(errors);
			}

		} catch (MandatoryGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new MandatoryException(e.getErrors());
		} catch (FormatGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new FormatErrorException(e.getErrors());
		}
	}



	/**
	 * permet de supprimer un document
	 * @throws ArchivageTechniqueException
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 */
	@Override
	public String deleteDoc(DeleteDocInput deleteDocInput) throws ArchivingException, MandatoryException {

		List<String> errors = new ArrayList<>();
		try {
			if(deleteDocInput !=null){
				HeaderRequest headerRequestDeleteDoc = new HeaderRequest(
						deleteDocInput.getCallingUserDeleteInput(),
						conf.getCallingApplication(),
						deleteDocInput.getLocaleCodeDeleteInput(),
						deleteDocInput.getCountryCodeDeleteInput(), null);

				BodyRequestCommon bodyRequestCommonDeleteDoc = new BodyRequestCommon();
				bodyRequestCommonDeleteDoc.setDocumentId(deleteDocInput.getDocumentIdDeleteInput());
				bodyRequestCommonDeleteDoc.setOwningApplication(conf.getOwningApplication());

				RequestDeleteDoc requestDeleteDoc = new RequestDeleteDoc(headerRequestDeleteDoc, bodyRequestCommonDeleteDoc);

				errors = checkMandatoryFields(deleteDocInput.getCallingUserDeleteInput(),Arrays.asList(VALUE), VALUE,
						VALUE, VALUE,
						VALUE, VALUE, VALUE,
						VALUE, VALUE, VALUE, deleteDocInput.getDocumentIdDeleteInput());



				if(!CollectionUtils.isEmpty(errors)){
					throw new MandatoryException(errors);
				}



				return getIdDocumentGdn(servicesGdn.deleteDoc(requestDeleteDoc));



			}else{

				errors = checkMandatoryFields(NULLVALUE, null, VALUE,
						VALUE, VALUE,
						VALUE, VALUE, VALUE,
						VALUE, VALUE, VALUE, NULLVALUE);

				throw new MandatoryException(errors);
			}

		} catch (ArchivageTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		} catch (MandatoryGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new MandatoryException(e.getErrors());
		}

	}

	/**
	 *Recupère un document correspondant à son id document dans GDN
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 * @throws ArchivingException
	 * @throws ArchivageTechniqueException
	 */
	@Override
	public DocOutput getDoc(DocInput docInput) throws  MandatoryException, ArchivingException{

		try {
			if(docInput !=null){

				RequestGetDocByIdGdn requestGetDocByIdGdn = new RequestGetDocByIdGdn(docInput.getCallingUserInput(),docInput.getUserTypeInput(),docInput.getDocumentIdInput());

				ResponseGetFromGdn responseGetDoc = null;

				DocOutput docOutput = null;

				List<String> error = checkMandatoryOfGetDoc(docInput.getCallingUserInput(), docInput.getUserTypeInput(), docInput.getDocumentIdInput()) ;

				if(!CollectionUtils.isEmpty(error)){
					throw new MandatoryException(error);
				}


				responseGetDoc = servicesGdn.getDocbyIdGdn(requestGetDocByIdGdn);

				//TODO Filename null to implemente
				docOutput = new DocOutput(responseGetDoc.getRepCompress(),
						responseGetDoc.getRepEncoding(), responseGetDoc.getRepData(),
						responseGetDoc.getRepArchiveFormat(),null,responseGetDoc.getMimeType(),
						responseGetDoc.getErrorGdn());
				return docOutput;

			}else{
				throw  new MandatoryException(checkMandatoryOfGetDoc(NULLVALUE, NULLVALUE, NULLVALUE));

			}

		} catch (ArchivageTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		} catch (MandatoryGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new MandatoryException(e.getErrors());
		}
	}

	/**
	 * recupère le document-Id de tout les services GDN
	 * crée les exceptions quand il le faut
	 * @param reponsegdn
	 * @return
	 * @throws ArchivingException
	 * @throws SmcTechnicalException
	 */
	private String getIdDocumentGdn(ResponseFromGdn reponsegdn) throws ArchivingException{

		Map<String, List<String>> errors = new HashMap<String, List<String>>();
		if(reponsegdn != null){

			String documentid = null;
			JdfError jdfError = reponsegdn.getJdfErrors();
			if (jdfError == null) {
				if(reponsegdn.getDocumentId() != null){
					documentid = reponsegdn.getDocumentId();
				}else{
					documentid = reponsegdn.getIdentifier();
				}

			} else {

				JdfErrorDetail infraError = jdfError.getInfrastructural();
				if(infraError !=null){
					LOG.error(infraError.getCode()+" : "+infraError.getMessage());
					throw new ArchivingException(conf.getMessageErrorTechnique());
				}

				if(!CollectionUtils.isEmpty(jdfError.getApplicative())) {
					for (JdfErrorDetail errorDetail : jdfError.getApplicative()) {
						LOG.error(errorDetail.getCode()+" : "+errorDetail.getMessage());
					}
					throw new ArchivingException(conf.getMessageErrorTechnique());
				}
			}

			return documentid;
		}else{
			LOG.error(conf.getReponseIncorectGDN());
			throw new ArchivingException(conf.getMessageErrorTechnique());
		}
	}



	/**
	 * enregistre un nouveau document dans la gdn
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws ArchivageTechniqueException
	 */
	@Override
	public String newDoc(NewDocInput newDocInput) throws ArchivingException,MandatoryException, FormatErrorException {
		try {
			if(newDocInput !=null){

				HeaderRequest headerRequestNewDoc = new HeaderRequest(newDocInput.getCallingUserNewDocInput()

						,conf.getCallingApplication(),
						newDocInput.getLocaleCodeNewDocInput(),
						newDocInput.getCountryCodeNewDocInput(), null);

				BodyRequestCommon bodyRequestCommonNewDoc = new BodyRequestCommon();

				bodyRequestCommonNewDoc.setNormLevel(conf.getNormLevel());
				bodyRequestCommonNewDoc.setOwningApplication(conf.getOwningApplication());
				bodyRequestCommonNewDoc.setStorageLevel(conf.getStorageLevel());
				bodyRequestCommonNewDoc.setClassificationNatureId(conf.getClassificationNatureId());


				ArrayList<IndexRequest> listIndex = new ArrayList<>();

				listIndex.add(new IndexRequest(conf.getIndexname2(),newDocInput.getTitreNewDocInput()));


				listIndex.add(new IndexRequest(conf.getIndexname3(),newDocInput.getMimeTypeNewDocInput()));


				listIndex.add(new IndexRequest(conf.getIndexname1(),conf.getIndexvalue1()));

				List<String> errors = checkMandatoryFields(newDocInput.getCallingUserNewDocInput(), Arrays.asList(VALUE), newDocInput.getDocumentTypeIdNewDocInput(),
						VALUE, newDocInput.getTitreNewDocInput(), newDocInput.getFileNameNewDocInput(),
						newDocInput.getArchiveFormatNewDocInput(), newDocInput.getMimeTypeNewDocInput(), newDocInput.getCompressNewDocInput(),
						newDocInput.getEncodingNewDocInput(), newDocInput.getDataNewDocInput(), VALUE);

				if(!CollectionUtils.isEmpty(errors)){
					throw new MandatoryException(errors);
				}

				if((newDocInput.getDocumentTypeIdNewDocInput() != null) &&(
						newDocInput.getDocumentTypeIdNewDocInput().equals(conf.getCodeTypeDocumentContestation()) ||
						newDocInput.getDocumentTypeIdNewDocInput().equals(conf.getCodeTypeDocumentJustificatif()))){

					RequestDescriptiveContext  requestDescriptiveContext = new RequestDescriptiveContext(newDocInput.getDocumentTypeIdNewDocInput(),conf.getLotId(),conf.getLotLabel(), listIndex);

					RequestDocumentData requestDocumentData = new RequestDocumentData();

					requestDocumentData.setArchiveFormat(newDocInput.getArchiveFormatNewDocInput());
					requestDocumentData.setCompress(newDocInput.getCompressNewDocInput());
					requestDocumentData.setFileName(newDocInput.getFileNameNewDocInput());
					requestDocumentData.setObject(newDocInput.getDataNewDocInput());
					requestDocumentData.setEncoding(newDocInput.getEncodingNewDocInput());


					RequestSaveDoc requestSaveDoc = new RequestSaveDoc(headerRequestNewDoc, bodyRequestCommonNewDoc, requestDescriptiveContext, requestDocumentData);



					return getIdDocumentGdn(servicesGdn.saveDoc2(requestSaveDoc));

				}else{
					throw new FormatErrorException(conf.getMessageErrorIdTypeDocument());
				}

			}else{
				throw new MandatoryException(checkMandatoryFields(NULLVALUE, Arrays.asList(VALUE), NULLVALUE,
						VALUE, NULLVALUE, NULLVALUE,
						NULLVALUE, NULLVALUE, NULLVALUE,
						NULLVALUE, NULLVALUE, VALUE));
			}

		} catch (ArchivageTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		} catch (MandatoryGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new MandatoryException(e.getErrors());
		}
	}

	/**
	 * permet de creer un Id dossier de contestation dans la GDN
	 * @throws MandatoryException
	 * @throws ArchivingException
	 * @throws SmcTechnicalException
	 * @throws ArchivageTechniqueException
	 */
	@Override
	public String newFolder(NewFolderInput newFolderInput) throws MandatoryException, ArchivingException  {
		Map<String, List<String>> errors = new HashMap<String, List<String>>();

		try {

			if(newFolderInput !=null){

				String callingUser = newFolderInput.getCallingUser();
				if(callingUser == null || callingUser.isEmpty()){
					throw new MandatoryException(Arrays.asList(conf.getCallingUserAbsent()));
				}

				HeaderRequest headerRequestGenerateId = new HeaderRequest(newFolderInput.getCallingUser(),conf.getCallingApplication(), newFolderInput.getLocaleCode(), newFolderInput.getCountryCode(), null);

				RequestGenerateId requestGenerateId = new RequestGenerateId();
				requestGenerateId.setHeaderRequestGenerateId(headerRequestGenerateId);

				return getIdDocumentGdn(servicesGdn.generateId(requestGenerateId));
			}else{
				throw new MandatoryException(Arrays.asList(conf.getCallingUserAbsent()));
			}


		} catch (ArchivageTechniqueException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		} catch (MandatoryGdnException e) {
			LOG.error(e.getMessage(),e);
			throw new MandatoryException(e.getErrors());
		}
	}


	/**
	 * change l'etat du dossier de contestation à purgé
	 */
	@Override
	public String purgeFolder(PurgeFolderInput purgeFolderInput) throws ContestationException{
		List<String> listeIdContestation = purgeFolderInput.getListeIdContestationPurgeFolderInput();



		if(contestationRepositoryImpl.isPurged(listeIdContestation)){
			return conf.getMessagePurgeSuccess();
		}else{
			throw new ContestationException(conf.getMessageNotFoundContestaionByFolderNumber());
		}



	}


}
