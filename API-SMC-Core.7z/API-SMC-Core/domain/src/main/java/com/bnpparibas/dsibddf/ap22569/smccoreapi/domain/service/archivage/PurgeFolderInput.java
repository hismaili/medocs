/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;

import java.util.List;

/**
 * @author c65344
 *
 */
public class PurgeFolderInput {
	private String callingUserPurgeFolderInput;

	private List<String> listeIdContestationPurgeFolderInput;

	/**
	 *
	 */
	public PurgeFolderInput() {
		super();

	}

	/**
	 * @param callingUserPurgeFolderInput
	 * @param listeIdContestationPurgeFolderInput
	 */
	public PurgeFolderInput(String callingUserPurgeFolderInput,
			List<String> listeIdContestationPurgeFolderInput) {
		this.callingUserPurgeFolderInput = callingUserPurgeFolderInput;
		this.listeIdContestationPurgeFolderInput = listeIdContestationPurgeFolderInput;
	}

	/**
	 * @return the callingUserPurgeFolderInput
	 */
	public String getCallingUserPurgeFolderInput() {
		return callingUserPurgeFolderInput;
	}

	/**
	 * @return the listeIdContestationPurgeFolderInput
	 */
	public List<String> getListeIdContestationPurgeFolderInput() {
		return listeIdContestationPurgeFolderInput;
	}

	/**
	 * @param callingUserPurgeFolderInput the callingUserPurgeFolderInput to set
	 */
	public void setCallingUserPurgeFolderInput(String callingUserPurgeFolderInput) {
		this.callingUserPurgeFolderInput = callingUserPurgeFolderInput;
	}

	/**
	 * @param listeIdContestationPurgeFolderInput the listeIdContestationPurgeFolderInput to set
	 */
	public void setListeIdContestationPurgeFolderInput(
			List<String> listeIdContestationPurgeFolderInput) {
		this.listeIdContestationPurgeFolderInput = listeIdContestationPurgeFolderInput;
	}



}
