/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.notification.batch.model;


/**
 * @author c65344
 *
 */
public class NotificationLine {
	/**
	 * Detail notifications
	 */
	private String codeEnregistrement;
	private String idTechnique;
	private String dossierSmc;
	private String numCarteDossier;
	private String  dateAppel;
	private String numClient;
	private String codeAgence;
	private String heureAppel;
	private String  notifSms;
	private String  notifMail;
	private String  numTel;
	private String  mailClient;
	private String  codeNotif;
	private String  contenuNotif;
	private String  objetDuMail;
	private String civilite;
	private String nom;
	private String prenom;
	private String dateCreationDossier;
	private String dateCreationNotification;
	private String originalLine;
	private Integer lineNumber;
	private String empty;

	private NotificationFileMetadata fileInfo;

	public String getCodeEnregistrement() {
		return codeEnregistrement;
	}

	public void setCodeEnregistrement(String codeEnregistrement) {
		this.codeEnregistrement = codeEnregistrement;
	}

	public String getIdTechnique() {
		return idTechnique;
	}

	public void setIdTechnique(String idTechnique) {
		this.idTechnique = idTechnique;
	}

	public String getDossierSmc() {
		return dossierSmc;
	}

	public void setDossierSmc(String dossierSmc) {
		this.dossierSmc = dossierSmc;
	}

	public String getNumCarteDossier() {
		return numCarteDossier;
	}

	public void setNumCarteDossier(String numCarteDossier) {
		this.numCarteDossier = numCarteDossier;
	}

	public String getDateAppel() {
		return dateAppel;
	}

	public void setDateAppel(String dateAppel) {
		this.dateAppel = dateAppel;
	}

	public String getNumClient() {
		return numClient;
	}

	public void setNumClient(String numClient) {
		this.numClient = numClient;
	}

	public String getCodeAgence() {
		return codeAgence;
	}

	public void setCodeAgence(String codeAgence) {
		this.codeAgence = codeAgence;
	}

	public String getHeureAppel() {
		return heureAppel;
	}

	public void setHeureAppel(String heureAppel) {
		this.heureAppel = heureAppel;
	}

	public String getNotifSms() {
		return notifSms;
	}

	public void setNotifSms(String notifSms) {
		this.notifSms = notifSms;
	}

	public String getNotifMail() {
		return notifMail;
	}

	public void setNotifMail(String notifMail) {
		this.notifMail = notifMail;
	}

	public String getNumTel() {
		return numTel;
	}

	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}

	public String getMailClient() {
		return mailClient;
	}

	public void setMailClient(String mailClient) {
		this.mailClient = mailClient;
	}

	public String getCodeNotif() {
		return codeNotif;
	}

	public void setCodeNotif(String codeNotif) {
		this.codeNotif = codeNotif;
	}

	public String getContenuNotif() {
		return contenuNotif;
	}

	public void setContenuNotif(String contenuNotif) {
		this.contenuNotif = contenuNotif;
	}

	public String getObjetDuMail() {
		return objetDuMail;
	}

	public void setObjetDuMail(String objetDuMail) {
		this.objetDuMail = objetDuMail;
	}

	public String getCivilite() {
		return civilite;
	}

	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getDateCreationDossier() {
		return dateCreationDossier;
	}

	public void setDateCreationDossier(String dateCreationDossier) {
		this.dateCreationDossier = dateCreationDossier;
	}

	public String getOriginalLine() {
		return originalLine;
	}

	public void setOriginalLine(String originalLine) {
		this.originalLine = originalLine;
	}

	public Integer getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public NotificationFileMetadata getFileInfo() {
		return fileInfo;
	}

	public void setFileInfo(NotificationFileMetadata fileInfo) {
		this.fileInfo = fileInfo;
	}

	public String getDateCreationNotification() {
		return dateCreationNotification;
	}

	public void setDateCreationNotification(String dateCreationNotification) {
		this.dateCreationNotification = dateCreationNotification;
	}

	public String getEmpty() {
		return empty;
	}

	public void setEmpty(String empty) {
		this.empty = empty;
	}
}
