package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public class DocumentJustificatif {

	private String labelJustificatif;

	private String typeDocGDN;

	/**
	 *
	 */
	public DocumentJustificatif() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentJustificatif(String labelJustificatif, String typeDocGDN) {
		this.labelJustificatif = labelJustificatif;
		this.typeDocGDN = typeDocGDN;
	}

	public String getLabelJustificatif() {
		return labelJustificatif;
	}

	public String getTypeDocGDN() {
		return typeDocGDN;
	}

	/**
	 * @param labelJustificatif the labelJustificatif to set
	 */
	public void setLabelJustificatif(String labelJustificatif) {
		this.labelJustificatif = labelJustificatif;
	}

	/**
	 * @param typeDocGDN the typeDocGDN to set
	 */
	public void setTypeDocGDN(String typeDocGDN) {
		this.typeDocGDN = typeDocGDN;
	}


}
