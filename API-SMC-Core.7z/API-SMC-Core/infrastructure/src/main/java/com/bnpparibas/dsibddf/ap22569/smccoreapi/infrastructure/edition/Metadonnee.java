package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.thoughtworks.xstream.annotations.XStreamAlias;


/**
 *
 * @author c65344
 *
 */
@XStreamAlias("metadonee")
public class Metadonnee {
	@XStreamAlias("nom")
	private String nom;
	@XStreamAlias("valeur")
	private String valeur;
	/**
	 *
	 */
	public Metadonnee() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param nom
	 * @param valeur
	 */
	public Metadonnee(String nom, String valeur) {
		this.nom = nom;
		this.valeur = valeur;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @return the valeur
	 */
	public String getValeur() {
		return valeur;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @param valeur the valeur to set
	 */
	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
}
