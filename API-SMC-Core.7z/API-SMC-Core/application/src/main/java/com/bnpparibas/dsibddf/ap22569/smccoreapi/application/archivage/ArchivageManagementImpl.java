package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.commons.MappingExceptionApp;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.IContestationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.personne.IInfoPersonneManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.InfoCarte;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ArchivageManagementImpl implements IArchivageManagement {
	private static final Logger LOG = LoggerFactory.getLogger(ArchivageManagementImpl.class);
	@Autowired
	private transient IArchivageDocument archivageDocument;
	@Autowired
	private transient IInfoPersonneManagement infoPersonneWS ;
	@Autowired
	private transient ICardServicesManagement cardServicesManagement;

	@Autowired
	private transient IContestationManagement contestationManagement;
	@Autowired
	private transient MappingExceptionApp map;


	/**
	 * Recuperation de L'Id unique client chez BCMP et recupération des informations RP avec cet Id
	 * @throws DonneIncorectException
	 * @throws FormatErrorException
	 * @throws MandatoryException
	 * @throws ArchivingException
	 * @throws PorteurException
	 * @throws SmcTechnicalException
	 */
	@Override
	public String closeFolder(CloseFolderInput closeFolderInput) throws ArchivingException, MandatoryException, FormatErrorException, DonneIncorectException {

		InfoPersonneOutput info = null;

		Contestation contestation;

		try {

			contestation = contestationManagement.consulterContestation(closeFolderInput.getIdContestationSmcCloseFolderInput(),null);

			InfoCarte infoCarte = cardServicesManagement.getInfoCarte(contestation.getNumCarte());

			String idClient = infoCarte.getIdUniqueClientInput();

			closeFolderInput.setClientId(idClient);

			closeFolderInput.setContractIDValue(infoCarte.getIdContratMonetiquePorteurInput());
			closeFolderInput.setContractIdTypeCodeValue(infoCarte.getCodeTypContratInput());
			closeFolderInput.setContractIdTypeLabelValue(infoCarte.getCodeAgenceRattachementInput());

			info = infoPersonneWS.getInfopersonne(idClient);

			closeFolderInput.setClientFirstnameCloseFolderInput(info.getClientFirstname());
			closeFolderInput.setClientNameCloseFolderInput(info.getClientName());
			closeFolderInput.setBirthDay(info.getBirthDay());
			closeFolderInput.setSirenCloseFolderInput(info.getSirenNumber());
			closeFolderInput.setClientNatureIdCloseFolderInput(info.getClientNatureId());
			return archivageDocument.closeFolder(closeFolderInput);

		} catch (PorteurException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		}catch (ContestationException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		} catch (CardException e) {
			LOG.error(e.getMessage(),e);
			throw new ArchivingException(e.getMessage());
		}
	}

	@Override
	public String deleteDoc(DeleteDocInput deleteDocInput) throws ArchivingException, MandatoryException {
		return archivageDocument.deleteDoc(deleteDocInput);
	}

	@Override
	public DocOutput getDoc(DocInput docInput)	throws ArchivingException,MandatoryException {
		return archivageDocument.getDoc(docInput);
	}

	@Override
	public String newDoc(NewDocInput newDocInput) throws ArchivingException, MandatoryException, FormatErrorException {
		return archivageDocument.newDoc(newDocInput);
	}

	@Override
	public String newFolder(NewFolderInput newFolderInput) throws ArchivingException, MandatoryException{
		return archivageDocument.newFolder(newFolderInput);
	}



	@Override
	public String purgeFolder(PurgeFolderInput purgeFolderInput) throws  ContestationException {
		return archivageDocument.purgeFolder(purgeFolderInput);
	}
}
