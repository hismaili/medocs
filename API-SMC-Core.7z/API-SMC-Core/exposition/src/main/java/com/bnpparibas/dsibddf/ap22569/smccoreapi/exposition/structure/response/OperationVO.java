package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/**
 * OperationVO
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-03-27T14:00:58.610Z")

public class OperationVO   {
	/**
	 * signe de l'opération (PLUS => Crédit, MOINS => Débit)
	 */
	public enum OperationSignEnum {
		PLUS("PLUS"),

		MOINS("MOINS");

		@JsonCreator
		public static OperationSignEnum fromValue(String text) {
			for (OperationSignEnum b : OperationSignEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}

		private String value;

		OperationSignEnum(String value) {
			this.value = value;
		}

		@Override
		@JsonValue
		public String toString() {
			return String.valueOf(value);
		}
	}

	
	/**
	 * type de l'opération (PAIEMENT,RETRAIT)
	 */
	public enum OperationType {
		PAIEMENT("PAIEMENT"),

		RETRAIT("RETRAIT");

		@JsonCreator
		public static OperationType fromValue(String text) {
			for (OperationType b : OperationType.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}

		private String value;

		OperationType(String value) {
			this.value = value;
		}

		@Override
		@JsonValue
		public String toString() {
			return String.valueOf(value);
		}
	}
	
	@JsonProperty("operationCode")
	private String operationCode;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonProperty("dateOfOperation")
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateOfOperation;


	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonProperty("dateOfSale")
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateOfSale;

	@JsonProperty("merchantName")
	private String merchantName;

	@JsonProperty("operationLabel")
	private String operationLabel;

	@JsonProperty("operationAmount")
	private BigDecimal operationAmount;

	@JsonProperty("operationType")
	private OperationType operationType;

	@JsonProperty("operationSign")
	private OperationSignEnum operationSign;

	@JsonProperty("currencyOfOperation")
	private String currencyOfOperation;

	@JsonProperty("recognizedAmount")
	private BigDecimal recognizedAmount;

	@JsonProperty("disputable")
	private boolean disputable;

	@JsonProperty("inEEE")
	private boolean inEEE = Boolean.TRUE;
	/**
	 *
	 * @param currecnyOfOperation
	 * @return
	 */
	public OperationVO currecnyOfOperation(String currecnyOfOperation) {
		this.currencyOfOperation = currecnyOfOperation;
		return this;
	}
	/**
	 *
	 * @param dateOfOperation
	 * @return
	 */
	public OperationVO dateOfOperation(LocalDate dateOfOperation) {
		this.dateOfOperation = dateOfOperation;
		return this;
	}
	/**
	 *
	 * @param dateOfSale
	 * @return
	 */
	public OperationVO dateOfSale(LocalDate dateOfSale) {
		this.dateOfSale = dateOfSale;
		return this;
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		OperationVO operationVO = (OperationVO) o;
		return Objects.equals(this.operationCode, operationVO.operationCode) &&
				Objects.equals(this.dateOfOperation, operationVO.dateOfOperation) &&
				Objects.equals(this.dateOfSale, operationVO.dateOfSale) &&
				Objects.equals(this.merchantName, operationVO.merchantName) &&
				Objects.equals(this.operationLabel, operationVO.operationLabel) &&
				Objects.equals(this.operationAmount, operationVO.operationAmount) &&
				Objects.equals(this.operationType, operationVO.operationType) &&
				Objects.equals(this.operationSign, operationVO.operationSign) &&
				Objects.equals(this.currencyOfOperation, operationVO.currencyOfOperation) &&
				Objects.equals(this.recognizedAmount, operationVO.recognizedAmount);
	}
	/**
	 * devise de l opération
	 *
	 * @return currencyOfOperation
	 **/
	@ApiModelProperty(value = "devise de l opération")
	public String getCurrencyOfOperation() {
		return currencyOfOperation;
	}

	/**
	 * Date de l'opération = date de compensation
	 *
	 * @return dateOfOperation
	 **/
	@ApiModelProperty(value = "Date de l'opération = date de compensation")
	@Valid
	public LocalDate getDateOfOperation() {
		return dateOfOperation;
	}

	/**
	 * Date de vente
	 *
	 * @return dateOfSale
	 **/
	@ApiModelProperty(value = "Date de vente")
	@Valid
	public LocalDate getDateOfSale() {
		return dateOfSale;
	}

	/**
	 * Get merchantName
	 *
	 * @return merchantName
	 **/
	@ApiModelProperty(value = "")
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * montant de l'opération
	 *
	 * @return operationAmount
	 **/
	@ApiModelProperty(value = "montant de l'opération")
	@Valid
	public BigDecimal getOperationAmount() {
		return operationAmount;
	}

	/**
	 * coidop de l'opération
	 *
	 * @return operationCode
	 **/
	@ApiModelProperty(value = "coidop de l'opération")
	public String getOperationCode() {
		return operationCode;
	}

	/**
	 * libellé de l'opération
	 *
	 * @return operationLabel
	 **/
	@ApiModelProperty(value = "libellé de l'opération")
	public String getOperationLabel() {
		return operationLabel;
	}

	/**
	 * signe de l'opération (PLUS => Crédit, MOINS => Débit)
	 *
	 * @return operationSign
	 **/
	@ApiModelProperty(value = "signe de l'opération (PLUS => Crédit, MOINS => Débit)")
	public OperationSignEnum getOperationSign() {
		return operationSign;
	}

	/**
	 * type de l'opération
	 *
	 * @return operationType
	 **/
	@ApiModelProperty(example = "Retrait, paiement, remboursement...", value = "type de l'opération")
	public OperationType getOperationType() {
		return operationType;
	}

	/**
	 * le montant reconnu par l utilisateur. Obligatoire pour les motifs où l utilisateur conteste pour montant erroné
	 *
	 * @return recognizedAmount
	 **/
	@ApiModelProperty(value = "le montant reconnu par l utilisateur. Obligatoire pour les motifs où l utilisateur conteste pour montant erroné")
	@Valid
	public BigDecimal getRecognizedAmount() {
		return recognizedAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(operationCode, dateOfOperation, dateOfSale, merchantName, operationLabel, operationAmount, operationType, operationSign, currencyOfOperation, recognizedAmount);
	}

	/**
	 * @return the disputable
	 */
	public boolean isDisputable() {
		return disputable;
	}

	/**
	 *
	 * @param merchantName
	 * @return
	 */
	public OperationVO merchantName(String merchantName) {
		this.merchantName = merchantName;
		return this;
	}
	/**
	 *
	 * @param operationAmount
	 * @return
	 */
	public OperationVO operationAmount(BigDecimal operationAmount) {
		this.operationAmount = operationAmount;
		return this;
	}
	/**
	 *
	 * @param operationCode
	 * @return
	 */
	public OperationVO operationCode(String operationCode) {
		this.operationCode = operationCode;
		return this;
	}
	/**
	 *
	 * @param operationLabel
	 * @return
	 */
	public OperationVO operationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
		return this;
	}
	/**
	 *
	 * @param operationSign
	 * @return
	 */
	public OperationVO operationSign(OperationSignEnum operationSign) {
		this.operationSign = operationSign;
		return this;
	}
	/**
	 *
	 * @param operationType
	 * @return
	 */
	public OperationVO operationType(OperationType operationType) {
		this.operationType = operationType;
		return this;
	}
	/**
	 *
	 * @param recognizedAmount
	 * @return
	 */
	public OperationVO recognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
		return this;
	}
	/**
	 *
	 * @param currencyOfOperation
	 */
	public void setCurrencyOfOperation(String currencyOfOperation) {
		this.currencyOfOperation = currencyOfOperation;
	}
	/**
	 *
	 * @param dateOfOperation
	 */
	public void setDateOfOperation(LocalDate dateOfOperation) {
		this.dateOfOperation = dateOfOperation;
	}
	/**
	 *
	 * @param dateOfSale
	 */
	public void setDateOfSale(LocalDate dateOfSale) {
		this.dateOfSale = dateOfSale;
	}
	/**
	 * @param disputable the disputable to set
	 */
	public void setDisputable(boolean disputable) {
		this.disputable = disputable;
	}
	/**
	 *
	 * @param merchantName
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	/**
	 *
	 * @param operationAmount
	 */
	public void setOperationAmount(BigDecimal operationAmount) {
		this.operationAmount = operationAmount;
	}
	/**
	 *
	 * @param operationCode
	 */
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	/**
	 *
	 * @param operationLabel
	 */
	public void setOperationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
	}
	/**
	 *
	 * @param operationSign
	 */
	public void setOperationSign(OperationSignEnum operationSign) {
		this.operationSign = operationSign;
	}

	/**
	 *
	 * @param operationType
	 */
	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}
	/**
	 *
	 * @param recognizedAmount
	 */
	public void setRecognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
	}

	public boolean isInEEE() {
		return inEEE;
	}

	public void setInEEE(boolean inEEE) {
		this.inEEE = inEEE;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class OperationVO {\n");

		sb.append("    operationCode: ").append(toIndentedString(operationCode)).append("\n");
		sb.append("    dateOfOperation: ").append(toIndentedString(dateOfOperation)).append("\n");
		sb.append("    dateOfSale: ").append(toIndentedString(dateOfSale)).append("\n");
		sb.append("    merchantName: ").append(toIndentedString(merchantName)).append("\n");
		sb.append("    operationLabel: ").append(toIndentedString(operationLabel)).append("\n");
		sb.append("    operationAmount: ").append(toIndentedString(operationAmount)).append("\n");
		sb.append("    operationType: ").append(toIndentedString(operationType)).append("\n");
		sb.append("    operationSign: ").append(toIndentedString(operationSign)).append("\n");
		sb.append("    currencyOfOperation: ").append(toIndentedString(currencyOfOperation)).append("\n");
		sb.append("    recognizedAmount: ").append(toIndentedString(recognizedAmount)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

