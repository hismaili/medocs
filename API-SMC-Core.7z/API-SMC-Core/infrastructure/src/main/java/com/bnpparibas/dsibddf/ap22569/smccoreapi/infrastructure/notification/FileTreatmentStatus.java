package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

public enum FileTreatmentStatus {

    IN_PROGRESS, FAILED, SUCCEEDED;
}
