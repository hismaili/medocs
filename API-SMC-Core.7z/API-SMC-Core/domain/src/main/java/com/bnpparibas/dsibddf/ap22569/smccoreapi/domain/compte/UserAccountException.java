package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcBusinessException;

public class UserAccountException extends SmcBusinessException {

    public UserAccountException() {
    }

    public UserAccountException(String message) {
        super(message);
    }

    public UserAccountException(String message, Throwable cause) {
        super(message, cause);
    }
    public UserAccountException(Throwable cause) {
        super(cause);
    }
}
