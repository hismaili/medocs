package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.ErrorCode;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.UnexpectedException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file.FooterException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file.IncorrectHeaderException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Stream;

@Component
public class ControlFileListener {

    private static final Logger LOG = LoggerFactory.getLogger(ControlFileListener.class);


    private FileSystemResource inputResource;

    @Value("${FIELDS_CSV_SEPARATOR}")
    private String fieldsSeparator;

    @Value("${header_prefix}")
    private String headerPrefix;

    @Autowired
    private INotificationManagement notificationManagement;

    public ControlFileListener(@Value("${file.input}") FileSystemResource resource) {
        this.inputResource = resource;
    }

    public void beforeStep(StepExecution stepExecution) {
        List<Throwable> failureExceptions = stepExecution.getJobExecution().getFailureExceptions();
        BufferedReader reader = null;
        try {
        final File file = inputResource.getFile();
        //Check that we can read the file
        if(!(inputResource.exists() && inputResource.isFile() && inputResource.isReadable())) {
            final String errorMessage = String.format("Le fichier [%s] est introuvable ou ne peut être lu.", inputResource.getFilename());
            throw new UnexpectedException(ErrorCode.FILE_NOT_FOUND_OR_UNREADABLE,
                    errorMessage,
                    inputResource.getFilename(),
                    LocalDate.now(),
                    errorMessage);
        } else {
            reader = new BufferedReader(new InputStreamReader(inputResource.getInputStream()));
                final Stream<String> lines1 = reader.lines();
                if(lines1 != null) {
                    String[] lines = lines1.toArray(String[]::new);
                    if(lines.length > 0) {
                        try {
                            String header = lines[0];
                            checkHeaderIsCorrect(header);

                            String footer = lines[lines.length - 1];
                            checkFooterIsCorrect(footer, lines);
                        } catch (IncorrectHeaderException | UnexpectedException | FooterException e) {
                            failureExceptions.add(e);
                            LOG.error(e.getMessage(), e);
                        }
                    }
                }
            }
        } catch (IOException e) {
            failureExceptions.add(e);
            LOG.error(e.getMessage(), e);
        } catch (UnexpectedException e) {
            failureExceptions.add(e);
        } finally {
            if(reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                    failureExceptions.add(e);
                }
            }
        }

    }

    private void checkFooterIsCorrect(String footer, String[] lines) throws FooterException {
        String[] infos = footer.split(fieldsSeparator);
        Integer numberOfRecordsFotter = Integer.valueOf(infos[2]);

        int count = 0;
        for(String line : lines) {
            if(line.startsWith("05")) {
                count++;
            }
        }
        if(count != numberOfRecordsFotter) {
            LocalDate fileDate = LocalDate.parse(lines[0].split(fieldsSeparator)[1], DateTimeFormatter.ofPattern("ddMMyyyy"));
            throw new FooterException(ErrorCode.INCORRECT_NUMBER_OF_RECORDS, numberOfRecordsFotter, count, inputResource.getFilename(), fileDate,String.format("Incorrect number of records in footer. expected [%d] found [%d]", numberOfRecordsFotter, count));
        }
    }

    private void checkHeaderIsCorrect(String header) throws IncorrectHeaderException, UnexpectedException {
        String message = null;
        String[] headerFields = header.split(fieldsSeparator);
        if(headerFields == null || headerFields.length != 5) {
            message = "La ligne d'en t\u00eate doit contenir exactement 5 \u00e9l\u00e9ments. " + headerFields.length + " trouv\u00e9s.";
            throw new IncorrectHeaderException(ErrorCode.INCCORRECT_NUMBER_OF_FILEDS, message, inputResource.getFilename(), LocalDate.now(), message);
        } else if(!headerPrefix.equals(headerFields[0])) {
            message = "La ligne d'en t\u00eate doit commencer par "+headerPrefix;
            throw new IncorrectHeaderException(ErrorCode.INCCORRECT_PREFIX, message, inputResource.getFilename(), LocalDate.now(), message);
        } else {
            checkFileNotAlreadyTreated(headerFields);
            checkSequenceNumberIsTheExpectedOne(headerFields);
        }
    }

    private void checkSequenceNumberIsTheExpectedOne(String[] headerFields) throws IncorrectHeaderException, UnexpectedException {
        String currentSequenceNumber = headerFields[3];
        String dateflux = headerFields[1];
        try {
            NotificationInfoFile lastTreatedFile = notificationManagement.getLastTreatedFile(dateflux);
            if(lastTreatedFile != null) {
                String lastSequenceNumber = lastTreatedFile.getNumSeqHeader();
                int lastSequenceNumberInt = Integer.parseInt(lastSequenceNumber);
                int currentSequenceNumberInt = Integer.parseInt(currentSequenceNumber);

                if(currentSequenceNumberInt != lastSequenceNumberInt + 1) {
                    final String message = String.format("Le numéro de séquence [%d] n'est pas celui attendu [%d].", currentSequenceNumberInt, lastSequenceNumberInt + 1);
                    throw new IncorrectHeaderException(ErrorCode.UNEXPECTED_SEQUENCE_NUMBER, message, inputResource.getFilename(), LocalDate.now(), message);
                }
            }
        } catch (NotificationException e) {
            LOG.error(e.getMessage(), e);
            throw new UnexpectedException(ErrorCode.UNEXPECTED_EXCEPTION, e.getMessage(), inputResource.getFilename(), LocalDate.now(), e.getMessage());
        }
    }

    private void checkFileNotAlreadyTreated(String[] headerFields) throws UnexpectedException, IncorrectHeaderException {
        String currentSequenceNumber = headerFields[3];
        String dateflux = headerFields[1];
        try {
            NotificationInfoFile file = notificationManagement.getFileBySequenceNumber(dateflux, currentSequenceNumber);
            if(file != null) {
                final String message = String.format("Le fichier avec le numéro de séquence [%s] a déjà été traité.", currentSequenceNumber);
                throw new IncorrectHeaderException(ErrorCode.SEQUENCE_NUMBER_ALREADY_TREATED, message, inputResource.getFilename(), LocalDate.now(), message);
            }
        } catch (NotificationException e) {
            LOG.error(e.getMessage(), e);
            throw new UnexpectedException(ErrorCode.UNEXPECTED_EXCEPTION, e.getMessage(), inputResource.getFilename(), LocalDate.now(), e.getMessage());
        }
    }

    public ExitStatus afterStep(StepExecution stepExecution) {
        ExitStatus result = ExitStatus.COMPLETED;
        if(!CollectionUtils.isEmpty(stepExecution.getFailureExceptions())) {
            stepExecution.setExitStatus(ExitStatus.FAILED);
            result = ExitStatus.FAILED;
        }
        return result;
    }

}
