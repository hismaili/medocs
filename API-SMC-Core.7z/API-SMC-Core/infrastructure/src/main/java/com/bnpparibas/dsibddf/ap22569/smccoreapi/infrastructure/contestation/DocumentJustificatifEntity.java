package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/** Document justificatif de la contestation à fournir par le client */
@Entity
@Table(name = "JUSTIFS_CLIENT_DESC")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class DocumentJustificatifEntity extends AbstractEntity<DefaultEntityId> {

    @Column(length = 150)
    private String labelJustificatif;

    @Column(length = 20)
    private String typeDocGDN;

    public String getLabelJustificatif() {
        return labelJustificatif;
    }

    public void setLabelJustificatif(String labelJustificatif) {
        this.labelJustificatif = labelJustificatif;
    }

    public String getTypeDocGDN() {
        return typeDocGDN;
    }

    public void setTypeDocGDN(String typeDocGDN) {
        this.typeDocGDN = typeDocGDN;
    }
}
