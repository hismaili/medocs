package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.agence;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.RefoException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcTechnicalException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;

/**
 *
 * @author c65344
 *
 */
@SpringBootTest(classes = SpringBootApp.class)
@RunWith(SpringRunner.class)
@ActiveProfiles({"local","test"})
public class RefoImplTest {

	@Autowired
	private transient RefoImpl refoImpl;

	@Test
	public void testSuccess() throws RefoException, SmcTechnicalException {

		assertTrue(refoImpl.getTypeBank("00799") != null);
		//assertTrue("BDDF".equals(refoImpl.getTypeBank("00799")));
	}

}
