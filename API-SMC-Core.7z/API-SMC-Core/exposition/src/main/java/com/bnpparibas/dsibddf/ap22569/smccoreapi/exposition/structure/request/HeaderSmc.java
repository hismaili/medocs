package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.io.Serializable;

/**
 *
 * @author c65344
 *
 */
@Valid
public class HeaderSmc implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	@ApiModelProperty(value = "code application appelante", required = true)
	private String codeApplication;


	@ApiModelProperty(value = "canal web, mobile ...", required = true)
	private String canal;

	/**
	 *
	 */
	public HeaderSmc() {
		super();

	}

	/**
	 * @param codeApplication
	 * @param canal
	 */
	public HeaderSmc(String codeApplication, String canal) {
		this.codeApplication = codeApplication;
		this.canal = canal;
	}

	/**
	 * @return the canal
	 */
	public String getCanal() {
		return canal;
	}

	/**
	 * @return the codeApplication
	 */
	public String getCodeApplication() {
		return codeApplication;
	}

	/**
	 * @param canal the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}

	/**
	 * @param codeApplication the codeApplication to set
	 */
	public void setCodeApplication(String codeApplication) {
		this.codeApplication = codeApplication;
	}


}
