package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.jwt;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.JwtAuthorizationBuilder;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.JwtSmcException;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Fail;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({"local","test"})
@Ignore
public class JwtSmcBuilderTest {
	@Configuration
	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
	"com.bnpparibas.dsibddf.ap22569.smctohmp.goal"})
	static class TestConfig{
		//		@Bean("restTemplateSmc")
		//		public RestTemplate restTemplate() {
		//			return new RestTemplate();
		//		}
	}
	private static final Logger LOG = LoggerFactory
			.getLogger(JwtSmcBuilderTest.class);
	@Autowired
	private transient JwtAuthorizationBuilder jwt;

	@Test
	public void testBuildJwt() {

		String jeton;
		try {
			jeton = jwt.getCompactJws();
			Assertions.assertThat(jeton).isNotEmpty();
		} catch (JwtSmcException e) {
			LOG.error(e.getMessage(),e);
			Fail.fail(e.getMessage());
		}


	}

}
