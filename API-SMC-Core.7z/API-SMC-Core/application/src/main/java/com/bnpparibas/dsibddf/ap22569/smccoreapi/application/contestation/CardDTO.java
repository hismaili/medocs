package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import java.time.LocalDate;

public class CardDTO {

    private String cardId;

    private LocalDate cardExpirationDate;

    private LocalDate cardCancellationDate;

    private String cardState;

    private String maskedPan;

    private String cancellationReason;

    private String cardProductType;

    private String cardHolderName;

    private String pan;

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public LocalDate getCardExpirationDate() {
        return cardExpirationDate;
    }

    public void setCardExpirationDate(LocalDate cardExpirationDate) {
        this.cardExpirationDate = cardExpirationDate;
    }

    public LocalDate getCardCancellationDate() {
        return cardCancellationDate;
    }

    public void setCardCancellationDate(LocalDate cardCancellationDate) {
        this.cardCancellationDate = cardCancellationDate;
    }

    public String getCardState() {
        return cardState;
    }

    public void setCardState(String cardState) {
        this.cardState = cardState;
    }

    public String getMaskedPan() {
        return maskedPan;
    }

    public void setMaskedPan(String maskedPan) {
        this.maskedPan = maskedPan;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public String getCardProductType() {
        return cardProductType;
    }

    public void setCardProductType(String cardProductType) {
        this.cardProductType = cardProductType;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }
}
