package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Lazy
public class OperationService implements IOperationService {

	@Autowired
	private transient IOperationRepository operationRepository;

	@Override
	public void deleteOperationsTmp(String idTelematic,String userId) {
		operationRepository.deleteOperationsTmp(idTelematic,userId);

	}

	@Override
	public List<Operation> getCardOperations(String pan,String idTelematic,String userId) throws OperationException {
		return operationRepository.getCardOperations(pan,idTelematic,userId);
	}

	@Override
	public int getLastNumSeqTopHmp() {

		return operationRepository.getLastNumSeqTopHmp();
	}

	@Override
	public Operation getOperationByCodeOpe(String codeOpe,String idTelematic,String userId) throws OperationException {
		return operationRepository.getOperationByCodeOpe(codeOpe, idTelematic, userId);
	}

	@Override
	public OperationTop getOperationTopHmp() {

		return operationRepository.getOperationTopHmp();
	}

	@Override
	public List<OperationTop> getOperationTopHmps(boolean isTop) {

		return operationRepository.getOperationTopHmps(isTop);
	}

	@Override
	public void isTreated(int numSequence) {

		operationRepository.isTreated(numSequence);

	}


}
