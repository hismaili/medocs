--QUALIFICATION
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q001','Perte-Vol');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q002','Contrefaçon');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q099','Autres');

--Nature
---- perte-vol
INSERT INTO NATURE_CONTESTATION VALUES('N001','Carte Perdue', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N002','Carte Volée Sans violence', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N003','Carte extorquée avec violence', 'Q001');
INSERT INTO NATURE_CONTESTATION VALUES('N004','Carte non parvenue au porteur', 'Q001');
---- Contrefaçon
INSERT INTO NATURE_CONTESTATION VALUES('N005','Carte Contrefaite', 'Q002');
INSERT INTO NATURE_CONTESTATION VALUES('N006','Facture contestée', 'Q002');
INSERT INTO NATURE_CONTESTATION VALUES('N007','Traitement en double', 'Q002');
----Autres (Contestation)
INSERT INTO NATURE_CONTESTATION VALUES('N008','Service non rendu ou marchandise non reçue ou défectueuse', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N009','DAB billets non délivrés', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N010','DAB billets partiellement délivrés', 'Q099');
INSERT INTO NATURE_CONTESTATION VALUES('N011','Montant erroné', 'Q099');



--Motif
-- Motifs
---- perte-vol
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES('M001','Carte perdue',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'LESDEUX','N001','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES('M002','Carte volée sans violence',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'LESDEUX','N002','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES('M003','Carte extorquée avec menace',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'LESDEUX','N003','Q001');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES('M004','Carte non parvenue au porteur',TRUE,FALSE, FALSE,'facultatif',TRUE,'obligatoire',390, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'LESDEUX','N004','Q001');
--Contrefaçon
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M005','Carte contrefaite',FALSE,FALSE, FALSE,'facultatif',FAlSE,'facultatif',390, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'LESDEUX','N005','Q002');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M006','Facture contestée',FALSE,FALSE, FALSE,'obligatoire',FAlSE,'facultatif',390, 100, 'Je reconnais avoir effectué ce paiement, mais le montant débité sur mon compte est erroné.', 'PAIEMENT','N006','Q002');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M007','Traitement en double',FALSE,FALSE, FALSE,'facultatif',FAlSE,'facultatif',390, 100, 'Je reconnais avoir effectué ce(s) paiement(s) ou ce(s) retrait (s) d’espèces, mais mon compte a été débité plusieurs fois de cette(es) opération(s).', 'LESDEUX','N007','Q002');
-- Autres
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M008','Service non rendu ou marchandise non reçue ou défectueuse',FALSE,FALSE, FALSE,'facultatif',FALSE,'obligatoire',70, 100, 'Je conteste et déclare sur l honneur n avoir jamais effectué avec ma carte bancaire, ni autorisé, la(les) opération(s) de ce dossier', 'PAIEMENT','N008','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M009','DAB Billets non délivrés',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'Je reconnais avoir effectué ce retrait d espèces, mais le montant débité  sur mon compte est erroné.', 'RETRAIT','N009','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M010','DAB Billets partiellement délivrés',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'Je reconnais avoir effectué ce retrait d espèces, mais le montant débité  sur mon compte est erroné.', 'RETRAIT','N010','Q099');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif) VALUES
('M011','Montant erroné',FALSE,TRUE, TRUE,'facultatif',FALSE,'facultatif',390, 1, 'Je reconnais avoir effectué ce paiement, mais le montant débité sur mon compte est erroné.', 'LESDEUX','N011','Q099');



----Insertion des statuts de dossier
INSERT INTO STATUT_DOSSIER_SLEFCARE VALUES('SC001',1,'BROUILLON');
INSERT INTO STATUT_DOSSIER_SLEFCARE VALUES('SC002',2,'CREE');
INSERT INTO STATUT_DOSSIER_SLEFCARE VALUES('SC003',3,'En Cours');
INSERT INTO STATUT_DOSSIER_SLEFCARE VALUES('SC004',4,'TRAITE');
INSERT INTO STATUT_DOSSIER_SLEFCARE VALUES('SC005',5,'CLOTURE');

--Etat des cartes
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'BLOQUE');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'EN COURS');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'DISPONIBLE');

--Toutes les CARTES

INSERT INTO CARTE VALUES('CA001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'VOL DE CARTE','PIERRE','01000002676300000','VISA','ETAT001');
INSERT INTO CARTE VALUES('CA002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'PERTE DE CARTE','PIERRE','01000002676300001','MASTER CARD','ETAT002');

---Toutes les contestations
INSERT INTO CONTESTATION VALUES('C0001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TRUE,'Contestation de vole de carte','123456','85','bnp1@pbpparispas.com','50.000', 3.0,3.0,'Inconnu',3,FALSE,FALSE,FALSE,'01000002676300000','29',FALSE,'061252','CA001','SC001','M001');
INSERT INTO CONTESTATION VALUES('C0002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TRUE,'Contestation de disparition','123457','85','bnp2@pbpparispas.com','50.000', 3.0,3.0,'Inconnu',3,FALSE,FALSE,FALSE,'01000002676300001','27',FALSE,'061252','CA002','SC002','M002');



--- Attribution des idDocuments aux contestation

INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001mu','PAYEMENT','29','20180110','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m5','ACHAT','29','20180110','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m8','PAYEMENT','29','20180111','C0001');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC004',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m9','CONTESTATION','27','20180111','C0002');
INSERT INTO DOCUMENT_ATTACHEMENT VALUES('DOC005',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'PDF','GD11100jnlx2i0j000001m7','PAYEMENT','27','20180111','C0002');

----création des opération
INSERT INTO OPERATION VALUES('OP001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0001');
INSERT INTO OPERATION VALUES('OP002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0001');
INSERT INTO OPERATION VALUES('OP003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'code operation 1',DATEADD('SECOND', 1348560343, DATE '1970-01-01'),DATEADD('SECOND', 1348560343, DATE '1970-01-01'),'EURO','Operation de recuperation', 3.0, 1.0,'HENRY','CREDIT',1,'C0002');