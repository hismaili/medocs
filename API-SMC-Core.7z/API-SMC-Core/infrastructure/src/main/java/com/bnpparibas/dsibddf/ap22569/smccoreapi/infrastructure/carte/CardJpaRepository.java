package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * CardJpaRepository
 *
 */
@Repository
public interface CardJpaRepository extends JpaRepository<AnonymizedCardEntity, DefaultEntityId> {

	/**
	 * recuperation d'une carte par son id
	 * @param cardId
	 * @return
	 */
	AnonymizedCardEntity findByCardId(String cardId);

	/**
	 *
	 * @param ribs
	 * @param validityDate
	 * @return
	 */
	@Query("from AnonymizedCardEntity where numCompte in ?1 and dateMaj > ?2")
	List<AnonymizedCardEntity> findByRibs(List<String> ribs, LocalDateTime validityDate);
}
