package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions;

public class ErrorCode {
    //Rejet global fichier
    public static final String INCCORRECT_PREFIX = "002";
    public static final String INCCORRECT_NUMBER_OF_FILEDS = "001";
    public static final String UNEXPECTED_SEQUENCE_NUMBER = "003";
    public static final String SEQUENCE_NUMBER_ALREADY_TREATED = "004";
    public static final String INCORRECT_NUMBER_OF_RECORDS = "005";
    public static final String UNEXPECTED_EXCEPTION = "006";
    public static final String FILE_NOT_FOUND_OR_UNREADABLE = "007";

    //rejet notification
    public static final String UNKOWN_DISPUTE_FOLDER_NUMBER = "501";
    public static final String UNEXPECTED_RECORD_CODE = "502";
    public static final String AGENCY_CODE_NOT_PROVIDED = "503";
    public static final String UNEXPECTED_NOTIF_CODE = "504";
    public static final String CALL_DATE_INCORRECT = "505";
    public static final String FOLDER_CREATION_DATE_INCORRECT = "506";
    public static final String NO_MAIL_ADRESS_PROVIDED = "507";
    public static final String NO_PHONE_NUMBER_PROVIDED = "508";
    public static final String WRONG_MAIL_ADRESS_PROVIDED = "509";
    public static final String NO_NOTIFICATION_CHANNEL_PROVIDED = "510";

}
