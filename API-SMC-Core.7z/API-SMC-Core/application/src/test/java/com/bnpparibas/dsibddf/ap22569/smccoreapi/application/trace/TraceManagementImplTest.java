package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.ISmcTraceRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTraceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.fail;


@RunWith(SpringRunner.class)
public class TraceManagementImplTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(TraceManagementImplTest.class);

    @MockBean
    private ISmcTraceRepository traceRepository;

    @Autowired
    private ITraceManagement traceManagement;

    @Test
    public void traceTest() {
        TraceDTO traceDTO = new TraceDTO();
        final SmcTrace trace = SmcTraceMapper.mapDTOToDomainDTO(traceDTO);
        try {
            traceManagement.trace(traceDTO);
        } catch (SmcTraceException e) {
            LOGGER.error(e.getMessage(), e);
            fail(e.getMessage());
        }
    }

    @TestConfiguration
    @ComponentScan(basePackages = "com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace")
    static class TestConfig {

    }

}