/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

/**
 * @author c65344
 *
 */
public class ContestationException extends SmcBusinessException {


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public ContestationException() {
		super();

	}

	/**
	 * @param message
	 */
	public ContestationException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public ContestationException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param cause
	 */
	public ContestationException(Throwable cause) {
		super(cause);

	}

}
