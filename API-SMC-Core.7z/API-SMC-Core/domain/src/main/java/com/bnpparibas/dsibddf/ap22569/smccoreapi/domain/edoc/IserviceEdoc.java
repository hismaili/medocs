/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.edoc;

import org.springframework.stereotype.Service;

/**
 * @author c65344
 *
 */
@Service
public interface IserviceEdoc {

	/**
	 * recuperer l'idGdn a partir de l'idAttachment de Edoc
	 *
	 * @param idAttachment
	 * @return
	 */
	public String getIdGn(String idAttachment);
}
