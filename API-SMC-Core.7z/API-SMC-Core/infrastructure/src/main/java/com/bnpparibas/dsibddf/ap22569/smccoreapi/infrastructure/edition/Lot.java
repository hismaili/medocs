/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import java.util.List;

/**
 * @author c65344
 *
 */
public class Lot {

	private List<DocumentSmc> document;

	/**
	 * @return the document
	 */
	public List<DocumentSmc> getDocument() {
		return document;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(List<DocumentSmc> document) {
		this.document = document;
	}
}
