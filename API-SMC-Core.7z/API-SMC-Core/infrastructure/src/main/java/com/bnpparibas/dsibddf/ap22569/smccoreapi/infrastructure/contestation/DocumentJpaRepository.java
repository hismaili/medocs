/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;

/**
 * @author c65344
 *
 */
public interface DocumentJpaRepository extends JpaRepository<DocumentAttacheEntity, DefaultEntityId> {

	@Query("SELECT d from DocumentAttacheEntity d Where (d.idGDN is null or d.idGDN = '')")
	Page<DocumentAttacheEntity> findByDocumentWithNoIdGdn(Pageable pageable);


	//List<DocumentAttacheEntity> findBySendToSmc(Boolean sendToSmc);

	/**
	 *
	 * @return
	 */
	@Query("SELECT COUNT(*) from DocumentAttacheEntity d Where (d.idGDN is null or d.idGDN = '')")
	Integer getNumberOfDocumentWithNoIdGdn();


}
