package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification.test;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification.NotificationJpaRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification.NotificationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;

@SpringBootTest(classes = SpringBootApp.class)
@RunWith(SpringRunner.class)
@ActiveProfiles({"local","test"})
public class NotificationServiceTest {
	@Autowired
	private transient NotificationService notif;
	@Autowired
	private transient NotificationJpaRepository notifJpa;

	@Test
	public void testSaveNotification() throws NotificationException {
		Notification notifInput = new Notification();
		notifInput.setCivilite("Mr");
		notif.saveNotification(notifInput);

		assertTrue(notifJpa.findAll() !=null);
		assertTrue(!notifJpa.findAll().isEmpty());
		assertTrue(notifJpa.findAll().size() == 1);

	}

}
