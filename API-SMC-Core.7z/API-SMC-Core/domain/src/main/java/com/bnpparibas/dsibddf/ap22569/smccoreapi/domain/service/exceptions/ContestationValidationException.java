package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ContestationValidationException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 8573330677491678778L;
	private List<SmcError> errors;

	/**
	 *
	 */
	public ContestationValidationException() {
		super();

	}

	public ContestationValidationException(List<SmcError> errors) {
		super();
		this.errors = errors;
	}

	/**
	 * @param message
	 */
	public ContestationValidationException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public ContestationValidationException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ContestationValidationException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public ContestationValidationException(Throwable cause) {
		super(cause);

	}

	public ContestationValidationException(Throwable throwable, List<SmcError> errors) {
		super(throwable);
		this.errors = errors;
	}

	public ContestationValidationException(Throwable throwable, String[] errors) {
		super(throwable);
		List<SmcError> smcErrors = null;
		if(errors != null && errors.length > 0) {
			smcErrors = Arrays.asList(errors).stream().map(err -> new SmcError("", err)).collect(Collectors.toList());
		}
		this.errors = smcErrors;
	}

	public void addError(SmcError error) {
		if(this.errors == null) {
			this.errors = new ArrayList<>();
		}
		errors.add(error);
	}

	public List<SmcError> getErrors() {
		return this.errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<SmcError> errors) {
		this.errors = errors;
	}
}
