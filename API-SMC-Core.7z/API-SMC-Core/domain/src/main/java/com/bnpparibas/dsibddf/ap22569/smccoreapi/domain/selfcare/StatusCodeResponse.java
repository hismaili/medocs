package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;



/**
 * Status
 */
public class StatusCodeResponse   {

	private String statut;

	private String code;

	private String avancementId;

	private String complete;

	private String analyse;

	private String libelleSID;

	/**
	 * @return the analyse
	 */
	public String getAnalyse() {
		return analyse;
	}

	/**
	 * @return the avancementId
	 */
	public String getAvancementId() {
		return avancementId;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the complete
	 */
	public String getComplete() {
		return complete;
	}

	/**
	 * @return the libelleSID
	 */
	public String getLibelleSID() {
		return libelleSID;
	}

	/**
	 * @return the statut
	 */
	public String getStatut() {
		return statut;
	}

	/**
	 * @param analyse the analyse to set
	 */
	public void setAnalyse(String analyse) {
		this.analyse = analyse;
	}

	/**
	 * @param avancementId the avancementId to set
	 */
	public void setAvancementId(String avancementId) {
		this.avancementId = avancementId;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param complete the complete to set
	 */
	public void setComplete(String complete) {
		this.complete = complete;
	}

	/**
	 * @param libelleSID the libelleSID to set
	 */
	public void setLibelleSID(String libelleSID) {
		this.libelleSID = libelleSID;
	}

	/**
	 * @param statut the statut to set
	 */
	public void setStatut(String statut) {
		this.statut = statut;
	}




}

