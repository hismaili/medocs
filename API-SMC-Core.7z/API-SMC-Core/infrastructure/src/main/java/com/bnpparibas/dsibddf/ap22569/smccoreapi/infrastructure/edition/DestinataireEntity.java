/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "DESTINATAIRE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class DestinataireEntity extends AbstractEntity<DefaultEntityId>{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column(length = 1)
	private String civilite;
	@Column(length = 38)
	private String adresse1;
	@Column(length = 38)
	private String adresse2;
	@Column(length = 38)
	private String adresse3;
	@Column(length = 38)
	private String adresse4;
	@Column(length = 38)
	private String adresse6;
	/**
	 * @return the adresse1
	 */
	public String getAdresse1() {
		return adresse1;
	}
	/**
	 * @return the adresse2
	 */
	public String getAdresse2() {
		return adresse2;
	}
	/**
	 * @return the adresse3
	 */
	public String getAdresse3() {
		return adresse3;
	}
	/**
	 * @return the adresse4
	 */
	public String getAdresse4() {
		return adresse4;
	}
	/**
	 * @return the adresse6
	 */
	public String getAdresse6() {
		return adresse6;
	}
	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}
	/**
	 * @param adresse1 the adresse1 to set
	 */
	public void setAdresse1(String adresse1) {
		this.adresse1 = adresse1;
	}
	/**
	 * @param adresse2 the adresse2 to set
	 */
	public void setAdresse2(String adresse2) {
		this.adresse2 = adresse2;
	}
	/**
	 * @param adresse3 the adresse3 to set
	 */
	public void setAdresse3(String adresse3) {
		this.adresse3 = adresse3;
	}
	/**
	 * @param adresse4 the adresse4 to set
	 */
	public void setAdresse4(String adresse4) {
		this.adresse4 = adresse4;
	}
	/**
	 * @param adresse6 the adresse6 to set
	 */
	public void setAdresse6(String adresse6) {
		this.adresse6 = adresse6;
	}
	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}


}
