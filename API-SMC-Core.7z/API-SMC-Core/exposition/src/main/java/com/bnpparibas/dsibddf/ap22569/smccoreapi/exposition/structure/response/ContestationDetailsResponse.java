package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;


/**
 *
 *
 *
 */
public class ContestationDetailsResponse {

	/**
	 *
	 */
	private static final long serialVersionUID = -188518694000257436L;
	private DisputeDetails contestation;

	/**
	 *
	 */
	public ContestationDetailsResponse() {
		super();

	}


	/**
	 *
	 * @return
	 */
	public DisputeDetails getContestation() {
		return contestation;
	}

	/**
	 *
	 * @param contestation
	 */
	public void setContestation(DisputeDetails contestation) {
		this.contestation = contestation;
	}

}
