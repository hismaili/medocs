package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons;

import javax.persistence.Column;
import java.util.Objects;

public class DefaultEntityId implements EntityId {

	@Column(length = 25)
	protected String id;

    public DefaultEntityId() {
	}

    public DefaultEntityId(String id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		DefaultEntityId that = (DefaultEntityId) o;
		return Objects.equals(id, that.id);
	}

    public String getId() {
		return id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

    public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "DefaultEntityId{" +
				"id=" + id +
				'}';
	}
}
