package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "PORTEUR")
@GenericGenerator(name = "SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class PorteurEntity extends AbstractEntity<DefaultEntityId> {

	/**
	 *
	 */
	private static final long serialVersionUID = -4755245768790261293L;

	@Column(length = 100)
	private String ikpi;

	@Column(length = 100)
	private String civilite;

	@Column(length = 100)
	private String nom;

	@Column(length = 100)
	private String prenom;



	public String getCivilite() {
		return civilite;
	}

	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}

	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
}
