/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

/**
 * @author c65344
 *
 */
public enum Status {
	NONTRAITE,ENCOURS,REJETER,TRAITE
}
