/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;

/**
 * @author c65344
 *
 */
public class DocOutput {
	private String compressOutput;
	private String encodingOutput;
	private String dataOutputOutput;
	private String archiveFormatOutput;
	private String fileNameOutput;
	private String mimeTypeOutput;
	private String errorGdnOutput;
	/**
	 *
	 */
	public DocOutput() {
		super();

	}
	/**
	 * @param compressOutput
	 * @param encodingOutput
	 * @param dataOutputOutput
	 * @param archiveFormatOutput
	 * @param fileNameOutput
	 * @param mimeTypeOutput
	 * @param errorGdnOutput
	 */
	public DocOutput(String compressOutput, String encodingOutput,
			String dataOutputOutput, String archiveFormatOutput,
			String fileNameOutput, String mimeTypeOutput, String errorGdnOutput) {
		this.compressOutput = compressOutput;
		this.encodingOutput = encodingOutput;
		this.dataOutputOutput = dataOutputOutput;
		this.archiveFormatOutput = archiveFormatOutput;
		this.fileNameOutput = fileNameOutput;
		this.mimeTypeOutput = mimeTypeOutput;
		this.errorGdnOutput = errorGdnOutput;
	}
	/**
	 * @return the archiveFormatOutput
	 */
	public String getArchiveFormatOutput() {
		return archiveFormatOutput;
	}
	/**
	 * @return the compressOutput
	 */
	public String getCompressOutput() {
		return compressOutput;
	}
	/**
	 * @return the dataOutputOutput
	 */
	public String getDataOutputOutput() {
		return dataOutputOutput;
	}
	/**
	 * @return the encodingOutput
	 */
	public String getEncodingOutput() {
		return encodingOutput;
	}
	/**
	 * @return the errorGdnOutput
	 */
	public String getErrorGdnOutput() {
		return errorGdnOutput;
	}
	/**
	 * @return the fileNameOutput
	 */
	public String getFileNameOutput() {
		return fileNameOutput;
	}
	/**
	 * @return the mimeTypeOutput
	 */
	public String getMimeTypeOutput() {
		return mimeTypeOutput;
	}
	/**
	 * @param archiveFormatOutput the archiveFormatOutput to set
	 */
	public void setArchiveFormatOutput(String archiveFormatOutput) {
		this.archiveFormatOutput = archiveFormatOutput;
	}
	/**
	 * @param compressOutput the compressOutput to set
	 */
	public void setCompressOutput(String compressOutput) {
		this.compressOutput = compressOutput;
	}
	/**
	 * @param dataOutputOutput the dataOutputOutput to set
	 */
	public void setDataOutputOutput(String dataOutputOutput) {
		this.dataOutputOutput = dataOutputOutput;
	}
	/**
	 * @param encodingOutput the encodingOutput to set
	 */
	public void setEncodingOutput(String encodingOutput) {
		this.encodingOutput = encodingOutput;
	}
	/**
	 * @param errorGdnOutput the errorGdnOutput to set
	 */
	public void setErrorGdnOutput(String errorGdnOutput) {
		this.errorGdnOutput = errorGdnOutput;
	}
	/**
	 * @param fileNameOutput the fileNameOutput to set
	 */
	public void setFileNameOutput(String fileNameOutput) {
		this.fileNameOutput = fileNameOutput;
	}
	/**
	 * @param mimeTypeOutput the mimeTypeOutput to set
	 */
	public void setMimeTypeOutput(String mimeTypeOutput) {
		this.mimeTypeOutput = mimeTypeOutput;
	}

}
