package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService implements IAccountService {

	@Autowired
	private transient IAccountRepository accountRepository;


	@Override
	public UserAccount getAccountByAlias(String alias) throws UserAccountException {
		return this.accountRepository.getAccountByAlias(alias);
	}

	@Override
	public List<UserAccount> getUserAccounts(String telemeticId,String userId) throws UserAccountException {
		final List<UserAccount> userAccounts = this.accountRepository.getUserAccounts(telemeticId,userId);
		return userAccounts;
	}
}
