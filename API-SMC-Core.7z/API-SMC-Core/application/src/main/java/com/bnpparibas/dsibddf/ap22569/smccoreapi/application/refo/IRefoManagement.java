/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.refo;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.RefoException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.ResponseRefo;
import org.springframework.stereotype.Component;

/**
 * @author c65344
 *
 */
@Component
public interface IRefoManagement {

	/**
	 * recupère les informations Hello-bank et monaco en boolean
	 *
	 * @param codeUO
	 * @return
	 * @throws RefoException
	 */
	ResponseRefo getTypeBank(String codeUO) throws RefoException;
}
