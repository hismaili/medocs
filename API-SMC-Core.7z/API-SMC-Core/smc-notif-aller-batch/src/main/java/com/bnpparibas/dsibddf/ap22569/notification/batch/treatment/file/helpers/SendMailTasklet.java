package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.helpers;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.NotificationDetailValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class SendMailTasklet implements Tasklet {

    private static final Logger LOG = LoggerFactory.getLogger(SendMailTasklet.class);

    @Autowired
    private SendMailHelper sendMailHelper;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        LOG.info("Dealing with failures :");
        final StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
        List<Throwable> stepFailureExceptions = stepExecution.getFailureExceptions();
        List<Throwable> jobFailureExceptions = stepExecution.getJobExecution().getFailureExceptions();

        List<Throwable> failureExceptions = new ArrayList<>(stepFailureExceptions);
        failureExceptions.addAll(jobFailureExceptions);

        List<Throwable> detailRejectExceptions = failureExceptions.stream().filter(ex -> ex instanceof NotificationDetailValidationException).collect(Collectors.toList());
        List<Throwable> fileRejectExceptions = failureExceptions.stream().filter(ex -> !(ex instanceof NotificationDetailValidationException)).collect(Collectors.toList());

        if(!CollectionUtils.isEmpty(fileRejectExceptions)) {
            LOG.info("Sending file rejection mail");
            sendMailHelper.sendFileRejectMail(fileRejectExceptions);

        } else if(!CollectionUtils.isEmpty(detailRejectExceptions)){
            LOG.info("Sending notifications rejection mail");
            sendMailHelper.sendDetailRejectsMail(detailRejectExceptions);
        }

        return RepeatStatus.FINISHED;
    }

}
