/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationTop;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ContestationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ContestationJpaRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.MotifEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.NatureEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.OperationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.QualificationEntity;

/**
 * @author c65344
 *
 */
@Component
public class OperationTopMapper {

	@Autowired
	private transient ContestationJpaRepository contestationJpaRepository;

	/**
	 * convert operationEntity to OperationTop
	 * @param operationEntity
	 * @return
	 */
	public OperationTop mapOperationEntityToOperationTop(OperationEntity operationEntity){

		OperationTop operationTop = new OperationTop();
		if(operationEntity !=null){

			String codeOperation = operationEntity.getCodeOperation();

			if(!StringUtils.isEmpty(codeOperation)){

				ContestationEntity contestation = contestationJpaRepository.findByCodeOperation(codeOperation);

				if(contestation !=null){

					MotifEntity motifContestation = contestation.getMotifContestation();
					if(motifContestation !=null){

						NatureEntity natureContestation = motifContestation.getNatureContestation();
						QualificationEntity qualificationContestation = motifContestation.getQualificationContestation();

						if(natureContestation !=null){
							operationTop.setIdNatureDossier(natureContestation.getNatureCodeSmc());
						}

						if(qualificationContestation !=null){
							operationTop.setIdQualifDossier(qualificationContestation.getQualificationCodeSmc());
						}
					}

					LocalDate dateVente = operationEntity.getDateVente();

					if(!StringUtils.isEmpty(dateVente)){
						operationTop.setDateDeVente(dateVente.toString());
					}

					operationTop.setCodeDevise(operationEntity.getDeviseOperation());
					operationTop.setCodeOperation(codeOperation);
					LocalDateTime dateDeContestation = contestation.getDateDeContestation();

					if(dateDeContestation !=null){
						operationTop.setDateContestation(dateDeContestation.toString());
					}

					LocalDateTime dateCreationDossierSMC = contestation.getDateCreationDossierSMC();

					if(dateCreationDossierSMC !=null){
						operationTop.setDateCreation(dateCreationDossierSMC.toString());
					}


					operationTop.setDossierSansAnalyseAuto(contestation.getDossierSansAnalyseAuto());


					operationTop.setIdReseau(operationEntity.getIdReseau());
					operationTop.setLibelleDevise(operationEntity.getDeviseOperation());
					operationTop.setMontantFrais(operationEntity.getMontantCommission());
					operationTop.setMontantOperation(operationEntity.getMontantOperation());
					operationTop.setNatureOperation(operationEntity.getNatureOperation());
					operationTop.setNumCarte(contestation.getNumCarte());
					operationTop.setNumclient(contestation.getIdPorteur());
					operationTop.setNumDossier(contestation.getNumDossierSMC());
					operationTop.setTypeOperation(operationEntity.getTypeOperationHmp());

				}

			}

		}

		return operationTop;
	}
}
