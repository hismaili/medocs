package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcBusinessException;

public class EditingException extends SmcBusinessException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public EditingException() {
		super();
	}

	/**
	 * @param message
	 */
	public EditingException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public EditingException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public EditingException(Throwable cause) {
		super(cause);
	}


}
