package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;


/**
 *
 *
 *
 *
 */
public class DocumentAttache {

	private String id;
	private String idGDN;
	private String idAttachment;
	private String nomDocument;

	private String formatDocument;

	private String typeDocGDN;

	private String referenceDossierSMC;

	private StatusAttachment statusAttachment;


	private Boolean recap;

	/**
	 *
	 */
	public DocumentAttache() {
		super();
	}

	public DocumentAttache(String idGDN, String nomDocument, String formatDocument, String typeDocGDN) {
		this.idGDN = idGDN;
		this.nomDocument = nomDocument;
		this.formatDocument = formatDocument;
		this.typeDocGDN = typeDocGDN;
	}

	/**
	 * @param idGDN
	 * @param nomDocument
	 * @param formatDocument
	 * @param typeDocGDN
	 * @param referenceDossierSMC
	 */
	public DocumentAttache(String idGDN, String nomDocument,
			String formatDocument, String typeDocGDN, String referenceDossierSMC) {
		this.idGDN = idGDN;
		this.nomDocument = nomDocument;
		this.formatDocument = formatDocument;
		this.typeDocGDN = typeDocGDN;
		this.referenceDossierSMC = referenceDossierSMC;
	}

	/**
	 * @param idGDN
	 * @param nomDocument
	 * @param formatDocument
	 * @param typeDocGDN
	 * @param referenceDossierSMC
	 */
	public DocumentAttache(String idGDN, String nomDocument,
			String formatDocument, String typeDocGDN, String referenceDossierSMC,Boolean recap) {
		this.idGDN = idGDN;
		this.nomDocument = nomDocument;
		this.formatDocument = formatDocument;
		this.typeDocGDN = typeDocGDN;
		this.referenceDossierSMC = referenceDossierSMC;
		this.recap = recap;
	}


	/**
	 * @return the formatDocument
	 */
	public String getFormatDocument() {
		return formatDocument;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the idAttachment
	 */
	public String getIdAttachment() {
		return idAttachment;
	}

	/**
	 * @return the idGDN
	 */
	public String getIdGDN() {
		return idGDN;
	}


	/**
	 * @return the nomDocument
	 */
	public String getNomDocument() {
		return nomDocument;
	}

	/**
	 * @return the recap
	 */
	public Boolean getRecap() {
		return recap;
	}

	/**
	 * @return the referenceDossierSMC
	 */
	public String getReferenceDossierSMC() {
		return referenceDossierSMC;
	}


	/**
	 * @return the statusAttachment
	 */
	public StatusAttachment getStatusAttachment() {
		return statusAttachment;
	}


	/**
	 * @return the typeDocGDN
	 */
	public String getTypeDocGDN() {
		return typeDocGDN;
	}


	/**
	 * @param formatDocument the formatDocument to set
	 */
	public void setFormatDocument(String formatDocument) {
		this.formatDocument = formatDocument;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @param idAttachment the idAttachment to set
	 */
	public void setIdAttachment(String idAttachment) {
		this.idAttachment = idAttachment;
	}


	/**
	 * @param idGDN the idGDN to set
	 */
	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}


	/**
	 * @param nomDocument the nomDocument to set
	 */
	public void setNomDocument(String nomDocument) {
		this.nomDocument = nomDocument;
	}


	/**
	 * @param recap the recap to set
	 */
	public void setRecap(Boolean recap) {
		this.recap = recap;
	}


	/**
	 * @param referenceDossierSMC the referenceDossierSMC to set
	 */
	public void setReferenceDossierSMC(String referenceDossierSMC) {
		this.referenceDossierSMC = referenceDossierSMC;
	}


	/**
	 * @param statusAttachment the statusAttachment to set
	 */
	public void setStatusAttachment(StatusAttachment statusAttachment) {
		this.statusAttachment = statusAttachment;
	}





	/**
	 * @param typeDocGDN the typeDocGDN to set
	 */
	public void setTypeDocGDN(String typeDocGDN) {
		this.typeDocGDN = typeDocGDN;
	}
}
