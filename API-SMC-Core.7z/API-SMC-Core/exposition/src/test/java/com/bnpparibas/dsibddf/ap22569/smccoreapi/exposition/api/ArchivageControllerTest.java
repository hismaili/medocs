package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.DeleteDocDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.HeaderSmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.NewFolderDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(ArchivageController.class)
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Ignore
public class ArchivageControllerTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(ArchivageControllerTest.class);

	@Autowired
	private MockMvc mockMvc;
	private HeaderSmc head = new HeaderSmc();

	/**
	 * @return the head
	 */
	public HeaderSmc getHead() {
		return head;
	}

	/**
	 * @param head the head to set
	 */
	public void setHead(HeaderSmc head) {
		this.head = head;
	}

	@Test
	public void testDeleteDocBadRequest(){

		DeleteDocDTO deleteDocDTO = new DeleteDocDTO();

		//	head.setIdContestationSmc("444");
		//head.setNumCarteBancaire("4444");
		deleteDocDTO.setDocumentId("GD11100jnl");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("deleteDocDTO", deleteDocDTO);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String content = objectMapper.writeValueAsString(deleteDocDTO);

			MockHttpServletRequestBuilder request = post("/contestation/archivage/deleteDoc?CallingUser=c65344").header("Content-Type", MediaType.APPLICATION_JSON_VALUE,head)
					.content(content);

			ResultActions response = mockMvc.perform(request);
			response.andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			fail(e.getMessage());
		}
	}

	@Test
	public void testDeleteDocSuccess(){

		DeleteDocDTO deleteDocDTO = new DeleteDocDTO();
		//	head.setIdContestationSmc("4444");
		//head.setNumCarteBancaire("44444");
		deleteDocDTO.setDocumentId("GD11100jnlx2i0j000001mu");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("deleteDocDTO", deleteDocDTO);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String content = objectMapper.writeValueAsString(deleteDocDTO);

			MockHttpServletRequestBuilder request = post("/contestation/archivage/deleteDoc?callingUser=c65344").header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
					.content(content);

			ResultActions response = mockMvc.perform(request);
			response.andExpect(status().isOk());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			fail(e.getMessage());
		}
	}

	@Test
	public void testNewFolderBadRequest() {

		NewFolderDTO newFolderDTO = new NewFolderDTO();
		newFolderDTO.setCallingUser("c65344");
		//	head.setIdContestationSmc("4444");
		//head.setNumCarteBancaire("44444");

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String content = objectMapper.writeValueAsString(newFolderDTO);

			MockHttpServletRequestBuilder request = post("/contestation/archivage/newFolder").header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
					.content(content);

			ResultActions response = mockMvc.perform(request);
			response.andExpect(status().isBadRequest());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			fail(e.getMessage());
		}
	}




	@Test
	public void testNewFolderSuccess() {

		NewFolderDTO newFolderDTO = new NewFolderDTO();
		newFolderDTO.setCallingUser("593007");
		newFolderDTO.setIdContestationSmc("25642323541");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("newFolderDTO", newFolderDTO);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String content = objectMapper.writeValueAsString(newFolderDTO);

			MockHttpServletRequestBuilder request = post("/contestation/archivage/newFolder").header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
					.content(content);

			ResultActions response = mockMvc.perform(request);
			response.andExpect(status().isOk());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			fail(e.getMessage());
		}
	}

}