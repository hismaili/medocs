package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;

import java.math.BigDecimal;

/**
 * montant reconnu par le porteur
 */
public class AmountInput   {

	private BigDecimal value;
	private String currency;

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @return the value
	 */
	public BigDecimal getValue() {
		return value;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(BigDecimal value) {
		this.value = value;
	}


}

