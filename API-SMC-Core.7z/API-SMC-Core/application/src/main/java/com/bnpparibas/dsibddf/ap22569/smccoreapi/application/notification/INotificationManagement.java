/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;

import java.util.List;

/**
 * @author c65344
 *
 */
public interface INotificationManagement {
	void saveNotification(Notification notification) throws NotificationException;

	void saveNotificationFileHeader(NotificationInfoFile infoFileHeader)  throws NotificationException;

	void saveNotificationFileFooter(NotificationInfoFile infoFileFooter)  throws NotificationException;

	NotificationInfoFile getLastTreatedFile(String dateflux) throws NotificationException ;

	NotificationInfoFile getFileBySequenceNumber(String dateflux, String currentSequenceNumber) throws NotificationException;

	List<Notification> getPendingNotifications() throws NotificationException;

    void flagEventAsSucceeded(String notificationId) throws NotificationException;

	void flagNotificationFileTreatmentAsSucceeded(NotificationInfoFile infoFileHeader) throws NotificationException;

	void flagNotificationFileTreatmentAsFailed(NotificationInfoFile infoFileHeader) throws NotificationException;
}
