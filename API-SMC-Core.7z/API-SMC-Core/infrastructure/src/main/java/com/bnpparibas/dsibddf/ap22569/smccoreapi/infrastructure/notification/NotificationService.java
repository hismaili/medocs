/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.INotificationService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class NotificationService implements INotificationService {

	@Autowired
	private transient NotificationJpaRepository notificationJpaRepository;
	@Autowired
	private transient NotificationFileJpaRepository notificationFile;

	@Override
	public void saveNotification(Notification notification)
			throws NotificationException {
		NotificationEntity notificationEntity = new NotificationEntity();
		NotificationFileEntity notificationFileEntity = null;

		try{
			if(notification !=null){
				BeanUtils.copyProperties(notification, notificationEntity,"infoFile", "codeEnregistrement", "dateAppel"); //$NON-NLS-1$
				notificationEntity.setRecordCode(notification.getCodeEnregistrement());
				notificationEntity.setDateCall(notification.getDateAppel());
				notificationEntity.setDateCreation(LocalDateTime.now());
				notificationEntity.setProcessingDate(LocalDateTime.now());
				if(notification.getCorrect()) {
					notificationEntity.setProcessingStatus(NotificationEntity.NotificationProcessingStatus.SEND_IN_PROGRESS);
				} else {
					notificationEntity.setProcessingStatus(NotificationEntity.NotificationProcessingStatus.READ_REJECT);
				}


				if(notification.getInfoFile() !=null){

					Optional<NotificationFileEntity> optNotifFile = notificationFile.findById(notification.getInfoFile().getIdFileNotification());

					if(optNotifFile !=null && optNotifFile.isPresent()){
						notificationFileEntity = optNotifFile.get();
						notificationEntity.setInformationFile(notificationFileEntity);
					}else{

						notificationFileEntity	= new NotificationFileEntity();
						BeanUtils.copyProperties(notification.getInfoFile(), notificationFileEntity);
						notificationEntity.setInformationFile(notificationFileEntity);
					}
				}


				notificationJpaRepository.save(notificationEntity);
			}

		}catch(Exception e){
			throw new NotificationException(e);
		}
	}

	@Override
	public void saveNotificationFileHeader(NotificationInfoFile infoFileHeader) {
		NotificationFileEntity notificationFileEntity = new NotificationFileEntity();
		BeanUtils.copyProperties(infoFileHeader, notificationFileEntity);
		this.notificationFile.save(notificationFileEntity);

	}

	@Override
	public void saveNotificationFileFooter(NotificationInfoFile infoFileFooter) {
		NotificationFileEntity notificationFileEntity = new NotificationFileEntity();
		BeanUtils.copyProperties(infoFileFooter, notificationFileEntity);
		this.notificationFile.save(notificationFileEntity);
	}

	@Override
	public List<Notification> getPendingNotifications() {
		final List<NotificationEntity> pendingNotificationEntities = this.notificationJpaRepository.findPendingNotifications();
		List<Notification> pendingNotifications = null;
		if(!CollectionUtils.isEmpty(pendingNotificationEntities)) {
			pendingNotifications = pendingNotificationEntities.stream().map(notificationEntity -> {
				Notification notif = new Notification();
				BeanUtils.copyProperties(notificationEntity, notif);
				notif.setCodeEnregistrement(notificationEntity.getRecordCode());
				notif.setDateAppel(notificationEntity.getDateCall());
				notif.setNotificationInternalId(notificationEntity.getEntityId().getId());
				return notif;
			}).collect(Collectors.toList());
		}
		return pendingNotifications;
	}

	@Override
	public void flagEventAsSucceeded(String notificationId) throws NotificationException {
		Optional<NotificationEntity> optional = this.notificationJpaRepository.findById(notificationId);
		if(optional.isPresent()) {
			NotificationEntity entity = optional.get();
			entity.setEntityId(new DefaultEntityId(notificationId));
			entity.setProcessingStatus(NotificationEntity.NotificationProcessingStatus.SEND_SUCEEDED);
			this.notificationJpaRepository.save(entity);
		}

	}

	@Override
	public NotificationInfoFile getLastTreatedFile(String dateFlux) throws NotificationException {
		NotificationFileEntity notificationFile = this.notificationFile.getLastTreatedFileForDate(dateFlux);
		NotificationInfoFile notificationInfoFile = null;
		if(notificationInfoFile != null) {
			notificationInfoFile = new NotificationInfoFile();
			BeanUtils.copyProperties(notificationFile, notificationInfoFile);
		}
		return notificationInfoFile;
	}

	@Override
	public NotificationInfoFile getFileBySequenceNumber(String dateFlux, String currentSequenceNumber) throws NotificationException {
		NotificationFileEntity notificationFile = this.notificationFile.findByDateFluxHeaderAndNumSeqHeader(dateFlux, currentSequenceNumber);
		NotificationInfoFile notificationInfoFile = null;
		if(notificationInfoFile != null) {
			notificationInfoFile = new NotificationInfoFile();
			BeanUtils.copyProperties(notificationFile, notificationInfoFile);
		}
		return notificationInfoFile;
	}

	@Override
	public void flagNotificationFileTreatmentAsSucceeded(NotificationInfoFile infoFile) throws NotificationException {
		flagNotificationFileTreatmentStatus(infoFile, FileTreatmentStatus.SUCCEEDED);
	}

	public void flagNotificationFileTreatmentStatus(NotificationInfoFile infoFile, FileTreatmentStatus treatmentStatus)  throws NotificationException {
		if(infoFile != null) {
			Optional<NotificationFileEntity> notificationFile = this.notificationFile.findById(infoFile.getIdFileNotification());
			if(notificationFile.isPresent()) {
				NotificationFileEntity notificationFileEntity = notificationFile.get();
				notificationFileEntity.setTreatmentStatus(treatmentStatus);
				this.notificationFile.save(notificationFileEntity);
			}
		}
	}

	@Override
	public void flagNotificationFileTreatmentAsFailed(NotificationInfoFile infoFile) throws NotificationException {
		flagNotificationFileTreatmentStatus(infoFile, FileTreatmentStatus.FAILED);
	}
}
