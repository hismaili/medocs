/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.Document;

/**
 * @author c65344
 *
 */
public class ArchivageResponseGetDoc{
	private Document document;
	/**
	 *
	 */
	public ArchivageResponseGetDoc() {
		super();

	}

	/**
	 * @param document
	 */
	public ArchivageResponseGetDoc(Document document) {
		this.document = document;
	}



	/**
	 * @return the document
	 */
	public Document getDocument() {
		return document;
	}


	/**
	 * @param document the document to set
	 */
	public void setDocument(Document document) {
		this.document = document;
	}





}
