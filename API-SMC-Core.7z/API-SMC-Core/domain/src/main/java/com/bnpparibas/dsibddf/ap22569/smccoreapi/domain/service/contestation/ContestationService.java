package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.IDisputeSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.StatusCodeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.AnonymizedCard;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.ICardService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.IOperationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.porteur.IPorteurService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * ContestationService
 *
 */
@Service
@Lazy
public class ContestationService implements IContestationService {

	private static final Logger LOG = LoggerFactory.getLogger(ContestationService.class);

	private static final String CREER = "crée";

	private static final String ENCOURS = "SC003";

	private static final String TRAITE = "SC004";

	private static final String CLOTURE ="SC005";

	@Autowired(required = false)
	private transient IPorteurService porteurService;

	@Autowired(required = false)
	private transient IStatutDossierContestationRepository statutDossierContestationRepository;

	@Autowired(required = false)
	private transient IContestationRepository contestationRepository;

	@Autowired(required = false)
	private transient ContestationHelper contestationHelper;

	@Autowired(required = false)
	private transient IMotifRepository motifRepository;

	@Autowired(required = false)
	private transient IOperationRepository operationRepository;

	@Autowired(required = false)
	private transient ICardService cardService;
	@Autowired
	private transient IDisputeSelfCare disputeSelfCare;

	/**
	 * Consulter une contestation
	 */
	@Override
	public Contestation consulterContestation(String referenceDossier) throws ContestationException {

		Contestation contestation = contestationRepository.recupererContestation(referenceDossier);
		/*if(contestation !=null){
			StatutDossierContestation lastStatus = getLastStatus(contestation.getNumDossierSMC());

			if(lastStatus !=null){
				contestation.setDernierStatutDossier(lastStatus);
				contestation = updateContestation(contestation);
			}
		}*/
		return contestation;
	}

	/**
	 * Creer un dossier de contestation transmis par selfcare
	 * <p>
	 *
	 * @param contestationSelfcareIn
	 * @Return La référence du dossier de contestation
	 */
	@Override
	public Contestation creerDossierContestation(@Valid ContestationSelfcareIn contestationSelfcareIn) throws ContestationValidationException, ContestationException {
		Contestation contestationSaved = null;
		if (contestationHelper.isValidInput(contestationSelfcareIn)) {
			try {
				// TODO vérifier qu'il y a pas de contestation en cours pour
				// l'opération en se basant sur le PAN et le code opération
				// TODO persister le porteur



				contestationSaved = contestationRepository
						.creerContestation(mapToContestation(contestationSelfcareIn));

				/**
				 * Envoi de la contestation à SMC
				 */
				DisputeResponse reponseSmc = disputeSelfCare.sendDisputeToSmc(contestationSaved);


				if (reponseSmc != null && contestationSaved != null) {
					/* recuperation du numero de dossier de contestation  provenant du service SMC*/

					String fileIdSMC = reponseSmc.getFileIdSMC();

					if (!StringUtils.isEmpty(fileIdSMC)) {
						contestationSaved.setNumDossierSMC(fileIdSMC);

						contestationSaved = updateContestation(contestationSaved);
					} else {
						LOG.error("SMC n'a envoyé aucun numéro de dossier");
					}

				}

			} catch (CardException e) {
				operationRepository.deleteOperationsTmp(contestationSelfcareIn
						.getIdTelematiqueClient(),contestationSelfcareIn.getIkpiClient());
				throw new ContestationValidationException(e);
			} catch (DonneIncorectException e) {
				operationRepository.deleteOperationsTmp(contestationSelfcareIn
						.getIdTelematiqueClient(),contestationSelfcareIn.getIkpiClient());
				final ContestationValidationException contestationValidationException = new ContestationValidationException(
						e);
				if (!CollectionUtils.isEmpty(e.getErrors())) {
					List<SmcError> smcErrors = e.getErrors().stream()
							.map(err -> {
								return new SmcError("", err);
							}).collect(Collectors.toList());
					contestationValidationException.setErrors(smcErrors);
				}
				throw contestationValidationException;
			} catch (MandatoryException e) {
				operationRepository.deleteOperationsTmp(contestationSelfcareIn
						.getIdTelematiqueClient(),contestationSelfcareIn.getIkpiClient());
				throw new ContestationValidationException(e);
			} catch(Exception e) {
                operationRepository.deleteOperationsTmp(contestationSelfcareIn
                        .getIdTelematiqueClient(),contestationSelfcareIn.getIkpiClient());
                throw new ContestationException(e);
            }
		}
		return contestationSaved;
	}

	/**
	 * recupère le dernier status , de la contestation chez Smc
	 *
	 * @param referenceDossier
	 * @return
	 */
	private StatutDossierContestation getLastStatus(String referenceDossier){
		StatutDossierContestation lastStatus = null;

		try {
			/**
			 * recuperation du status de la contestation dans SMC
			 */
			DisputeResponse statusDispute = disputeSelfCare.getStatusDispute(referenceDossier);
			if(statusDispute !=null){
				lastStatus = new StatutDossierContestation();

				StatusCodeResponse statusSmc = statusDispute.getStatusCodeResponse();

				String avancementId = statusSmc.getAvancementId();
				String statut = statusSmc.getStatut();
				lastStatus = new StatutDossierContestation();

				if("5".equals(avancementId)){

					lastStatus.setCodeStatut(CLOTURE);

				}else if(CREER.equals(statut)) {

					switch (avancementId) {

					case "0":
						lastStatus.setCodeStatut(ENCOURS);
						break;

					case "1":
						lastStatus.setCodeStatut(ENCOURS);
						break;

					case "2":
						lastStatus.setCodeStatut(TRAITE);
						break;

					case "4":
						lastStatus.setCodeStatut(TRAITE);
						break;

					case "3":
						lastStatus.setCodeStatut(TRAITE);
						break;

					default:lastStatus = null;
					break;
					}

				}

			}

		} catch (MandatoryException e) {

			LOG.error("Aucune reference de dossier n'a été envoyé par SMART CONTESTATION ",e);
		}

		if(lastStatus == null){
			LOG.error("Aucun status valide n'a été envoyé par Smart contestation ");
		}
		return lastStatus;
	}

	@Override
	public boolean isAuthorized(String idGdn, String idTelematic) {
		return contestationRepository.isAuthorized(idGdn, idTelematic);
	}

	/**
	 * map ContestationSelfcareIn in Contestation
	 *
	 * @param contestationSelfcareIn
	 * @return
	 * @throws ContestationValidationException
	 * @throws CardException
	 * @throws ContestationException
	 * @throws DonneIncorectException
	 * @throws MandatoryException
	 */
	private Contestation mapToContestation(ContestationSelfcareIn contestationSelfcareIn) throws ContestationValidationException, CardException, ContestationException, DonneIncorectException, MandatoryException{
		//TODO vérifier qu'il y a pas de contestation en cours pour l'opération en se basant sur le PAN et le code opération

		String iKpi = contestationSelfcareIn.getIkpiClient();
		//Porteur porteur = porteurService.recupererInformationsPorteur(iKpi);
		Contestation contestation = new Contestation();
		BeanUtils.copyProperties(contestationSelfcareIn, contestation);
		contestation.setIdPorteur(iKpi);
		contestation.setIdTelematique(contestationSelfcareIn.getIdTelematiqueClient());
		BigDecimal montantConteste = new BigDecimal(0.00f);
		BigDecimal montantReconnu = new BigDecimal(0.00f);
		List<Operation> operations = contestationSelfcareIn.getOperations();
		final List<Throwable> errors = new ArrayList<>();
		if (!CollectionUtils.isEmpty(operations)) {
			List<Operation> realOperations = operations.stream().map(op -> {
				try {
					Operation ope = operationRepository.getOperationByCodeOpe(op.getCodeOperation(),contestationSelfcareIn.getIdTelematiqueClient(),contestationSelfcareIn.getIkpiClient());
					return ope;
				} catch (OperationException e) {
					errors.add(e);
					LOG.error(e.getMessage(), e);
				}
				return null;
			}).collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(errors)) {
				throw new ContestationValidationException("Une ou plusieurs opérations sélecionnées sont introuvables");
			}
			contestation.setOperations(realOperations);

			if(!CollectionUtils.isEmpty(realOperations)){
				double sumConteste = realOperations.stream().map(Operation::getMontantOperation).mapToDouble(montantOperation -> {
					if (montantOperation != null){
						return montantOperation.doubleValue();
					}else{
						return 0;
					}

				}).sum();
				montantConteste = new BigDecimal(sumConteste);
				contestation.setMontantConteste(montantConteste);
			}

			if(!CollectionUtils.isEmpty(operations)){
				double sumRecognized  =  operations.stream().map(Operation::getMontantReconnu).mapToDouble(montantRecognized -> {
					if (montantRecognized != null){
						return montantRecognized.doubleValue();
					}else{
						return 0;
					}

				}).sum();


				contestation.setNombreOperations(operations.size());
				montantReconnu = new BigDecimal(sumRecognized);
				contestation.setMontantReconnuPorteur(montantReconnu);
			}






		} else {
			contestation.setNombreOperations(Integer.valueOf(0));
		}


		contestation.setNumCarte(contestationSelfcareIn.getNumeroCarte());
		StatutDossierContestation statutDossierContestation = statutDossierContestationRepository.recupererStatutDossier("SC002");

		contestation.setDernierStatutDossier(statutDossierContestation);
		contestation.setDescription(contestationSelfcareIn.getDescription());
		contestation.setDocumentAttaches(contestationSelfcareIn.getDocumentsAttaches());

		contestation.setMotif(contestationSelfcareIn.getMotif());

		final AnonymizedCard card = cardService.getCardByCardId(contestationSelfcareIn.getCardId());
		//TODO check if card is null => throw exception

		if(card ==null){
			LOG.error("Aucune carte ne correspond à l'id carte : "+contestationSelfcareIn.getCardId());
			throw new CardException();

		}
		CartePorteur carte = card.getCarte();
		contestation.setCarte(carte);
		contestation.setNumCompte(carte.getNumCompte());
		return contestation;
	}

	@Override
	public Contestation recupererContestationByIdInterne(String idContestation)
			throws ContestationException {

		Contestation contestation = contestationRepository.recupererContestationByIdInterne(idContestation);

		/*if(contestation !=null){
			StatutDossierContestation lastStatus = getLastStatus(contestation.getNumDossierSMC());

			if(lastStatus !=null){
				contestation.setDernierStatutDossier(lastStatus);
				contestation = updateContestation(contestation);
			}
		}*/
		return contestation;
	}

	@Override
	public List<Contestation> recupererContestationsClient(String identifiant,Integer offset,Integer limit) throws ContestationException {
		List<Contestation> contestations = contestationRepository.recupererContestationsClient(identifiant,offset,limit);

		contestations.stream().filter(contestation -> contestation !=null && !StringUtils.isEmpty(contestation.getNumDossierSMC())).map(contestation -> {

			Contestation contestationUpdate = null;
			String numDossierSMC = contestation.getNumDossierSMC();
			StatutDossierContestation lastStatus = null;
			if(StringUtils.isEmpty(numDossierSMC)) {
				LOG.warn("La contestation n'a pas encore été créé dans SMC");
			} else {
				//lastStatus = getLastStatus(numDossierSMC);
			}

			if(lastStatus !=null){
				contestationUpdate = contestation;
				contestationUpdate.setDernierStatutDossier(lastStatus);
				contestationUpdate = updateContestation(contestationUpdate);
			}

			return contestationUpdate;
		}).collect(Collectors.toList());
		return contestations;
	}

	/**
	 * Récupérer la liste des motifs qui leurs sont associées
	 */
	@Override
	public List<MotifContestation> recupererMotifsContestation() {
		return motifRepository.getAllMotifs();
	}


	/**
	 * Récupérer la liste des motifs qui leurs sont associées
	 *
	 * @param operationType
	 */
	@Override
	public List<MotifContestation> recupererMotifsContestation(TypeOperation operationType) {
		return motifRepository.getMotifsByOperationType(operationType);
	}

	@Override
	public List<MotifContestation> recupererMotifsContestation(TypeOperation operationType, Boolean
			cardLost, Integer numberOfOperations) throws Exception {
		List<MotifContestation> reasons = motifRepository.getAppliedReasons(operationType, cardLost, numberOfOperations);
		List<MotifContestation> filteredReasons = null;
		if (!CollectionUtils.isEmpty(reasons)) {
			//si plusieurs opérations sélectionnées, enlever les motifs qui exigent une seule opération par dossier
			filteredReasons = reasons.stream()
					.filter(
							reason -> (numberOfOperations > 1 && !reason.isAppliedToOneOperation()) || numberOfOperations == 1
							).collect(Collectors.toList());
		}
		return filteredReasons;
	}

	@Override
	public StatutDossierContestation recupererStatutDossier(String codeStatut) throws
	ContestationException, DonneIncorectException, MandatoryException {
		return statutDossierContestationRepository.recupererStatutDossier(codeStatut);
	}

	/**
	 * Reprendre Contestation
	 */
	@Override
	public void reprendreContestation() {
		//TODO
	}

	/**
	 * Sauvegarder une contestation à l'état brouillon dans la couche monétique
	 *
	 * @param contestationSelfCare
	 */
	@Override
	public Contestation sauvegarderContestation(ContestationSelfcareIn contestationSelfCare) {

		return null;//TODO
	}





	@Override
	public Contestation updateContestation(Contestation contestation) {
		return contestationRepository.updateContestation(contestation);
	}
}
