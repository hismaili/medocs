package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name="qualification")
public class QualificationEntity implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "qualifcation_code", nullable=false, length = 25)
	private String qualifcationCode;
	@Column(name="qualification_libelle")
	private String qualificationLibelle;
	@Column(name="qualification_code_smc")
	private String qualificationCodeSmc;
	@Column(name="date_debut_effet")
	private LocalDateTime dateDebutEffet;
	@Column(name="date_fin_effet")
	private LocalDateTime dateFinEffet;

    public String getQualifcationCode() {
		return qualifcationCode;
	}

    public String getQualificationLibelle() {
		return qualificationLibelle;
	}

    public void setQualifcationCode(String qualifcationCode) {
		this.qualifcationCode = qualifcationCode;
	}

    public void setQualificationLibelle(String qualificationLibelle) {
		this.qualificationLibelle = qualificationLibelle;
	}

	public String getQualificationCodeSmc() {
		return qualificationCodeSmc;
	}

	public void setQualificationCodeSmc(String qualificationCodeSmc) {
		this.qualificationCodeSmc = qualificationCodeSmc;
	}

	public LocalDateTime getDateDebutEffet() {
		return dateDebutEffet;
	}

	public void setDateDebutEffet(LocalDateTime dateDebutEffet) {
		this.dateDebutEffet = dateDebutEffet;
	}

	public LocalDateTime getDateFinEffet() {
		return dateFinEffet;
	}

	public void setDateFinEffet(LocalDateTime dateFinEffet) {
		this.dateFinEffet = dateFinEffet;
	}
}
