package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.AttachmentData;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.Errors;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.ResponseDisputeFile;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare.StatusCode;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityManagerFactory;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@EnableJpaRepositories("com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.*")
@EntityScan("com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.*")
@Configuration
@EnableJpaAuditing
@EnableCaching
@Lazy
public class PersistenceConfiguration {

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

	@Bean(name="restTemplateSmc")
	@Lazy
	public RestTemplate  mockRestTemplateSmc(){

		RestTemplate restTemplate = Mockito.mock(RestTemplate.class);

		Mockito.when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(HttpEntity.class)
				, ArgumentMatchers.eq(ResponseDisputeFile.class)))
				.thenAnswer(new Answer<ResponseEntity<ResponseDisputeFile>>() {

					@Override
					public ResponseEntity answer(InvocationOnMock arg0)
							throws Throwable {

						ResponseDisputeFile responseDisputeFile = new ResponseDisputeFile();
						String folderNumber = null;

						URI uri = arg0.getArgument(0);
						String url = uri.getPath();
						if (url.contains("status")) {

							List<String> urlComposing = Arrays.asList(url.split("/"));
							urlComposing = new ArrayList<>();
							folderNumber = urlComposing.get(urlComposing.size() - 1);

							responseDisputeFile.setFileIdSMC(folderNumber);
							responseDisputeFile.setStatusCode(new StatusCode("crée", "3"));

						} else if((url.contains("file"))) {
							folderNumber = UUID.randomUUID().toString();
							responseDisputeFile.setFileIdSMC(folderNumber);
							responseDisputeFile.setStatusCode(new StatusCode("crée", "3"));
						} else if(url.contains("attachment")){


							HttpEntity argument = arg0.getArgument(2);
							AttachmentData attach = (AttachmentData) argument.getBody();
							if(attach !=null){
								String fileIdSMC = attach.getFileIdSMC();
								responseDisputeFile.setFileIdSMC(fileIdSMC);
								responseDisputeFile.setStatusCode(new StatusCode("crée", "3"));
							}


						}else  {
							Errors error = new Errors();
							error.setCode("4");
							error.setMessage("Erreur du service SMC");
							responseDisputeFile.setErrors(Arrays.asList(error));

							return ResponseEntity.badRequest().body(responseDisputeFile);
						}
						return ResponseEntity.ok().body(responseDisputeFile);
					}
				});
		return restTemplate;

	}

	@Bean
	public PlatformTransactionManager transactionManager(
			EntityManagerFactory emf) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);

		return transactionManager;
	}
}
