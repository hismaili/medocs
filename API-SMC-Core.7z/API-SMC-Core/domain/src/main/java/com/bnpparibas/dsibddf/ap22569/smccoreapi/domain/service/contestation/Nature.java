package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public class Nature {

    private Qualification qualification;

    private String natureLibelle;


    public String getNatureLibelle() {
        return natureLibelle;
    }

    public void setNatureLibelle(String natureLibelle) {
        this.natureLibelle = natureLibelle;
    }
}
