package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;


/**
 *
 *
 * @author c65344
 *
 */
public class SmcError {

	private String code;

	private String libelle;

	/**
	 *
	 */
	public SmcError() {
		super();

	}

	public SmcError(String code, String libelle) {
		this.code = code;
		this.libelle = libelle;
	}

	public String getCode() {
		return code;
	}

	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param libelle the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
}
