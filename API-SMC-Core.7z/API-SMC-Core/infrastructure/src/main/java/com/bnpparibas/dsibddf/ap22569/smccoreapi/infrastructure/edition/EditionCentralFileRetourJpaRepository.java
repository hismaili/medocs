/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

/**
 * @author c65344
 *
 */
@Component
public interface EditionCentralFileRetourJpaRepository extends JpaRepository<InfoFileReturnCentraleEntity, String> {

	@Query("SELECT max(e.numSequence) FROM InfoFileReturnCentraleEntity e")
	int getMaxNumSequence();
}
