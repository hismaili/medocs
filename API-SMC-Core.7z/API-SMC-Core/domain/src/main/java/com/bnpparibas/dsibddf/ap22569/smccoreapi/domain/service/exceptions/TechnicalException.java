package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

public class TechnicalException extends SmcTechnicalException {

}
