/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import java.util.List;

/**
 * @author c65344
 *
 */
public class PurgeFolderDTO {
	private List<String> listeIdContestations;

	/**
	 * @return the listeIdContestations
	 */
	public List<String> getListeIdContestations() {
		return listeIdContestations;
	}

	/**
	 * @param listeIdContestations the listeIdContestations to set
	 */
	public void setListeIdContestations(List<String> listeIdContestations) {
		this.listeIdContestations = listeIdContestations;
	}

}
