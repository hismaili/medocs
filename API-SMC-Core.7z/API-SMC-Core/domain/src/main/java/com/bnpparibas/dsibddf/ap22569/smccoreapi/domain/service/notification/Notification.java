/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification;

/**
 * @author c65344
 *
 */
public class Notification {
	private String codeEnregistrement;
	private String idTechnique;
	private String dossierSmc;
	private String numCarteDossier;
	private String  dateAppel;
	private String numClient;
	private String codeAgence;
	private String heureAppel;
	private String  notifSms;
	private String  notifMail;
	private String  numTel;
	private String  mailClient;
	private String  codeNotif;
	private String  contenuNotif;
	private String  objetDuMail;
	private String civilite;
	private String nom;
	private String prenom;
	private String dateCreationDossier;
	private String dateCreationNotification;

	private NotificationInfoFile infoFile;

	private String NotificationInternalId;

	private Boolean correct = Boolean.TRUE;


	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}
	/**
	 * @return the codeAgence
	 */
	public String getCodeAgence() {
		return codeAgence;
	}
	/**
	 * @return the codeNotif
	 */
	public String getCodeNotif() {
		return codeNotif;
	}

	/**
	 * @return the contenuNotif
	 */
	public String getContenuNotif() {
		return contenuNotif;
	}

	/**
	 * @return the dossierSmc
	 */
	public String getDossierSmc() {
		return dossierSmc;
	}
	/**
	 * @return the idTechnique
	 */
	public String getIdTechnique() {
		return idTechnique;
	}
	/**
	 * @return the infoFile
	 */
	public NotificationInfoFile getInfoFile() {
		return infoFile;
	}
	/**
	 * @return the mailClient
	 */
	public String getMailClient() {
		return mailClient;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @return the notifMail
	 */
	public String getNotifMail() {
		return notifMail;
	}
	/**
	 * @return the notifSms
	 */
	public String getNotifSms() {
		return notifSms;
	}
	/**
	 * @return the numCarteDossier
	 */
	public String getNumCarteDossier() {
		return numCarteDossier;
	}
	/**
	 * @return the numTel
	 */
	public String getNumTel() {
		return numTel;
	}
	/**
	 * @return the objetDuMail
	 */
	public String getObjetDuMail() {
		return objetDuMail;
	}
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}

	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	/**
	 * @param codeAgence the codeAgence to set
	 */
	public void setCodeAgence(String codeAgence) {
		this.codeAgence = codeAgence;
	}
	/**
	 * @param codeNotif the codeNotif to set
	 */
	public void setCodeNotif(String codeNotif) {
		this.codeNotif = codeNotif;
	}

	/**
	 * @param contenuNotif the contenuNotif to set
	 */
	public void setContenuNotif(String contenuNotif) {
		this.contenuNotif = contenuNotif;
	}

	/**
	 * @param dossierSmc the dossierSmc to set
	 */
	public void setDossierSmc(String dossierSmc) {
		this.dossierSmc = dossierSmc;
	}
	/**
	 * @param idTechnique the idTechnique to set
	 */
	public void setIdTechnique(String idTechnique) {
		this.idTechnique = idTechnique;
	}
	/**
	 * @param infoFile the infoFile to set
	 */
	public void setInfoFile(NotificationInfoFile infoFile) {
		this.infoFile = infoFile;
	}
	/**
	 * @param mailClient the mailClient to set
	 */
	public void setMailClient(String mailClient) {
		this.mailClient = mailClient;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @param notifMail the notifMail to set
	 */
	public void setNotifMail(String notifMail) {
		this.notifMail = notifMail;
	}
	/**
	 * @param notifSms the notifSms to set
	 */
	public void setNotifSms(String notifSms) {
		this.notifSms = notifSms;
	}
	/**
	 * @param numCarteDossier the numCarteDossier to set
	 */
	public void setNumCarteDossier(String numCarteDossier) {
		this.numCarteDossier = numCarteDossier;
	}
	/**
	 * @param numTel the numTel to set
	 */
	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}
	/**
	 * @param objetDuMail the objetDuMail to set
	 */
	public void setObjetDuMail(String objetDuMail) {
		this.objetDuMail = objetDuMail;
	}
	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getCodeEnregistrement() {
		return codeEnregistrement;
	}

	public void setCodeEnregistrement(String codeEnregistrement) {
		this.codeEnregistrement = codeEnregistrement;
	}

	public String getDateAppel() {
		return dateAppel;
	}

	public void setDateAppel(String dateAppel) {
		this.dateAppel = dateAppel;
	}

	public String getNumClient() {
		return numClient;
	}

	public void setNumClient(String numClient) {
		this.numClient = numClient;
	}

	public String getHeureAppel() {
		return heureAppel;
	}



	public void setHeureAppel(String heureAppel) {
		this.heureAppel = heureAppel;
	}

	public String getDateCreationDossier() {
		return dateCreationDossier;
	}

	public void setDateCreationDossier(String dateCreationDossier) {
		this.dateCreationDossier = dateCreationDossier;
	}

	public String getDateCreationNotification() {
		return dateCreationNotification;
	}

	public void setDateCreationNotification(String dateCreationNotification) {
		this.dateCreationNotification = dateCreationNotification;
	}

	public String getNotificationInternalId() {
		return NotificationInternalId;
	}

	public void setNotificationInternalId(String notificationInternalId) {
		NotificationInternalId = notificationInternalId;
	}

	public Boolean getCorrect() {
		return correct;
	}

	public void setCorrect(Boolean correct) {
		this.correct = correct;
	}

	@Override
	public String toString() {
		return "Notification{" +
				"codeEnregistrement='" + codeEnregistrement + '\'' +
				", idTechnique='" + idTechnique + '\'' +
				", dossierSmc='" + dossierSmc + '\'' +
				", numCarteDossier='" + numCarteDossier + '\'' +
				", dateAppel='" + dateAppel + '\'' +
				", numClient='" + numClient + '\'' +
				", codeAgence='" + codeAgence + '\'' +
				", heureAppel='" + heureAppel + '\'' +
				", notifSms='" + notifSms + '\'' +
				", notifMail='" + notifMail + '\'' +
				", numTel='" + numTel + '\'' +
				", mailClient='" + mailClient + '\'' +
				", codeNotif='" + codeNotif + '\'' +
				", contenuNotif='" + contenuNotif + '\'' +
				", objetDuMail='" + objetDuMail + '\'' +
				", civilite='" + civilite + '\'' +
				", nom='" + nom + '\'' +
				", prenom='" + prenom + '\'' +
				", dateCreationDossier='" + dateCreationDossier + '\'' +
				", dateCreationNotification='" + dateCreationNotification + '\'' +
				", infoFile=" + infoFile +
				'}';
	}
}
