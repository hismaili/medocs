package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

public class NoDataAvailableException extends RuntimeException {

    public NoDataAvailableException(String s) {
        super(s);
    }
}
