package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * DisputeDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-05-28T16:07:49.642Z")

public class DisputeDetails {
	@JsonProperty("factsSummary")
	private String factsSummary;

	@JsonProperty("disputeInternalIdentifier")
	private String disputeInternalIdentifier;

	@JsonProperty("attachedDocuments")
	@Valid
	private List<DisputeDetailsAttachedDocuments> attachedDocuments;

	@JsonProperty("disputedAmount")
	@JsonFormat(pattern = "#0.00")
	private BigDecimal disputedAmount;

	@JsonProperty("recognizedAmount")
	@JsonFormat(pattern = "#0.00")
	private BigDecimal recognizedAmount;

	@JsonProperty("reason")
	private String reason;

	@JsonProperty("attachedOperations")
	@Valid
	private List<OperationVO> attachedOperations;

	@JsonProperty("disputeFolderReference")
	private String disputeFolderReference;

	@JsonProperty("currentStatus")
	private String currentStatus;

	@JsonProperty("cardholderFirstName")
	private String cardholderFirstName;

	@JsonProperty("cardholderLastName")
	private String cardholderLastName;

	@JsonProperty("maskedPan")
	private String maskedPan;

	@JsonProperty("cardType")
	private String cardType;

	@JsonProperty("creationDate")
	@JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	private LocalDateTime creationDate;

	@JsonProperty("cardCancellationDate")
	@JsonFormat(pattern = "dd/MM/yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate cardCancellationDate;

	/**
	 *
	 * @param attachedDocumentsItem
	 * @return
	 */
	public DisputeDetails addAttachedDocumentsItem(DisputeDetailsAttachedDocuments attachedDocumentsItem) {
		if (this.attachedDocuments == null) {
			this.attachedDocuments = new ArrayList<DisputeDetailsAttachedDocuments>();
		}
		this.attachedDocuments.add(attachedDocumentsItem);
		return this;
	}
	/**
	 *
	 * @param attachedOperationsItem
	 * @return
	 */
	public DisputeDetails addAttachedOperationsItem(OperationVO attachedOperationsItem) {
		if (this.attachedOperations == null) {
			this.attachedOperations = new ArrayList<OperationVO>();
		}
		this.attachedOperations.add(attachedOperationsItem);
		return this;
	}
	/**
	 *
	 * @param attachedDocuments
	 * @return
	 */
	public DisputeDetails attachedDocuments(List<DisputeDetailsAttachedDocuments> attachedDocuments) {
		this.attachedDocuments = attachedDocuments;
		return this;
	}
	/**
	 *
	 * @param attachedOperations
	 * @return
	 */
	public DisputeDetails attachedOperations(List<OperationVO> attachedOperations) {
		this.attachedOperations = attachedOperations;
		return this;
	}
	/**
	 *
	 * @param cardCancellationDate
	 * @return
	 */
	public DisputeDetails cardCancellationDate(LocalDate cardCancellationDate) {
		this.cardCancellationDate = cardCancellationDate;
		return this;
	}
	/**
	 *
	 * @param cardholderFirstName
	 * @return
	 */
	public DisputeDetails cardholderFirstName(String cardholderFirstName) {
		this.cardholderFirstName = cardholderFirstName;
		return this;
	}
	/**
	 *
	 * @param cardholderLastName
	 * @return
	 */
	public DisputeDetails cardholderLastName(String cardholderLastName) {
		this.cardholderLastName = cardholderLastName;
		return this;
	}
	/**
	 *
	 * @param cardType
	 * @return
	 */
	public DisputeDetails cardType(String cardType) {
		this.cardType = cardType;
		return this;
	}
	/**
	 *
	 * @param creationDate
	 * @return
	 */
	public DisputeDetails creationDate(LocalDateTime creationDate) {
		this.creationDate = creationDate;
		return this;
	}

	/**
	 *
	 * @param currentStatus
	 * @return
	 */
	public DisputeDetails currentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
		return this;
	}
	/**
	 *
	 * @param disputedAmount
	 * @return
	 */
	public DisputeDetails disputedAmount(BigDecimal disputedAmount) {
		this.disputedAmount = disputedAmount;
		return this;
	}
	/**
	 *
	 * @param disputeFolderReference
	 * @return
	 */
	public DisputeDetails disputeFolderReference(String disputeFolderReference) {
		this.disputeFolderReference = disputeFolderReference;
		return this;
	}

	/**
	 *
	 * @param disputeInternalIdentifier
	 * @return
	 */
	public DisputeDetails disputeInternalIdentifier(String disputeInternalIdentifier) {
		this.disputeInternalIdentifier = disputeInternalIdentifier;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeDetails disputeDetails = (DisputeDetails) o;
		return Objects.equals(this.factsSummary, disputeDetails.factsSummary) &&
				Objects.equals(this.disputeInternalIdentifier, disputeDetails.disputeInternalIdentifier) &&
				Objects.equals(this.attachedDocuments, disputeDetails.attachedDocuments) &&
				Objects.equals(this.disputedAmount, disputeDetails.disputedAmount) &&
				Objects.equals(this.recognizedAmount, disputeDetails.recognizedAmount) &&
				Objects.equals(this.reason, disputeDetails.reason) &&
				Objects.equals(this.attachedOperations, disputeDetails.attachedOperations) &&
				Objects.equals(this.disputeFolderReference, disputeDetails.disputeFolderReference) &&
				Objects.equals(this.currentStatus, disputeDetails.currentStatus) &&
				Objects.equals(this.cardholderFirstName, disputeDetails.cardholderFirstName) &&
				Objects.equals(this.cardholderLastName, disputeDetails.cardholderLastName) &&
				Objects.equals(this.maskedPan, disputeDetails.maskedPan) &&
				Objects.equals(this.cardType, disputeDetails.cardType) &&
				Objects.equals(this.creationDate, disputeDetails.creationDate) &&
				Objects.equals(this.cardCancellationDate, disputeDetails.cardCancellationDate);
	}

	/**
	 *
	 * @param factsSummary
	 * @return
	 */
	public DisputeDetails factsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
		return this;
	}

	/**
	 * Get attachedDocuments
	 *
	 * @return attachedDocuments
	 **/
	@ApiModelProperty(value = "")
	/**
	 *
	 * @return
	 */
	@Valid
	public List<DisputeDetailsAttachedDocuments> getAttachedDocuments() {
		return attachedDocuments;
	}

	/**
	 * Get attachedOperations
	 *
	 * @return attachedOperations
	 **/
	@ApiModelProperty(value = "")
	/**
	 *
	 * @return
	 */
	@Valid
	public List<OperationVO> getAttachedOperations() {
		return attachedOperations;
	}

	/**
	 * date d'opposition de la carte
	 *
	 * @return cardCancellationDate
	 **/
	@ApiModelProperty(value = "date d'opposition de la carte")

	@Valid

	public LocalDate getCardCancellationDate() {
		return cardCancellationDate;
	}

	/**
	 * nom du porteur de la carte
	 *
	 * @return cardholderFirstName
	 **/
	@ApiModelProperty(value = "nom du porteur de la carte")


	public String getCardholderFirstName() {
		return cardholderFirstName;
	}

	/**
	 * prénom du porteur de la carte
	 *
	 * @return cardholderLastName
	 **/
	@ApiModelProperty(value = "prénom du porteur de la carte")
	public String getCardholderLastName() {
		return cardholderLastName;
	}

	/**
	 * type de carte
	 *
	 * @return cardType
	 **/
	@ApiModelProperty(value = "type de carte")
	public String getCardType() {
		return cardType;
	}

	/**
	 * date d enregistrement de la contestation
	 *
	 * @return creationDate
	 **/
	@ApiModelProperty(value = "date d enregistrement de la contestation")
	@Valid
	public LocalDateTime getCreationDate() {
		return creationDate;
	}

	/**
	 * statut du dossier
	 *
	 * @return currentStatus
	 **/
	@ApiModelProperty(value = "statut du dossier")
	public String getCurrentStatus() {
		return currentStatus;
	}

	/**
	 * montant contesté
	 *
	 * @return disputedAmount
	 **/
	@ApiModelProperty(value = "montant contesté")

	@Valid
	public BigDecimal getDisputedAmount() {
		return disputedAmount;
	}

	/**
	 * référence du dossier de contestation
	 *
	 * @return disputeFolderReference
	 **/
	@ApiModelProperty(value = "référence du dossier de contestation")
	public String getDisputeFolderReference() {
		return disputeFolderReference;
	}

	/**
	 * identifiant interne du dossier de contestation dans le service monétique
	 *
	 * @return disputeInternalIdentifier
	 **/
	@ApiModelProperty(value = "identifiant interne du dossier de contestation dans le service monétique")
	public String getDisputeInternalIdentifier() {
		return disputeInternalIdentifier;
	}

	/**
	 * Get factsSummary
	 *
	 * @return factsSummary
	 **/
	@ApiModelProperty(value = "")
	public String getFactsSummary() {
		return factsSummary;
	}

	/**
	 * le numéro de carte masqué (2222 xxxxxxxxx 5654)
	 *
	 * @return maskedPan
	 **/
	@ApiModelProperty(value = "le numéro de carte masqué (2222 xxxxxxxxx 5654)")
	public String getMaskedPan() {
		return maskedPan;
	}

	/**
	 * motif de contestation
	 *
	 * @return reason
	 **/
	@ApiModelProperty(value = "motif de contestation")
	public String getReason() {
		return reason;
	}

	/**
	 * montant reconnu
	 *
	 * @return recognizedAmount
	 **/
	@ApiModelProperty(value = "montant reconnu")
	@Valid
	public BigDecimal getRecognizedAmount() {
		return recognizedAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(factsSummary, disputeInternalIdentifier, attachedDocuments, disputedAmount, recognizedAmount, reason, attachedOperations, disputeFolderReference, currentStatus, cardholderFirstName, cardholderLastName, maskedPan, cardType, creationDate, cardCancellationDate);
	}
	/**
	 *
	 * @param maskedPan
	 * @return
	 */
	public DisputeDetails maskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
		return this;
	}
	/**
	 *
	 * @param reason
	 * @return
	 */
	public DisputeDetails reason(String reason) {
		this.reason = reason;
		return this;
	}
	/**
	 *
	 * @param recognizedAmount
	 * @return
	 */
	public DisputeDetails recognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
		return this;
	}

	/**
	 *
	 * @param attachedDocuments
	 */
	public void setAttachedDocuments(List<DisputeDetailsAttachedDocuments> attachedDocuments) {
		this.attachedDocuments = attachedDocuments;
	}
	/**
	 *
	 * @param attachedOperations
	 */
	public void setAttachedOperations(List<OperationVO> attachedOperations) {
		this.attachedOperations = attachedOperations;
	}
	/**
	 *
	 * @param cardCancellationDate
	 */
	public void setCardCancellationDate(LocalDate cardCancellationDate) {
		this.cardCancellationDate = cardCancellationDate;
	}
	/**
	 *
	 * @param cardholderFirstName
	 */
	public void setCardholderFirstName(String cardholderFirstName) {
		this.cardholderFirstName = cardholderFirstName;
	}
	/**
	 *
	 * @param cardholderLastName
	 */
	public void setCardholderLastName(String cardholderLastName) {
		this.cardholderLastName = cardholderLastName;
	}
	/**
	 *
	 * @param cardType
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	/**
	 *
	 * @param creationDate
	 */
	public void setCreationDate(LocalDateTime creationDate) {
		this.creationDate = creationDate;
	}
	/**
	 *
	 * @param currentStatus
	 */
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	/**
	 *
	 * @param disputedAmount
	 */
	public void setDisputedAmount(BigDecimal disputedAmount) {
		this.disputedAmount = disputedAmount;
	}
	/**
	 *
	 * @param disputeFolderReference
	 */
	public void setDisputeFolderReference(String disputeFolderReference) {
		this.disputeFolderReference = disputeFolderReference;
	}

	/**
	 *
	 * @param disputeInternalIdentifier
	 */
	public void setDisputeInternalIdentifier(String disputeInternalIdentifier) {
		this.disputeInternalIdentifier = disputeInternalIdentifier;
	}

	/**
	 *
	 * @param factsSummary
	 */
	public void setFactsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
	}
	/**
	 *
	 * @param maskedPan
	 */
	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}

	/**
	 *
	 * @param reason
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 *
	 * @param recognizedAmount
	 */
	public void setRecognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeDetails {\n");

		sb.append("    factsSummary: ").append(toIndentedString(factsSummary)).append("\n");
		sb.append("    disputeInternalIdentifier: ").append(toIndentedString(disputeInternalIdentifier)).append("\n");
		sb.append("    attachedDocuments: ").append(toIndentedString(attachedDocuments)).append("\n");
		sb.append("    disputedAmount: ").append(toIndentedString(disputedAmount)).append("\n");
		sb.append("    recognizedAmount: ").append(toIndentedString(recognizedAmount)).append("\n");
		sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
		sb.append("    attachedOperations: ").append(toIndentedString(attachedOperations)).append("\n");
		sb.append("    disputeFolderReference: ").append(toIndentedString(disputeFolderReference)).append("\n");
		sb.append("    currentStatus: ").append(toIndentedString(currentStatus)).append("\n");
		sb.append("    cardholderFirstName: ").append(toIndentedString(cardholderFirstName)).append("\n");
		sb.append("    cardholderLastName: ").append(toIndentedString(cardholderLastName)).append("\n");
		sb.append("    maskedPan: ").append(toIndentedString(maskedPan)).append("\n");
		sb.append("    cardType: ").append(toIndentedString(cardType)).append("\n");
		sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
		sb.append("    cardCancellationDate: ").append(toIndentedString(cardCancellationDate)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

