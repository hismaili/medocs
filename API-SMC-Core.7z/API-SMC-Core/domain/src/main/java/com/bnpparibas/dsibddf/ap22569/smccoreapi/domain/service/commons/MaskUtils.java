package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.HolderMail;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.HolderPhoneNumber;
import org.springframework.util.StringUtils;

public class MaskUtils {
    public static String maskPan(String numCarteInput) {
        String maskedPan = null;
        if(!StringUtils.isEmpty(numCarteInput)) {
            StringBuilder result = new StringBuilder();
            StringBuilder temp = new StringBuilder(numCarteInput.trim());
            while(temp.length()>0 && '0' == temp.charAt(0)) {
                temp = temp.deleteCharAt(0);
            }
            final int length = temp.length();
            result.append(temp.subSequence(0, 4))
                    .append(" **** **** ")
                    .append(temp.subSequence(length - 4, length));
            maskedPan = result.toString();
        }
        return maskedPan;

    }

    public static String maskRib(String rib) {
        String maskedRib = null;
        if(!StringUtils.isEmpty(rib)) {
            StringBuilder result = new StringBuilder();
            StringBuilder temp = new StringBuilder(rib);
            final int length = temp.length();
            result.append("****").append(temp.subSequence(length - 4, length));
            maskedRib = result.toString();
        }
        return maskedRib;

    }

    public static String maskMail(HolderMail holderMail) {
        String maskedMail = null;
        if(holderMail != null) {
            String userName = holderMail.getMailUserName();
            String mailDoamin = holderMail.getMailDomain();

            if (!StringUtils.isEmpty(userName) && !StringUtils.isEmpty(mailDoamin)) {
                StringBuilder result = new StringBuilder(userName).append("@").append(mailDoamin);
                maskedMail = result.toString();
            }
        }
        return maskedMail;
    }

    public static String maskPhoneNumber(HolderPhoneNumber holderPhoneNumber) {
        String maskedPhoneNumber = null;
        if(holderPhoneNumber != null) {
            String countryCode = holderPhoneNumber.getCountryCode();
            String regionCode = holderPhoneNumber.getRegionCode();
            String phoneNumber = holderPhoneNumber.getPhoneNumber();

            if (!StringUtils.isEmpty(phoneNumber)) {
                StringBuilder result = new StringBuilder();
                StringBuilder temp = new StringBuilder(phoneNumber);
                final int length = temp.length();
                if(!StringUtils.isEmpty(countryCode)) {
                    result = result.append(countryCode).append(" ");
                }
                result = result.append("** ** ** ")
                        .append(temp.subSequence(length - 4, length));
                maskedPhoneNumber = result.toString();
            }
        }
        return maskedPhoneNumber;
    }
}
