/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.DocumentAttache;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatusContestationSmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatutDossierContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;

/**
 * @author c65344
 *
 */
public class ContestaionVO {
	/** identifiant de la contestation dans la couche monétique */
	private String idContestation;
	/** Numéro de dossier SMC (Smart Contestation)*/
	private String numDossierSMC;
	/** 5 premiers chiffres du rib  */
	private String numCompte;
	/** Numéro de la carte bancaire : le PAN */
	private String numCarte;
	/** identifiant porteur : client de la banque */
	private String idPorteur;

	/** identifiant telematic : identifiant en rapport avec un compte bancaire*/
	private String idTelematique;
	/**
	 * date de creation dossier
	 */
	private LocalDateTime dateDeCreationDossier;
	/** montant remboursement */
	private BigDecimal montantRemboursement;

	/** montant reconnu porteur : montant reconnu par le porteur (dans le cas de contestation du nombre de billets distribués par un GAB) */
	private BigDecimal montantReconnuPorteur;

	/** statut dossier */
	private StatutDossierContestation dernierStatutDossier;
	/** Le client souhaite être notifié par SMS ou non */
	private Boolean notifSMS;
	/** Le client souhaite être notifié par Mail ou non */
	private Boolean notifMail;

	/** Le motif de rejet du dossier de contestation après son traitement */
	private String motifRejet;

	/** Nombre d'opérations contestées */
	private Integer nombreOperations;
	/** Le montant contesté */
	private BigDecimal montantConteste;
	/** La liste des operations contestées */
	private List<Operation> operations;
	/** List des identifiants documents */
	private List<DocumentAttache> documentAttaches;
	/** Etat de purge du dossier */
	private boolean isPurged;
	/** description des faits */
	private String description;
	/** motif de la contestation */
	private MotifContestation motif;
	private String numeroTel;
	private String phoneCountryCode;

	private String mail;

	private Boolean topNumeroTelModifie;

	private Boolean topMailModifie;


	private Boolean cardVoleePerdue;

	private CartePorteur carte;

	private StatusContestationSmc statusSmc;
}
