package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons;

import javax.persistence.EmbeddedId;
import javax.persistence.GeneratedValue;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Objects;

@MappedSuperclass
public abstract class AbstractEntity<T extends EntityId> extends AbstractAuditableEntity implements Serializable {

    @EmbeddedId
    @GeneratedValue(generator = "SHORT_UUID_GENERATOR")
    private T entityId;

    protected AbstractEntity() {
    }

    protected AbstractEntity(T entityId) {
        this.entityId = Objects.requireNonNull(entityId);
    }

    public T getEntityId() {
        return entityId;
    }

    public void setEntityId(T entityId) {
        this.entityId = entityId;
    }

    public String asString() {
        return entityId.toString();
    }

    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (this == o) {
            result = true;
        } else if (o instanceof AbstractEntity) {
            AbstractEntity other = (AbstractEntity) o;
            result = Objects.equals(entityId, other.entityId);
        }
        return result;
    }

    @Override
    public int hashCode() {
        return Objects.hash(entityId);
    }

    @Override
    public String toString() {
        return "AbstractEntity[" +
                "entityId=" + entityId!= null? entityId.toString():"" +
                ']';
    }
}

