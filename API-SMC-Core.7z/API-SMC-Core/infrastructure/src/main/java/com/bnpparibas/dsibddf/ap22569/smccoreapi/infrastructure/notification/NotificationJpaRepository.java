/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

/**
 * @author c65344
 *
 */
public interface NotificationJpaRepository extends JpaRepository<NotificationEntity, String> {

    @Query("from NotificationEntity Where processingStatus = 'IN_PROGRESS'")
    List<NotificationEntity> findPendingNotifications();

    @Query("from NotificationEntity Where entityId.id=?1")
    Optional<NotificationEntity> findById(String entityId);

}
