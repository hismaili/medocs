package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

public enum ExigenceAjoutInformation {
    obligatoire, recommande, facultatif
}
