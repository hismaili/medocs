package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Operation
 */
public class TransactionItem   {
	@JsonProperty("id")
	private String coidop;

	@JsonProperty("bankId")
	private String bankId;

	@JsonProperty("acknowledgedAmount")
	private Amount acknowledgedAmount;

	/**
	 * @return the acknowledgedAmount
	 */
	public Amount getAcknowledgedAmount() {
		return acknowledgedAmount;
	}

	/**
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * @return the coidop
	 */
	public String getCoidop() {
		return coidop;
	}

	/**
	 * @param acknowledgedAmount the acknowledgedAmount to set
	 */
	public void setAcknowledgedAmount(Amount acknowledgedAmount) {
		this.acknowledgedAmount = acknowledgedAmount;
	}

	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * @param coidop the coidop to set
	 */
	public void setCoidop(String coidop) {
		this.coidop = coidop;
	}



}

