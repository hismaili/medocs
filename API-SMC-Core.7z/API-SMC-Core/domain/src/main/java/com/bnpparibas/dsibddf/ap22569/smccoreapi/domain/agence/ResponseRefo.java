/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence;

/**
 * @author c65344
 *
 */
public class ResponseRefo {
	private boolean helloBank;
	private boolean monaco;
	/**
	 *
	 */
	public ResponseRefo() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param helloBank
	 * @param monaco
	 */
	public ResponseRefo(boolean helloBank, boolean monaco) {
		this.helloBank = helloBank;
		this.monaco = monaco;
	}
	/**
	 * @return the helloBank
	 */
	public boolean isHelloBank() {
		return helloBank;
	}
	/**
	 * @return the monaco
	 */
	public boolean isMonaco() {
		return monaco;
	}
	/**
	 * @param helloBank the helloBank to set
	 */
	public void setHelloBank(boolean helloBank) {
		this.helloBank = helloBank;
	}
	/**
	 * @param monaco the monaco to set
	 */
	public void setMonaco(boolean monaco) {
		this.monaco = monaco;
	}

}
