package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte;

import java.util.List;

public interface IAccountService {

	UserAccount getAccountByAlias(String alias) throws UserAccountException;

	List<UserAccount> getUserAccounts(String telemeticId,String userId) throws UserAccountException;
}
