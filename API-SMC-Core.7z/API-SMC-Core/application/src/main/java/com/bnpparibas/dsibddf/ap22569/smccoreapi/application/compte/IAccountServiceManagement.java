package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.compte.UserAccountException;

import java.util.List;

public interface IAccountServiceManagement {

	List<AccountDTO> getUserAccounts(String telemeticId,String userId) throws UserAccountException;
}
