package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface IEditionManagement {

	/**
	 * recupère le document PDF
	 *
	 * @param request
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput getDocumentPDF(RequestEditiqueInput request) throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException;

	/**
	 * recupère au hazard un enregistrement non traité
	 * et le transforme à en cours
	 * @return
	 */
	EditionRecording getEditionRecording();

	/**
	 *
	 * @return
	 */
	int getLastNumSeqEditiqueToSmc();

	/**
	 * recupère le dernier numéro de sequence
	 * @return
	 */
	int getLastNumSequence();

	/**
	 * recupère les enregistrement en base de donné pour le batch aller editique centrale
	 * @return
	 */
	List<EditionRecording> getRecordingEditionTreated(boolean istreated);

	/**
	 *
	 * @return
	 */
	String getXmlFileSmcFromEditique();

	/**
	 * change l'état des fichiers non traité à traité
	 *
	 * @param numSequence
	 */
	void isTreated(int numSequence);

	/**
	 * enregistre les documents provenant de l'editique centrale
	 * @param document
	 */
	void saveDocumentReturnCentral(DocumentRetour document);

	/**
	 * enregistre les informations du header et du footer du document retour Editique centrale
	 */
	void saveInfoFileReturnCentral(InfoFileArchivage infoFile) ;

}
