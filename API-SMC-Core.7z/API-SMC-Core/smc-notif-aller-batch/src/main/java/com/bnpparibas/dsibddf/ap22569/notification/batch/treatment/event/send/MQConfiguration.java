package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.event.send;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;


@Component
public class MQConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(MQConfiguration.class);

    @Autowired
    private JmsTemplate jmsTemplate;

    @Value("${ibm.mq.queue}")
    private String queueName;

    public void sendNotificationEvent(String event) {

        try {
            LOG.info("sending event "+event+" to queue "+queueName);

            this.jmsTemplate.convertAndSend(queueName, event);
        } catch(JmsException ex) {
            ex.printStackTrace();
        }
    }

}
