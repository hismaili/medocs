/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load;

import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.stereotype.Component;


/**
 * @author c65344
 *
 */
@Component
public class NotificationItemReader extends FlatFileItemReader<NotificationLine> {

	private static final Logger LOG = LoggerFactory.getLogger(NotificationItemReader.class);

	private transient LineMapper<NotificationLine> lineMapper;

	public NotificationItemReader(LineMapper<NotificationLine> lineMapper) {
		super();

		setLineMapper(lineMapper);
		this.lineMapper = lineMapper;
	}

	public LineMapper<NotificationLine> getLineMapper() {
		return lineMapper;
	}

}
