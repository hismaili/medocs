package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

import java.util.List;

//@Service
public interface IOperationService {

	/**
	 * supprime une opération
	 * @param idTelematic
	 * @param userId
	 */
	void deleteOperationsTmp(String idTelematic,String userId);

	/**
	 * recupère des opérations à partir des paramètres
	 *
	 * @param pan
	 * @param idTelematic
	 * @param userId
	 * @return
	 * @throws OperationException
	 */
	List<Operation> getCardOperations(String pan,String idTelematic,String userId) throws OperationException;

	/**
	 * recupère le dernier numéro de sequence top HMP
	 *
	 * @return
	 */
	int getLastNumSeqTopHmp();

	/**
	 * recupère une opération à partir des paramètres
	 *
	 * @param codeOpe
	 * @param idTelematic
	 * @param userId
	 * @return
	 * @throws OperationException
	 */
	Operation getOperationByCodeOpe(String codeOpe, String idTelematic,String userId) throws OperationException;

	/**
	 * recupère une opération top HMP
	 *
	 * @return
	 */
	OperationTop getOperationTopHmp();


	/**
	 *recupère les opération top HMP
	 *
	 * @return
	 */
	List<OperationTop> getOperationTopHmps(boolean isTop);

	/**
	 * change l'état des opérations de tosend  à send
	 *
	 * @param numSequence
	 */
	void isTreated(int numSequence);
}
