package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.CarteVO;

import java.util.List;

public class CartesPorteurResponse {

    private List<CarteVO> cartes;

    public List<CarteVO> getCartes() {
        return cartes;
    }

    public void setCartes(List<CarteVO> cartes) {
        this.cartes = cartes;
    }
}
