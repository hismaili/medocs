package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTraceException;
/**
 *
 *
 *
 */
public interface ITraceManagement {

	/**
	 * Tracer les appels des services web de l'application
	 *
	 * @param traceDTO : elements à tracer
	 * @throws SmcTraceException : levée si une erreur a lieu
	 */
	void trace(TraceDTO traceDTO) throws SmcTraceException;
}
