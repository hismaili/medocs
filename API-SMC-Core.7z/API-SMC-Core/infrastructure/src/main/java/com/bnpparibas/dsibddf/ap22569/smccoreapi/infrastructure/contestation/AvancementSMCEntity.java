package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "AVANCEMENT_SMC")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class AvancementSMCEntity extends AbstractEntity<DefaultEntityId> {

	@Column(length = 2)
	private String code;

	@Column(length = 100)
	private String libelle;

    public AvancementSMCEntity() {
	}

	/**
	 * @param code
	 * @param libelle
	 */
	public AvancementSMCEntity(String code, String libelle) {
		this.code = code;
		this.libelle = libelle;
	}

    public String getCode() {
		return code;
	}

    public String getLibelle() {
		return libelle;
	}

    public void setCode(String code) {
		this.code = code;
	}

    public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
}
