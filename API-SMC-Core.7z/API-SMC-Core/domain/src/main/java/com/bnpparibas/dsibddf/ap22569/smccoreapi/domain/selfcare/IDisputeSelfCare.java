package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import org.springframework.stereotype.Service;

/**
 *
 * @author c65344
 *
 */
@Service
public interface IDisputeSelfCare {

	/**
	 * Permet de rattacher des fichiers à un dossier de contestation à partir du numéro de dossier
	 * et des identifiants GED.
	 *
	 * @param attach
	 * @return
	 */
	DisputeResponse attachedDocuments(AttachmentDataInput attach) throws MandatoryException;


	/**
	 *
	 * Permet de récupérer le statut d'avancement à partir du numéro de dossier de contestation.
	 *
	 * @param folderNumber
	 * @return
	 */
	DisputeResponse getStatusDispute(String folderNumber) throws MandatoryException;


	/**
	 * Créer un dossier SelfCare
	 *
	 * @param dispute
	 * @return
	 */
	DisputeResponse sendDisputeToSmc(Contestation dispute) throws MandatoryException;

}
