package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public class AndSpecification extends AbstractInputFieldSpecification {

    public boolean isSatisfiedBy() {
        return isSatisfiedBy();
    }

    public boolean isSatisfiedBy(final Object candidate) {
        boolean result = true;

        for (IInputValidationSpecification specification : super.getSpecifications()) {
            result &= specification.isSatisfiedBy(candidate);
        }
        return result;
    }

    public AndSpecification(IInputValidationSpecification... specifications) {
        super(specifications);
    }
}
