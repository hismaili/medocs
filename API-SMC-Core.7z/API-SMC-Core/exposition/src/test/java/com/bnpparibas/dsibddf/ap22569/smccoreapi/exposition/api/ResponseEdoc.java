/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

/**
 * @author c65344
 *
 */
public class ResponseEdoc {
	private String idAttachment;
	private String idGDN;

	/**
	 * @return the idAttachment
	 */
	public String getIdAttachment() {
		return idAttachment;
	}

	/**
	 * @return the idGDN
	 */
	public String getIdGDN() {
		return idGDN;
	}
	/**
	 * @param idAttachment the idAttachment to set
	 */
	public void setIdAttachment(String idAttachment) {
		this.idAttachment = idAttachment;
	}

	/**
	 * @param idGDN the idGDN to set
	 */
	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}
}
