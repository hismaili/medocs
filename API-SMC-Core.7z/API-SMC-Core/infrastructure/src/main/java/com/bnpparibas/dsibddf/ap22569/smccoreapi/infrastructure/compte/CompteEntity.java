package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "COMPTE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class CompteEntity extends AbstractEntity<DefaultEntityId> {

    @Column(length = 30)
    private String rib;

    @Column(length = 50)
    private String typeCompte;

    @Column(length = 100)
    private String titulaireCompte;

    @Column(length = 100)
    private String alias;

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public String getTypeCompte() {
        return typeCompte;
    }

    public void setTypeCompte(String typeCompte) {
        this.typeCompte = typeCompte;
    }

    public String getTitulaireCompte() {
        return titulaireCompte;
    }

    public void setTitulaireCompte(String titulaireCompte) {
        this.titulaireCompte = titulaireCompte;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}
