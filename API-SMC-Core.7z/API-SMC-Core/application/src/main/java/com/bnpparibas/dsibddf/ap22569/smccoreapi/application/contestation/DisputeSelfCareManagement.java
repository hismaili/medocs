package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.commons.MapperEditionSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.AttachmentDataInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.IDisputeSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;

@Component
public class DisputeSelfCareManagement implements IDisputeSelfCareManagement {

	private static final Logger LOG = LoggerFactory.getLogger(DisputeSelfCareManagement.class);

	@Autowired
	private transient IDisputeSelfCare disputeSelf;

	@Autowired
	private transient MapperEditionSelfCare map;

	@Autowired
	private transient ContestationManagement contestationManagement;

	@Override
	public DisputeResponse attachedDocuments(AttachmentDataInput attach)
			throws MandatoryException {
		return disputeSelf.attachedDocuments(attach);
	}

	@Transactional(transactionManager="transactionManager")
	@Override
	public void generateAndSaveRecap(Contestation dispute) throws ContestationException, ContestationValidationException {


		RequestEditiqueInput requestEditique = map.generateRequestEditique(dispute);

		contestationManagement.saveRecapitulatif(dispute, requestEditique);

	}


	@Override
	public DisputeResponse sendDisputeToSmc(Contestation dispute) throws MandatoryException{

		return disputeSelf.sendDisputeToSmc(dispute);
	}



}
