/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.OperationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.StatusTopOperation;

/**
 * @author c65344
 *
 */
@Component
public interface OperationTopJpaRepository extends JpaRepository<OperationEntity, String> {

	/**
	 * recupère des opérations à partie du status
	 * @param status
	 * @return
	 */
	List<OperationEntity> findByStatusTop(StatusTopOperation statusTop);


	@Query("SELECT max(f.numSequence) FROM OperationEntity f")
	Integer getMaxNumSequenceOperation();
}
