

--Jutificatifs par motif
--- Vol
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('DWg4zGG/RLO1S982Ux7mKQ','M002');
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('DWg4zGG/RLO1S982Ux7mKQ','M003');
--- Litige commercial
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('q0Umf+vVSDiJVCR1ra5uAg','M008');
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code)VALUES('0QdGs72/RWeKln/F+tK1JA','M008');
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('T/jAumuaTnKrhZdmmGds2g','M008');
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('eax0DCEGRdmkhceeLdCyhg','M008');
---montant erroné
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('rFCx9O/LTTaECHv7TPZWRA','M011');
--INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('0A/UtsFGRreBKmTBQPX0xQ','M011');



--insertion des cartes

insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('31/03/2019','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT001','VOL DE CARTE','PIERRE','4974028305717800','VISA','CA001');

insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2020','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT002','VOL DE CARTE','CHARLES','4974108217705420','VISA','CA002');


insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2021','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT003','VOL DE CARTE','CARL','4974028130208163','MASTER CARD','CA003');



---1 JDD avec 1 contestation historisée sur plusieurs opérations
insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CA002',1,'SC001','Contestation de vole de carte','01260016662400000','3610838481','bnp1@pbpparispas.com', 13.0, 13.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974108217705420','NUMDOSSIER090',0,'0612525744', 'C00040');


insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE1',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'C00040','OP0004');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE2',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'C00040','OP0005');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE3',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'C00040','OP006');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'C00040','OP007');




----1 JDD avec 1 contestation historisée avec plusieurs documents joints
insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CA003',1,'SC001','Contestation de vole de carte','01700021073900000','3865814351','bnp1@pbpparispas.com', 73.0, 13.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028130208163','NUMDOSSIER080',0,'0612525744', 'C00041');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',73.0, 13.0,'HENRY','DEBIT',0,'C00041','OP041');



insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001mu','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC006');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m5','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC007');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m9','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC008');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m7','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC009');
 
 

----historique des contestations avec tout les cas de status
insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CA001',1,'SC001','Contestation de vole de carte','01630005685900000','2289627126','bnp1@pbpparispas.com', 77.0, 50.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028305717800','NUMDOSSIER043',0,'0612525744', 'C0043');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',77.0, 50.0,'HENRY','DEBIT',1,'C0043','OP043');



insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('05/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('11/05/2019','dd/mm/yyyy'),'CA001',1,'SC002','Contestation de vole de carte','01630005685900000','2289627126','bnp1@pbpparispas.com', 80.0, 23.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'0004974074205032328','NUMDOSSIER044',0,'0612525744', 'C0044');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque', 80.0, 23.0 ,'HENRY','DEBIT',1,'C0044','OP044');



insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('06/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('12/05/2019','dd/mm/yyyy'),'CA001',1,'SC003','Contestation de vole de carte','01630005685900000','2289627126','bnp1@pbpparispas.com', 20.0, 12.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028305717800','NUMDOSSIER045',0,'0612525744', 'C0045');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',20.0, 12.0 ,'HENRY','DEBIT',1,'C0045','OP045');


insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('02/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('13/05/2019','dd/mm/yyyy'),'CA001',1,'SC004','Contestation de vole de carte','01630005685900000','2289627126','bnp1@pbpparispas.com', 18.0, 13.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028305717800','NUMDOSSIER046',0,'0612525744', 'C0046');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',18.0, 13.0,'HENRY','DEBIT',1,'C0046','OP046');



insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('02/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('14/05/2019','dd/mm/yyyy'),'CA001',1,'SC005','Contestation de vole de carte','01630005685900000','2289627126','bnp1@pbpparispas.com', 73.0, 22.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028305717800','NUMDOSSIER047',0,'0612525744', 'C0047');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque', 73.0, 22.0,'HENRY','DEBIT',1,'C0047','OP047');


--1 JDD avec 1 contestation historisée sur 1 opération
INSERT INTO CARTE(ID, DATE_CREATION, DATE_MAJ, DATE_EXPIR, DATE_OPPO, MOTIF_OPPO, NOM_ESTAMPE, PAN, TYPE_CARTE, ETAT_CARTE) VALUES
('CAT001',TO_TIMESTAMP('15/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('15/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2020','dd/mm/yyyy'),null, null,'PIERRE lefevre','4974013792774124','VISA CLASSIC','ETAT002');

INSERT INTO contestation(date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id)
VALUES(TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),'CAT001',1,'SC001','Contestation de vole de carte','01630005685900000','2289627126','l.pierre@wooow.com', 100.00, 20.00 , null ,'M001',null,1, 1, 0, 0,'4974013792774124','S456210545007',0,'0612525744', 'CT0013');

INSERT INTO operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id)
VALUES (TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),'op5632',TO_TIMESTAMP('25/09/2018','dd/mm/yyyy'),TO_TIMESTAMP('25/05/2019','dd/mm/yyyy'),'EUR','Retrait en banque',100.0, 20.0,'GRAND Hotel','DEBIT',2,'CT0013','OP019');
