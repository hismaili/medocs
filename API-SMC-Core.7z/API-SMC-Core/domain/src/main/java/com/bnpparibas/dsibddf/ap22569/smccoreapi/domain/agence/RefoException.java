/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcBusinessException;

/**
 * @author c65344
 *
 */
public class RefoException extends SmcBusinessException{
	/**
	 *
	 */
	private static final long serialVersionUID = -7374499614350091001L;

	/**
	 *
	 */
	public RefoException() {
		super();

	}

	/**
	 * @param message
	 */
	public RefoException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public RefoException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param cause
	 */
	public RefoException(Throwable cause) {
		super(cause);

	}


}
