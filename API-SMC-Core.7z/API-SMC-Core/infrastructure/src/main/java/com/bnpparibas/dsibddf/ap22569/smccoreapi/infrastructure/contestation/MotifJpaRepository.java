package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface MotifJpaRepository extends JpaRepository<MotifEntity, String> {

    @Query("FROM MotifEntity m where m.typeOperationApplicable='LESDEUX' OR m.typeOperationApplicable=?1")
    Optional<List<MotifEntity>> findByTypeOperationApplicable(TypeOperationEntity typeOperationApplicable);

    @Query("FROM MotifEntity m where (m.typeOperationApplicable='LESDEUX' OR m.typeOperationApplicable=?1) AND m.appliedToCardLostOnly=?2")
    Optional<List<MotifEntity>> findByTypeOperationApplicableAndAppliedToCardLostOnly(TypeOperationEntity typeOperationApplicable, Boolean cardLost);


}
