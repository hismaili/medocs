package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.event.send;

import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEvent;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationEventVariable;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.ResponseRefo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Component
public class NotificationEventBuilder {


    private  static final String STRING_EMPTY = "";
    private  static final String RECEIVER_ID_TYPE_ID_PERSONNE = "ID-PERSONNE";
    private  static final String ADDRESS_TYPE_MAIL = "MAIL";
    private  static final String ADDRESS_TYPE_SMS = "TEL";
    private  static final String CHANNELS_LIST_MAIL = "MAIL";
    private  static final String CHANNELS_LIST_SMS = "SMS";
    private  static final String CHANNELS_LIST_MAIL_SMS = "MAIL,SMS";
    private  static final String CHANNELS_LIST_SECURE = "MSU";
    private  static final String RECEIVER_PREFERENCES_NO = "N";
    private  static final String RECEIVER_NATURE_PARTHB = "PARTHB";
    private  static final String RECEIVER_NATURE_PARTBNP = "PARTBNP";
    private  static final String DATE_PATTERN = "yyyy-MM-dd";
    private  static final String HB_ESTABLISHMENT_CODE = "HELLO BANK!";
    private  static final String BNPP_ESTABLISHMENT_CODE = "BNP PARIBAS";
    private  static final String VARIABLE_NAME = "etablissement";
    private  static final String VARIABLE_NUMERO_DOSSIER = "numero_dossier";
    private  static final String VARIABLE_DATE_APPEL = "date_appel";
    private  static final String VARIABLE_DATE_CREATION_DOSSIER = "date_creation_dossier";
    private  static final String MAIL_AROBAS = "@";
    private  static final String STR_ZERO = "0";

    //TODO configInfrastructure error when loading
    //@Autowired
    //private IRefo agencyService;

    private static final Map<String, String> simpleMessageReference = new HashMap<>();
    private static final Map<String, String> secureMessageReference = new HashMap<>();
    public static final String DIFFUSION_TIME = "10.00.00.000000";
    public static final String NO_MULTI_CHANNEL = "N";

    static {
        simpleMessageReference.put("10", "AP225690000001");
        simpleMessageReference.put("20", "AP225690000002");
        simpleMessageReference.put("30", "AP225690000003");
        simpleMessageReference.put("40", "AP225690000004");
        simpleMessageReference.put("50", "AP225690000005");
        simpleMessageReference.put("60", "AP225690000003");
        simpleMessageReference.put("70", "AP225690000003");

        secureMessageReference.put("10", "AP225690000006");
        secureMessageReference.put("20", "AP225690000007");
        secureMessageReference.put("30", "AP225690000008");
        secureMessageReference.put("40", "AP225690000009");
        secureMessageReference.put("50", "AP225690000010");
        secureMessageReference.put("60", "AP225690000008");
        secureMessageReference.put("70", "AP225690000008");

    }


    public NotificationEvent buildSimpleMessage(Notification notif) {
        final NotificationEvent notifEvent = buildCommonNotificationEvent(notif);
        if("1".equals(notif.getNotifMail()) && isValidMail(notif.getMailClient())) {
            notifEvent.setReceiverAddress(notif.getMailClient());
            notifEvent.setReceiverAddressType(ADDRESS_TYPE_MAIL);
            notifEvent.setChannelsList(CHANNELS_LIST_MAIL);
        }  else if("1".equals(notif.getNotifSms()) && isValidPhoneNumber(notif.getNumTel())) {
            notifEvent.setReceiverAddress(notif.getNumTel());
            notifEvent.setReceiverAddressType(ADDRESS_TYPE_SMS);
            notifEvent.setChannelsList(CHANNELS_LIST_SMS);
        } else {
            notifEvent.setChannelsList(CHANNELS_LIST_MAIL_SMS);
        }

        notifEvent.setMsgReference(getMsgReference(notif.getCodeNotif(), false));

        return notifEvent;
    }

    public NotificationEvent buildSecureMessage(Notification notif) {
        final NotificationEvent notifEvent = buildCommonNotificationEvent(notif);

        notifEvent.setReceiverAddress(STRING_EMPTY);
        notifEvent.setReceiverAddressType(STRING_EMPTY);
        notifEvent.setChannelsList(STRING_EMPTY);

        notifEvent.setReceiverId(notif.getNumClient());
        notifEvent.setReceiverIdType(RECEIVER_ID_TYPE_ID_PERSONNE);

        notifEvent.setMsgReference(getMsgReference(notif.getCodeNotif(), true));

        notifEvent.setChannelsList(CHANNELS_LIST_SECURE);
        return notifEvent;
    }

    private NotificationEvent buildCommonNotificationEvent(Notification notif) {
        NotificationEvent notifEvent = new NotificationEvent();
        notifEvent.setNotificationInternalId(notif.getNotificationInternalId());
        notifEvent.setEventId(UUID.randomUUID().toString());


        if(StringUtils.isEmpty(notifEvent.getReceiverAddress())) {
            notifEvent.setReceiverId(notif.getNumClient());
            notifEvent.setReceiverIdType(RECEIVER_ID_TYPE_ID_PERSONNE);
        }

        ResponseRefo agencyResponse = null;
       // try {
//            agencyResponse = agencyService.getTypeBank(notif.getCodeAgence());
            agencyResponse = new ResponseRefo();
            agencyResponse.setHelloBank(true);
            if(agencyResponse.isHelloBank()) {
                notifEvent.setReceiverNature(RECEIVER_NATURE_PARTHB);
            } else {
                notifEvent.setReceiverNature(RECEIVER_NATURE_PARTBNP);
            }
        //} catch (RefoException e) {
            //TODO throw exception
          //  e.printStackTrace();
        //}

        notifEvent.setApplicationId("AP22569");
        notifEvent.setCustomerJourneyId(STRING_EMPTY);
        notifEvent.setApplicationUseCase(STRING_EMPTY);

        notifEvent.setStartDiffusionDate(LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_PATTERN))+ " " + DIFFUSION_TIME);
        notifEvent.setReceiverPreferences(RECEIVER_PREFERENCES_NO);
        notifEvent.setMultiChannel(NO_MULTI_CHANNEL);

        notifEvent.setVariablesList(getVariableList(notif, agencyResponse.isHelloBank()));

        return notifEvent;
    }

    private List<NotificationEventVariable> getVariableList(Notification notif, boolean isHelloBank) {

        String etablissement = isHelloBank? HB_ESTABLISHMENT_CODE : BNPP_ESTABLISHMENT_CODE;

        // les codes 20, 30, 60 et 70 ne contiennent que ces 2 variables
        List<NotificationEventVariable> variablesList = new ArrayList<>();
        variablesList.add(new NotificationEventVariable(VARIABLE_NAME, etablissement));
        variablesList.add(new NotificationEventVariable(VARIABLE_NUMERO_DOSSIER, notif.getDossierSmc()));
        String notificationCode = notif.getCodeNotif();
        if("10".equals(notificationCode)) {
            variablesList.add(new NotificationEventVariable(VARIABLE_DATE_APPEL, notif.getDateAppel()));
        } else if(Arrays.asList("40", "50").contains(notificationCode)) {
            variablesList.add(new NotificationEventVariable(VARIABLE_DATE_CREATION_DOSSIER, notif.getDateCreationDossier()));
        }
        return variablesList;
    }

    private String getMsgReference(String codeNotif, boolean secureMsg) {
        if(secureMsg) {
            return secureMessageReference.get(codeNotif);
        } else {
            return simpleMessageReference.get(codeNotif);
        }
    }

    private boolean isValidPhoneNumber(String numTel) {
        int occurencesOfZero = StringUtils.countOccurrencesOf(numTel, STR_ZERO);
        return !StringUtils.isEmpty(numTel) && occurencesOfZero != numTel.length();
    }

    private boolean isValidMail(String mailClient) {
        return !StringUtils.isEmpty(mailClient) && mailClient.contains(MAIL_AROBAS);
    }
}
