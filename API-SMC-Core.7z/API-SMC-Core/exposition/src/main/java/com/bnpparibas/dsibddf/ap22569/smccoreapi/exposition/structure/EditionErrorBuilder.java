/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edition.EditionManagementImpl;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.SmcEditionException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author c65344
 *
 */
@Component
public class EditionErrorBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(EditionErrorBuilder.class);
	private static final String FICHEDELIAISON = "trby9lia";
	private static final String FORMRETRAIT = "trby9ret";
	private static final String FORMPAYEMENT = "trby9pai";
	private static final String CLOTURE = "trby9clo";
	private static final String GENERIQUE = "trby9gen";
	private static final String CONTESTATAION = "trby9con";

	private static final String ERRORBODY = "Le corps de la requette est absente ou incorrect";

	private static final String MAQUETTEIDABSENT ="La données MaquetteId est obligatoire";
	private static final String ERROROPERATION = "L'une des valeurs suivante (dateCompensation,raisonSociale,dateVente,MontantImpute) d'une ou de plusieurs opérations est manquante";


	@Autowired
	private transient EditionManagementImpl editionManagement;
	@Autowired
	private transient EditionMaper editionMapper;
	@Autowired
	private transient ControlBuilder helper;
	@Autowired
	private transient ConfigExposition conf;


	public void checkError(GeneratePDFRequest infoDocument,String canal) throws SmcEditionException{

		List<String> missingDatasUI = new ArrayList<String>();
		List<String> missingDatasNoUI = new ArrayList<String>();
		SmcEditionException smcEditionException = new SmcEditionException();

		GeneratePDFRequestMaquetteDef maquette = infoDocument.getMaquette();

		if(StringUtils.isEmpty(canal)){
			missingDatasNoUI.add(conf.getCanalAbsent());
		}

		if(infoDocument !=null && maquette !=null){

			PDFRequestMaquetteIdentification maquetteIdentification = maquette.getMaquetteIdentification();



			if(maquetteIdentification !=null){

				PDFRequestDonneesMaquette donneesMaquette = maquette.getDonneesMaquette();

				if(donneesMaquette !=null){

					if(StringUtils.isEmpty(donneesMaquette.getDateTraitement())){
						missingDatasNoUI.add(conf.getDateTraitementAbsent());
					}


					if (StringUtils.isEmpty(donneesMaquette.getAdrRetour())) {
						missingDatasNoUI.add(conf.getAdresseEmeteurManquant());//TODO a confirmer
					}


					//					if (StringUtils.isEmpty(donneesMaquette.getTelephoneEmet())) {
					//						missingDatasUI.add(conf.getTelEmeteurManquant());
					//					}

					if (StringUtils.isEmpty(donneesMaquette.getNumeroCarte())) {
						missingDatasUI.add(conf.getNumCarteManquante());
					}

					String maquetteID = maquetteIdentification.getMaquette();

					if(StringUtils.isEmpty(maquetteID)){
						missingDatasNoUI.add(MAQUETTEIDABSENT);
					}

					if(CONTESTATAION.equals(maquetteID)){

						if (StringUtils.isEmpty(donneesMaquette.getNumCarteMasque())) {
							missingDatasNoUI.add(conf.getNumcartemasqueManquante());
						}

						Arrays.asList(helper.addError(donneesMaquette.getQualificationDossier() , conf.getQualificationDossierAbsent()),
								helper.addError(donneesMaquette.getDateOpposition(), conf.getDateOppositionabsent()),
								helper.addError(donneesMaquette.getNatureDossier(), conf.getNatureDossierAbsent()),
								helper.addError(donneesMaquette.getDateAppel(), conf.getDateAppelAbsent()))
								.stream().filter(value -> !StringUtils.isEmpty(value))
								.forEach(error -> missingDatasUI.add(error));


						List<DetailOperation> detailsOperations = donneesMaquette.getDetailsOperations();
						//						if(!CollectionUtils.isEmpty(detailsOperations)){
						//
						//							List<String> errors = detailsOperations.stream().filter(oper -> StringUtils.isEmpty(oper.getDateCompensation()) || StringUtils.isEmpty(oper.getDateVente())
						//									|| StringUtils.isEmpty(oper.getMontantImpute()) || oper.getMontantImpute() == null ).map(oper -> {
						//										return "error";
						//									}).collect(Collectors.toList());
						//
						//							if(!CollectionUtils.isEmpty(errors)){
						//
						//								missingDatasUI.add(ERROROPERATION);
						//							}
						//
						//						}

					}else if(GENERIQUE.equals(maquetteID)){

						if (StringUtils.isEmpty(donneesMaquette.getNumCarteMasque())) {
							missingDatasNoUI.add(conf.getNumcartemasqueManquante());
						}
						if(StringUtils.isEmpty(donneesMaquette.getNatureDossierLibelle())){
							missingDatasNoUI.add(conf.getNatureDossierLibelleAbsent());
						}

						if(StringUtils.isEmpty(donneesMaquette.getNumDossier())){
							missingDatasUI.add(conf.getNumdossierManquante());
						}


						if(CollectionUtils.isEmpty(donneesMaquette.getChampsLibres())){
							missingDatasUI.add(conf.getTabHeaderAbsent());
						}

					}else if(CLOTURE.equals(maquetteID)){
						if(StringUtils.isEmpty(donneesMaquette.getNatureDossierLibelle())){
							missingDatasNoUI.add(conf.getNatureDossierLibelleAbsent());
						}
						if(StringUtils.isEmpty(donneesMaquette.getNumDossier())){
							missingDatasUI.add(conf.getNumdossierManquante());
						}

						if(StringUtils.isEmpty(donneesMaquette.getDateCreationSmc())){
							missingDatasUI.add(conf.getDateCreationAbsent());
						}

						if(StringUtils.isEmpty(donneesMaquette.getMontantConteste())){
							missingDatasUI.add(conf.getMontantContesteAbsent());
						}

						if(StringUtils.isEmpty(donneesMaquette.getNombreOperations())){
							missingDatasUI.add(conf.getNombreOperationsAbsent());
						}

					}else if(FORMPAYEMENT.equals(maquetteID)){

						if(StringUtils.isEmpty(donneesMaquette.getNumCarteMasque())){
							missingDatasNoUI.add(conf.getNumcartemasqueManquante());
						}

						Arrays.asList(helper.addError(donneesMaquette.getCodeChefdefileemet(), conf.getCodeChefdefileemetAbsent()),
								helper.addError(donneesMaquette.getContactEmet(), conf.getContactEmetAbsent()),
								helper.addError(donneesMaquette.getFaxEmet(), conf.getFaxEmetAbsent()),
								helper.addError(donneesMaquette.getEmailEmet(), conf.getEmailEmetAbsent()),
								helper.addError(donneesMaquette.getCodeChefdefiledest(), conf.getCodeChefdefiledestAbsent()),
								helper.addError(donneesMaquette.getContactDest(), conf.getContactDestAbsent()),
								helper.addError(donneesMaquette.getTelephoneDest(), conf.getTelephoneDestAbsent()),
								helper.addError(donneesMaquette.getFaxDest(), conf.getFaxDestAbsent()),
								helper.addError(donneesMaquette.getEmailDest(), conf.getEmailDestAbsent()),
								helper.addError(donneesMaquette.getTypeOperation(), conf.getTypeOperationAbsent()),
								helper.addError(donneesMaquette.getCodebanqueMempracc(), conf.getCodebanqueMempraccAbsent()),
								helper.addError(donneesMaquette.getCodebanqueDom(), conf.getCodebanqueDomAbsent()),
								helper.addError(donneesMaquette.getNumSiret(), conf.getNumSiretAbsent()),
								helper.addError(donneesMaquette.getLocDepart(), conf.getLocDepartAbsent()),

								helper.addError(donneesMaquette.getCodeApe(), conf.getCodeApeAbsent()),
								helper.addError(donneesMaquette.getCodebanqueMemprtit(), conf.getCodebanqueMemprtitAbsent()),
								helper.addError(donneesMaquette.getCodeMotifipaye(), conf.getCodeMotifipayeAbsent()),
								helper.addError(donneesMaquette.getMontantBrut(), conf.getMontantBrutAbsent()),
								helper.addError(donneesMaquette.getMontantCompense(), conf.getMontantCompenseAbsent()),
								helper.addError(donneesMaquette.getDateheureTransaction(), conf.getDateheureTransactionAbsent()),
								helper.addError(donneesMaquette.getDateReglmntinitial(), conf.getDateReglmntinitialAbsent()),
								helper.addError(donneesMaquette.getDateRglmntimpaye(), conf.getDateRglmntimpayeAbsent()),
								helper.addError(donneesMaquette.getReferenceArchivage(), conf.getReferenceArchivageAbsent()),
								helper.addError(donneesMaquette.getAutresDonnees(), conf.getAutresDonneesAbsent()),
								helper.addError(donneesMaquette.getTypeReglmntsouhaite(), conf.getTypeReglmntsouhaiteAbsent()))
								.stream().filter(value -> value != null)
								.forEach(error -> missingDatasUI.add(error));


					}else if(FORMRETRAIT.equals(maquetteID)){

						if(StringUtils.isEmpty(donneesMaquette.getNumCarteMasque())){
							missingDatasNoUI.add(conf.getNumcartemasqueManquante());
						}

						Arrays.asList(helper.addError(donneesMaquette.getCodeChefdefileemet(), conf.getCodeChefdefileemetAbsent()),
								helper.addError(donneesMaquette.getContactEmet(), conf.getContactEmetAbsent()),
								helper.addError(donneesMaquette.getFaxEmet(), conf.getFaxEmetAbsent()),

								helper.addError(donneesMaquette.getEmailEmet(), conf.getEmailEmetAbsent()),

								helper.addError(donneesMaquette.getCodeChefdefiledest(), conf.getCodeChefdefiledestAbsent()),

								helper.addError(donneesMaquette.getContactDest(), conf.getContactDestAbsent()),

								helper.addError(donneesMaquette.getTelephoneDest(), conf.getTelephoneDestAbsent()),

								helper.addError(donneesMaquette.getFaxDest(), conf.getFaxDestAbsent()),

								helper.addError(donneesMaquette.getEmailDest(), conf.getEmailDestAbsent()),

								helper.addError(donneesMaquette.getTypeOperation(), conf.getTypeOperationAbsent()),

								helper.addError(donneesMaquette.getCodebanqueMempracc(), conf.getCodebanqueMempraccAbsent()),

								helper.addError(donneesMaquette.getCodebanqueDom(), conf.getCodebanqueDomAbsent()),

								helper.addError(donneesMaquette.getNumDistributeur(), conf.getNumDistributeurAbsent()),
								helper.addError(donneesMaquette.getLocDepart(), conf.getLocDepartAbsent()),
								helper.addError(donneesMaquette.getCodebanqueMemprtit(), conf.getCodebanqueMemprtitAbsent()),
								helper.addError(donneesMaquette.getCodeMotifipaye(), conf.getCodeMotifipayeAbsent()),
								helper.addError(donneesMaquette.getMontantCompense(), conf.getMontantCompenseAbsent()),
								helper.addError(donneesMaquette.getDateheureTransaction(), conf.getDateheureTransactionAbsent()),
								helper.addError(donneesMaquette.getDateReglmntinitial(), conf.getDateReglmntinitialAbsent()),
								helper.addError(donneesMaquette.getAutresDonnees(), conf.getAutresDonneesAbsent()),
								helper.addError(donneesMaquette.getTypeReglmntsouhaite(), conf.getTypeReglmntsouhaiteAbsent()))
								.stream().filter(value -> value != null)
								.forEach(error -> missingDatasUI.add(error));

					}else if(FICHEDELIAISON.equals(maquetteID)){
						Arrays.asList(helper.addError(donneesMaquette.getContactEmet(), conf.getContactEmetAbsent()),
								helper.addError(donneesMaquette.getIdUser(), conf.getIdUserAbsent()),
								helper.addError(donneesMaquette.getNumDossier(), conf.getNumdossierManquante()),
								helper.addError(donneesMaquette.getNumClient() , conf.getNumClientAbsent()))
								.stream().filter(value -> value != null)
								.forEach(error -> missingDatasUI.add(error));

					}

					/**
					 * verification des données incorrect
					 */
					List<String> dataPDFIncorrect = helper.validateDataPDFIncorrect(donneesMaquette, canal,maquetteID);


					/**
					 * verification des erreurs format
					 */
					List<String> errorFormat = new ArrayList<>();

					Arrays.asList(helper.checkFormatCarte(donneesMaquette.getNumeroCarte()),
							helper.checkFormatDate(donneesMaquette.getDateTraitement(),"dateTraitement"),
							helper.checkFormatDate(donneesMaquette.getDateAppel(),"dateAppel"),
							helper.checkFormatDate(donneesMaquette.getDateCreationSmc(),"dtRefArchiv"),
							helper.checkFormatDate(donneesMaquette.getDateOpposition(),"dateMiseOpposition"),
							helper.checkFormatDate(donneesMaquette.getDateReglmntinitial(),"datRgltInitial"),
							helper.checkFormatDate(donneesMaquette.getDateRglmntimpaye(),"datRglmntImpay"),
							helper.checkFormatDate(donneesMaquette.getDateRglmntrepres(),"datRglmntRepres"))
							.stream().filter(obj -> !StringUtils.isEmpty(obj))
							.forEach(obj -> errorFormat.add(obj));



					if(!CollectionUtils.isEmpty(missingDatasUI) && !CollectionUtils.isEmpty(missingDatasNoUI)){
						smcEditionException.setDonnesAbsentUI(missingDatasUI);
						smcEditionException.setDonnesAbsentNoUI(missingDatasNoUI);
						throw smcEditionException;
					}else if(!CollectionUtils.isEmpty(missingDatasUI)){
						smcEditionException.setDonnesAbsentUI(missingDatasUI);
						throw smcEditionException;
					}else if(!CollectionUtils.isEmpty(missingDatasNoUI)){
						smcEditionException.setDonnesAbsentNoUI(missingDatasNoUI);
						throw smcEditionException;
					}


					if(!CollectionUtils.isEmpty(errorFormat) && !CollectionUtils.isEmpty(dataPDFIncorrect)){
						smcEditionException.setFormatIncorrect(errorFormat);
						smcEditionException.setDonnesIncorrect(dataPDFIncorrect);
						throw smcEditionException;
					}else if(!CollectionUtils.isEmpty(errorFormat)){
						smcEditionException.setDonnesIncorrect(errorFormat);
						throw smcEditionException;
					}else if(!CollectionUtils.isEmpty(dataPDFIncorrect)){
						smcEditionException.setDonnesIncorrect(dataPDFIncorrect);
						throw smcEditionException;
					}

				}else{


					missingDatasNoUI.add(conf.getDateTraitementAbsent());

					missingDatasNoUI.add(conf.getCanalAbsent());
					missingDatasNoUI.add(conf.getAdresseEmeteurManquant());//TODO a confirmer

					missingDatasUI.add(conf.getTelEmeteurManquant());

					smcEditionException.setDonnesAbsentUI(missingDatasUI);
					smcEditionException.setDonnesAbsentNoUI(missingDatasNoUI);
					throw smcEditionException;

				}

			}else{
				smcEditionException.setDonnesAbsentUI(Arrays.asList(MAQUETTEIDABSENT));
				throw smcEditionException;
			}

		}else{
			missingDatasNoUI.add(conf.getDateTraitementAbsent());

			missingDatasNoUI.add(conf.getCanalAbsent());
			missingDatasNoUI.add(conf.getAdresseEmeteurManquant());

			missingDatasUI.add(conf.getTelEmeteurManquant());

			smcEditionException.setDonnesAbsentUI(missingDatasUI);
			smcEditionException.setDonnesAbsentNoUI(missingDatasNoUI);
			throw smcEditionException;
		}
	}




}
