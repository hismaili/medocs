package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="NATURE_CONTESTATION")
public class NatureEntity {

    @Id
    @Column(name = "nature_code", length = 25)
    private String natureCode;

    @Column(name = "nature_libelle")
    private String natureLibelle;

    @Column(name = "nature_code_smc",length=20)
    private String natureCodeSmc;

    @Column(name="date_debut_effet")
    private LocalDateTime dateDebutEffet;
    @Column(name="date_fin_effet")
    private LocalDateTime dateFinEffet;

    @ManyToOne
    @JoinColumn(name = "qualification")
    private QualificationEntity qualification;


    public String getNatureCode() {
        return natureCode;
    }

    public void setNatureCode(String natureCode) {
        this.natureCode = natureCode;
    }

    public String getNatureLibelle() {
        return natureLibelle;
    }

    public void setNatureLibelle(String natureLibelle) {
        this.natureLibelle = natureLibelle;
    }

    public String getNatureCodeSmc() {
        return natureCodeSmc;
    }

    public void setNatureCodeSmc(String natureCodeSmc) {
        this.natureCodeSmc = natureCodeSmc;
    }

    public LocalDateTime getDateDebutEffet() {
        return dateDebutEffet;
    }

    public void setDateDebutEffet(LocalDateTime dateDebutEffet) {
        this.dateDebutEffet = dateDebutEffet;
    }

    public LocalDateTime getDateFinEffet() {
        return dateFinEffet;
    }

    public void setDateFinEffet(LocalDateTime dateFinEffet) {
        this.dateFinEffet = dateFinEffet;
    }

    public QualificationEntity getQualification() {
        return qualification;
    }

    public void setQualification(QualificationEntity qualification) {
        this.qualification = qualification;
    }
}
