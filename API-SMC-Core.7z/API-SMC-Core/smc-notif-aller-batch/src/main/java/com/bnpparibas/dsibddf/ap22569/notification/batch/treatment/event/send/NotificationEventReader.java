package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.event.send;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class NotificationEventReader implements ItemReader<List<Notification>> {

    @Autowired
    private INotificationManagement notificationManagement;

    @Override
    public List<Notification> read() throws Exception {
        List<Notification> pendingNotifications = this.notificationManagement.getPendingNotifications();

        return pendingNotifications;
    }

}
