/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation;

/**
 * @author c65344
 *
 */
public enum SigneOperation {
	PLUS, MOINS;
}
