package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 *
 * @author c65344
 *
 */
public class CloseFolderDTO {

	@ApiModelProperty( value = "l'utilisateur appelant")
	private String callingUser;

	@ApiModelProperty( value = "Les identifiants GDN des documents rattachés au dossier à clôturer",required = true)
	private List<String> docsIdsGDN;

	@ApiModelProperty( value = "Date de référence de l’archivage", required = true)
	private String  archivingReferenceDate;

	@ApiModelProperty(value = "Code type du document", required = true)
	private String documentTypeId;

	@ApiModelProperty(value = "MIME Type", required = true)
	private String mimeType;

	@ApiModelProperty(value = "Le Titre", required = true)
	private String titre;

	@ApiModelProperty(value = "Document à enregistrer", required = true)
	private  Document document;
	@ApiModelProperty(value = "Id de la contestation")
	private String idContestationSmc;

	/**
	 *
	 */
	public CloseFolderDTO() {
		super();

	}

	/**
	 * @param callingUser
	 * @param docsIdsGDN
	 * @param archivingReferenceDate
	 * @param documentTypeId
	 * @param mimeType
	 * @param titre
	 * @param document
	 */
	public CloseFolderDTO(String callingUser, List<String> docsIdsGDN,
			String archivingReferenceDate, String documentTypeId,
			String mimeType, String titre, Document document) {
		this.callingUser = callingUser;
		this.docsIdsGDN = docsIdsGDN;
		this.archivingReferenceDate = archivingReferenceDate;
		this.documentTypeId = documentTypeId;
		this.mimeType = mimeType;
		this.titre = titre;
		this.document = document;
	}

	/**
	 * @return the archivingReferenceDate
	 */
	public String getArchivingReferenceDate() {
		return archivingReferenceDate;
	}

	/**
	 * @return the callingUser
	 */
	public String getCallingUser() {
		return callingUser;
	}

	/**
	 * @return the docsIdsGDN
	 */
	public List<String> getDocsIdsGDN() {
		return docsIdsGDN;
	}

	/**
	 * @return the document
	 */
	public Document getDocument() {
		return document;
	}

	/**
	 * @return the documentTypeId
	 */
	public String getDocumentTypeId() {
		return documentTypeId;
	}

	/**
	 * @return the idContestationSmc
	 */
	public String getIdContestationSmc() {
		return idContestationSmc;
	}

	/**
	 * @return the mimeType
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @return the titre
	 */
	public String getTitre() {
		return titre;
	}

	/**
	 * @param archivingReferenceDate the archivingReferenceDate to set
	 */
	public void setArchivingReferenceDate(String archivingReferenceDate) {
		this.archivingReferenceDate = archivingReferenceDate;
	}

	/**
	 * @param callingUser the callingUser to set
	 */
	public void setCallingUser(String callingUser) {
		this.callingUser = callingUser;
	}

	/**
	 * @param docsIdsGDN the docsIdsGDN to set
	 */
	public void setDocsIdsGDN(List<String> docsIdsGDN) {
		this.docsIdsGDN = docsIdsGDN;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(Document document) {
		this.document = document;
	}

	/**
	 * @param documentTypeId the documentTypeId to set
	 */
	public void setDocumentTypeId(String documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	/**
	 * @param idContestationSmc the idContestationSmc to set
	 */
	public void setIdContestationSmc(String idContestationSmc) {
		this.idContestationSmc = idContestationSmc;
	}

	/**
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	/**
	 * @param titre the titre to set
	 */
	public void setTitre(String titre) {
		this.titre = titre;
	}

}
