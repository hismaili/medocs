package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.CardDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardExistException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.IOperationService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationTop;

@Component
@Lazy
public class OperationManagement implements IOperationManagement {

	private static final Logger LOG = LoggerFactory.getLogger(OperationManagement.class);

	@Autowired
	private transient IOperationService operationService;


	@Autowired
	private transient ICardServicesManagement cardServicesManagement;

	@Override
	public void deleteOperationsTmp(String idTelematic,String userId) {
		operationService.deleteOperationsTmp(idTelematic,userId);
	}

	@Override
	public List<OperationDTO> getCardOperations(String cardAlias,String idTelematic,String userId) throws ContestationException, CardExistException {
		if(StringUtils.isEmpty(cardAlias)) {
			LOG.error("cardAlias ne peut être vide");
			throw new ContestationException("cardAlias ne peut être vide");
		}
		try {

			List<OperationDTO> result = null;
			CardDTO cardWithMask = this.cardServicesManagement.getCardInfosWithMask(cardAlias);

			if(cardWithMask !=null){
				String pan = cardWithMask.getPan();
				List<Operation> operations = operationService.getCardOperations(pan,idTelematic,userId);
				if(!CollectionUtils.isEmpty(operations)) {
					result = operations.stream().map(op -> {
						OperationDTO operationDTO = new OperationDTO();
						BeanUtils.copyProperties(op, operationDTO);
						operationDTO.setCurrencyOfOperation(op.getDeviseOperation());
						return operationDTO;
					}).collect(Collectors.toList());
				}
			}else{

				String reponse = "Aucune carte ne correspond à la carte alias :"+cardAlias;
				LOG.error(reponse);
				throw new CardExistException(reponse);
			}

			return result;
		} catch (CardException | OperationException e) {
			LOG.error("Une erreur est survenue lors de la recuperation des opérations de la carte "+cardAlias);
			throw new ContestationException(e);
		}

	}

	@Override
	public int getLastNumSeqTopHmp() {

		return operationService.getLastNumSeqTopHmp();
	}

	@Override
	public OperationTop getOperationTopHmp() {

		return operationService.getOperationTopHmp();
	}

	@Override
	public List<OperationTop> getOperationTopHmps(boolean isTop) {

		return operationService.getOperationTopHmps(isTop);
	}

	@Override
	public void isTreated(int numSequence) {
		operationService.isTreated(numSequence);

	}




}
