package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.EtatCarteEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.PorteurEntity;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "CARTE")
@GenericGenerator(name = "SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class CarteEntity extends AbstractEntity<DefaultEntityId> {

    /**
     * numéro de carte
     */
    @Column(name = "PAN", length = 30)
    private String numeroCarte;

    /**
     * type de carte
     */
    @Column(name = "type_carte", length = 30)
    private String typeCarte;

    /**
     * date d'expiration de la carte
     */
    @Column(name = "date_expir")
    private LocalDate dateExpiration;

    /**
     * nom estampe du porteur de carte
     */
    @Column(name = "nom_estampe")
    private String nomPorteur;

    /**
     * etat de carte
     */
    @ManyToOne
    @JoinColumn(name = "etat_carte")
    private EtatCarteEntity etatCarte;

    /**
     * date d'opposition de carte
     */
    @Column(name = "date_oppo")
    private LocalDate dateOpposition;

    /**
     * motif d'opposition de carte
     */
    @Column(name = "motif_oppo", length = 30)
    private String motifOpposition;

    /**
     * Porteur de la carte
     */
    @ManyToOne(cascade=CascadeType.PERSIST)
    //@JoinColumn(name = "etat_carte")
    private PorteurEntity porteur;

    private String alias;

    public String getNumeroCarte() {
        return numeroCarte;
    }

    public void setNumeroCarte(String numeroCarte) {
        this.numeroCarte = numeroCarte;
    }

    public String getTypeCarte() {
        return typeCarte;
    }

    public void setTypeCarte(String typeCarte) {
        this.typeCarte = typeCarte;
    }

    public LocalDate getDateExpiration() {
        return dateExpiration;
    }

    public void setDateExpiration(LocalDate dateExpiration) {
        this.dateExpiration = dateExpiration;
    }

    public String getNomPorteur() {
        return nomPorteur;
    }

    public void setNomPorteur(String nomPorteur) {
        this.nomPorteur = nomPorteur;
    }

    public EtatCarteEntity getEtatCarte() {
        return etatCarte;
    }

    public void setEtatCarte(EtatCarteEntity etatCarte) {
        this.etatCarte = etatCarte;
    }

    public LocalDate getDateOpposition() {
        return dateOpposition;
    }

    public void setDateOpposition(LocalDate dateOpposition) {
        this.dateOpposition = dateOpposition;
    }

    public String getMotifOpposition() {
        return motifOpposition;
    }

    public void setMotifOpposition(String motifOpposition) {
        this.motifOpposition = motifOpposition;
    }

    public PorteurEntity getPorteur() {
        return porteur;
    }

    public void setPorteur(PorteurEntity porteur) {
        this.porteur = porteur;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}
