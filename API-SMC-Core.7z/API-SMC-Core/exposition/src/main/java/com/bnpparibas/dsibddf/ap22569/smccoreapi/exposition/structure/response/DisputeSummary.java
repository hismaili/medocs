package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * DisputeSummary
 */
@Validated
public class DisputeSummary   {
	@JsonProperty("factsSummary")
	private String factsSummary;

	@JsonProperty("identifiantInterne")
	private String identifiantInterne;

	@JsonProperty("disputedAmount")
	@JsonFormat(pattern = "#0.00")
	private BigDecimal disputedAmount;

	@JsonProperty("recognizedAmount")
	private BigDecimal recognizedAmount;

	@JsonProperty("reason")
	private String reason;

	@JsonProperty("numberOfOperations")
	private Integer numberOfOperations;

	@JsonProperty("disputeFolderReference")
	private String disputeFolderReference;

	@JsonProperty("currentStatus")
	private String currentStatus;

	@JsonProperty("maskedPan")
	private String maskedPan;

	@JsonProperty("cardType")
	private String cardType;

	@JsonProperty("dateOpposition")
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateOpposition;

	@JsonProperty("disputeFolderCreationDate")
	@JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	private LocalDateTime disputeFolderCreationDate;

	/**
	 *
	 * @param cardType
	 * @return
	 */
	public DisputeSummary cardType(String cardType) {
		this.cardType = cardType;
		return this;
	}
	/**
	 *
	 * @param currentStatus
	 * @return
	 */
	public DisputeSummary currentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
		return this;
	}
	/**
	 *
	 * @param dateOpposition
	 * @return
	 */
	public DisputeSummary dateOpposition(LocalDate dateOpposition) {
		this.dateOpposition = dateOpposition;
		return this;
	}
	/**
	 *
	 * @param dipsutedAmount
	 * @return
	 */
	public DisputeSummary dipsutedAmount(BigDecimal dipsutedAmount) {
		this.disputedAmount = dipsutedAmount;
		return this;
	}
	/**
	 *
	 * @param disputeFolderCreationDate
	 * @return
	 */
	public DisputeSummary disputeFolderCreationDate(LocalDateTime disputeFolderCreationDate) {
		this.disputeFolderCreationDate = disputeFolderCreationDate;
		return this;
	}
	/**
	 *
	 * @param disputeFolderReference
	 * @return
	 */
	public DisputeSummary disputeFolderReference(String disputeFolderReference) {
		this.disputeFolderReference = disputeFolderReference;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeSummary disputeSummary = (DisputeSummary) o;
		return Objects.equals(this.factsSummary, disputeSummary.factsSummary) &&
				Objects.equals(this.identifiantInterne, disputeSummary.identifiantInterne) &&
				Objects.equals(this.disputedAmount, disputeSummary.disputedAmount) &&
				Objects.equals(this.recognizedAmount, disputeSummary.recognizedAmount) &&
				Objects.equals(this.reason, disputeSummary.reason) &&
				Objects.equals(this.numberOfOperations, disputeSummary.numberOfOperations) &&
				Objects.equals(this.disputeFolderReference, disputeSummary.disputeFolderReference) &&
				Objects.equals(this.currentStatus, disputeSummary.currentStatus) &&
				Objects.equals(this.maskedPan, disputeSummary.maskedPan) &&
				Objects.equals(this.cardType, disputeSummary.cardType) &&
				Objects.equals(this.dateOpposition, disputeSummary.dateOpposition) &&
				Objects.equals(this.disputeFolderCreationDate, disputeSummary.disputeFolderCreationDate);
	}
	/**
	 *
	 * @param factsSummary
	 * @return
	 */
	public DisputeSummary factsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
		return this;
	}

	/**
	 * Get cardType
	 *
	 * @return cardType
	 **/
	@ApiModelProperty(value = "")
	public String getCardType() {
		return cardType;
	}

	/**
	 * Get currentStatus
	 *
	 * @return currentStatus
	 **/
	@ApiModelProperty(value = "")
	public String getCurrentStatus() {
		return currentStatus;
	}

	/**
	 * Get dateOpposition
	 *
	 * @return dateOpposition
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public LocalDate getDateOpposition() {
		return dateOpposition;
	}

	/**
	 * montant contesté
	 *
	 * @return disputedAmount
	 **/
	@ApiModelProperty(value = "montant contesté")

	@Valid

	public BigDecimal getDisputedAmount() {
		return disputedAmount;
	}

	/**
	 * Get disputeFolderCreationDate
	 *
	 * @return disputeFolderCreationDate
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public LocalDateTime getDisputeFolderCreationDate() {
		return disputeFolderCreationDate;
	}

	/**
	 * Get disputeFolderReference
	 *
	 * @return disputeFolderReference
	 **/
	@ApiModelProperty(value = "")


	public String getDisputeFolderReference() {
		return disputeFolderReference;
	}

	/**
	 * Get factsSummary
	 *
	 * @return factsSummary
	 **/
	@ApiModelProperty(value = "")


	public String getFactsSummary() {
		return factsSummary;
	}

	/**
	 * identifiant interne du dossier de contestation dans le service monétique
	 *
	 * @return identifiantInterne
	 **/
	@ApiModelProperty(value = "identifiant interne du dossier de contestation dans le service monétique")


	public String getIdentifiantInterne() {
		return identifiantInterne;
	}

	/**
	 * Get maskedPan
	 *
	 * @return maskedPan
	 **/
	@ApiModelProperty(value = "")


	public String getMaskedPan() {
		return maskedPan;
	}

	/**
	 * nombre d'opérations rattachées au dossier
	 *
	 * @return numberOfOperations
	 **/
	@ApiModelProperty(value = "nombre d'opérations rattachées au dossier")


	public Integer getNumberOfOperations() {
		return numberOfOperations;
	}

	/**
	 * Get reason
	 *
	 * @return reason
	 **/
	@ApiModelProperty(value = "")


	public String getReason() {
		return reason;
	}

	/**
	 * montant reconnu
	 *
	 * @return recognizedAmount
	 **/
	@ApiModelProperty(value = "montant reconnu")
	@Valid
	public BigDecimal getRecognizedAmount() {
		return recognizedAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(factsSummary, identifiantInterne, disputedAmount, recognizedAmount, reason, numberOfOperations, disputeFolderReference, currentStatus, maskedPan, cardType, dateOpposition, disputeFolderCreationDate);
	}
	/**
	 *
	 * @param identifiantInterne
	 * @return
	 */
	public DisputeSummary identifiantInterne(String identifiantInterne) {
		this.identifiantInterne = identifiantInterne;
		return this;
	}
	/**
	 *
	 * @param maskedPan
	 * @return
	 */
	public DisputeSummary maskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
		return this;
	}
	/**
	 *
	 * @param numberOfOperations
	 * @return
	 */
	public DisputeSummary numberOfOperations(Integer numberOfOperations) {
		this.numberOfOperations = numberOfOperations;
		return this;
	}
	/**
	 *
	 * @param reason
	 * @return
	 */
	public DisputeSummary reason(String reason) {
		this.reason = reason;
		return this;
	}
	/**
	 *
	 * @param recognizedAmount
	 * @return
	 */
	public DisputeSummary recognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
		return this;
	}
	/**
	 *
	 * @param cardType
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	/**
	 *
	 * @param currentStatus
	 */
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	/**
	 *
	 * @param dateOpposition
	 */
	public void setDateOpposition(LocalDate dateOpposition) {
		this.dateOpposition = dateOpposition;
	}
	/**
	 *
	 * @param disputedAmount
	 */
	public void setDisputedAmount(BigDecimal disputedAmount) {
		if (disputedAmount != null) {
			this.disputedAmount = disputedAmount.setScale(2, RoundingMode.HALF_EVEN);
		}
	}
	/**
	 *
	 * @param disputeFolderCreationDate
	 */
	public void setDisputeFolderCreationDate(LocalDateTime disputeFolderCreationDate) {
		this.disputeFolderCreationDate = disputeFolderCreationDate;
	}
	/**
	 *
	 * @param disputeFolderReference
	 */
	public void setDisputeFolderReference(String disputeFolderReference) {
		this.disputeFolderReference = disputeFolderReference;
	}
	/**
	 *
	 * @param factsSummary
	 */
	public void setFactsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
	}
	/**
	 *
	 * @param identifiantInterne
	 */
	public void setIdentifiantInterne(String identifiantInterne) {
		this.identifiantInterne = identifiantInterne;
	}
	/**
	 *
	 * @param maskedPan
	 */
	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}
	/**
	 *
	 * @param numberOfOperations
	 */
	public void setNumberOfOperations(Integer numberOfOperations) {
		this.numberOfOperations = numberOfOperations;
	}

	/**
	 *
	 * @param reason
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 *
	 * @param recognizedAmount
	 */
	public void setRecognizedAmount(BigDecimal recognizedAmount) {
		this.recognizedAmount = recognizedAmount;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeSummary {\n");

		sb.append("    factsSummary: ").append(toIndentedString(factsSummary)).append("\n");
		sb.append("    identifiantInterne: ").append(toIndentedString(identifiantInterne)).append("\n");
		sb.append("    disputedAmount: ").append(toIndentedString(disputedAmount)).append("\n");
		sb.append("    recognizedAmount: ").append(toIndentedString(recognizedAmount)).append("\n");
		sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
		sb.append("    numberOfOperations: ").append(toIndentedString(numberOfOperations)).append("\n");
		sb.append("    disputeFolderReference: ").append(toIndentedString(disputeFolderReference)).append("\n");
		sb.append("    currentStatus: ").append(toIndentedString(currentStatus)).append("\n");
		sb.append("    maskedPan: ").append(toIndentedString(maskedPan)).append("\n");
		sb.append("    cardType: ").append(toIndentedString(cardType)).append("\n");
		sb.append("    dateOpposition: ").append(toIndentedString(dateOpposition)).append("\n");
		sb.append("    disputeFolderCreationDate: ").append(toIndentedString(disputeFolderCreationDate)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

