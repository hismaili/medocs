/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.IinfoPersonne;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author c65344
 *
 */
@Service
public class InfoPersonneManagementImpl implements IInfoPersonneManagement {
	@Autowired
	private transient IinfoPersonne infoPersonne;

	@Override
	public InfoPersonneOutput getInfopersonne(String iKpi) throws PorteurException {

		return infoPersonne.getInfoPersonneRP(iKpi);
	}

}
