package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.Base64;
import java.util.UUID;

public class EntityIdGenerator implements IdentifierGenerator {

    public Serializable generate(SharedSessionContractImplementor s, Object obj) {
        DefaultEntityId id = new DefaultEntityId();
        UUID uuid = UUID.randomUUID();
        byte[] uuidArray = toByteArray(uuid);
        byte[] encodedArray = Base64.getEncoder().encode(uuidArray);
        StringBuilder returnValue = new StringBuilder(new String(encodedArray));
        int index = returnValue.indexOf("=");
        while (index >= 0) {
            returnValue.deleteCharAt(index);
            index = returnValue.indexOf("=");
        }
        id.setId(returnValue.toString());
        return id;
    }

    private static byte[] toByteArray(UUID uuid) {
        byte[] byteArray = new byte[(Long.SIZE / Byte.SIZE) * 2];
        ByteBuffer buffer = ByteBuffer.wrap(byteArray);
        LongBuffer longBuffer = buffer.asLongBuffer();
        longBuffer.put(new long[]{uuid.getMostSignificantBits(), uuid.getLeastSignificantBits()});
        return byteArray;
    }
}
