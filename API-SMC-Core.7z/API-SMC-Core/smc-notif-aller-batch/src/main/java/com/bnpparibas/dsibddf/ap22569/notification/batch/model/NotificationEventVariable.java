package com.bnpparibas.dsibddf.ap22569.notification.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("variable")
public class NotificationEventVariable {

    @XStreamAlias("name")
    @XStreamAsAttribute
    private String variableName;

    @XStreamAlias("value")
    @XStreamAsAttribute
    private String variableValue;

    public NotificationEventVariable(String variableName, String variableValue) {
        this.variableName = variableName;
        this.variableValue = variableValue;
    }

    public String getVariableName() {
        return variableName;
    }

    public String getVariableValue() {
        return variableValue;
    }
}
