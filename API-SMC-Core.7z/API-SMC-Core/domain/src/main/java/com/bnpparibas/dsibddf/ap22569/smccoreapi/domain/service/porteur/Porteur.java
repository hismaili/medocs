package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.porteur;

/**
 *
 *
 *
 */
public class Porteur {

	private String ikpi;

	private String civilite;


	private String nom;

	private String prenom;

	/**
	 *
	 */
	public Porteur() {
		super();

	}

	/**
	 * @param iKpi
	 * @param civilite
	 * @param nom
	 * @param prenom
	 */
	public Porteur(String iKpi, String civilite, String nom, String prenom) {
		this.ikpi = iKpi;
		this.civilite = civilite;
		this.nom = nom;
		this.prenom = prenom;
	}

	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}



	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}

	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}

	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}

	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}



	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


}
