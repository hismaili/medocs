/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.AttachmentDataInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DocumentInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.IDisputeSelfCare;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.MotifEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.MotifJpaRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.NatureEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.QualificationEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.PersonContactJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Service
public class DisputeSelfCareWs implements IDisputeSelfCare {
	private static final Logger LOG = LoggerFactory.getLogger(DisputeSelfCareWs.class);
	@Autowired()
	//@Qualifier("restTemplateSmc")
	@Qualifier("simpleresttemplate")
	private RestTemplate restTemplate;
	@Autowired
	private ConfigInfrastructure conf;
	@Autowired
	private MandatoryBuilder madatory;
	@Autowired
	private MapperBuilderDispute map;

	@Autowired
	private MotifJpaRepository jpaRepository;
	@Autowired
	private JwtAuthorizationBuilder jwt;

	@Autowired
	private transient PersonContactJpaRepository jpaPerContact;


	@Override
	public DisputeResponse attachedDocuments(AttachmentDataInput attach)
			throws MandatoryException {
		DisputeResponse responseSmc = null;
		List<String> attachmentMandatory = madatory.checkAttachment(attach);

		if (!CollectionUtils.isEmpty(attachmentMandatory)) {
			throw new MandatoryException(attachmentMandatory);
		}
		String token = "";
		try {
			token = jwt.getCompactJws();
		} catch (JwtSmcException e) {
			LOG.error(e.getMessage(),e);
			LOG.error("problème de construction du certificat SMC provenant de la couche monetique");
		}

		final List<DocumentInput> documents = attach.getDocuments();

		AttachmentData attachmentData = new AttachmentData();

		attachmentData.setFileIdSMC(attach.getFileIdSMC());

		if (!CollectionUtils.isEmpty(documents)) {
			attachmentData.setDocuments(documents.stream().
					filter(document -> document !=null).map(document -> {
						Document attachDoc = new Document();
						BeanUtils.copyProperties(document, attachDoc);
						return attachDoc;
					})
					.collect(Collectors.toList()));
		}

		try {
			HttpHeaders header = new HttpHeaders();

			header.set("Accept", "application/json");
			header.add("Content-Type", "application/json");
			header.add("Authorization", "Bearer "+token);

			HttpEntity<AttachmentData> request = new HttpEntity<AttachmentData>(
					attachmentData, header);
			LOG.info("la requête vers SMC :"+request.toString());
			URI uri = URI.create(conf.getUrlAttachmentSelf());

			ResponseEntity<ResponseDisputeFile> response = restTemplate.exchange(
					uri, HttpMethod.POST, request,
					ResponseDisputeFile.class);


			if (response != null) {
				LOG.info("Reponse du service smc attach document contestation :"+response.toString());
				responseSmc = map.getResponseSmc(response);
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
		}


		return responseSmc;
	}



	@Override
	public DisputeResponse getStatusDispute(String folderNumber)
			throws MandatoryException {
		DisputeResponse responseSmc = null;

		if (!StringUtils.isEmpty(folderNumber)) {
			throw new MandatoryException(Arrays.asList(folderNumber));
		}

		String token = "";
		try {
			token = jwt.getCompactJws();
		} catch (JwtSmcException e) {
			LOG.error(e.getMessage(),e);
			LOG.error("problème de construction du certificat SMC provenant de la couche monetique");
		}
		HttpHeaders header = new HttpHeaders();

		header.set("Accept", "application/json");
		header.add("Content-Type", "application/json");
		header.add("Authorization", "Bearer "+token);

		try {
			HttpEntity<String> request = new HttpEntity<String>(header);
			LOG.info("la requête vers SMC :"+request.toString());
			ResponseEntity<ResponseDisputeFile> response = restTemplate.exchange(
					conf.getUrlGetStatuSelf() + "/" + folderNumber, HttpMethod.GET,
					request, ResponseDisputeFile.class);


			if (response != null) {
				LOG.info("Reponse du service smc get status contestation :"+response.toString());
				responseSmc = map.getResponseSmc(response);
			}

		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
		}

		return responseSmc;
	}


	@Override
	public DisputeResponse sendDisputeToSmc(Contestation dispute)
			throws MandatoryException {
		DisputeResponse responseSmc = null;
		DisputeData disputeData = null;
		List<String> mandatory = madatory.checkMandatoryDisputInput(dispute);

		if (!CollectionUtils.isEmpty(mandatory)) {

			mandatory.forEach(err->LOG.error(err));

			throw new MandatoryException(mandatory);
		}

		disputeData = map.mapContestationToDisputeData(dispute);

		MotifContestation motif = dispute.getMotif();
		NatureEntity natureContestation = null;
		QualificationEntity qualificationContestation = null;

		String token = "";
		try {
			token = jwt.getCompactJws();
		} catch (JwtSmcException e) {
			LOG.error(e.getMessage(),e);
			LOG.error("problème de construction du certificat SMC provenant de la couche monetique");
		}

		if(disputeData !=null){

			if(motif !=null){
				String code = motif.getCode();
				if(code !=null){

					Optional<MotifEntity> findById = jpaRepository.findById(code);
					if(findById.isPresent()){

						MotifEntity motifEntity = findById.get();
						if(motifEntity != null) {
							natureContestation = motifEntity.getNatureContestation();
							qualificationContestation = motifEntity.getQualificationContestation();
						}
					}
				}
			}

		}


		if(natureContestation !=null){
			disputeData.setNature(natureContestation.getNatureCode());
		}
		if(qualificationContestation !=null){
			disputeData.setQualification(qualificationContestation.getQualifcationCode());
		}


		try {
			HttpHeaders header = new HttpHeaders();

			header.set("Accept", "application/json");
			header.add("Content-Type", "application/json");
			header.add("Authorization", "Bearer "+token);

			HttpEntity<DisputeData> request = new HttpEntity<DisputeData>(
					disputeData, header);

			LOG.info("la requête vers SMC :"+request.toString());
			URI uri = URI.create(conf.getUrlCreateSelf());

			ResponseEntity<ResponseDisputeFile> response = restTemplate
					.exchange(uri, HttpMethod.POST,
							request, ResponseDisputeFile.class);


			if (response != null) {
				LOG.info("Reponse du service smc send contestation :"+response.toString());
				responseSmc = map.getResponseSmc(response);
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
		}

		return responseSmc;
	}

}
