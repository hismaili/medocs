package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.CardDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.AnonymizedCard;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.InfoCarte;

import java.util.List;

/**
 *
 * Interface des methodes des informations carte
 *
 */
public interface ICardServicesManagement {

	/**
	 * Recupère la liste des carte d'un client
	 * @param iKpi
	 * @return
	 */
	List<CartePorteur> getCartesPorteur(String iKpi)  throws CardException;

	/**
	 * recupère les informations d'une carte
	 * @param pan
	 * @return
	 */
	InfoCarte getInfoCarte(String pan)  throws CardException;

	CardDTO getCardInfosWithMask(String cardId) throws CardException;

	List<AnonymizedCard> getCartesPorteur(List<String> ribs)  throws CardException;
}
