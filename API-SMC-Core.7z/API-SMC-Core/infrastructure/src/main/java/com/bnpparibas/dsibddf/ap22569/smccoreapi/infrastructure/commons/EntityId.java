package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons;

import java.io.Serializable;

public interface EntityId extends Serializable {
}
