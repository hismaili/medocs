package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Données permettant d&#39;identifier la maquette à utiliser côté éditique
 */
@ApiModel(description = "Données permettant d'identifier la maquette à utiliser côté éditique ")
public class PDFRequestMaquetteIdentification   {
	@ApiModelProperty(required = true, value = "Maquette")
	@JsonProperty("Maquette")
	private String maquette;

	@ApiModelProperty(required = true, value = "DataMatrix")
	@JsonProperty("DataMatrix")
	private String dataMatrix;

	@ApiModelProperty(required = true, value = "ModeleCourrier")
	@JsonProperty("ModeleCourrier")
	private String modeleCourrier;

	/**
	 *
	 */
	public PDFRequestMaquetteIdentification() {
		super();

	}

	/**
	 * @param maquette
	 * @param dataMatrix
	 * @param modeleCourrier
	 */
	public PDFRequestMaquetteIdentification(String maquette, String dataMatrix,
			String modeleCourrier) {
		this.maquette = maquette;
		this.dataMatrix = dataMatrix;
		this.modeleCourrier = modeleCourrier;
	}

	/**
	 * @return the dataMatrix
	 */
	public String getDataMatrix() {
		return dataMatrix;
	}

	/**
	 * @return the maquette
	 */
	public String getMaquette() {
		return maquette;
	}

	/**
	 * @return the modeleCourrier
	 */
	public String getModeleCourrier() {
		return modeleCourrier;
	}

	/**
	 * @param dataMatrix the dataMatrix to set
	 */
	public void setDataMatrix(String dataMatrix) {
		this.dataMatrix = dataMatrix;
	}

	/**
	 * @param maquette the maquette to set
	 */
	public void setMaquette(String maquette) {
		this.maquette = maquette;
	}

	/**
	 * @param modeleCourrier the modeleCourrier to set
	 */
	public void setModeleCourrier(String modeleCourrier) {
		this.modeleCourrier = modeleCourrier;
	}


}

