package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * DisputeData
 */
public class DisputeData   {
	@JsonProperty("factsSummary")
	private String factsSummary;

	@JsonProperty("cardLost")
	private Boolean cardLost;

	@JsonProperty("reason")
	private String reason;

	@JsonProperty("notifMail")
	private Boolean notifMail;

	@JsonProperty("notifPush")
	private Boolean notifPush;

	@JsonProperty("notifSMS")
	private Boolean notifSMS;

	@JsonProperty("cardId")
	private String cardId;

	@JsonProperty("operations")
	@Valid
	private List<DisputeDataOperations> operations = new ArrayList<DisputeDataOperations>();

	@JsonProperty("phoneNumber")
	private String phoneNumber;

	@JsonProperty("mail")
	private String mail;

	@JsonProperty("topPhoneNumberModified")
	private Boolean topPhoneNumberModified;

	@JsonProperty("topMailModified")
	private Boolean topMailModified;

	@JsonProperty("attachedFiles")
	private List<DisputeDataAttachedFiles> attachedFiles;

	/**
	 *
	 * @param attachedFilesItem
	 * @return
	 */
	public DisputeData addAttachedFilesItem(DisputeDataAttachedFiles attachedFilesItem) {
		if (this.attachedFiles == null) {
			this.attachedFiles = new ArrayList<DisputeDataAttachedFiles>();
		}
		this.attachedFiles.add(attachedFilesItem);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DisputeData disputeData = (DisputeData) o;
		return Objects.equals(this.factsSummary, disputeData.factsSummary) &&
				Objects.equals(this.cardLost, disputeData.cardLost) &&
				Objects.equals(this.reason, disputeData.reason) &&
				Objects.equals(this.notifMail, disputeData.notifMail) &&
				Objects.equals(this.notifPush, disputeData.notifPush) &&
				Objects.equals(this.notifSMS, disputeData.notifSMS) &&
				Objects.equals(this.cardId, disputeData.cardId) &&
				Objects.equals(this.operations, disputeData.operations) &&
				Objects.equals(this.phoneNumber, disputeData.phoneNumber) &&
				Objects.equals(this.mail, disputeData.mail) &&
				Objects.equals(this.topPhoneNumberModified, disputeData.topPhoneNumberModified) &&
				Objects.equals(this.topMailModified, disputeData.topMailModified) &&
				Objects.equals(this.attachedFiles, disputeData.attachedFiles);
	}

	/**
	 * Get attachedFiles
	 *
	 * @return attachedFiles
	 **/
	@ApiModelProperty(value = "")
	public List<DisputeDataAttachedFiles> getAttachedFiles() {
		return attachedFiles;
	}

	/**
	 * identifiant de la carte tel qu'il figure dans CarteVO
	 *
	 * @return cardId
	 **/
	@ApiModelProperty(required = true, value = "identifiant de la carte tel qu'il figure dans CarteVO")
	public String getCardId() {
		return cardId;
	}

	/**
	 * @return the cardLost
	 */
	public Boolean getCardLost() {
		return cardLost;
	}

	/**
	 * Description des faits
	 *
	 * @return factsSummary
	 **/
	@ApiModelProperty(value = "Description des faits")
	public String getFactsSummary() {
		return factsSummary;
	}

	/**
	 * l adresse mail où l utilisateur souhaite être notifié ou son id si l utilisateur n'a pas modifié l adresse affichée
	 *
	 * @return mail
	 **/
	@ApiModelProperty(value = "l adresse mail où l utilisateur souhaite être notifié ou son id si l utilisateur n'a pas modifié l adresse affichée ")
	public String getMail() {
		return mail;
	}

	/**
	 * @return the notifMail
	 */
	public Boolean getNotifMail() {
		return notifMail;
	}

	/**
	 * @return the notifPush
	 */
	public Boolean getNotifPush() {
		return notifPush;
	}

	/**
	 * @return the notifSMS
	 */
	public Boolean getNotifSMS() {
		return notifSMS;
	}

	/**
	 * Get operations
	 *
	 * @return operations
	 **/
	@ApiModelProperty(required = true, value = "")
	public List<DisputeDataOperations> getOperations() {
		return operations;
	}

	/**
	 * le numéro de téléphone où l utilisateur souhaite être notifié ou son id si l utilisateur n a pas modifié le numéro affiché
	 *
	 * @return phoneNumber
	 **/
	@ApiModelProperty(value = "le numéro de téléphone où l utilisateur souhaite être notifié ou son id si l utilisateur n a pas modifié le numéro affiché ")
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Motif de la contestation
	 *
	 * @return reason
	 **/
	@ApiModelProperty(value = "Motif de la contestation")
	public String getReason() {
		return reason;
	}

	/**
	 * @return the topMailModified
	 */
	public Boolean getTopMailModified() {
		return topMailModified;
	}

	/**
	 * @return the topPhoneNumberModified
	 */
	public Boolean getTopPhoneNumberModified() {
		return topPhoneNumberModified;
	}

	@Override
	public int hashCode() {
		return Objects.hash(factsSummary, cardLost, reason, notifMail, notifPush, notifSMS, cardId, operations, phoneNumber, mail, topPhoneNumberModified, topMailModified, attachedFiles);
	}


	/**
	 * carte perdue ou volée
	 *
	 * @return cardLost
	 **/
	@ApiModelProperty(value = "carte perdue ou volée")
	public Boolean isCardLost() {
		return cardLost;
	}

	/**
	 * Le client préfère-t-il être notifié par Mail ou non
	 *
	 * @return notifMail
	 **/
	@ApiModelProperty(example = "false", value = "Le client préfère-t-il être notifié par Mail ou non")
	public Boolean isNotifMail() {
		return notifMail;
	}

	/**
	 * Le client préfère-t-il être notifié en push ou non
	 *
	 * @return notifPush
	 **/
	@ApiModelProperty(example = "false", value = "Le client préfère-t-il être notifié en push ou non")
	public Boolean isNotifPush() {
		return notifPush;
	}

	/**
	 * Le client préfère-t-il être notifié par SMS ou non
	 *
	 * @return notifSMS
	 **/
	@ApiModelProperty(example = "false", value = "Le client préfère-t-il être notifié par SMS ou non")
	public Boolean isNotifSMS() {
		return notifSMS;
	}

	/**
	 * décrit si l utilisateur a saisi une adresse mail autre que celle proposée.
	 *
	 * @return topMailModified
	 **/
	@ApiModelProperty(value = "décrit si l utilisateur a saisi une adresse mail autre que celle proposée.")
	public Boolean isTopMailModified() {
		return topMailModified;
	}

	/**
	 * décrit si l utilisateur a saisi un numéro de téléphone autre que  celui proposé.
	 *
	 * @return topPhoneNumberModified
	 **/
	@ApiModelProperty(value = "décrit si l utilisateur a saisi un numéro de téléphone autre que  celui proposé.")
	public Boolean isTopPhoneNumberModified() {
		return topPhoneNumberModified;
	}
	/**
	 *
	 * @param attachedFiles
	 */
	public void setAttachedFiles(List<DisputeDataAttachedFiles> attachedFiles) {
		this.attachedFiles = attachedFiles;
	}
	/**
	 *
	 * @param cardId
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	/**
	 *
	 * @param cardLost
	 */
	public void setCardLost(Boolean cardLost) {
		this.cardLost = cardLost;
	}
	/**
	 *
	 * @param factsSummary
	 */
	public void setFactsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
	}
	/**
	 *
	 * @param mail
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 *
	 * @param notifMail
	 */
	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}
	/**
	 *
	 * @param notifPush
	 */
	public void setNotifPush(Boolean notifPush) {
		this.notifPush = notifPush;
	}
	/**
	 *
	 * @param notifSMS
	 */
	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}
	/**
	 *
	 * @param operations
	 */
	public void setOperations(List<DisputeDataOperations> operations) {
		this.operations = operations;
	}
	/**
	 *
	 * @param phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 *
	 * @param reason
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 *
	 * @param topMailModified
	 */
	public void setTopMailModified(Boolean topMailModified) {
		this.topMailModified = topMailModified;
	}
	/**
	 *
	 * @param topPhoneNumberModified
	 */
	public void setTopPhoneNumberModified(Boolean topPhoneNumberModified) {
		this.topPhoneNumberModified = topPhoneNumberModified;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class DisputeData {\n");

		sb.append("    factsSummary: ").append(toIndentedString(factsSummary)).append("\n");
		sb.append("    cardLost: ").append(toIndentedString(cardLost)).append("\n");
		sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
		sb.append("    notifMail: ").append(toIndentedString(notifMail)).append("\n");
		sb.append("    notifPush: ").append(toIndentedString(notifPush)).append("\n");
		sb.append("    notifSMS: ").append(toIndentedString(notifSMS)).append("\n");
		sb.append("    cardId: ").append(toIndentedString(cardId)).append("\n");
		sb.append("    operations: ").append(toIndentedString(operations)).append("\n");
		sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
		sb.append("    mail: ").append(toIndentedString(mail)).append("\n");
		sb.append("    topPhoneNumberModified: ").append(toIndentedString(topPhoneNumberModified)).append("\n");
		sb.append("    topMailModified: ").append(toIndentedString(topMailModified)).append("\n");
		sb.append("    attachedFiles: ").append(toIndentedString(attachedFiles)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

