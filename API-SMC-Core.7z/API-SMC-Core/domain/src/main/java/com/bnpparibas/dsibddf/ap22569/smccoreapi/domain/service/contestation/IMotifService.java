package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;

import java.util.List;

public interface IMotifService {

    List<MotifContestation> getAllMotifs();

    List<MotifContestation> getMotifsByOperationType(TypeOperation operationType);

    MotifContestation getMotif(String code);

}
