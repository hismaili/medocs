/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.refo;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.IRefo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.RefoException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.ResponseRefo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author c65344
 *
 */
@Component
public class RefoManagementImpl implements IRefoManagement {
	@Autowired(required=false)
	private transient IRefo refo;
	@Override
	public ResponseRefo getTypeBank(String codeUO) throws RefoException {

		return refo.getTypeBank(codeUO);
	}

}
