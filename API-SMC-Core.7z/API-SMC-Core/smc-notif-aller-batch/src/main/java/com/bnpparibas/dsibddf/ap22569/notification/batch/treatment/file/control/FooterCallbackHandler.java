package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("FooterCallbackHandler")
public class FooterCallbackHandler  implements LineCallbackHandler {

    private static final Logger LOG = LoggerFactory.getLogger(FooterCallbackHandler.class);

    private StepExecution stepExecution;

    @Autowired
    private transient INotificationManagement notificationManagement;

    @Override
    public void handleLine(String footer) {
        LOG.info("Processing footer "+footer);
        NotificationInfoFile infoFile = (NotificationInfoFile) this.stepExecution.getExecutionContext().get("FILE_INFO");
        if(infoFile == null) {
            LOG.error("Aucun fichier stocké");
        } else {
            String[] infos = footer.split(";");
            try {
                infoFile.setRecordNumber(Integer.valueOf(infos[2]));
                this.notificationManagement.saveNotificationFileFooter(infoFile);
            } catch (NotificationException e) {
                LOG.error(e.getMessage(), e);
            }
        }
    }

    public StepExecution getStepExecution() {
        return stepExecution;
    }

    public void setStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }
}
