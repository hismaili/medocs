package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STATUT_DOSSIER_SELFCARE")
public class StatutDossierContestationSelfCare {

	@Id
	@Column(length = 25)
	private String codeStatut;

	@Column
	private String libelleStatut;

	@Column(name = "indice")
	private int index;

	/**
	 *
	 */
	public StatutDossierContestationSelfCare() {
		super();

	}

	public StatutDossierContestationSelfCare(String codeStatut, String libelleStatut, int index) {
		this.codeStatut = codeStatut;
		this.libelleStatut = libelleStatut;
		this.index = index;
	}

	public String getCodeStatut() {
		return codeStatut;
	}

	public int getIndex() {
		return index;
	}

	public String getLibelleStatut() {
		return libelleStatut;
	}

	/**
	 * @param codeStatut the codeStatut to set
	 */
	public void setCodeStatut(String codeStatut) {
		this.codeStatut = codeStatut;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(int index) {
		this.index = index;
	}

	/**
	 * @param libelleStatut the libelleStatut to set
	 */
	public void setLibelleStatut(String libelleStatut) {
		this.libelleStatut = libelleStatut;
	}
}
