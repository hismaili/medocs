package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;

/**
 *
 * @author c65344
 *
 */
@Entity
@Table(name = "OPERATION")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class OperationEntity extends AbstractEntity<DefaultEntityId> {

	/** Coidop de l'opération */
	@Column(name="code_peration")
	private String codeOperation;

	/** Le type d'opération : retrait, VAD,  */
	@Column(name="type_operation")
	private TypeOperation typeOperation;

	/** Le montant de l'opération */
	@Column(name="montant_operation")
	private BigDecimal montantOperation;

	/** La date de l'opération */
	@Column(name="date_operation")
	private LocalDate dateOperation;

	/** Le libellé de l'opération */
	@Column(name="libelle_operation")
	private String libelleOperation;

	/** Le montant reconnu par l'utilisateur pour les contestations pour des montants erronés */
	@Column(name="montant_reconnu")
	private BigDecimal montantReconnu;

	@Column(name="Nom_Commercant")
	private String nomCommercant;

	@Column(name="date_vente")
	private LocalDate dateVente;

	@Enumerated(EnumType.STRING)
	private SensOperation sensOperation;

	@Column(name="devise_operation")
	private String deviseOperation;

	/***
	 * ajout des propiétés Top HMP
	 */
	@Column
	private Integer numSequence;

	@Column(name="status_top")
	@Enumerated(EnumType.STRING)
	private StatusTopOperation statusTop;

	@Column(name="treatedDate")
	private LocalDate treatedDate;

	@Column(name = "nature_operation")
	private String natureOperation;

	@Column(name = "type_operation_hmp")
	private String typeOperationHmp;

	@Column(name = "id_reseau")
	private String idReseau;

	@Column(name = "montant_commission")
	private BigDecimal montantCommission;

	/**
	 * @return the codeOperation
	 */
	public String getCodeOperation() {
		return codeOperation;
	}

	/**
	 * @return the dateOperation
	 */
	public LocalDate getDateOperation() {
		return dateOperation;
	}

	public LocalDate getDateVente() {
		return dateVente;
	}

	public String getDeviseOperation() {
		return deviseOperation;
	}

	/**
	 * @return the idReseau
	 */
	public String getIdReseau() {
		return idReseau;
	}

	/**
	 * @return the libelleOperation
	 */
	public String getLibelleOperation() {
		return libelleOperation;
	}

	/**
	 * @return the montantCommission
	 */
	public BigDecimal getMontantCommission() {
		return montantCommission;
	}

	/**
	 * @return the montantOperation
	 */
	public BigDecimal getMontantOperation() {
		return montantOperation;
	}

	/**
	 * @return the montantReconnu
	 */
	public BigDecimal getMontantReconnu() {
		return montantReconnu;
	}

	/**
	 * @return the natureOperation
	 */
	public String getNatureOperation() {
		return natureOperation;
	}

	public String getNomCommercant() {
		return nomCommercant;
	}

	/**
	 * @return the numSequence
	 */
	public Integer getNumSequence() {
		return numSequence;
	}

	public SensOperation getSensOperation() {
		return sensOperation;
	}

	/**
	 * @return the statusTop
	 */
	public StatusTopOperation getStatusTop() {
		return statusTop;
	}



	/**
	 * @return the treatedDate
	 */
	public LocalDate getTreatedDate() {
		return treatedDate;
	}

	/**
	 * @return the typeOperation
	 */
	public TypeOperation getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @return the typeOperationHmp
	 */
	public String getTypeOperationHmp() {
		return typeOperationHmp;
	}

	/**
	 * @param codeOperation the codeOperation to set
	 */
	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}



	/**
	 * @param dateOperation the dateOperation to set
	 */
	public void setDateOperation(LocalDate dateOperation) {
		this.dateOperation = dateOperation;
	}

	public void setDateVente(LocalDate dateVente) {
		this.dateVente = dateVente;
	}

	public void setDeviseOperation(String deviseOperation) {
		this.deviseOperation = deviseOperation;
	}

	/**
	 * @param idReseau the idReseau to set
	 */
	public void setIdReseau(String idReseau) {
		this.idReseau = idReseau;
	}

	/**
	 * @param libelleOperation the libelleOperation to set
	 */
	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	/**
	 * @param montantCommission the montantCommission to set
	 */
	public void setMontantCommission(BigDecimal montantCommission) {
		this.montantCommission = montantCommission;
	}

	/**
	 * @param montantOperation the montantOperation to set
	 */
	public void setMontantOperation(BigDecimal montantOperation) {
		this.montantOperation = montantOperation;
	}

	/**
	 * @param montantReconnu the montantReconnu to set
	 */
	public void setMontantReconnu(BigDecimal montantReconnu) {
		this.montantReconnu = montantReconnu;
	}

	/**
	 * @param natureOperation the natureOperation to set
	 */
	public void setNatureOperation(String natureOperation) {
		this.natureOperation = natureOperation;
	}

	public void setNomCommercant(String nomCommercant) {
		this.nomCommercant = nomCommercant;
	}

	/**
	 * @param numSequence the numSequence to set
	 */
	public void setNumSequence(Integer numSequence) {
		this.numSequence = numSequence;
	}

	public void setSensOperation(SensOperation sensOperation) {
		this.sensOperation = sensOperation;
	}

	/**
	 * @param statusTop the statusTop to set
	 */
	public void setStatusTop(StatusTopOperation statusTop) {
		this.statusTop = statusTop;
	}

	/**
	 * @param treatedDate the treatedDate to set
	 */
	public void setTreatedDate(LocalDate treatedDate) {
		this.treatedDate = treatedDate;
	}



	/**
	 * @param typeOperation the typeOperation to set
	 */
	public void setTypeOperation(TypeOperation typeOperation) {
		this.typeOperation = typeOperation;
	}

	/**
	 * @param typeOperationHmp the typeOperationHmp to set
	 */
	public void setTypeOperationHmp(String typeOperationHmp) {
		this.typeOperationHmp = typeOperationHmp;
	}
}
