/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigInteger;
import java.time.LocalDate;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "DOCUMENT_RETOUR_EDITIQUE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class DocumentGdnReturnEntity extends AbstractEntity<DefaultEntityId>{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column
	private String numDossier;
	@Column
	private BigInteger idDocSmc;
	@Column
	private String idGDN;
	@Column
	private LocalDate dateRetrait;
	@Column
	private boolean topSecurisation;
	@Column
	private String originalLine;
	@Column
	private Integer lineNumber;
	@Column
	private boolean send;
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "file_info")
	private InfoFileReturnCentraleEntity info;

	/**
	 * @return the dateRetrait
	 */
	public LocalDate getDateRetrait() {
		return dateRetrait;
	}

	/**
	 * @return the idDocSmc
	 */
	public BigInteger getIdDocSmc() {
		return idDocSmc;
	}

	/**
	 * @return the idGDN
	 */
	public String getIdGDN() {
		return idGDN;
	}

	/**
	 * @return the info
	 */
	public InfoFileReturnCentraleEntity getInfo() {
		return info;
	}
	/**
	 * @return the lineNumber
	 */
	public Integer getLineNumber() {
		return lineNumber;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the originalLine
	 */
	public String getOriginalLine() {
		return originalLine;
	}

	/**
	 * @return the send
	 */
	public boolean isSend() {
		return send;
	}

	/**
	 * @return the topSecurisation
	 */
	public boolean isTopSecurisation() {
		return topSecurisation;
	}

	/**
	 * @param dateRetrait the dateRetrait to set
	 */
	public void setDateRetrait(LocalDate dateRetrait) {
		this.dateRetrait = dateRetrait;
	}

	/**
	 * @param idDocSmc the idDocSmc to set
	 */
	public void setIdDocSmc(BigInteger idDocSmc) {
		this.idDocSmc = idDocSmc;
	}

	/**
	 * @param idGDN the idGDN to set
	 */
	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}

	/**
	 * @param info the info to set
	 */
	public void setInfo(InfoFileReturnCentraleEntity info) {
		this.info = info;
	}

	/**
	 * @param lineNumber the lineNumber to set
	 */
	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}

	/**
	 * @param originalLine the originalLine to set
	 */
	public void setOriginalLine(String originalLine) {
		this.originalLine = originalLine;
	}

	/**
	 * @param send the send to set
	 */
	public void setSend(boolean send) {
		this.send = send;
	}

	/**
	 * @param topSecurisation the topSecurisation to set
	 */
	public void setTopSecurisation(boolean topSecurisation) {
		this.topSecurisation = topSecurisation;
	}
}
