package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;
/**
 *
 *
 *
 */
public enum TypeOperationVO {

	PAIEMENT, RETRAIT, MIXTE
}
