package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte.CardJpaRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte.CarteEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.PersonContactEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.PersonContactJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
/**
 *
 *
 *
 */
@Repository
public class ContestationRepositoryImpl implements IContestationRepository {
	private static final Logger LOG = LoggerFactory.getLogger(ContestationRepositoryImpl.class);

	private transient ContestationJpaRepository contestationJpaRepository;

	@Autowired(required = false)
	private transient MotifJpaRepository motifRepository;

	@Autowired
	private transient StatutDossierContestationJpaRepository statutDossierContestationJpaRepository;

	@Autowired
	private transient ConfigInfrastructure conf;

	@Autowired
	private transient PersonContactJpaRepository personJpa;
	@Autowired
	private transient CardJpaRepository cardJpa;

	public ContestationRepositoryImpl(ContestationJpaRepository contestationJpaRepository) {
		this.contestationJpaRepository = contestationJpaRepository;
	}

	/**
	 * Creer une contestation dans la couche monétique
	 *
	 * @param contestation : la demande de contestation à créer
	 */
	@Override
	public Contestation creerContestation(Contestation contestation) {

		List<DocumentAttache> documentAttaches = contestation.getDocumentAttaches();

		/**
		 * Ajout du typeDocument GDN
		 */
		if(!CollectionUtils.isEmpty(documentAttaches)){

			contestation.setDocumentAttaches(documentAttaches.stream().map(documentAttache -> {

				documentAttache.setTypeDocGDN(conf.getCodeTypeDocumentContestation());

				return documentAttache;
			}).collect(Collectors.toList()));
		}

		ContestationEntity contestationEntity = ContestationMapper.mapModelEntityToJpaEntity(contestation);
		final StatutDossierContestation dernierStatutDossier = contestation.getDernierStatutDossier();
		//FIXME throw exception if that come
		StatutDossierContestationSelfCare statut = null;
		if(dernierStatutDossier != null) {
			statut = statutDossierContestationJpaRepository.findStatutDossierContestationByCodeStatut(dernierStatutDossier.getCodeStatut());
		}

		String numeroTel = contestation.getNumeroTel();

		/**
		 * si l'utilisateur a modifié son numero de telephone on persiste celui qu'il a saisie
		 * si non on recupère ses infos dans la table contact personne
		 */
		Boolean topNumeroTelModifie = contestation.getTopNumeroTelModifie();
		if(topNumeroTelModifie !=null && topNumeroTelModifie.booleanValue()){
			contestationEntity.setTelephone(numeroTel);
			contestationEntity.setPhoneCountryCode("+33");
		}else{
			PersonContactEntity personne = personJpa.findByPhoneNumberId(numeroTel);
			if(personne !=null){
				contestationEntity.setTelephone(personne.getPhoneNumber());
				contestationEntity.setPhoneCountryCode(personne.getCountryCode());
			}
		}
		/**
		 * si l'utilisateur a modifié son mail, on persiste celui qu'il a saisie
		 * si non on recupère ses infos dans la table contact personne
		 */
		String mail = contestation.getMail();
		Boolean topMailModifie = contestation.getTopMailModifie();
		if(topMailModifie !=null && topMailModifie.booleanValue()){
			contestationEntity.setMail(mail);
		}else{
			PersonContactEntity personne = personJpa.findByMailId(mail);
			if(personne !=null){
				contestationEntity.setMail(personne.getMailUserName()+"@"+personne.getMailDomain());
			}

		}

		// statut must be retrieved from database using its code
		if(statut != null){
			contestationEntity.setDernierStatutDossier(statut);
		}

		final MotifContestation motif = contestation.getMotif();
		if(motif != null) {
			Optional<MotifEntity> motifEntity = motifRepository.findById(motif.getCode());
			if(motifEntity.isPresent()) {
				contestationEntity.setMotifContestation(motifEntity.get());
			}
		}
		final CartePorteur cartePorteur = contestation.getCarte();

		//FIXME throw exception if it comes to happen
		if(cartePorteur != null) {
			contestationEntity.setNumCompte(cartePorteur.getNumCompte());
			CarteEntity carte = new CarteEntity();
			carte.setDateExpiration(cartePorteur.getDateFinValiditeInput());
			carte.setNumeroCarte(cartePorteur.getNumCarteInput());
			carte.setTypeCarte(cartePorteur.getTypeProduit());
			//TODO EtatCarteEntity is a table : carte.setEtatCarte(cartePorteur.getStatutCarteInput());
			carte.setDateOpposition(cartePorteur.getDatOppositionInput());
			carte.setMotifOpposition(cartePorteur.getCodeMotifOpposition());
			contestationEntity.setCarte(carte);
		}

		final ContestationEntity contestationEntitySaved = this.contestationJpaRepository.save(contestationEntity);

		Contestation contestationSaved = ContestationMapper.mapJpaEntityToModelEntity(contestationEntitySaved);
		if(contestationSaved !=null){
			contestationSaved.setTopMailModifie(topMailModifie);
			contestationSaved.setTopNumeroTelModifie(topNumeroTelModifie);
		}

		return contestationSaved;
	}

	@Override
	public boolean isAuthorized(String idGdn, String idTelematic) {
		boolean isauthorized = false;
		List<ContestationEntity> contestations = contestationJpaRepository.findByIdTelematicAndIdGdn(idTelematic, idGdn);

		if(!CollectionUtils.isEmpty(contestations)){
			isauthorized = true;
			LOG.info("L'utilisateur ayant l'idTelematic :"+idTelematic+" est propriétaire du document ayant l'idGdn :"+idGdn);
		}else{
			LOG.error("L'utilisateur ayant l'idTelematic :"+idTelematic+" n'est pas propriétaire du document ayant l'idGdn :"+idGdn);
		}
		return isauthorized;
	}

	@Override
	public boolean isPurged(List<String> numeroDossiers) throws ContestationException {

		try{
			List<ContestationEntity> contestationEntities = numeroDossiers.stream().map(id -> {
				ContestationEntity contestationEntity =contestationJpaRepository.findByNumDossierSMC(id);

				if(contestationEntity !=null){
					contestationEntity.setPurged(new Boolean(true));
				}

				LOG.info("Le dossier numero :"+id+" est il purgé ? : "+contestationEntity.getPurged());
				return contestationEntity;

			}).collect(Collectors.toList());

			if(!CollectionUtils.isEmpty(contestationEntities)){
				contestationEntities = contestationJpaRepository.saveAll(contestationEntities);
			}else{
				throw new ContestationException(conf.getMessageNotFoundContestaionByFolderNumber());
			}

			return true;
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
			throw new ContestationException(conf.getMessageNotFoundContestaionByFolderNumber());
		}

	}


	/**
	 * recuperer une contestation identifiée par sa référence dossier SMC
	 *
	 * @param referenceDossier : la reference du dossier de contestattion dans Smart Contestation
	 */
	@Override
	public Contestation recupererContestation(String referenceDossier) throws ContestationException{

		ContestationEntity contestationEntity = contestationJpaRepository.findByNumDossierSMC(referenceDossier);

		if(contestationEntity == null  ){
			throw new ContestationException(conf.getMessageNotFoundContestaionByFolderNumber());
		}
		return ContestationMapper.mapJpaEntityToModelEntity(contestationEntity);
	}




	@Override
	public Contestation recupererContestationByIdInterne(String idContestation)
			throws ContestationException {
		DefaultEntityId id = new DefaultEntityId(idContestation);
		Optional<ContestationEntity> contestationOptional = contestationJpaRepository.findById(id);

		if(contestationOptional !=null && contestationOptional.isPresent()){
			ContestationEntity contestationEntity = contestationOptional.get();

			if(contestationEntity !=null){
				return ContestationMapper.mapJpaEntityToModelEntity(contestationEntity);
			}else{
				throw new ContestationException(conf.getMessageNotFoundContestaionByIdentifier());
			}
		}else{
			throw new ContestationException(conf.getMessageNotFoundContestaionByIdentifier());
		}
	}

	@Override
	public List<Contestation> recupererContestationsClient(String identifiant,Integer offset,Integer limit) throws ContestationException{
		int start = offset.intValue();

		int max = (limit.intValue() + start);

		List<Contestation> constestations = null;
		List<ContestationEntity> contestationEntities = contestationJpaRepository.findByIdTelematiqueOrderByDateMajDesc(identifiant);

		int nombreDecontestationsTotal = (contestationEntities.size() - 1);

		if (contestationEntities == null || contestationEntities.isEmpty()) {
			throw new ContestationException(conf.getMessageNotFoundContestaionByTelematicId());
		}else{
			constestations = IntStream.range(start, max).filter(i -> i <= nombreDecontestationsTotal).mapToObj(i -> ContestationMapper.mapJpaEntityToModelEntity(contestationEntities.get(i)))
					.collect(Collectors.toList());
		}
		return constestations;
	}

	@Override
	public Contestation updateContestation(Contestation contestation) {

		Contestation contestationSaved = null;
		if (contestation !=null) {

			String idContestation = contestation.getIdContestation();

			if(!StringUtils.isEmpty(idContestation)){
				DefaultEntityId id = new DefaultEntityId(idContestation);
				Optional<ContestationEntity> contestationOptional = contestationJpaRepository
						.findById(id);

				if (contestationOptional != null && contestationOptional.isPresent()) {
					ContestationEntity contestationEntity = contestationOptional.get();
					String numDossierSMC = contestation.getNumDossierSMC();

					/**
					 * mis a jour du numéro de dossier
					 */
					if(!StringUtils.isEmpty(numDossierSMC)) {
						contestationEntity.setNumDossierSMC(numDossierSMC);
					}

					LocalDateTime dateCreationDossierSMC = contestation.getDateDeCreationDossier();

					contestationEntity.setDateCreationDossierSMC(dateCreationDossierSMC);


					List<DocumentAttache> documentAttaches = contestation.getDocumentAttaches();

					if(!CollectionUtils.isEmpty(documentAttaches)){


						documentAttaches.stream().forEach(document -> {

							DocumentAttacheEntity documentAttacheEntity = new DocumentAttacheEntity();

							BeanUtils.copyProperties(document, documentAttacheEntity);
							documentAttacheEntity.setTypeDocGDN(conf.getCodeTypeDocumentContestation());
							documentAttacheEntity.setReferenceDossierSMC(numDossierSMC);
							contestationEntity.addDocumentAttach(documentAttacheEntity);
						});

					}



					/**
					 * Enregistrement de la modification
					 */
					ContestationEntity contestationEntitySaved = contestationJpaRepository.save(contestationEntity);
					if (contestationEntitySaved != null) {
						contestationSaved = ContestationMapper.mapJpaEntityToModelEntity(contestationEntitySaved);
					}


				}
			}



		}

		return contestationSaved;
	}
}
