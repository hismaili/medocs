package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smctocontacts.goal.*;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.goal.AdresseMail;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.goal.InfoPersonWs;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.goal.ReferentielPersonneException;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.response.ErrorsRP;
import com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm.response.InfoPersonneGlobalResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author c65344
 */
@Component
public class InfoPersonneImpl implements IinfoPersonne {
	private static final Logger LOG = LoggerFactory.getLogger(InfoPersonneImpl.class);

	private static final int NUMBERDAYSVALID = 7;

	private static boolean validMail(AdresseMail adresseMail) {
		return "O".equals(adresseMail.getIndiceValidite());//remplacement de 1 par 0 d'après la doc RP
	}

	@Autowired(required=false)
	private transient InfoPersonWs infoPersonRP;

	@Autowired(required=false)
	private transient InFoTelWs inFoTelWs;
	@Autowired(required=false)
	private transient InFoPersonneMapper map;
	@Autowired(required=false)
	private transient ConfigInfrastructure conf;

	@Autowired(required=false)
	private transient PersonContactJpaRepository jpaPersonneContact;

	@Autowired(required=false)
	private transient InfoContactsParameters configZosPhoneNumber;

	/**
	 * crée ou fait un update des info de contact en base de donnée selon que PersonContactEntity soit null ou pas
	 *
	 * @param iKpi
	 * @param telematicId
	 * @param personContact
	 * @return
	 * @throws PorteurException
	 */
	private PersonContactInfo getInfoContact(String iKpi,String telematicId,PersonContactEntity personContact) throws PorteurException{
		PersonContactEntity personContactEntity = personContact;
		PersonContactInfo personContactInfo =null;
		HolderMail holderMail = null;
		HolderPhoneNumber holderPhoneNumber =null;
		String mailId = UUID.randomUUID().toString();
		String phoneNumberId = UUID.randomUUID().toString();

		if (StringUtils.isEmpty(iKpi)) {
			LOG.error(conf.getMessageIkpiAbsent());
			throw new PorteurException(conf.getMessageErrorTechnique());
		}

		try {

			final InfoPersonneGlobalResponse infoPersonne = infoPersonRP.getInfoPersonne(iKpi);
			if(infoPersonne != null){
				ErrorsRP error = infoPersonne.getError();
				if(error ==null){

					final List<AdresseMail> adressesMail = infoPersonne.getAdressesMails();
					if(!CollectionUtils.isEmpty(adressesMail)){
						List<HolderMail> mailsValides = adressesMail.stream().filter(InfoPersonneImpl::validMail).map(validMail -> {
							HolderMail holdermail = new HolderMail();
							holdermail.setMailUserName(validMail.getMailLigne1());
							holdermail.setMailDomain(validMail.getMailLigne2());
							return holdermail;
						}).collect(Collectors.toList());

						if (CollectionUtils.isEmpty(mailsValides)) {
							LOG.error("Aucun Mail Valide pour l'utilisateur " + iKpi);
						} else if (mailsValides.size() >= 1) {
							if(mailsValides.size() > 1){
								LOG.error("Plusieurs Mails Valides trouvés pour l'utilisateur " + iKpi);
							}

							if(personContactEntity == null){
								personContactEntity = new PersonContactEntity();
								personContactEntity.setUserId(iKpi);
								personContactEntity.setTelematicId(telematicId);
							}

							if(personContactInfo == null){
								personContactInfo = new PersonContactInfo();
							}

							holderMail = mailsValides.get(0);

							/**
							 * construction pour la persistence
							 */
							personContactEntity.setMailDomain(holderMail.getMailDomain());
							personContactEntity.setMailUserName(holderMail.getMailUserName());
							personContactEntity.setMailId(mailId);

							/**
							 * construction pour le bean retour
							 */
							holderMail.setMailId(mailId);
							personContactInfo.setHolderMail(holderMail);
						}
					}else{
						LOG.error("Aucun Mail trouvé pour l'utilisateur " + iKpi);
					}
				}else{
					LOG.error("Aucun Mail trouvé pour l'utilisateur ayant l'ikpi : " + iKpi+", code error : "+error.getCodeError()+", message error "+error.getMessageError());
				}
			}

			final NumeroTelephone phoneNumber = inFoTelWs.getPhoneNumber(telematicId);

			//final NumeroTelephone phoneNumber = mockPhoneNumbers(iKpi);


			if(phoneNumber !=null && !StringUtils.isEmpty(phoneNumber.getNumeroTelephone())){
				final ErrorContacts error = phoneNumber.getError();
				if(error ==null){
					holderPhoneNumber = new HolderPhoneNumber();


					if(personContactEntity == null){
						personContactEntity = new PersonContactEntity();
						personContactEntity.setUserId(iKpi);
						personContactEntity.setTelematicId(telematicId);
					}

					if(personContactInfo == null) {
						personContactInfo = new PersonContactInfo();
					}
					/**
					 * construction pour la persistence
					 */
					final String indicatifInternational = phoneNumber.getIndicatifInternational();
					final String numeroTelephone = phoneNumber.getNumeroTelephone();

					personContactEntity.setCountryCode(indicatifInternational);
					personContactEntity.setPhoneNumber(numeroTelephone);
					personContactEntity.setPhoneNumberId(phoneNumberId);

					/**
					 * construction pour le bean retour
					 */
					holderPhoneNumber.setPhoneNumberId(phoneNumberId);
					holderPhoneNumber.setCountryCode(indicatifInternational);
					holderPhoneNumber.setPhoneNumber(numeroTelephone);
					personContactInfo.setHolderPhoneNumber(holderPhoneNumber);
				}else{
					LOG.error("Aucun numéro de téléphone trouvé pour l'utilisateur " + iKpi+", code anomalie : "+error.getCodeAnomalie()+", code retour : "+error.getCodeRetour()+", message"+error.getLabelAnomale());
				}
			}else{
				LOG.error("Aucun numéro de téléphone trouvé pour l'utilisateur " + iKpi);
			}



			if(personContactEntity !=null){
				PersonContactEntity personeContact = jpaPersonneContact.save(personContactEntity);
			}

		} catch (ReferentielPersonneException e) {
			LOG.error(e.getMessage(),e);
			throw new PorteurException(conf.getMessageErrorTechnique());
		} catch (ReferentielContactsException e) {
			LOG.error(e.getMessage(),e);
			throw new PorteurException(conf.getMessageErrorTechnique());
		}

		if(personContactInfo == null){
			LOG.error("Aucun contact utilisateur trouvé pour le client recherché");
		}

		return personContactInfo;
	}

	/**
	 * recupère les informations personne de RP
	 */
	@Override
	public InfoPersonneOutput getInfoPersonneRP(String iKpi) throws PorteurException {
		if (iKpi != null && !(iKpi.isEmpty())) {

			InfoPersonneGlobalResponse infoPersonne;
			try {
				infoPersonne = infoPersonRP.getInfoPersonne(iKpi);
				if (infoPersonne != null) {

					if (infoPersonne.getError() == null) {
						return map.mapInfoPersonneGlobalToInfoPersonneOutput(infoPersonne);
					} else {
						LOG.error("Aucun utilisateur trouvé dans RP pour L'IKPI : "+iKpi);
						LOG.error("codeRP : " + infoPersonne.getError().getCodeError() + " ,  MessageRP" + infoPersonne.getError().getMessageError());

						throw new PorteurException(conf.getMessageErrorTechnique());
					}
				} else {
					LOG.error(conf.getReponseNullRP());
					throw new PorteurException(conf.getMessageErrorTechnique());
				}

			} catch (ReferentielPersonneException e) {
				LOG.error(e.getMessage(), e);
				throw new PorteurException(conf.getMessageErrorTechnique());
			}
		} else {
			LOG.error(conf.getMessageIkpiAbsent());
			throw new PorteurException(conf.getMessageErrorTechnique());
		}
	}



	@Override
	public PersonContactInfo getPersonContactInfos(String iKpi,String telematicId) throws PorteurException {
		PersonContactEntity personContactEntity = null;
		PersonContactInfo personContactInfo = null;

		HolderMail holderMail = null;
		HolderPhoneNumber holderPhoneNumber =null;

		String mailId = null;

		String phoneNumberId = null;
		personContactEntity = jpaPersonneContact.findByTelematicIdAndUserId(telematicId, iKpi);

		if(personContactEntity !=null ){

			LocalDateTime dateMaj = personContactEntity.getDateMaj();


			if(dateMaj !=null && dateMaj.plusDays(NUMBERDAYSVALID).isBefore(LocalDateTime.now())){
				personContactInfo =	getInfoContact(iKpi, telematicId, personContactEntity);
			}else{
				holderMail = new HolderMail();
				holderPhoneNumber = new HolderPhoneNumber();

				personContactInfo = new PersonContactInfo();

				mailId = personContactEntity.getMailId();
				if(!StringUtils.isEmpty(mailId)){
					holderMail.setMailDomain(personContactEntity.getMailDomain());
					holderMail.setMailId(mailId);
					holderMail.setMailUserName(personContactEntity.getMailUserName());
					personContactInfo.setHolderMail(holderMail);
				}else{
					LOG.error("Aucun Mail trouvé pour l'utilisateur " + iKpi);
				}

				phoneNumberId = personContactEntity.getPhoneNumberId();
				if(!StringUtils.isEmpty(phoneNumberId)){
					holderPhoneNumber.setCountryCode(personContactEntity.getCountryCode());
					holderPhoneNumber.setPhoneNumber(personContactEntity.getPhoneNumber());
					holderPhoneNumber.setPhoneNumberId(phoneNumberId);
					holderPhoneNumber.setRegionCode(personContactEntity.getRegionCode());
					personContactInfo.setHolderPhoneNumber(holderPhoneNumber);
				}else{
					LOG.error("Aucun numéro de téléphone trouvé pour l'utilisateur " + iKpi);
				}

			}

		}else{
			personContactInfo =	getInfoContact(iKpi, telematicId, personContactEntity);
		}

		return personContactInfo;
	}

	/**
	 *
	 * @param idTelematic
	 * @return
	 */
	private NumeroTelephone mockPhoneNumbers(String idTelematic) {
		NumeroTelephone phoneNumber = null;
		if ("3610838481".equals(idTelematic)) {
			phoneNumber = new NumeroTelephone();
			phoneNumber.setIndicatifInternational("+33");
			phoneNumber.setNumeroTelephone("566521485");

		} else if ("01630005685900000".equals(idTelematic)) {
			phoneNumber = new NumeroTelephone();
			phoneNumber.setIndicatifInternational("+33");
			phoneNumber.setNumeroTelephone("566521485");
		}
		return phoneNumber;
	}

}
