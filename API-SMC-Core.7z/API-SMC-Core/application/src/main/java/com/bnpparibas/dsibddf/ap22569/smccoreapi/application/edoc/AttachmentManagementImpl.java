/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edoc;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.edoc.IserviceEdoc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author c65344
 *
 */
@Service
public class AttachmentManagementImpl implements IAttachmentManagement {
	@Autowired
	private transient IserviceEdoc edoc;
	/* (non-Javadoc)
	 * @see com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edoc.IAttachmentManagement#getIdGn(java.lang.String)
	 */
	@Override
	public String getIdGn(String idAttachment) {
		// TODO Auto-generated method stub
		return edoc.getIdGn(idAttachment);
	}

}
