package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

/**
 * @author 472957
 *
 */
@SpringBootConfiguration
@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons","com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal","com.bnpparibas.dsibddf.ap22569.smccoreapi", "com.bnpparibas.dsibddf.ap22569.smctogdnapi","com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm","com.bnpparibas.dsibddf.ap22569.smctobcmp",
		"com.bnpparibas.dsibddf.ap22569.smccoreapi.application","com.bnpparibas.dsibddf.ap22569.smctoeditique.service","com.bnpparibas.dsibddf.ap22569.smctoeditique.service.builder","com.bnpparibas.dsibddf.ap22569.smctoeditique.commons","com.bnpparibas.dsibddf.ap22569.smctoeditique.model.conf","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration",
"com.bnpparibas.dsibddf.ap22569.accounts"}, lazyInit = true)
public class SpringBootApp {

	@Autowired
	private Environment env;


	/**
	 * @param args
	 */
	public static void main(final String[] args) {

		SpringApplication.run(SpringBootApp.class, args);
	}


	@Bean("simpleresttemplate")
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}


	/*

	public DataSourceInitializer dsIntializer(DataSource dataSource) {
		DataSourceInitializer dsInit = new DataSourceInitializer();
		dsInit.setDataSource(dataSource);
		DatabasePopulator dsPopulator = new DatabasePopulator() {
			@Override
			public void populate(Connection connection) throws SQLException, ScriptException {

			}
		};
		dsInit.setDatabasePopulator(dsPopulator);
		return dsInit;
	}
	 */


}