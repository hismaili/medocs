/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.util.List;

/**
 * @author c65344
 *
 */
public class SmcResponseError {
	List<SmcApiError> errors;

	/**
	 *
	 */
	public SmcResponseError() {
		super();

	}

	/**
	 * @param errors
	 */
	public SmcResponseError(List<SmcApiError> errors) {
		this.errors = errors;
	}

	/**
	 * @return the errors
	 */
	public List<SmcApiError> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<SmcApiError> errors) {
		this.errors = errors;
	}
}
