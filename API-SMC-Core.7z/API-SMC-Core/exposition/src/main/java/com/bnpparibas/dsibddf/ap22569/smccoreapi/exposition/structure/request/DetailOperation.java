package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * DetailOperation
 */

public class DetailOperation   {
	@ApiModelProperty(value = "dateCompensation")
	private String dateCompensation;

	@ApiModelProperty(value = "raisonSociale")
	private String raisonSociale;

	@ApiModelProperty(value = "dateVente")
	private String dateVente;

	@ApiModelProperty(value = "MontantImpute")
	@JsonProperty("MontantImpute")
	private BigDecimal montantImpute;

	/**
	 *
	 */
	public DetailOperation() {
		super();

	}

	/**
	 * @param dateCompensation
	 * @param raisonSociale
	 * @param dateVente
	 * @param montantImpute
	 */
	public DetailOperation(String dateCompensation, String raisonSociale,
			String dateVente, BigDecimal montantImpute) {
		this.dateCompensation = dateCompensation;
		this.raisonSociale = raisonSociale;
		this.dateVente = dateVente;
		this.montantImpute = montantImpute;
	}

	/**
	 * @return the dateCompensation
	 */
	public String getDateCompensation() {
		return dateCompensation;
	}

	/**
	 * @return the dateVente
	 */
	public String getDateVente() {
		return dateVente;
	}

	/**
	 * @return the montantImpute
	 */
	public BigDecimal getMontantImpute() {
		return montantImpute;
	}

	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}

	/**
	 * @param dateCompensation the dateCompensation to set
	 */
	public void setDateCompensation(String dateCompensation) {
		this.dateCompensation = dateCompensation;
	}

	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(String dateVente) {
		this.dateVente = dateVente;
	}

	/**
	 * @param montantImpute the montantImpute to set
	 */
	public void setMontantImpute(BigDecimal montantImpute) {
		this.montantImpute = montantImpute;
	}

	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}


}

