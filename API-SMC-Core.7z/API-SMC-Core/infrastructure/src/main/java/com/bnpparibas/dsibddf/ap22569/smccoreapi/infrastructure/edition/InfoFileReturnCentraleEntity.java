/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;


/**
 * @author c65344
 *
 */
@Entity
@Table(name = "INFO_DOCUMENT_RETOUR_EDITIQUE")
public class InfoFileReturnCentraleEntity{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private String idFileArchivage;
	@Column
	private LocalDateTime dateFlux;
	@Column
	private String codeAppEmetrice;
	@Column
	private String fluxName;
	@Column
	private int numSequence;
	@Column
	private Integer recordNumber;
	/**
	 * @return the codeAppEmetrice
	 */
	public String getCodeAppEmetrice() {
		return codeAppEmetrice;
	}
	/**
	 * @return the dateFlux
	 */
	public LocalDateTime getDateFlux() {
		return dateFlux;
	}
	/**
	 * @return the fluxName
	 */
	public String getFluxName() {
		return fluxName;
	}
	/**
	 * @return the idFileArchivage
	 */
	public String getIdFileArchivage() {
		return idFileArchivage;
	}
	/**
	 * @return the numSequence
	 */
	public int getNumSequence() {
		return numSequence;
	}
	/**
	 * @return the recordNumber
	 */
	public Integer getRecordNumber() {
		return recordNumber;
	}
	/**
	 * @param codeAppEmetrice the codeAppEmetrice to set
	 */
	public void setCodeAppEmetrice(String codeAppEmetrice) {
		this.codeAppEmetrice = codeAppEmetrice;
	}
	/**
	 * @param dateFlux the dateFlux to set
	 */
	public void setDateFlux(LocalDateTime dateFlux) {
		this.dateFlux = dateFlux;
	}
	/**
	 * @param fluxName the fluxName to set
	 */
	public void setFluxName(String fluxName) {
		this.fluxName = fluxName;
	}
	/**
	 * @param idFileArchivage the idFileArchivage to set
	 */
	public void setIdFileArchivage(String idFileArchivage) {
		this.idFileArchivage = idFileArchivage;
	}
	/**
	 * @param numSequence the numSequence to set
	 */
	public void setNumSequence(int numSequence) {
		this.numSequence = numSequence;
	}
	/**
	 * @param recordNumber the recordNumber to set
	 */
	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

}
