/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author c65344
 *
 */


@Configuration
@PropertySource(value = "classpath:messages.properties", encoding="ISO-8859-1")
public class ConfigExposition {
	@Value("${CODE_OR_MOUNT_OPE_ABSENT}")
	private String codeOrMountOpeAbsent;

	/**
	 * usertype de selfCare
	 */
	@Value("${USER_TYPE_SELFCARE}")
	private String userTypeSelfCare;
	/**
	 * just for test
	 */
	@Value("${CHANNEL_EDOC}")
	private String channelEdoc;

	@Value("${USERID_EDOC}")
	private String userIdEdoc;

	@Value("${MEDIA_EDOC}")
	private String mediaEdoc;
	/**
	 * uniquement pour les tests unitaire
	 */
	@Value("${URL_POST_EDOC}")
	private String urlPostEdoc;

	/**
	 * mandatory absent selfcare
	 *
	 */

	@Value("${REASON_ABSENT}")
	private String reasonAbsent;

	@Value("${CARDID_ABSENT}")
	private String cardIdAbsent;

	@Value("${OPERATIONS_ABSENT}")
	private String operationsAbsent;
	@Value("${APPLICATION_CODE_ABSENT}")
	private String applicationCodeAbsent;
	@Value("${USER_ID_ABSENT}")
	private String userIdAbsent;
	/**
	 *
	 * Nouvelle données edition
	 */
	@Value("${RAISON_SOCIALE.ABSENT}")
	private String raisonSocialeAbsent;
	@Value("${DATE_TRAITEMENT.ABSENT}")
	private String dateTraitementAbsent;
	@Value("${ID_USER.ABSENT}")
	private String idUserAbsent;
	@Value("${QUALIFICATION_DOSSIER.ABSENT}")
	private String qualificationDossierAbsent;
	@Value("${NATURE_DOSSIER.ABSENT}")
	private String natureDossierAbsent;
	@Value("${NATURE_DOSSIER_LIBELLE.ABSENT}")
	private String natureDossierLibelleAbsent;

	@Value("${NUM_DOSSIER.ABSENT}")
	private String numDossierAbsent;


	@Value("${DATE_APPEL.ABSENT}")
	private String dateAppelAbsent;

	@Value("${TELEPHONE_EMET.ABSENT}")
	private String telephoneEmetAbsent;

	@Value("${EMAIL_EMET.ABSENT}")
	private String emailEmetAbsent;
	@Value("${DELAIS_REPONSE.ABSENT}")
	private String delaisReponseAbsent;
	@Value("${DATE_OPPOSITION.ABSENT}")
	private String dateOppositionAbsent;
	@Value("${TOTAL_OPERATIONS.ABSENT}")
	private String totalOperationsAbsent;

	@Value("${CODE_CHEFDEFILEEMET.ABSENT}")
	private String codeChefdefileemetAbsent;
	@Value("${CONTACT_EMET.ABSENT}")
	private String contactEmetAbsent;
	@Value("${FAX_EMET.ABSENT}")
	private String faxEmetAbsent;

	@Value("${CODE_CHEFDEFILEDEST.ABSENT}")
	private String codeChefdefiledestAbsent;
	@Value("${CONTACT_DEST.ABSENT}")
	private String contactDestAbsent;
	@Value("${TELEPHONE_DEST.ABSENT}")
	private String telephoneDestAbsent;
	@Value("${FAX_DEST.ABSENT}")
	private String faxDestAbsent;
	@Value("${EMAIL_DEST.ABSENT}")
	private String emailDestAbsent;
	@Value("${TYPE_OPERATION.ABSENT}")
	private String typeOperationAbsent;

	@Value("${CODEBANQUE_MEMPRACC.ABSENT}")
	private String codebanqueMempraccAbsent;
	@Value("${CODEBANQUE_DOM.ABSENT}")
	private String codebanqueDomAbsent;
	@Value("${NUM_DISTRIBUTEUR.ABSENT}")
	private String numDistributeurAbsent;

	@Value("${LOC_DEPART.ABSENT}")
	private String locDepartAbsent;
	@Value("${CODEBANQUE_MEMPRTIT.ABSENT}")
	private String codebanqueMemprtitAbsent;
	@Value("${NUM_CARTE_MASQUE.ABSENT}")
	private String numCarteMasqueAbsent;
	@Value("${CODE_MOTIFIPAYE.ABSENT}")
	private String codeMotifipayeAbsent;
	@Value("${MONTANT_COMPENSE.ABSENT}")
	private String montantCompenseAbsent;
	@Value("${DATEHEURE_TRANSACTION.ABSENT}")
	private String dateheureTransactionAbsent;
	@Value("${DATE_REGLMNTINITIAL.ABSENT}")
	private String dateReglmntinitialAbsent;
	@Value("${AUTRES_DONNEES.ABSENT}")
	private String autresDonneesAbsent;
	@Value("${TYPE_REGLMNTSOUHAITE.ABSENT}")
	private String typeReglmntsouhaiteAbsent;
	@Value("${NUM_SIRET.ABSENT}")
	private String numSiretAbsent;
	@Value("${CODE_APE.ABSENT}")
	private String codeApeAbsent;
	@Value("${DATE_RGLMNTIMPAYE.ABSENT}")
	private String dateRglmntimpayeAbsent;
	@Value("${DATE_RGLMNTREPRES.ABSENT}")
	private String dateRglmntrepresAbsent;
	@Value("${REFERENCE_ARCHIVAGE.ABSENT}")
	private String referenceArchivageAbsent;
	@Value("${MONTANT_BRUT.ABSENT}")
	private String montantBrutAbsent;
	@Value("${NUM_CLIENT.ABSENT}")
	private String numClientAbsent;
	@Value("${DATE_CREATION.ABSENT}")
	private String dateCreationAbsent;
	@Value("${MONTANT_CONTESTE.ABSENT}")
	private String montantContesteAbsent;
	@Value("${NOMBRE_OPERATIONS.ABSENT}")
	private String nombreOperationsAbsent;
	@Value("${_TAB_HEADER.ABSENT}")
	private String tabHeaderAbsent;
	@Value("${_TAB_PS.ABSENT}")
	private String tabPsAbsent;
	@Value("${_TAB_CONTEST.ABSENT}")
	private String tabContestAbsent;
	@Value("${_TAB_COMMENTAIRES.ABSENT}")
	private String tabCommentairesAbsent;
	@Value("${EDITION.TOP_CLIENTELE.ABSENT}")
	private String topClienteleAbsent;
	@Value("${EDITION.NOM_PORTEUR.ABSENT}")
	private String nomPorteurAbsent;
	@Value("${EDITION.PRENOM_PORTEUR.ABSENT}")
	private String prenomPorteurAbsent;
	@Value("${EDITION.DATE_OPPOSITION.ABSENT}")
	private String dateOppositionabsent;
	/**
	 * Verification de la longueur des données
	 */

	@Value("${NOMBRE_DE_LIGNE_INCORRECT}")
	private String nombreDeLigneIncorect;
	@Value("${LONGUEUR_DE_LIGNE_INCORRECT}")
	private String nombreDeCaractereDeLigneIncorrect;
	@Value("${RAISON_SOCIALE.INCORRECTE}")
	private String raisonSocialeIncorrect;
	@Value("${DATE_TRAITEMENT.INCORRECTE}")
	private String dateTraitementIncorrect;
	@Value("${ID_USER.INCORRECTE}")
	private String idUserIncorrect;
	@Value("${QUALIFICATION_DOSSIER.INCORRECTE}")
	private String qualificationDossierIncorrect;
	@Value("${NATURE_DOSSIER.INCORRECTE}")
	private String natureDossierIncorrect;
	@Value("${NATURE_DOSSIER_LIBELLE.INCORRECTE}")
	private String natureDossierLibelleIncorrect;
	@Value("${NUM_DOSSIER.INCORRECTE}")
	private String numDossierIncorrect;
	@Value("${DATE_APPEL.INCORRECTE}")
	private String dateAppelIncorrect;
	@Value("${TELEPHONE_EMET.INCORRECTE}")
	private String telephoneEmetIncorrect;
	@Value("${EMAIL_EMET.INCORRECTE}")
	private String emailEmetIncorrect;
	@Value("${DELAIS_REPONSE.INCORRECTE}")
	private String delaisReponseIncorrect;
	@Value("${TOTAL_OPERATIONS.INCORRECTE}")
	private String totalOperationsIncorrect;
	@Value("${CODE_CHEFDEFILEEMET.INCORRECTE}")
	private String codeChefdefileemetIncorrect;
	@Value("${CONTACT_EMET.INCORRECTE}")
	private String contactEmetIncorrect;
	@Value("${FAX_EMET.INCORRECTE}")
	private String faxEmetIncorrect;
	@Value("${CODE_CHEFDEFILEDEST.INCORRECTE}")
	private String codeChefdefiledestIncorrect;
	@Value("${CONTACT_DEST.INCORRECTE}")
	private String contactDestIncorrect;
	@Value("${TELEPHONE_DEST.INCORRECTE}")
	private String telephoneDestIncorrect;
	@Value("${FAX_DEST.INCORRECTE}")
	private String faxDestIncorrect;
	@Value("${EMAIL_DEST.INCORRECTE}")
	private String emailDestIncorrect;
	@Value("${TYPE_OPERATION.INCORRECTE}")
	private String typeOperationIncorrect;
	@Value("${CODEBANQUE_MEMPRACC.INCORRECTE}")
	private String codebanqueMempraccIncorrect;
	@Value("${CODEBANQUE_DOM.INCORRECTE}")
	private String codebanqueDomIncorrect;
	@Value("${NUM_DISTRIBUTEUR.INCORRECTE}")
	private String numDistributeurIncorrect;
	@Value("${LOC_DEPART.INCORRECTE}")
	private String locDepartIncorrect;
	@Value("${CODEBANQUE_MEMPRTIT.INCORRECTE}")
	private String codebanqueMemprtitIncorrect;
	@Value("${NUM_CARTE_MASQUE.INCORRECTE}")
	private String numCarteMasqueIncorrect;
	@Value("${CODE_MOTIFIPAYE.INCORRECTE}")
	private String codeMotifipayeIncorrect;
	@Value("${MONTANT_COMPENSE.INCORRECTE}")
	private String montantCompenseIncorrect;
	@Value("${DATEHEURE_TRANSACTION.INCORRECTE}")
	private String dateheureTransactionIncorrect;
	@Value("${DATE_REGLMNTINITIAL.INCORRECTE}")
	private String dateReglmntinitialIncorrect;
	@Value("${AUTRES_DONNEES.INCORRECTE}")
	private String autresDonneesIncorrect;
	@Value("${TYPE_REGLMNTSOUHAITE.INCORRECTE}")
	private String typeReglmntsouhaiteIncorrect;
	@Value("${NUM_SIRET.INCORRECTE}")
	private String numSiretIncorrect;
	@Value("${CODE_APE.INCORRECTE}")
	private String codeApeIncorrect;
	@Value("${DATE_RGLMNTIMPAYE.INCORRECTE}")
	private String dateRglmntimpayeIncorrect;
	@Value("${DATE_RGLMNTREPRES.INCORRECTE}")
	private String dateRglmntrepresIncorrect;
	@Value("${REFERENCE_ARCHIVAGE.INCORRECTE}")
	private String referenceArchivageIncorrect;
	@Value("${MONTANT_BRUT.INCORRECTE}")
	private String montantBrutIncorrect;
	@Value("${NUM_CLIENT.INCORRECTE}")
	private String numClientIncorrect;
	@Value("${DATE_CREATION.INCORRECTE}")
	private String dateCreationIncorrect;
	@Value("${MONTANT_CONTESTE.INCORRECTE}")
	private String montantContesteIncorrect;
	@Value("${NOMBRE_OPERATIONS.INCORRECTE}")
	private String nombreOperationsIncorrect;
	@Value("${_TAB_HEADER.INCORRECTE}")
	private String tabHeaderIncorrect;
	@Value("${_TAB_PS.INCORRECTE}")
	private String tabPsIncorrect;
	@Value("${_TAB_CONTEST.INCORRECTE}")
	private String tabContestIncorrect;
	@Value("${_TAB_COMMENTAIRES.INCORRECTE}")
	private String tabCommentairesIncorrect;
	@Value("${TOP_CLIENTELE.INCORRECTE}")
	private String topClienteleIncorrect;
	@Value("${QUALIFICATION_DOSSIER.INCORRECTE}")
	private String qualificationIncorrect;
	@Value("${NOM_PORTEUR.INCORRECTE}")
	private String nomPorteurIncorrect;
	@Value("${PRENOM_PORTEUR.INCORRECTE}")
	private String prenomPorteurIncorrect;
	@Value("${DATE_OPPOSITION.INCORRECTE}")
	private String dateOppositionIncorrect;
	//	@Value("${MESSAGE.TELEMATATICID.MANQUANTE}")
	//	private String identifiantInterneIncorect;
	@Value("${ERROR.GENERIQUE.CONTESTATION.NOTFOUND}")
	private String errorGeneriqueContestation;
	@Value("${ERROR.GDN.DONNE.CODEAPPLICATION.MANQUANTE}")
	private String codeApplicationAbsent;
	@Value("${CODE.ERROR.INTERNE.CONTESTATION}")
	private String codeErreurServiceContestation;
	@Value("${MESSAGE.TELEMATATICID.MANQUANTE}")
	private String telematicIdAbsent;
	@Value("${service.body.archivingContext.indexingData.publicationTop}")
	private String publicationTop;
	@Value("${service.closefolder.reponse.success}")
	private String reponseSuccessSecureDoc;
	@Value("${service.body.normLevel}")
	private  String normLevel;
	@Value("${service.body.storageLevel}")
	private  String storageLevel;
	@Value("${service.body.classificationNatureId}")
	private  String classificationNatureId;
	@Value("${service.body.owningApplication}")
	private  String owningApplication;
	@Value("${service.body.descriptiveContext.lotId}")
	private  String lotId;
	@Value("${service.body.descriptiveContext.lotLabel}")
	private  String lotLabel;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname1}")
	private  String indexname1;
	@Value("${service.body.descriptiveContext.indexingData.index.indexvalue1}")
	private String indexvalue1;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname2}")
	private String indexname2;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname3}")
	private String indexname3;
	@Value("${service.header.calling-application}")
	private String callingApplication;
	@Value("${service.body.archivingContext.indexingData.clientNatureId}")
	private String clientNatureId;
	@Value("${service.body.archivingContext.indexingData.clientName}")
	private String clientName;
	@Value("${service.body.archivingContext.indexingData.clientFirstname}")
	private String clientFirstname;
	@Value("${service.body.archivingContext.indexingData.birthDate}")
	private String birthDate;
	@Value("${service.body.archivingContext.indexingData.clientId}")
	private String clientId;
	@Value("${service.body.archivingContext.indexingData.sirenNumber}")
	private String sirenNumber;
	@Value("${service.body.archivingContext.indexingData.contractId}")
	private String contractId;
	@Value("${service.body.archivingContext.indexingData.contractIdTypeCode}")
	private String contractIdTypeCode;
	@Value("${service.body.archivingContext.indexingData.contractIdTypeLabel}")
	private String contractIdTypeLabel;
	@Value("${contestation.monetique.code.type.document}")
	private String codeTypeDocumentContestation;
	@Value("${justificatif.client.code.type.document}")
	private String codeTypeDocumentJustificatif;
	@Value("${message.error.type.document}")
	private String messageErrorIdTypeDocument;
	@Value("${message.purge.success}")
	private String messagePurgeSuccess;
	@Value("${CODE.CONTESTATION.NOTFOUND.ERROR}")
	private String codeNotFoundContestion;
	@Value("${MESSAGE.CONTESTATION.NOTFOUND.FOLDER.NUMBER}")
	private String folderNumberNotFound;
	@Value("${MESSAGE.IDCONTESTATIONSMC.MANQUANTE}")
	private String idContestationSmcAbsent;
	@Value("${MESSAGE.CONTESTATION.NOTFOUND.TELEMATICID}")
	private String telemataticIdNotFound;
	/**
	 * document non trouvé par identifiant interne
	 */
	@Value("${MESSAGE.CONTESTATION.NOTFOUND.FOLDER.IDENTIFIER}")
	private String identifierNotFound;
	@Value("${MESSAGE.CODE.STATUS.ABSENT}")
	private String messageDisputStatusAbsent;
	@Value("${MESSAGE.CODE.STATUS.INCORRECT}")
	private String messageDisputStatusIncorrect;
	@Value("${ERROR.GDN.DONNE.CALLINGUSER.MANQUANTE}")
	private String callingUserAbsent;
	/**
	 * config de la partie editique
	 */
	@Value("${EDITIQUE.FILE.TYPE}")
	private String editiqueFileType;
	@Value("${EDITIQUE.ENVIRONNEMENT}")
	private String environnement;
	@Value("${EDITIQUE.TYPE}")
	private String type;
	@Value("${EDITIQUE.FORMATSORTIE}")
	private String formatSortie;
	@Value("${EDITIQUE.APPLICATION}")
	private String application;
	@Value("${EDITIQUE.TRANSACTION}")
	private String transaction;
	@Value("${EDITIQUE.DESCRIPTION}")
	private String description;
	@Value("${EDITIQUE.TRACEXML}")
	private String traceXml;
	@Value("${EDITIQUE.TRACELOG}")
	private String traceLog;
	@Value("${EDITIQUE.IDOC}")
	private String idoc;
	@Value("${EDITIQUE.PRIORITE}")
	private String priorite;
	@Value("${EDITIQUE.SNEDATA.PARAGRAPHE}")
	private String lignepar;
	@Value("${EDITIQUE.SNEDATA.LIGNEPARTAB}")
	private String lignepartab;
	@Value("${EDITIQUE.SNEDATA.LIGNETAB}")
	private String lignetab;
	/**
	 *
	 */
	@Value("${EDITIQUE.SNEATTR.CTYPE}")
	private String ctype;
	@Value("${EDITIQUE.SNEATTR.LFORMAT}")
	private String lformat;
	@Value("${EDITIQUE.SNEATTR.CLANGUEKPI}")
	private String clanguekpi;
	@Value("${EDITIQUE.SNEATTR.SEPIALG}")
	private String sepialg;
	@Value("${EDITIQUE.SNEATTR.SEPIAML}")
	private String sepiaml;
	@Value("${EDITIQUE.SNETECH.TYPI}")
	private String typi;
	@Value("${MESSAGE.ERROR.TECHNIQUE}")
	private String messageErrorTechnique;
	@Value("${MESSAGE.CODEUO.ABSENT}")
	private String messageCodeUOAbsent;
	@Value("${MESSAGE.NUMEROPAN.ABSENT}")
	private String messageNumeroPanAbsent;
	@Value("${RP.IKPI.ABSENT}")
	private String messageIkpiAbsent;
	@Value("${MESSAGE.REPONSENULL.RP}")
	private String reponseNullRP;
	@Value("${ERROR.EDITION.REPONSE.INCORRECT}")
	private String reponseIncorect;
	@Value("${ERROR.GDN.REPONSE.INCORRECT}")
	private String reponseIncorectGDN;
	@Value("${COMMONS.PHRASE}")
	private String commonsPhrase;
	@Value("${RP.REPONSE.INCORRECT}")
	private String responseIncorectRP;
	@Value("${GDN.DOC.NO.SECURISED}")
	private String noSecurised;
	/**
	 * Les codes erreurs
	 */
	@Value("${CODE.ERROR.INTERNE.EDITION}")
	private String codeErreurServeurEdition;
	@Value("${CODE.ERROR.INTERNE.RP}")
	private String codeErreurServeurRP;
	@Value("${CODE.ERROR.INTERNE.REFO}")
	private String codeErreurServeurRefo;
	@Value("${CODE.ERROR.INTERNE.GDN}")
	private String codeErreurServeurGdn;
	@Value("${CODE.ERROR.INTERNE.BCMP}")
	private String codeErreurServeurBcmp;
	@Value("${CODE.ERROR.ABSENT}")
	private String codeAbsentDonne;
	@Value("${CODE.ERROR.ABSENT.UI}")
	private String codeAbsentDonneUI;
	@Value("${CODE.ERROR.DONNE.INCORRECT}")
	private String codeDonneIncorrect;
	@Value("${CODE.ERROR.DONNE.INCORRECT.UI}")
	private String codeDonneIncorrectUI;
	@Value("${CODE.FORMAT.INCORRECT}")
	private String codeFormatIncorrect;
	/**
	 * MESSAGE ERROR GENERIQUE
	 */
	@Value("${ERROR.GENERIQUE.DONNE.ABSENT}")
	private String errorGeneriqueAbsent;
	@Value("${ERROR.GENERIQUE.DONNE.INCORRECT}")
	private String errorGeneriqueIncorect;
	@Value("${ERROR.GENERIQUE.INTERNE}")
	private String errorGeneriqueInterne;
	/**
	 * données manquant dans smccore de la gdn
	 */
	@Value("${ERROR.GDN.DONNE.DOCUMENTID.MANQUANTE}")
	private String documentIdAbsent;
	@Value("${ERROR.GDN.DONNE.ARCHIVINGREFERENCEDATE.MANQUANTE}")
	private String archivingreferencedateAbsent;
	@Value("${ERROR.GDN.DONNE.TITRE.MANQUANTE}")
	private String titreAbsent;
	@Value("${ERROR.GDN.DONNE.FILENAME.MANQUANTE}")
	private String filenameAbsent;
	@Value("${ERROR.GDN.DONNE.ARCHIVEFORMAT.MANQUANTE}")
	private String archiveformatAbsent;
	@Value("${ERROR.GDN.DONNE.MIMETYPE.MANQUANTE}")
	private String mimetypeAbsent;
	@Value("${ERROR.GDN.DONNE.DATA.MANQUANTE}")
	private String dataAbsent;
	@Value("${ERROR.GDN.DONNE.COMPRESS.MANQUANTE}")
	private String compressAbsent;
	@Value("${ERROR.GDN.DONNE.ENCODING.MANQUANTE}")
	private String encodingAbsent;
	@Value("${ERROR.GDN.DONNE.DOCUMENTTYPEID.MANQUANTE}")
	private String documentTypeIdAbsent;
	@Value("${ERROR.GDN.DONNE.LISTEIDDOCUMENT.MANQUANTE}")
	private String listeIdDocsAbsent;
	@Value("${ERROR.GDN.DONNE.USERTYPE.MANQUANTE}")
	private String usertypeAbsent;
	@Value("${ERROR.GDN.DONNE.USER.MANQUANTE}")//TODO a supprimer ?
	private String userAbsent;
	/**
	 *
	 *
	 *
	 * Gestion des erreurs données absente Editique
	 *
	 *
	 *
	 *
	 *
	 */
	@Value("${ERROR.EDITION.NUMCARTE.MANQUANTE}")
	private String numCarteManquante;
	@Value("${ERROR.EDITION.MAQUETTE.MANQUANTE}")
	private String maquetteManquante;
	@Value("${ERROR.EDITION.DATAMATRIX.MANQUANTE}")
	private String datamaTrixManquante;
	@Value("${ERROR.EDITION.LIBNATURE.MANQUANTE}")
	private String libnatureManquante;
	@Value("${ERROR.EDITION.NUMCARTEMASQUE.MANQUANTE}")
	private String numcartemasqueManquante;
	@Value("${ERROR.EDITION.NUMDOSSIER.MANQUANTE}")
	private String numdossierManquante;
	@Value("${ERROR.EDITION.LISTEPARAGRAPHE.MANQUANTE}")
	private String listeparagrapheManquante;
	@Value("${ERROR.EDITION.ADRESSE.EMETEUR.MANQUANTE}")
	private String adresseEmeteurManquant;
	@Value("${ERROR.EDITION.TELEPHONE.EMETTEUR.MANQUANTE}")
	private String telEmeteurManquant;
	@Value("${ERROR.EDITION.DATE.DE.TRAITEMENT.MANQUANTE}")
	private String dateDetraitementManquant;
	@Value("${ERROR.EDITION.CANAL.MANQUANTE}")
	private String canalAbsent;
	@Value("${ERROR.EDITION.BOOLEAN.CENTRAL.MANQUANTE}")
	private String booleanEditionAbsent;
	/**
	 *
	 *
	 * Gestions des erreurs formats
	 *
	 *
	 */
	@Value("${ERROR.MIMETYPE.ERROR.FORMAT}")
	private String mimeTypeErrorFormat;
	@Value("${EXEMPLE.MIMETYPE1}")
	private String mimeTypeformat1;
	@Value("${EXEMPLE.MIMETYPE2}")
	private String mimeTypeformat2;
	@Value("${ERROR.DATE.ERROR.FORMAT}")
	private String formatDateError;
	@Value("${ERROR.NUMCARTE.ERROR.FORMAT}")
	private String formatCarteBancaireError;
	@Value("${ERROR.CANAL.ERROR.FORMAT}")
	private String canalMauvaisFormat;
	/**
	 * @return the adresseEmeteurManquant
	 */
	public String getAdresseEmeteurManquant() {
		return adresseEmeteurManquant;
	}
	/**
	 * @return the application
	 */
	public String getApplication() {
		return application;
	}
	/**
	 * @return the applicationCodeAbsent
	 */
	public String getApplicationCodeAbsent() {
		return applicationCodeAbsent;
	}
	/**
	 * @return the archiveformatAbsent
	 */
	public String getArchiveformatAbsent() {
		return archiveformatAbsent;
	}
	/**
	 * @return the archivingreferencedateAbsent
	 */
	public String getArchivingreferencedateAbsent() {
		return archivingreferencedateAbsent;
	}
	/**
	 * @return the autresDonneesAbsent
	 */
	public String getAutresDonneesAbsent() {
		return autresDonneesAbsent;
	}
	/**
	 * @return the autresDonneesIncorrect
	 */
	public String getAutresDonneesIncorrect() {
		return autresDonneesIncorrect;
	}
	/**
	 * @return the birthDate
	 */
	public String getBirthDate() {
		return birthDate;
	}
	/**
	 * @return the booleanEditionAbsent
	 */
	public String getBooleanEditionAbsent() {
		return booleanEditionAbsent;
	}
	/**
	 * @return the callingApplication
	 */
	public String getCallingApplication() {
		return callingApplication;
	}
	/**
	 * @return the callingUserAbsent
	 */
	public String getCallingUserAbsent() {
		return callingUserAbsent;
	}
	//	/**
	//	 * @return the canal
	//	 */
	//	public String getCanal() {
	//		return canal;
	//	}
	/**
	 * @return the canalAbsent
	 */
	public String getCanalAbsent() {
		return canalAbsent;
	}
	/**
	 * @return the canalMauvaisFormat
	 */
	public String getCanalMauvaisFormat() {
		return canalMauvaisFormat;
	}
	/**
	 * @return the cardIdAbsent
	 */
	public String getCardIdAbsent() {
		return cardIdAbsent;
	}
	/**
	 * @return the channelEdoc
	 */
	public String getChannelEdoc() {
		return channelEdoc;
	}
	/**
	 * @return the clanguekpi
	 */
	public String getClanguekpi() {
		return clanguekpi;
	}
	/**
	 * @return the classificationNatureId
	 */
	public String getClassificationNatureId() {
		return classificationNatureId;
	}
	/**
	 * @return the clientFirstname
	 */
	public String getClientFirstname() {
		return clientFirstname;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @return the clientNatureId
	 */
	public String getClientNatureId() {
		return clientNatureId;
	}
	/**
	 * @return the codeAbsentDonne
	 */
	public String getCodeAbsentDonne() {
		return codeAbsentDonne;
	}
	/**
	 * @return the codeAbsentDonneUI
	 */
	public String getCodeAbsentDonneUI() {
		return codeAbsentDonneUI;
	}
	/**
	 * @return the codeApeAbsent
	 */
	public String getCodeApeAbsent() {
		return codeApeAbsent;
	}
	/**
	 * @return the codeApeIncorrect
	 */
	public String getCodeApeIncorrect() {
		return codeApeIncorrect;
	}
	/**
	 * @return the codeApplicationAbsent
	 */
	public String getCodeApplicationAbsent() {
		return codeApplicationAbsent;
	}
	/**
	 * @return the codebanqueDomAbsent
	 */
	public String getCodebanqueDomAbsent() {
		return codebanqueDomAbsent;
	}
	/**
	 * @return the codebanqueDomIncorrect
	 */
	public String getCodebanqueDomIncorrect() {
		return codebanqueDomIncorrect;
	}
	/**
	 * @return the codebanqueMempraccAbsent
	 */
	public String getCodebanqueMempraccAbsent() {
		return codebanqueMempraccAbsent;
	}
	/**
	 * @return the codebanqueMempraccIncorrect
	 */
	public String getCodebanqueMempraccIncorrect() {
		return codebanqueMempraccIncorrect;
	}
	/**
	 * @return the codebanqueMemprtitAbsent
	 */
	public String getCodebanqueMemprtitAbsent() {
		return codebanqueMemprtitAbsent;
	}
	/**
	 * @return the codebanqueMemprtitIncorrect
	 */
	public String getCodebanqueMemprtitIncorrect() {
		return codebanqueMemprtitIncorrect;
	}

	/**
	 * @return the codeChefdefiledestAbsent
	 */
	public String getCodeChefdefiledestAbsent() {
		return codeChefdefiledestAbsent;
	}
	/**
	 * @return the codeChefdefiledestIncorrect
	 */
	public String getCodeChefdefiledestIncorrect() {
		return codeChefdefiledestIncorrect;
	}
	/**
	 * @return the codeChefdefileemetAbsent
	 */
	public String getCodeChefdefileemetAbsent() {
		return codeChefdefileemetAbsent;
	}
	/**
	 * @return the codeChefdefileemetIncorrect
	 */
	public String getCodeChefdefileemetIncorrect() {
		return codeChefdefileemetIncorrect;
	}
	/**
	 * @return the codeDonneIncorrect
	 */
	public String getCodeDonneIncorrect() {
		return codeDonneIncorrect;
	}
	/**
	 * @return the codeDonneIncorrectUI
	 */
	public String getCodeDonneIncorrectUI() {
		return codeDonneIncorrectUI;
	}
	/**
	 * @return the codeErreurServeurBcmp
	 */
	public String getCodeErreurServeurBcmp() {
		return codeErreurServeurBcmp;
	}
	/**
	 * @return the codeErreurServeurEdition
	 */
	public String getCodeErreurServeurEdition() {
		return codeErreurServeurEdition;
	}
	/**
	 * @return the codeErreurServeurGdn
	 */
	public String getCodeErreurServeurGdn() {
		return codeErreurServeurGdn;
	}
	/**
	 * @return the codeErreurServeurRefo
	 */
	public String getCodeErreurServeurRefo() {
		return codeErreurServeurRefo;
	}
	/**
	 * @return the codeErreurServeurRP
	 */
	public String getCodeErreurServeurRP() {
		return codeErreurServeurRP;
	}
	/**
	 * @return the codeErreurServiceContestation
	 */
	public String getCodeErreurServiceContestation() {
		return codeErreurServiceContestation;
	}
	/**
	 * @return the codeFormatIncorrect
	 */
	public String getCodeFormatIncorrect() {
		return codeFormatIncorrect;
	}
	/**
	 * @return the codeMotifipayeAbsent
	 */
	public String getCodeMotifipayeAbsent() {
		return codeMotifipayeAbsent;
	}
	/**
	 * @return the codeMotifipayeIncorrect
	 */
	public String getCodeMotifipayeIncorrect() {
		return codeMotifipayeIncorrect;
	}
	/**
	 * @return the codeErrorContestion
	 */
	public String getCodeNotFoundContestion() {
		return codeNotFoundContestion;
	}
	/**
	 * @return the codeOrMountOpeAbsent
	 */
	public String getCodeOrMountOpeAbsent() {
		return codeOrMountOpeAbsent;
	}
	/**
	 * @return the codeTypeDocumentContestation
	 */
	public String getCodeTypeDocumentContestation() {
		return codeTypeDocumentContestation;
	}
	/**
	 * @return the codeTypeDocumentJustificatif
	 */
	public String getCodeTypeDocumentJustificatif() {
		return codeTypeDocumentJustificatif;
	}
	/**
	 * @return the commonsPhrase
	 */
	public String getCommonsPhrase() {
		return commonsPhrase;
	}
	/**
	 * @return the compressAbsent
	 */
	public String getCompressAbsent() {
		return compressAbsent;
	}
	/**
	 * @return the contactDestAbsent
	 */
	public String getContactDestAbsent() {
		return contactDestAbsent;
	}
	/**
	 * @return the contactDestIncorrect
	 */
	public String getContactDestIncorrect() {
		return contactDestIncorrect;
	}
	/**
	 * @return the contactEmetAbsent
	 */
	public String getContactEmetAbsent() {
		return contactEmetAbsent;
	}
	/**
	 * @return the contactEmetIncorrect
	 */
	public String getContactEmetIncorrect() {
		return contactEmetIncorrect;
	}
	/**
	 * @return the contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @return the contractIdTypeCode
	 */
	public String getContractIdTypeCode() {
		return contractIdTypeCode;
	}
	/**
	 * @return the contractIdTypeLabel
	 */
	public String getContractIdTypeLabel() {
		return contractIdTypeLabel;
	}
	/**
	 * @return the ctype
	 */
	public String getCtype() {
		return ctype;
	}
	/**
	 * @return the dataAbsent
	 */
	public String getDataAbsent() {
		return dataAbsent;
	}

	/**
	 * @return the datamaTrixManquante
	 */
	public String getDatamaTrixManquante() {
		return datamaTrixManquante;
	}
	/**
	 * @return the dateAppelAbsent
	 */
	public String getDateAppelAbsent() {
		return dateAppelAbsent;
	}

	/**
	 * @return the dateAppelIncorrect
	 */
	public String getDateAppelIncorrect() {
		return dateAppelIncorrect;
	}


	/**
	 * @return the dateCreationAbsent
	 */
	public String getDateCreationAbsent() {
		return dateCreationAbsent;
	}
	/**
	 * @return the dateCreationIncorrect
	 */
	public String getDateCreationIncorrect() {
		return dateCreationIncorrect;
	}
	/**
	 * @return the dateDetraitementManquant
	 */
	public String getDateDetraitementManquant() {
		return dateDetraitementManquant;
	}





	/**
	 * Nouvelle données absente
	 */

	/**
	 * @return the dateheureTransactionAbsent
	 */
	public String getDateheureTransactionAbsent() {
		return dateheureTransactionAbsent;
	}
	/**
	 * @return the dateheureTransactionIncorrect
	 */
	public String getDateheureTransactionIncorrect() {
		return dateheureTransactionIncorrect;
	}
	/**
	 * @return the dateOppositionabsent
	 */
	public String getDateOppositionabsent() {
		return dateOppositionabsent;
	}
	/**
	 * @return the dateOppositionAbsent
	 */
	public String getDateOppositionAbsent() {
		return dateOppositionAbsent;
	}
	/**
	 * @return the dateOppositionIncorrect
	 */
	public String getDateOppositionIncorrect() {
		return dateOppositionIncorrect;
	}

	/**
	 * @return the dateReglmntinitialAbsent
	 */
	public String getDateReglmntinitialAbsent() {
		return dateReglmntinitialAbsent;
	}


	/**
	 * @return the dateReglmntinitialIncorrect
	 */
	public String getDateReglmntinitialIncorrect() {
		return dateReglmntinitialIncorrect;
	}
	/**
	 * @return the dateRglmntimpayeAbsent
	 */
	public String getDateRglmntimpayeAbsent() {
		return dateRglmntimpayeAbsent;
	}
	/**
	 * @return the dateRglmntimpayeIncorrect
	 */
	public String getDateRglmntimpayeIncorrect() {
		return dateRglmntimpayeIncorrect;
	}

	/**
	 * @return the dateRglmntrepresAbsent
	 */
	public String getDateRglmntrepresAbsent() {
		return dateRglmntrepresAbsent;
	}
	/**
	 * @return the dateRglmntrepresIncorrect
	 */
	public String getDateRglmntrepresIncorrect() {
		return dateRglmntrepresIncorrect;
	}
	/**
	 * @return the dateTraitementAbsent
	 */
	public String getDateTraitementAbsent() {
		return dateTraitementAbsent;
	}
	/**
	 * @return the dateTraitementIncorrect
	 */
	public String getDateTraitementIncorrect() {
		return dateTraitementIncorrect;
	}
	/**
	 * @return the delaisReponseAbsent
	 */
	public String getDelaisReponseAbsent() {
		return delaisReponseAbsent;
	}
	/**
	 * @return the delaisReponseIncorrect
	 */
	public String getDelaisReponseIncorrect() {
		return delaisReponseIncorrect;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @return the documentIdAbsent
	 */
	public String getDocumentIdAbsent() {
		return documentIdAbsent;
	}

	/**
	 * @return the documentTypeIdAbsent
	 */
	public String getDocumentTypeIdAbsent() {
		return documentTypeIdAbsent;
	}
	/**
	 * @return the editiqueFileType
	 */
	public String getEditiqueFileType() {
		return editiqueFileType;
	}
	/**
	 * @return the emailDestAbsent
	 */
	public String getEmailDestAbsent() {
		return emailDestAbsent;
	}
	/**
	 * @return the emailDestIncorrect
	 */
	public String getEmailDestIncorrect() {
		return emailDestIncorrect;
	}
	/**
	 * @return the emailEmetAbsent
	 */
	public String getEmailEmetAbsent() {
		return emailEmetAbsent;
	}
	/**
	 * @return the emailEmetIncorrect
	 */
	public String getEmailEmetIncorrect() {
		return emailEmetIncorrect;
	}
	/**
	 * @return the encodingAbsent
	 */
	public String getEncodingAbsent() {
		return encodingAbsent;
	}
	/**
	 * @return the environnement
	 */
	public String getEnvironnement() {
		return environnement;
	}
	/**
	 * @return the errorGeneriqueAbsent
	 */
	public String getErrorGeneriqueAbsent() {
		return errorGeneriqueAbsent;
	}
	/**
	 * @return the errorGeneriqueContestation
	 */
	public String getErrorGeneriqueContestation() {
		return errorGeneriqueContestation;
	}
	/**
	 * @return the errorGeneriqueIncorect
	 */
	public String getErrorGeneriqueIncorect() {
		return errorGeneriqueIncorect;
	}
	/**
	 * @return the errorGeneriqueInterne
	 */
	public String getErrorGeneriqueInterne() {
		return errorGeneriqueInterne;
	}
	/**
	 * @return the faxDestAbsent
	 */
	public String getFaxDestAbsent() {
		return faxDestAbsent;
	}
	/**
	 * @return the faxDestIncorrect
	 */
	public String getFaxDestIncorrect() {
		return faxDestIncorrect;
	}
	/**
	 * @return the faxEmetAbsent
	 */
	public String getFaxEmetAbsent() {
		return faxEmetAbsent;
	}
	/**
	 * @return the faxEmetIncorrect
	 */
	public String getFaxEmetIncorrect() {
		return faxEmetIncorrect;
	}
	/**
	 * @return the filenameAbsent
	 */
	public String getFilenameAbsent() {
		return filenameAbsent;
	}
	/**
	 * @return the folderNumberNotFound
	 */
	public String getFolderNumberNotFound() {
		return folderNumberNotFound;
	}
	/**
	 * @return the formatCarteBancaireError
	 */
	public String getFormatCarteBancaireError() {
		return formatCarteBancaireError;
	}
	/**
	 * @return the formatDateError
	 */
	public String getFormatDateError() {
		return formatDateError;
	}
	/**
	 * @return the formatSortie
	 */
	public String getFormatSortie() {
		return formatSortie;
	}
	/**
	 * @return the idContestationSmcAbsent
	 */
	public String getIdContestationSmcAbsent() {
		return idContestationSmcAbsent;
	}
	/**
	 * @return the identifierNotFound
	 */
	public String getIdentifierNotFound() {
		return identifierNotFound;
	}
	/**
	 * @return the idoc
	 */
	public String getIdoc() {
		return idoc;
	}
	/**
	 * @return the idUserAbsent
	 */
	public String getIdUserAbsent() {
		return idUserAbsent;
	}
	/**
	 * @return the idUserIncorrect
	 */
	public String getIdUserIncorrect() {
		return idUserIncorrect;
	}
	/**
	 * @return the indexname1
	 */
	public String getIndexname1() {
		return indexname1;
	}
	/**
	 * @return the indexname2
	 */
	public String getIndexname2() {
		return indexname2;
	}
	/**
	 * @return the indexname3
	 */
	public String getIndexname3() {
		return indexname3;
	}
	/**
	 * @return the indexvalue1
	 */
	public String getIndexvalue1() {
		return indexvalue1;
	}
	/**
	 * @return the lformat
	 */
	public String getLformat() {
		return lformat;
	}
	/**
	 * @return the libnatureManquante
	 */
	public String getLibnatureManquante() {
		return libnatureManquante;
	}
	/**
	 * @return the lignepar
	 */
	public String getLignepar() {
		return lignepar;
	}
	/**
	 * @return the lignepartab
	 */
	public String getLignepartab() {
		return lignepartab;
	}

	/**
	 * @return the lignetab
	 */
	public String getLignetab() {
		return lignetab;
	}
	/**
	 * @return the listeIdDocsAbsent
	 */
	public String getListeIdDocsAbsent() {
		return listeIdDocsAbsent;
	}

	/**
	 * @return the listeparagrapheManquante
	 */
	public String getListeparagrapheManquante() {
		return listeparagrapheManquante;
	}























	/**
	 * @return the locDepartAbsent
	 */
	public String getLocDepartAbsent() {
		return locDepartAbsent;
	}
	/**
	 * @return the locDepartIncorrect
	 */
	public String getLocDepartIncorrect() {
		return locDepartIncorrect;
	}

	/**
	 * @return the lotId
	 */
	public String getLotId() {
		return lotId;
	}

	/**
	 * @return the lotLabel
	 */
	public String getLotLabel() {
		return lotLabel;
	}

	/**
	 * @return the maquetteManquante
	 */
	public String getMaquetteManquante() {
		return maquetteManquante;
	}

	/**
	 * @return the mediaEdoc
	 */
	public String getMediaEdoc() {
		return mediaEdoc;
	}

	/**
	 * @return the messageCodeUOAbsent
	 */
	public String getMessageCodeUOAbsent() {
		return messageCodeUOAbsent;
	}

	/**
	 * @return the messageDisputStatusAbsent
	 */
	public String getMessageDisputStatusAbsent() {
		return messageDisputStatusAbsent;
	}

	/**
	 * @return the messageDisputStatusIncorrect
	 */
	public String getMessageDisputStatusIncorrect() {
		return messageDisputStatusIncorrect;
	}

	/**
	 * @return the messageErrorIdTypeDocument
	 */
	public String getMessageErrorIdTypeDocument() {
		return messageErrorIdTypeDocument;
	}

	/**
	 * @return the messageErrorTechnique
	 */
	public String getMessageErrorTechnique() {
		return messageErrorTechnique;
	}

	/**
	 * @return the messageIkpiAbsent
	 */
	public String getMessageIkpiAbsent() {
		return messageIkpiAbsent;
	}

	/**
	 * @return the messageNumeroPanAbsent
	 */
	public String getMessageNumeroPanAbsent() {
		return messageNumeroPanAbsent;
	}

	/**
	 * @return the messagePurgeSuccess
	 */
	public String getMessagePurgeSuccess() {
		return messagePurgeSuccess;
	}

	//	/**
	//	 * @return the messageXsdValidation
	//	 */
	//	public String getMessageXsdValidation() {
	//		return messageXsdValidation;
	//	}
	/**
	 * @return the mimetypeAbsent
	 */
	public String getMimetypeAbsent() {
		return mimetypeAbsent;
	}

	/**
	 * @return the mimeTypeErrorFormat
	 */
	public String getMimeTypeErrorFormat() {
		return mimeTypeErrorFormat;
	}

	/**
	 * @return the mimeTypeformat1
	 */
	public String getMimeTypeformat1() {
		return mimeTypeformat1;
	}

	/**
	 * @return the mimeTypeformat2
	 */
	public String getMimeTypeformat2() {
		return mimeTypeformat2;
	}

	/**
	 * @return the montantBrutAbsent
	 */
	public String getMontantBrutAbsent() {
		return montantBrutAbsent;
	}

	/**
	 * @return the montantBrutIncorrect
	 */
	public String getMontantBrutIncorrect() {
		return montantBrutIncorrect;
	}

	/**
	 * @return the montantCompenseAbsent
	 */
	public String getMontantCompenseAbsent() {
		return montantCompenseAbsent;
	}

	/**
	 * @return the montantCompenseIncorrect
	 */
	public String getMontantCompenseIncorrect() {
		return montantCompenseIncorrect;
	}

	/**
	 * @return the montantContesteAbsent
	 */
	public String getMontantContesteAbsent() {
		return montantContesteAbsent;
	}


	/**
	 * @return the montantContesteIncorrect
	 */
	public String getMontantContesteIncorrect() {
		return montantContesteIncorrect;
	}

	/**
	 * @return the natureDossierAbsent
	 */
	public String getNatureDossierAbsent() {
		return natureDossierAbsent;
	}

	/**
	 * @return the natureDossierIncorrect
	 */
	public String getNatureDossierIncorrect() {
		return natureDossierIncorrect;
	}

	/**
	 * @return the natureDossierLibelleAbsent
	 */
	public String getNatureDossierLibelleAbsent() {
		return natureDossierLibelleAbsent;
	}


	/**
	 * @return the natureDossierLibelleIncorrect
	 */
	public String getNatureDossierLibelleIncorrect() {
		return natureDossierLibelleIncorrect;
	}

	/**
	 * @return the nombreDeCaractereDeLigneIncorrect
	 */
	public String getNombreDeCaractereDeLigneIncorrect() {
		return nombreDeCaractereDeLigneIncorrect;
	}


	/**
	 * @return the nombreDeLigneIncorect
	 */
	public String getNombreDeLigneIncorect() {
		return nombreDeLigneIncorect;
	}

	/**
	 * @return the nombreOperationsAbsent
	 */
	public String getNombreOperationsAbsent() {
		return nombreOperationsAbsent;
	}


	/**
	 * @return the nombreOperationsIncorrect
	 */
	public String getNombreOperationsIncorrect() {
		return nombreOperationsIncorrect;
	}

	/**
	 * @return the nomPorteurAbsent
	 */
	public String getNomPorteurAbsent() {
		return nomPorteurAbsent;
	}

	/**
	 * @return the nomPorteurIncorrect
	 */
	public String getNomPorteurIncorrect() {
		return nomPorteurIncorrect;
	}

	/**
	 * @return the normLevel
	 */
	public String getNormLevel() {
		return normLevel;
	}
	/**
	 * @return the noSecurised
	 */
	public String getNoSecurised() {
		return noSecurised;
	}
	/**
	 * @return the numCarteManquante
	 */
	public String getNumCarteManquante() {
		return numCarteManquante;
	}

	/**
	 * @return the numCarteMasqueAbsent
	 */
	public String getNumCarteMasqueAbsent() {
		return numCarteMasqueAbsent;
	}
	/**
	 * @return the numCarteMasqueIncorrect
	 */
	public String getNumCarteMasqueIncorrect() {
		return numCarteMasqueIncorrect;
	}

	/**
	 * @return the numcartemasqueManquante
	 */
	public String getNumcartemasqueManquante() {
		return numcartemasqueManquante;
	}

	/**
	 * @return the numClientAbsent
	 */
	public String getNumClientAbsent() {
		return numClientAbsent;
	}
	/**
	 * @return the numClientIncorrect
	 */
	public String getNumClientIncorrect() {
		return numClientIncorrect;
	}
	/**
	 * @return the numDistributeurAbsent
	 */
	public String getNumDistributeurAbsent() {
		return numDistributeurAbsent;
	}

	/**
	 * @return the numDistributeurIncorrect
	 */
	public String getNumDistributeurIncorrect() {
		return numDistributeurIncorrect;
	}

	/**
	 * @return the numDossierAbsent
	 */
	public String getNumDossierAbsent() {
		return numDossierAbsent;
	}

	/**
	 * @return the numDossierIncorrect
	 */
	public String getNumDossierIncorrect() {
		return numDossierIncorrect;
	}

	/**
	 * @return the numdossierManquante
	 */
	public String getNumdossierManquante() {
		return numdossierManquante;
	}

	/**
	 * @return the numSiretAbsent
	 */
	public String getNumSiretAbsent() {
		return numSiretAbsent;
	}

	/**
	 * @return the numSiretIncorrect
	 */
	public String getNumSiretIncorrect() {
		return numSiretIncorrect;
	}

	/**
	 * @return the operationsAbsent
	 */
	public String getOperationsAbsent() {
		return operationsAbsent;
	}

	/**
	 * @return the owningApplication
	 */
	public String getOwningApplication() {
		return owningApplication;
	}

	/**
	 * @return the prenomPorteurAbsent
	 */
	public String getPrenomPorteurAbsent() {
		return prenomPorteurAbsent;
	}

	/**
	 * @return the prenomPorteurIncorrect
	 */
	public String getPrenomPorteurIncorrect() {
		return prenomPorteurIncorrect;
	}
	/**
	 * @return the priorite
	 */
	public String getPriorite() {
		return priorite;
	}

	/**
	 * @return the publicationTop
	 */
	public String getPublicationTop() {
		return publicationTop;
	}
	/**
	 * @return the qualificationDossierAbsent
	 */
	public String getQualificationDossierAbsent() {
		return qualificationDossierAbsent;
	}

	/**
	 * @return the qualificationDossierIncorrect
	 */
	public String getQualificationDossierIncorrect() {
		return qualificationDossierIncorrect;
	}

	/**
	 * @return the qualificationIncorrect
	 */
	public String getQualificationIncorrect() {
		return qualificationIncorrect;
	}
	/**
	 * @return the raisonSocialeAbsent
	 */
	public String getRaisonSocialeAbsent() {
		return raisonSocialeAbsent;
	}

	/**
	 * @return the raisonSocialeIncorrect
	 */
	public String getRaisonSocialeIncorrect() {
		return raisonSocialeIncorrect;
	}

	/**
	 * @return the reasonAbsent
	 */
	public String getReasonAbsent() {
		return reasonAbsent;
	}
	/**
	 * @return the referenceArchivageAbsent
	 */
	public String getReferenceArchivageAbsent() {
		return referenceArchivageAbsent;
	}
	/**
	 * @return the referenceArchivageIncorrect
	 */
	public String getReferenceArchivageIncorrect() {
		return referenceArchivageIncorrect;
	}
	/**
	 * @return the reponseIncorect
	 */
	public String getReponseIncorect() {
		return reponseIncorect;
	}

	/**
	 * @return the reponseIncorectGDN
	 */
	public String getReponseIncorectGDN() {
		return reponseIncorectGDN;
	}
	/**
	 * @return the reponseNullRP
	 */
	public String getReponseNullRP() {
		return reponseNullRP;
	}
	/**
	 * @return the reponseSuccessSecureDoc
	 */
	public String getReponseSuccessSecureDoc() {
		return reponseSuccessSecureDoc;
	}
	/**
	 * @return the responseIncorectRP
	 */
	public String getResponseIncorectRP() {
		return responseIncorectRP;
	}
	/**
	 * @return the sepialg
	 */
	public String getSepialg() {
		return sepialg;
	}
	/**
	 * @return the sepiaml
	 */
	public String getSepiaml() {
		return sepiaml;
	}
	/**
	 * @return the sirenNumber
	 */
	public String getSirenNumber() {
		return sirenNumber;
	}
	/**
	 * @return the storageLevel
	 */
	public String getStorageLevel() {
		return storageLevel;
	}
	/**
	 * @return the tabCommentairesAbsent
	 */
	public String getTabCommentairesAbsent() {
		return tabCommentairesAbsent;
	}
	/**
	 * @return the tabCommentairesIncorrect
	 */
	public String getTabCommentairesIncorrect() {
		return tabCommentairesIncorrect;
	}
	/**
	 * @return the tabContestAbsent
	 */
	public String getTabContestAbsent() {
		return tabContestAbsent;
	}



	/**
	 * @return the tabContestIncorrect
	 */
	public String getTabContestIncorrect() {
		return tabContestIncorrect;
	}


	/**
	 * @return the tabHeaderAbsent
	 */
	public String getTabHeaderAbsent() {
		return tabHeaderAbsent;
	}
	/**
	 * @return the tabHeaderIncorrect
	 */
	public String getTabHeaderIncorrect() {
		return tabHeaderIncorrect;
	}
	/**
	 * @return the tabPsAbsent
	 */
	public String getTabPsAbsent() {
		return tabPsAbsent;
	}



	/**
	 * @return the tabPsIncorrect
	 */
	public String getTabPsIncorrect() {
		return tabPsIncorrect;
	}

	/**
	 * @return the telemataticIdNotFound
	 */
	public String getTelemataticIdNotFound() {
		return telemataticIdNotFound;
	}

	/**
	 * @return the telematicIdAbsent
	 */
	public String getTelematicIdAbsent() {
		return telematicIdAbsent;
	}

	/**
	 * @return the telEmeteurManquant
	 */
	public String getTelEmeteurManquant() {
		return telEmeteurManquant;
	}
	/**
	 * @return the telephoneDestAbsent
	 */
	public String getTelephoneDestAbsent() {
		return telephoneDestAbsent;
	}
	/**
	 * @return the telephoneDestIncorrect
	 */
	public String getTelephoneDestIncorrect() {
		return telephoneDestIncorrect;
	}
	/**
	 * @return the telephoneEmetAbsent
	 */
	public String getTelephoneEmetAbsent() {
		return telephoneEmetAbsent;
	}
	/**
	 * @return the telephoneEmetIncorrect
	 */
	public String getTelephoneEmetIncorrect() {
		return telephoneEmetIncorrect;
	}
	/**
	 * @return the titreAbsent
	 */
	public String getTitreAbsent() {
		return titreAbsent;
	}

	/**
	 * @return the topClienteleAbsent
	 */
	public String getTopClienteleAbsent() {
		return topClienteleAbsent;
	}

	/**
	 * @return the topClienteleIncorrect
	 */
	public String getTopClienteleIncorrect() {
		return topClienteleIncorrect;
	}

	/**
	 * @return the totalOperationsAbsent
	 */
	public String getTotalOperationsAbsent() {
		return totalOperationsAbsent;
	}
	/**
	 * @return the totalOperationsIncorrect
	 */
	public String getTotalOperationsIncorrect() {
		return totalOperationsIncorrect;
	}
	/**
	 * @return the traceLog
	 */
	public String getTraceLog() {
		return traceLog;
	}


	/**
	 * @return the traceXml
	 */
	public String getTraceXml() {
		return traceXml;
	}

	/**
	 * @return the transaction
	 */
	public String getTransaction() {
		return transaction;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @return the typeOperationAbsent
	 */
	public String getTypeOperationAbsent() {
		return typeOperationAbsent;
	}

	/**
	 * @return the typeOperationIncorrect
	 */
	public String getTypeOperationIncorrect() {
		return typeOperationIncorrect;
	}
	/**
	 * @return the typeReglmntsouhaiteAbsent
	 */
	public String getTypeReglmntsouhaiteAbsent() {
		return typeReglmntsouhaiteAbsent;
	}
	/**
	 * @return the typeReglmntsouhaiteIncorrect
	 */
	public String getTypeReglmntsouhaiteIncorrect() {
		return typeReglmntsouhaiteIncorrect;
	}
	/**
	 * @return the typi
	 */
	public String getTypi() {
		return typi;
	}
	/**
	 * @return the urlPostEdoc
	 */
	public String getUrlPostEdoc() {
		return urlPostEdoc;
	}
	/**
	 * @return the userAbsent
	 */
	public String getUserAbsent() {
		return userAbsent;
	}

	/**
	 * @return the userIdAbsent
	 */
	public String getUserIdAbsent() {
		return userIdAbsent;
	}

	/**
	 * @return the userIdEdoc
	 */
	public String getUserIdEdoc() {
		return userIdEdoc;
	}

	/**
	 * @return the usertypeAbsent
	 */
	public String getUsertypeAbsent() {
		return usertypeAbsent;
	}
	/**
	 * @return the userTypeSelfCare
	 */
	public String getUserTypeSelfCare() {
		return userTypeSelfCare;
	}
	/**
	 * @param adresseEmeteurManquant the adresseEmeteurManquant to set
	 */
	public void setAdresseEmeteurManquant(String adresseEmeteurManquant) {
		this.adresseEmeteurManquant = adresseEmeteurManquant;
	}
	/**
	 * @param application the application to set
	 */
	public void setApplication(String application) {
		this.application = application;
	}
	/**
	 * @param applicationCodeAbsent the applicationCodeAbsent to set
	 */
	public void setApplicationCodeAbsent(String applicationCodeAbsent) {
		this.applicationCodeAbsent = applicationCodeAbsent;
	}

	/**
	 * @param archiveformatAbsent the archiveformatAbsent to set
	 */
	public void setArchiveformatAbsent(String archiveformatAbsent) {
		this.archiveformatAbsent = archiveformatAbsent;
	}
	/**
	 * @param archivingreferencedateAbsent the archivingreferencedateAbsent to set
	 */
	public void setArchivingreferencedateAbsent(String archivingreferencedateAbsent) {
		this.archivingreferencedateAbsent = archivingreferencedateAbsent;
	}

	/**
	 * @param autresDonneesAbsent the autresDonneesAbsent to set
	 */
	public void setAutresDonneesAbsent(String autresDonneesAbsent) {
		this.autresDonneesAbsent = autresDonneesAbsent;
	}

	/**
	 * @param autresDonneesIncorrect the autresDonneesIncorrect to set
	 */
	public void setAutresDonneesIncorrect(String autresDonneesIncorrect) {
		this.autresDonneesIncorrect = autresDonneesIncorrect;
	}
	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @param booleanEditionAbsent the booleanEditionAbsent to set
	 */
	public void setBooleanEditionAbsent(String booleanEditionAbsent) {
		this.booleanEditionAbsent = booleanEditionAbsent;
	}

	/**
	 * @param callingApplication the callingApplication to set
	 */
	public void setCallingApplication(String callingApplication) {
		this.callingApplication = callingApplication;
	}

	/**
	 * @param callingUserAbsent the callingUserAbsent to set
	 */
	public void setCallingUserAbsent(String callingUserAbsent) {
		this.callingUserAbsent = callingUserAbsent;
	}
	//	/**
	//	 * @param canal the canal to set
	//	 */
	//	public void setCanal(String canal) {
	//		this.canal = canal;
	//	}
	/**
	 * @param canalAbsent the canalAbsent to set
	 */
	public void setCanalAbsent(String canalAbsent) {
		this.canalAbsent = canalAbsent;
	}

	/**
	 * @param canalMauvaisFormat the canalMauvaisFormat to set
	 */
	public void setCanalMauvaisFormat(String canalMauvaisFormat) {
		this.canalMauvaisFormat = canalMauvaisFormat;
	}


	/**
	 * @param cardIdAbsent the cardIdAbsent to set
	 */
	public void setCardIdAbsent(String cardIdAbsent) {
		this.cardIdAbsent = cardIdAbsent;
	}

	/**
	 * @param channelEdoc the channelEdoc to set
	 */
	public void setChannelEdoc(String channelEdoc) {
		this.channelEdoc = channelEdoc;
	}

	/**
	 * @param clanguekpi the clanguekpi to set
	 */
	public void setClanguekpi(String clanguekpi) {
		this.clanguekpi = clanguekpi;
	}

	/**
	 * @param classificationNatureId the classificationNatureId to set
	 */
	public void setClassificationNatureId(String classificationNatureId) {
		this.classificationNatureId = classificationNatureId;
	}

	/**
	 * @param clientFirstname the clientFirstname to set
	 */
	public void setClientFirstname(String clientFirstname) {
		this.clientFirstname = clientFirstname;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	/**
	 * @param clientNatureId the clientNatureId to set
	 */
	public void setClientNatureId(String clientNatureId) {
		this.clientNatureId = clientNatureId;
	}

	/**
	 * @param codeAbsentDonne the codeAbsentDonne to set
	 */
	public void setCodeAbsentDonne(String codeAbsentDonne) {
		this.codeAbsentDonne = codeAbsentDonne;
	}
	/**
	 * @param codeAbsentDonneUI the codeAbsentDonneUI to set
	 */
	public void setCodeAbsentDonneUI(String codeAbsentDonneUI) {
		this.codeAbsentDonneUI = codeAbsentDonneUI;
	}

	/**
	 * @param codeApeAbsent the codeApeAbsent to set
	 */
	public void setCodeApeAbsent(String codeApeAbsent) {
		this.codeApeAbsent = codeApeAbsent;
	}

	/**
	 * @param codeApeIncorrect the codeApeIncorrect to set
	 */
	public void setCodeApeIncorrect(String codeApeIncorrect) {
		this.codeApeIncorrect = codeApeIncorrect;
	}

	/**
	 * @param codeApplicationAbsent the codeApplicationAbsent to set
	 */
	public void setCodeApplicationAbsent(String codeApplicationAbsent) {
		this.codeApplicationAbsent = codeApplicationAbsent;
	}

	/**
	 * @param codebanqueDomAbsent the codebanqueDomAbsent to set
	 */
	public void setCodebanqueDomAbsent(String codebanqueDomAbsent) {
		this.codebanqueDomAbsent = codebanqueDomAbsent;
	}
	/**
	 * @param codebanqueDomIncorrect the codebanqueDomIncorrect to set
	 */
	public void setCodebanqueDomIncorrect(String codebanqueDomIncorrect) {
		this.codebanqueDomIncorrect = codebanqueDomIncorrect;
	}

	/**
	 * @param codebanqueMempraccAbsent the codebanqueMempraccAbsent to set
	 */
	public void setCodebanqueMempraccAbsent(String codebanqueMempraccAbsent) {
		this.codebanqueMempraccAbsent = codebanqueMempraccAbsent;
	}

	/**
	 * @param codebanqueMempraccIncorrect the codebanqueMempraccIncorrect to set
	 */
	public void setCodebanqueMempraccIncorrect(String codebanqueMempraccIncorrect) {
		this.codebanqueMempraccIncorrect = codebanqueMempraccIncorrect;
	}
	/**
	 * @param codebanqueMemprtitAbsent the codebanqueMemprtitAbsent to set
	 */
	public void setCodebanqueMemprtitAbsent(String codebanqueMemprtitAbsent) {
		this.codebanqueMemprtitAbsent = codebanqueMemprtitAbsent;
	}
	/**
	 * @param codebanqueMemprtitIncorrect the codebanqueMemprtitIncorrect to set
	 */
	public void setCodebanqueMemprtitIncorrect(String codebanqueMemprtitIncorrect) {
		this.codebanqueMemprtitIncorrect = codebanqueMemprtitIncorrect;
	}
	/**
	 * @param codeChefdefiledestAbsent the codeChefdefiledestAbsent to set
	 */
	public void setCodeChefdefiledestAbsent(String codeChefdefiledestAbsent) {
		this.codeChefdefiledestAbsent = codeChefdefiledestAbsent;
	}

	/**
	 * @param codeChefdefiledestIncorrect the codeChefdefiledestIncorrect to set
	 */
	public void setCodeChefdefiledestIncorrect(String codeChefdefiledestIncorrect) {
		this.codeChefdefiledestIncorrect = codeChefdefiledestIncorrect;
	}

	/**
	 * @param codeChefdefileemetAbsent the codeChefdefileemetAbsent to set
	 */
	public void setCodeChefdefileemetAbsent(String codeChefdefileemetAbsent) {
		this.codeChefdefileemetAbsent = codeChefdefileemetAbsent;
	}

	/**
	 * @param codeChefdefileemetIncorrect the codeChefdefileemetIncorrect to set
	 */
	public void setCodeChefdefileemetIncorrect(String codeChefdefileemetIncorrect) {
		this.codeChefdefileemetIncorrect = codeChefdefileemetIncorrect;
	}

	//	/**
	//	 * @param codeDataMissing the codeDataMissing to set
	//	 */
	//	public void setCodeDataMissing(String codeDataMissing) {
	//		this.codeDataMissing = codeDataMissing;
	//	}
	/**
	 * @param codeDonneIncorrect the codeDonneIncorrect to set
	 */
	public void setCodeDonneIncorrect(String codeDonneIncorrect) {
		this.codeDonneIncorrect = codeDonneIncorrect;
	}


	/**
	 * @param codeDonneIncorrectUI the codeDonneIncorrectUI to set
	 */
	public void setCodeDonneIncorrectUI(String codeDonneIncorrectUI) {
		this.codeDonneIncorrectUI = codeDonneIncorrectUI;
	}

	/**
	 * @param codeErreurServeurBcmp the codeErreurServeurBcmp to set
	 */
	public void setCodeErreurServeurBcmp(String codeErreurServeurBcmp) {
		this.codeErreurServeurBcmp = codeErreurServeurBcmp;
	}

	/**
	 * @param codeErreurServeurEdition the codeErreurServeurEdition to set
	 */
	public void setCodeErreurServeurEdition(String codeErreurServeurEdition) {
		this.codeErreurServeurEdition = codeErreurServeurEdition;
	}


	/**
	 * @param codeErreurServeurGdn the codeErreurServeurGdn to set
	 */
	public void setCodeErreurServeurGdn(String codeErreurServeurGdn) {
		this.codeErreurServeurGdn = codeErreurServeurGdn;
	}
	/**
	 * @param codeErreurServeurRefo the codeErreurServeurRefo to set
	 */
	public void setCodeErreurServeurRefo(String codeErreurServeurRefo) {
		this.codeErreurServeurRefo = codeErreurServeurRefo;
	}

	/**
	 * @param codeErreurServeurRP the codeErreurServeurRP to set
	 */
	public void setCodeErreurServeurRP(String codeErreurServeurRP) {
		this.codeErreurServeurRP = codeErreurServeurRP;
	}
	/**
	 * @param codeErreurServiceContestation the codeErreurServiceContestation to set
	 */
	public void setCodeErreurServiceContestation(
			String codeErreurServiceContestation) {
		this.codeErreurServiceContestation = codeErreurServiceContestation;
	}
	/**
	 * @param codeFormatIncorrect the codeFormatIncorrect to set
	 */
	public void setCodeFormatIncorrect(String codeFormatIncorrect) {
		this.codeFormatIncorrect = codeFormatIncorrect;
	}
	/**
	 * @param codeMotifipayeAbsent the codeMotifipayeAbsent to set
	 */
	public void setCodeMotifipayeAbsent(String codeMotifipayeAbsent) {
		this.codeMotifipayeAbsent = codeMotifipayeAbsent;
	}
	/**
	 * @param codeMotifipayeIncorrect the codeMotifipayeIncorrect to set
	 */
	public void setCodeMotifipayeIncorrect(String codeMotifipayeIncorrect) {
		this.codeMotifipayeIncorrect = codeMotifipayeIncorrect;
	}
	/**
	 * @param codeErrorContestion the codeErrorContestion to set
	 */
	public void setCodeNotFoundContestion(String codeNotFoundContestion) {
		this.codeNotFoundContestion = codeNotFoundContestion;
	}

	/**
	 * @param codeOrMountOpeAbsent the codeOrMountOpeAbsent to set
	 */
	public void setCodeOrMountOpeAbsent(String codeOrMountOpeAbsent) {
		this.codeOrMountOpeAbsent = codeOrMountOpeAbsent;
	}

	/**
	 * @param codeTypeDocumentContestation the codeTypeDocumentContestation to set
	 */
	public void setCodeTypeDocumentContestation(String codeTypeDocumentContestation) {
		this.codeTypeDocumentContestation = codeTypeDocumentContestation;
	}

	/**
	 * @param codeTypeDocumentJustificatif the codeTypeDocumentJustificatif to set
	 */
	public void setCodeTypeDocumentJustificatif(String codeTypeDocumentJustificatif) {
		this.codeTypeDocumentJustificatif = codeTypeDocumentJustificatif;
	}

	/**
	 * @param commonsPhrase the commonsPhrase to set
	 */
	public void setCommonsPhrase(String commonsPhrase) {
		this.commonsPhrase = commonsPhrase;
	}

	/**
	 * @param compressAbsent the compressAbsent to set
	 */
	public void setCompressAbsent(String compressAbsent) {
		this.compressAbsent = compressAbsent;
	}

	/**
	 * @param contactDestAbsent the contactDestAbsent to set
	 */
	public void setContactDestAbsent(String contactDestAbsent) {
		this.contactDestAbsent = contactDestAbsent;
	}

	/**
	 * @param contactDestIncorrect the contactDestIncorrect to set
	 */
	public void setContactDestIncorrect(String contactDestIncorrect) {
		this.contactDestIncorrect = contactDestIncorrect;
	}

	/**
	 * @param contactEmetAbsent the contactEmetAbsent to set
	 */
	public void setContactEmetAbsent(String contactEmetAbsent) {
		this.contactEmetAbsent = contactEmetAbsent;
	}

	/**
	 * @param contactEmetIncorrect the contactEmetIncorrect to set
	 */
	public void setContactEmetIncorrect(String contactEmetIncorrect) {
		this.contactEmetIncorrect = contactEmetIncorrect;
	}




	//	@Value("${ERROR.EDITION.CIVILITE.MANQUANTE}")
	//	private String cvltManquant;
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE1.MANQUANTE}")
	//	private String adresseDesti1Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE2.MANQUANTE}")
	//	private String adresseDesti2Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE3.MANQUANTE}")
	//	private String adresseDesti3Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE6.MANQUANTE}")
	//	private String adresseDesti6Manquant;

	/**
	 * @param contractId the contractId to set
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}


	/**
	 * @param contractIdTypeCode the contractIdTypeCode to set
	 */
	public void setContractIdTypeCode(String contractIdTypeCode) {
		this.contractIdTypeCode = contractIdTypeCode;
	}

	/**
	 * @param contractIdTypeLabel the contractIdTypeLabel to set
	 */
	public void setContractIdTypeLabel(String contractIdTypeLabel) {
		this.contractIdTypeLabel = contractIdTypeLabel;
	}

	//	/**
	//	 * @return the codeDataMissing
	//	 */
	//	public String getCodeDataMissing() {
	//		return codeDataMissing;
	//	}

	/**
	 * @param ctype the ctype to set
	 */
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}

	//	@Value("${ERROR.EDITION.FORMAT.MANQUANTE}")
	//	private String formatManquant;
	//
	//	@Value("${ERROR.EDITION.LANGUEKPI.MANQUANTE}")
	//	private String languekpiManquant;
	//
	//	@Value("${ERROR.EDITION.SEPIALG.MANQUANTE}")
	//	private String sepialgManquant;
	//
	//	@Value("${ERROR.EDITION.SEPIAML.MANQUANTE}")
	//	private String sepiamlManquant;
	//
	//	@Value("${ERROR.EDITION.CTYPE.MANQUANTE}")
	//	private String ctypeManquant;
	//
	//	@Value("${ERROR.EDITION.TYPI.MANQUANTE}")
	//	private String typiManquant;


	/**
	 * @param dataAbsent the dataAbsent to set
	 */
	public void setDataAbsent(String dataAbsent) {
		this.dataAbsent = dataAbsent;
	}


	/**
	 * @param datamaTrixManquante the datamaTrixManquante to set
	 */
	public void setDatamaTrixManquante(String datamaTrixManquante) {
		this.datamaTrixManquante = datamaTrixManquante;
	}

	/**
	 * @param dateAppelAbsent the dateAppelAbsent to set
	 */
	public void setDateAppelAbsent(String dateAppelAbsent) {
		this.dateAppelAbsent = dateAppelAbsent;
	}

	/**
	 * @param dateAppelIncorrect the dateAppelIncorrect to set
	 */
	public void setDateAppelIncorrect(String dateAppelIncorrect) {
		this.dateAppelIncorrect = dateAppelIncorrect;
	}

	/**
	 * @param dateCreationAbsent the dateCreationAbsent to set
	 */
	public void setDateCreationAbsent(String dateCreationAbsent) {
		this.dateCreationAbsent = dateCreationAbsent;
	}

	/**
	 * @param dateCreationIncorrect the dateCreationIncorrect to set
	 */
	public void setDateCreationIncorrect(String dateCreationIncorrect) {
		this.dateCreationIncorrect = dateCreationIncorrect;
	}

	/**
	 * @param dateDetraitementManquant the dateDetraitementManquant to set
	 */
	public void setDateDetraitementManquant(String dateDetraitementManquant) {
		this.dateDetraitementManquant = dateDetraitementManquant;
	}

	/**
	 * @param dateheureTransactionAbsent the dateheureTransactionAbsent to set
	 */
	public void setDateheureTransactionAbsent(String dateheureTransactionAbsent) {
		this.dateheureTransactionAbsent = dateheureTransactionAbsent;
	}

	/**
	 * @param dateheureTransactionIncorrect the dateheureTransactionIncorrect to set
	 */
	public void setDateheureTransactionIncorrect(
			String dateheureTransactionIncorrect) {
		this.dateheureTransactionIncorrect = dateheureTransactionIncorrect;
	}

	/**
	 * @param dateOppositionabsent the dateOppositionabsent to set
	 */
	public void setDateOppositionabsent(String dateOppositionabsent) {
		this.dateOppositionabsent = dateOppositionabsent;
	}

	/**
	 * @param dateOppositionAbsent the dateOppositionAbsent to set
	 */
	public void setDateOppositionAbsent(String dateOppositionAbsent) {
		this.dateOppositionAbsent = dateOppositionAbsent;
	}

	/**
	 * @param dateOppositionIncorrect the dateOppositionIncorrect to set
	 */
	public void setDateOppositionIncorrect(String dateOppositionIncorrect) {
		this.dateOppositionIncorrect = dateOppositionIncorrect;
	}

	/**
	 * @param dateReglmntinitialAbsent the dateReglmntinitialAbsent to set
	 */
	public void setDateReglmntinitialAbsent(String dateReglmntinitialAbsent) {
		this.dateReglmntinitialAbsent = dateReglmntinitialAbsent;
	}

	/**
	 * @param dateReglmntinitialIncorrect the dateReglmntinitialIncorrect to set
	 */
	public void setDateReglmntinitialIncorrect(String dateReglmntinitialIncorrect) {
		this.dateReglmntinitialIncorrect = dateReglmntinitialIncorrect;
	}

	/**
	 * @param dateRglmntimpayeAbsent the dateRglmntimpayeAbsent to set
	 */
	public void setDateRglmntimpayeAbsent(String dateRglmntimpayeAbsent) {
		this.dateRglmntimpayeAbsent = dateRglmntimpayeAbsent;
	}

	/**
	 * @param dateRglmntimpayeIncorrect the dateRglmntimpayeIncorrect to set
	 */
	public void setDateRglmntimpayeIncorrect(String dateRglmntimpayeIncorrect) {
		this.dateRglmntimpayeIncorrect = dateRglmntimpayeIncorrect;
	}

	/**
	 * @param dateRglmntrepresAbsent the dateRglmntrepresAbsent to set
	 */
	public void setDateRglmntrepresAbsent(String dateRglmntrepresAbsent) {
		this.dateRglmntrepresAbsent = dateRglmntrepresAbsent;
	}

	//	/**
	//	 * @return the codeEchecService
	//	 */
	//	public String getCodeEchecService() {
	//		return codeEchecService;
	//	}

	/**
	 * @param dateRglmntrepresIncorrect the dateRglmntrepresIncorrect to set
	 */
	public void setDateRglmntrepresIncorrect(String dateRglmntrepresIncorrect) {
		this.dateRglmntrepresIncorrect = dateRglmntrepresIncorrect;
	}

	//	/**
	//	 * @return the codeErrorTechnique
	//	 */
	//	public String getCodeErrorTechnique() {
	//		return codeErrorTechnique;
	//	}

	//	/**
	//	 * @return the codeErrorTypeDocument
	//	 */
	//	public String getCodeErrorTypeDocument() {
	//		return codeErrorTypeDocument;
	//	}

	/**
	 * @param dateTraitementAbsent the dateTraitementAbsent to set
	 */
	public void setDateTraitementAbsent(String dateTraitementAbsent) {
		this.dateTraitementAbsent = dateTraitementAbsent;
	}

	/**
	 * @param dateTraitementIncorrect the dateTraitementIncorrect to set
	 */
	public void setDateTraitementIncorrect(String dateTraitementIncorrect) {
		this.dateTraitementIncorrect = dateTraitementIncorrect;
	}

	/**
	 * @param delaisReponseAbsent the delaisReponseAbsent to set
	 */
	public void setDelaisReponseAbsent(String delaisReponseAbsent) {
		this.delaisReponseAbsent = delaisReponseAbsent;
	}

	/**
	 * @param delaisReponseIncorrect the delaisReponseIncorrect to set
	 */
	public void setDelaisReponseIncorrect(String delaisReponseIncorrect) {
		this.delaisReponseIncorrect = delaisReponseIncorrect;
	}


	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @param documentIdAbsent the documentIdAbsent to set
	 */
	public void setDocumentIdAbsent(String documentIdAbsent) {
		this.documentIdAbsent = documentIdAbsent;
	}

	/**
	 * @param documentTypeIdAbsent the documentTypeIdAbsent to set
	 */
	public void setDocumentTypeIdAbsent(String documentTypeIdAbsent) {
		this.documentTypeIdAbsent = documentTypeIdAbsent;
	}

	/**
	 * @param editiqueFileType the editiqueFileType to set
	 */
	public void setEditiqueFileType(String editiqueFileType) {
		this.editiqueFileType = editiqueFileType;
	}
	/**
	 * @param emailDestAbsent the emailDestAbsent to set
	 */
	public void setEmailDestAbsent(String emailDestAbsent) {
		this.emailDestAbsent = emailDestAbsent;
	}

	/**
	 * @param emailDestIncorrect the emailDestIncorrect to set
	 */
	public void setEmailDestIncorrect(String emailDestIncorrect) {
		this.emailDestIncorrect = emailDestIncorrect;
	}

	/**
	 * @param emailEmetAbsent the emailEmetAbsent to set
	 */
	public void setEmailEmetAbsent(String emailEmetAbsent) {
		this.emailEmetAbsent = emailEmetAbsent;
	}

	/**
	 * @param emailEmetIncorrect the emailEmetIncorrect to set
	 */
	public void setEmailEmetIncorrect(String emailEmetIncorrect) {
		this.emailEmetIncorrect = emailEmetIncorrect;
	}

	/**
	 * @param encodingAbsent the encodingAbsent to set
	 */
	public void setEncodingAbsent(String encodingAbsent) {
		this.encodingAbsent = encodingAbsent;
	}

	/**
	 * @param environnement the environnement to set
	 */
	public void setEnvironnement(String environnement) {
		this.environnement = environnement;
	}

	/**
	 * @param errorGeneriqueAbsent the errorGeneriqueAbsent to set
	 */
	public void setErrorGeneriqueAbsent(String errorGeneriqueAbsent) {
		this.errorGeneriqueAbsent = errorGeneriqueAbsent;
	}

	/**
	 * @param errorGeneriqueContestation the errorGeneriqueContestation to set
	 */
	public void setErrorGeneriqueContestation(String errorGeneriqueContestation) {
		this.errorGeneriqueContestation = errorGeneriqueContestation;
	}


	//	/**
	//	 * @return the errorDonneManquante
	//	 */
	//	public String getErrorDonneManquante() {
	//		return errorDonneManquante;
	//	}

	/**
	 * @param errorGeneriqueIncorect the errorGeneriqueIncorect to set
	 */
	public void setErrorGeneriqueIncorect(String errorGeneriqueIncorect) {
		this.errorGeneriqueIncorect = errorGeneriqueIncorect;
	}

	/**
	 * @param errorGeneriqueInterne the errorGeneriqueInterne to set
	 */
	public void setErrorGeneriqueInterne(String errorGeneriqueInterne) {
		this.errorGeneriqueInterne = errorGeneriqueInterne;
	}

	/**
	 * @param faxDestAbsent the faxDestAbsent to set
	 */
	public void setFaxDestAbsent(String faxDestAbsent) {
		this.faxDestAbsent = faxDestAbsent;
	}

	/**
	 * @param faxDestIncorrect the faxDestIncorrect to set
	 */
	public void setFaxDestIncorrect(String faxDestIncorrect) {
		this.faxDestIncorrect = faxDestIncorrect;
	}

	//	/**
	//	 * @return the messageDataMissing
	//	 */
	//	public String getMessageDataMissing() {
	//		return messageDataMissing;
	//	}

	/**
	 * @param faxEmetAbsent the faxEmetAbsent to set
	 */
	public void setFaxEmetAbsent(String faxEmetAbsent) {
		this.faxEmetAbsent = faxEmetAbsent;
	}

	/**
	 * @param faxEmetIncorrect the faxEmetIncorrect to set
	 */
	public void setFaxEmetIncorrect(String faxEmetIncorrect) {
		this.faxEmetIncorrect = faxEmetIncorrect;
	}

	/**
	 * @param filenameAbsent the filenameAbsent to set
	 */
	public void setFilenameAbsent(String filenameAbsent) {
		this.filenameAbsent = filenameAbsent;
	}
	/**
	 * @param folderNumberNotFound the folderNumberNotFound to set
	 */
	public void setFolderNumberNotFound(String folderNumberNotFound) {
		this.folderNumberNotFound = folderNumberNotFound;
	}
	/**
	 * @param formatCarteBancaireError the formatCarteBancaireError to set
	 */
	public void setFormatCarteBancaireError(String formatCarteBancaireError) {
		this.formatCarteBancaireError = formatCarteBancaireError;
	}
	/**
	 * @param formatDateError the formatDateError to set
	 */
	public void setFormatDateError(String formatDateError) {
		this.formatDateError = formatDateError;
	}
	/**
	 * @param formatSortie the formatSortie to set
	 */
	public void setFormatSortie(String formatSortie) {
		this.formatSortie = formatSortie;
	}
	/**
	 * @param idContestationSmcAbsent the idContestationSmcAbsent to set
	 */
	public void setIdContestationSmcAbsent(String idContestationSmcAbsent) {
		this.idContestationSmcAbsent = idContestationSmcAbsent;
	}
	/**
	 * @param identifierNotFound the identifierNotFound to set
	 */
	public void setIdentifierNotFound(String identifierNotFound) {
		this.identifierNotFound = identifierNotFound;
	}



	/**
	 * @param idoc the idoc to set
	 */
	public void setIdoc(String idoc) {
		this.idoc = idoc;
	}

	/**
	 * @param idUserAbsent the idUserAbsent to set
	 */
	public void setIdUserAbsent(String idUserAbsent) {
		this.idUserAbsent = idUserAbsent;
	}

	/**
	 * @param idUserIncorrect the idUserIncorrect to set
	 */
	public void setIdUserIncorrect(String idUserIncorrect) {
		this.idUserIncorrect = idUserIncorrect;
	}

	/**
	 * @param indexname1 the indexname1 to set
	 */
	public void setIndexname1(String indexname1) {
		this.indexname1 = indexname1;
	}

	/**
	 * @param indexname2 the indexname2 to set
	 */
	public void setIndexname2(String indexname2) {
		this.indexname2 = indexname2;
	}

	/**
	 * @param indexname3 the indexname3 to set
	 */
	public void setIndexname3(String indexname3) {
		this.indexname3 = indexname3;
	}

	/**
	 * @param indexvalue1 the indexvalue1 to set
	 */
	public void setIndexvalue1(String indexvalue1) {
		this.indexvalue1 = indexvalue1;
	}

	/**
	 * @param lformat the lformat to set
	 */
	public void setLformat(String lformat) {
		this.lformat = lformat;
	}

	//	/**
	//	 * @return the reseau
	//	 */
	//	public String getReseau() {
	//		return reseau;
	//	}

	/**
	 * @param libnatureManquante the libnatureManquante to set
	 */
	public void setLibnatureManquante(String libnatureManquante) {
		this.libnatureManquante = libnatureManquante;
	}

	/**
	 * @param lignepar the lignepar to set
	 */
	public void setLignepar(String lignepar) {
		this.lignepar = lignepar;
	}
	/**
	 * @param lignepartab the lignepartab to set
	 */
	public void setLignepartab(String lignepartab) {
		this.lignepartab = lignepartab;
	}

	/**
	 * @param lignetab the lignetab to set
	 */
	public void setLignetab(String lignetab) {
		this.lignetab = lignetab;
	}

	/**
	 * @param listeIdDocsAbsent the listeIdDocsAbsent to set
	 */
	public void setListeIdDocsAbsent(String listeIdDocsAbsent) {
		this.listeIdDocsAbsent = listeIdDocsAbsent;
	}

	/**
	 * @param listeparagrapheManquante the listeparagrapheManquante to set
	 */
	public void setListeparagrapheManquante(String listeparagrapheManquante) {
		this.listeparagrapheManquante = listeparagrapheManquante;
	}

	/**
	 * @param locDepartAbsent the locDepartAbsent to set
	 */
	public void setLocDepartAbsent(String locDepartAbsent) {
		this.locDepartAbsent = locDepartAbsent;
	}

	/**
	 * @param locDepartIncorrect the locDepartIncorrect to set
	 */
	public void setLocDepartIncorrect(String locDepartIncorrect) {
		this.locDepartIncorrect = locDepartIncorrect;
	}

	/**
	 * @param lotId the lotId to set
	 */
	public void setLotId(String lotId) {
		this.lotId = lotId;
	}








	/**
	 * @param lotLabel the lotLabel to set
	 */
	public void setLotLabel(String lotLabel) {
		this.lotLabel = lotLabel;
	}

	/**
	 * @param maquetteManquante the maquetteManquante to set
	 */
	public void setMaquetteManquante(String maquetteManquante) {
		this.maquetteManquante = maquetteManquante;
	}

	/**
	 * @param mediaEdoc the mediaEdoc to set
	 */
	public void setMediaEdoc(String mediaEdoc) {
		this.mediaEdoc = mediaEdoc;
	}

	/**
	 * @param messageCodeUOAbsent the messageCodeUOAbsent to set
	 */
	public void setMessageCodeUOAbsent(String messageCodeUOAbsent) {
		this.messageCodeUOAbsent = messageCodeUOAbsent;
	}

	/**
	 * @param messageDisputStatusAbsent the messageDisputStatusAbsent to set
	 */
	public void setMessageDisputStatusAbsent(String messageDisputStatusAbsent) {
		this.messageDisputStatusAbsent = messageDisputStatusAbsent;
	}

	/**
	 * @param messageDisputStatusIncorrect the messageDisputStatusIncorrect to set
	 */
	public void setMessageDisputStatusIncorrect(String messageDisputStatusIncorrect) {
		this.messageDisputStatusIncorrect = messageDisputStatusIncorrect;
	}

	/**
	 * @param messageErrorIdTypeDocument the messageErrorIdTypeDocument to set
	 */
	public void setMessageErrorIdTypeDocument(String messageErrorIdTypeDocument) {
		this.messageErrorIdTypeDocument = messageErrorIdTypeDocument;
	}

	/**
	 * @param messageErrorTechnique the messageErrorTechnique to set
	 */
	public void setMessageErrorTechnique(String messageErrorTechnique) {
		this.messageErrorTechnique = messageErrorTechnique;
	}
	/**
	 * @param messageIkpiAbsent the messageIkpiAbsent to set
	 */
	public void setMessageIkpiAbsent(String messageIkpiAbsent) {
		this.messageIkpiAbsent = messageIkpiAbsent;
	}

	/**
	 * @param messageNumeroPanAbsent the messageNumeroPanAbsent to set
	 */
	public void setMessageNumeroPanAbsent(String messageNumeroPanAbsent) {
		this.messageNumeroPanAbsent = messageNumeroPanAbsent;
	}

	/**
	 * @param messagePurgeSuccess the messagePurgeSuccess to set
	 */
	public void setMessagePurgeSuccess(String messagePurgeSuccess) {
		this.messagePurgeSuccess = messagePurgeSuccess;
	}

	//
	//	/**
	//	 * @param messageXsdValidation the messageXsdValidation to set
	//	 */
	//	public void setMessageXsdValidation(String messageXsdValidation) {
	//		this.messageXsdValidation = messageXsdValidation;
	//	}
	/**
	 * @param mimetypeAbsent the mimetypeAbsent to set
	 */
	public void setMimetypeAbsent(String mimetypeAbsent) {
		this.mimetypeAbsent = mimetypeAbsent;
	}

	/**
	 * @param mimeTypeErrorFormat the mimeTypeErrorFormat to set
	 */
	public void setMimeTypeErrorFormat(String mimeTypeErrorFormat) {
		this.mimeTypeErrorFormat = mimeTypeErrorFormat;
	}
	/**
	 * @param mimeTypeformat1 the mimeTypeformat1 to set
	 */
	public void setMimeTypeformat1(String mimeTypeformat1) {
		this.mimeTypeformat1 = mimeTypeformat1;
	}
	/**
	 * @param mimeTypeformat2 the mimeTypeformat2 to set
	 */
	public void setMimeTypeformat2(String mimeTypeformat2) {
		this.mimeTypeformat2 = mimeTypeformat2;
	}
	/**
	 * @param montantBrutAbsent the montantBrutAbsent to set
	 */
	public void setMontantBrutAbsent(String montantBrutAbsent) {
		this.montantBrutAbsent = montantBrutAbsent;
	}
	/**
	 * @param montantBrutIncorrect the montantBrutIncorrect to set
	 */
	public void setMontantBrutIncorrect(String montantBrutIncorrect) {
		this.montantBrutIncorrect = montantBrutIncorrect;
	}
	/**
	 * @param montantCompenseAbsent the montantCompenseAbsent to set
	 */
	public void setMontantCompenseAbsent(String montantCompenseAbsent) {
		this.montantCompenseAbsent = montantCompenseAbsent;
	}
	/**
	 * @param montantCompenseIncorrect the montantCompenseIncorrect to set
	 */
	public void setMontantCompenseIncorrect(String montantCompenseIncorrect) {
		this.montantCompenseIncorrect = montantCompenseIncorrect;
	}

	/**
	 * @param montantContesteAbsent the montantContesteAbsent to set
	 */
	public void setMontantContesteAbsent(String montantContesteAbsent) {
		this.montantContesteAbsent = montantContesteAbsent;
	}

	/**
	 * @param montantContesteIncorrect the montantContesteIncorrect to set
	 */
	public void setMontantContesteIncorrect(String montantContesteIncorrect) {
		this.montantContesteIncorrect = montantContesteIncorrect;
	}

	/**
	 * @param natureDossierAbsent the natureDossierAbsent to set
	 */
	public void setNatureDossierAbsent(String natureDossierAbsent) {
		this.natureDossierAbsent = natureDossierAbsent;
	}

	/**
	 * @param natureDossierIncorrect the natureDossierIncorrect to set
	 */
	public void setNatureDossierIncorrect(String natureDossierIncorrect) {
		this.natureDossierIncorrect = natureDossierIncorrect;
	}

	/**
	 * @param natureDossierLibelleAbsent the natureDossierLibelleAbsent to set
	 */
	public void setNatureDossierLibelleAbsent(String natureDossierLibelleAbsent) {
		this.natureDossierLibelleAbsent = natureDossierLibelleAbsent;
	}

	/**
	 * @param natureDossierLibelleIncorrect the natureDossierLibelleIncorrect to set
	 */
	public void setNatureDossierLibelleIncorrect(
			String natureDossierLibelleIncorrect) {
		this.natureDossierLibelleIncorrect = natureDossierLibelleIncorrect;
	}

	/**
	 * @param nombreDeCaractereDeLigneIncorrect the nombreDeCaractereDeLigneIncorrect to set
	 */
	public void setNombreDeCaractereDeLigneIncorrect(
			String nombreDeCaractereDeLigneIncorrect) {
		this.nombreDeCaractereDeLigneIncorrect = nombreDeCaractereDeLigneIncorrect;
	}

	/**
	 * @param nombreDeLigneIncorect the nombreDeLigneIncorect to set
	 */
	public void setNombreDeLigneIncorect(String nombreDeLigneIncorect) {
		this.nombreDeLigneIncorect = nombreDeLigneIncorect;
	}

	/**
	 * @param nombreOperationsAbsent the nombreOperationsAbsent to set
	 */
	public void setNombreOperationsAbsent(String nombreOperationsAbsent) {
		this.nombreOperationsAbsent = nombreOperationsAbsent;
	}
	/**
	 * @param nombreOperationsIncorrect the nombreOperationsIncorrect to set
	 */
	public void setNombreOperationsIncorrect(String nombreOperationsIncorrect) {
		this.nombreOperationsIncorrect = nombreOperationsIncorrect;
	}
	/**
	 * @param nomPorteurAbsent the nomPorteurAbsent to set
	 */
	public void setNomPorteurAbsent(String nomPorteurAbsent) {
		this.nomPorteurAbsent = nomPorteurAbsent;
	}



	/**
	 * @param nomPorteurIncorrect the nomPorteurIncorrect to set
	 */
	public void setNomPorteurIncorrect(String nomPorteurIncorrect) {
		this.nomPorteurIncorrect = nomPorteurIncorrect;
	}

	/**
	 * @param normLevel the normLevel to set
	 */
	public void setNormLevel(String normLevel) {
		this.normLevel = normLevel;
	}

	/**
	 * @param noSecurised the noSecurised to set
	 */
	public void setNoSecurised(String noSecurised) {
		this.noSecurised = noSecurised;
	}

	/**
	 * @param numCarteManquante the numCarteManquante to set
	 */
	public void setNumCarteManquante(String numCarteManquante) {
		this.numCarteManquante = numCarteManquante;
	}

	/**
	 * @param numCarteMasqueAbsent the numCarteMasqueAbsent to set
	 */
	public void setNumCarteMasqueAbsent(String numCarteMasqueAbsent) {
		this.numCarteMasqueAbsent = numCarteMasqueAbsent;
	}

	/**
	 * @param numCarteMasqueIncorrect the numCarteMasqueIncorrect to set
	 */
	public void setNumCarteMasqueIncorrect(String numCarteMasqueIncorrect) {
		this.numCarteMasqueIncorrect = numCarteMasqueIncorrect;
	}

	//	/**
	//	 * @param codeEchecService the codeEchecService to set
	//	 */
	//	public void setCodeEchecService(String codeEchecService) {
	//		this.codeEchecService = codeEchecService;
	//	}

	/**
	 * @param numcartemasqueManquante the numcartemasqueManquante to set
	 */
	public void setNumcartemasqueManquante(String numcartemasqueManquante) {
		this.numcartemasqueManquante = numcartemasqueManquante;
	}

	//	/**
	//	 * @param codeErrorTechnique the codeErrorTechnique to set
	//	 */
	//	public void setCodeErrorTechnique(String codeErrorTechnique) {
	//		this.codeErrorTechnique = codeErrorTechnique;
	//	}

	//	/**
	//	 * @param codeErrorTypeDocument the codeErrorTypeDocument to set
	//	 */
	//	public void setCodeErrorTypeDocument(String codeErrorTypeDocument) {
	//		this.codeErrorTypeDocument = codeErrorTypeDocument;
	//	}

	/**
	 * @param numClientAbsent the numClientAbsent to set
	 */
	public void setNumClientAbsent(String numClientAbsent) {
		this.numClientAbsent = numClientAbsent;
	}

	/**
	 * @param numClientIncorrect the numClientIncorrect to set
	 */
	public void setNumClientIncorrect(String numClientIncorrect) {
		this.numClientIncorrect = numClientIncorrect;
	}

	/**
	 * @param numDistributeurAbsent the numDistributeurAbsent to set
	 */
	public void setNumDistributeurAbsent(String numDistributeurAbsent) {
		this.numDistributeurAbsent = numDistributeurAbsent;
	}

	/**
	 * @param numDistributeurIncorrect the numDistributeurIncorrect to set
	 */
	public void setNumDistributeurIncorrect(String numDistributeurIncorrect) {
		this.numDistributeurIncorrect = numDistributeurIncorrect;
	}

	/**
	 * @param numDossierAbsent the numDossierAbsent to set
	 */
	public void setNumDossierAbsent(String numDossierAbsent) {
		this.numDossierAbsent = numDossierAbsent;
	}

	/**
	 * @param numDossierIncorrect the numDossierIncorrect to set
	 */
	public void setNumDossierIncorrect(String numDossierIncorrect) {
		this.numDossierIncorrect = numDossierIncorrect;
	}

	/**
	 * @param numdossierManquante the numdossierManquante to set
	 */
	public void setNumdossierManquante(String numdossierManquante) {
		this.numdossierManquante = numdossierManquante;
	}

	/**
	 * @param numSiretAbsent the numSiretAbsent to set
	 */
	public void setNumSiretAbsent(String numSiretAbsent) {
		this.numSiretAbsent = numSiretAbsent;
	}

	/**
	 * @param numSiretIncorrect the numSiretIncorrect to set
	 */
	public void setNumSiretIncorrect(String numSiretIncorrect) {
		this.numSiretIncorrect = numSiretIncorrect;
	}

	/**
	 * @param operationsAbsent the operationsAbsent to set
	 */
	public void setOperationsAbsent(String operationsAbsent) {
		this.operationsAbsent = operationsAbsent;
	}

	/**
	 * @param owningApplication the owningApplication to set
	 */
	public void setOwningApplication(String owningApplication) {
		this.owningApplication = owningApplication;
	}
	/**
	 * @param prenomPorteurAbsent the prenomPorteurAbsent to set
	 */
	public void setPrenomPorteurAbsent(String prenomPorteurAbsent) {
		this.prenomPorteurAbsent = prenomPorteurAbsent;
	}

	/**
	 * @param prenomPorteurIncorrect the prenomPorteurIncorrect to set
	 */
	public void setPrenomPorteurIncorrect(String prenomPorteurIncorrect) {
		this.prenomPorteurIncorrect = prenomPorteurIncorrect;
	}

	/**
	 * @param priorite the priorite to set
	 */
	public void setPriorite(String priorite) {
		this.priorite = priorite;
	}

	/**
	 * @param publicationTop the publicationTop to set
	 */
	public void setPublicationTop(String publicationTop) {
		this.publicationTop = publicationTop;
	}

	/**
	 * @param qualificationDossierAbsent the qualificationDossierAbsent to set
	 */
	public void setQualificationDossierAbsent(String qualificationDossierAbsent) {
		this.qualificationDossierAbsent = qualificationDossierAbsent;
	}

	/**
	 * @param qualificationDossierIncorrect the qualificationDossierIncorrect to set
	 */
	public void setQualificationDossierIncorrect(
			String qualificationDossierIncorrect) {
		this.qualificationDossierIncorrect = qualificationDossierIncorrect;
	}

	//	/**
	//	 * @param errorDonneManquante the errorDonneManquante to set
	//	 */
	//	public void setErrorDonneManquante(String errorDonneManquante) {
	//		this.errorDonneManquante = errorDonneManquante;
	//	}

	/**
	 * @param qualificationIncorrect the qualificationIncorrect to set
	 */
	public void setQualificationIncorrect(String qualificationIncorrect) {
		this.qualificationIncorrect = qualificationIncorrect;
	}

	/**
	 * @param raisonSocialeAbsent the raisonSocialeAbsent to set
	 */
	public void setRaisonSocialeAbsent(String raisonSocialeAbsent) {
		this.raisonSocialeAbsent = raisonSocialeAbsent;
	}

	/**
	 * @param raisonSocialeIncorrect the raisonSocialeIncorrect to set
	 */
	public void setRaisonSocialeIncorrect(String raisonSocialeIncorrect) {
		this.raisonSocialeIncorrect = raisonSocialeIncorrect;
	}

	/**
	 * @param reasonAbsent the reasonAbsent to set
	 */
	public void setReasonAbsent(String reasonAbsent) {
		this.reasonAbsent = reasonAbsent;
	}

	/**
	 * @param referenceArchivageAbsent the referenceArchivageAbsent to set
	 */
	public void setReferenceArchivageAbsent(String referenceArchivageAbsent) {
		this.referenceArchivageAbsent = referenceArchivageAbsent;
	}

	/**
	 * @param referenceArchivageIncorrect the referenceArchivageIncorrect to set
	 */
	public void setReferenceArchivageIncorrect(String referenceArchivageIncorrect) {
		this.referenceArchivageIncorrect = referenceArchivageIncorrect;
	}

	/**
	 * @param reponseIncorect the reponseIncorect to set
	 */
	public void setReponseIncorect(String reponseIncorect) {
		this.reponseIncorect = reponseIncorect;
	}

	/**
	 * @param reponseIncorectGDN the reponseIncorectGDN to set
	 */
	public void setReponseIncorectGDN(String reponseIncorectGDN) {
		this.reponseIncorectGDN = reponseIncorectGDN;
	}

	/**
	 * @param reponseNullRP the reponseNullRP to set
	 */
	public void setReponseNullRP(String reponseNullRP) {
		this.reponseNullRP = reponseNullRP;
	}

	/**
	 * @param reponseSuccessSecureDoc the reponseSuccessSecureDoc to set
	 */
	public void setReponseSuccessSecureDoc(String reponseSuccessSecureDoc) {
		this.reponseSuccessSecureDoc = reponseSuccessSecureDoc;
	}

	/**
	 * @param responseIncorectRP the responseIncorectRP to set
	 */
	public void setResponseIncorectRP(String responseIncorectRP) {
		this.responseIncorectRP = responseIncorectRP;
	}
	/**
	 * @param sepialg the sepialg to set
	 */
	public void setSepialg(String sepialg) {
		this.sepialg = sepialg;
	}
	/**
	 * @param sepiaml the sepiaml to set
	 */
	public void setSepiaml(String sepiaml) {
		this.sepiaml = sepiaml;
	}


	/**
	 * @param sirenNumber the sirenNumber to set
	 */
	public void setSirenNumber(String sirenNumber) {
		this.sirenNumber = sirenNumber;
	}

	/**
	 * @param storageLevel the storageLevel to set
	 */
	public void setStorageLevel(String storageLevel) {
		this.storageLevel = storageLevel;
	}

	//	/**
	//	 * @param messageDataMissing the messageDataMissing to set
	//	 */
	//	public void setMessageDataMissing(String messageDataMissing) {
	//		this.messageDataMissing = messageDataMissing;
	//	}



	/**
	 * @param tabCommentairesAbsent the tabCommentairesAbsent to set
	 */
	public void setTabCommentairesAbsent(String tabCommentairesAbsent) {
		this.tabCommentairesAbsent = tabCommentairesAbsent;
	}

	/**
	 * @param tabCommentairesIncorrect the tabCommentairesIncorrect to set
	 */
	public void setTabCommentairesIncorrect(String tabCommentairesIncorrect) {
		this.tabCommentairesIncorrect = tabCommentairesIncorrect;
	}

	/**
	 * @param tabContestAbsent the tabContestAbsent to set
	 */
	public void setTabContestAbsent(String tabContestAbsent) {
		this.tabContestAbsent = tabContestAbsent;
	}


	/**
	 * @param tabContestIncorrect the tabContestIncorrect to set
	 */
	public void setTabContestIncorrect(String tabContestIncorrect) {
		this.tabContestIncorrect = tabContestIncorrect;
	}

	/**
	 * @param tabHeaderAbsent the tabHeaderAbsent to set
	 */
	public void setTabHeaderAbsent(String tabHeaderAbsent) {
		this.tabHeaderAbsent = tabHeaderAbsent;
	}

	/**
	 * @param tabHeaderIncorrect the tabHeaderIncorrect to set
	 */
	public void setTabHeaderIncorrect(String tabHeaderIncorrect) {
		this.tabHeaderIncorrect = tabHeaderIncorrect;
	}

	/**
	 * @param tabPsAbsent the tabPsAbsent to set
	 */
	public void setTabPsAbsent(String tabPsAbsent) {
		this.tabPsAbsent = tabPsAbsent;
	}

	/**
	 * @param tabPsIncorrect the tabPsIncorrect to set
	 */
	public void setTabPsIncorrect(String tabPsIncorrect) {
		this.tabPsIncorrect = tabPsIncorrect;
	}

	/**
	 * @param telemataticIdNotFound the telemataticIdNotFound to set
	 */
	public void setTelemataticIdNotFound(String telemataticIdNotFound) {
		this.telemataticIdNotFound = telemataticIdNotFound;
	}

	/**
	 * @param telematicIdAbsent the telematicIdAbsent to set
	 */
	public void setTelematicIdAbsent(String telematicIdAbsent) {
		this.telematicIdAbsent = telematicIdAbsent;
	}

	/**
	 * @param telEmeteurManquant the telEmeteurManquant to set
	 */
	public void setTelEmeteurManquant(String telEmeteurManquant) {
		this.telEmeteurManquant = telEmeteurManquant;
	}

	/**
	 * @param telephoneDestAbsent the telephoneDestAbsent to set
	 */
	public void setTelephoneDestAbsent(String telephoneDestAbsent) {
		this.telephoneDestAbsent = telephoneDestAbsent;
	}

	/**
	 * @param telephoneDestIncorrect the telephoneDestIncorrect to set
	 */
	public void setTelephoneDestIncorrect(String telephoneDestIncorrect) {
		this.telephoneDestIncorrect = telephoneDestIncorrect;
	}

	/**
	 * @param telephoneEmetAbsent the telephoneEmetAbsent to set
	 */
	public void setTelephoneEmetAbsent(String telephoneEmetAbsent) {
		this.telephoneEmetAbsent = telephoneEmetAbsent;
	}

	/**
	 * @param telephoneEmetIncorrect the telephoneEmetIncorrect to set
	 */
	public void setTelephoneEmetIncorrect(String telephoneEmetIncorrect) {
		this.telephoneEmetIncorrect = telephoneEmetIncorrect;
	}

	/**
	 * @param titreAbsent the titreAbsent to set
	 */
	public void setTitreAbsent(String titreAbsent) {
		this.titreAbsent = titreAbsent;
	}

	/**
	 * @param topClienteleAbsent the topClienteleAbsent to set
	 */
	public void setTopClienteleAbsent(String topClienteleAbsent) {
		this.topClienteleAbsent = topClienteleAbsent;
	}

	/**
	 * @param topClienteleIncorrect the topClienteleIncorrect to set
	 */
	public void setTopClienteleIncorrect(String topClienteleIncorrect) {
		this.topClienteleIncorrect = topClienteleIncorrect;
	}

	/**
	 * @param totalOperationsAbsent the totalOperationsAbsent to set
	 */
	public void setTotalOperationsAbsent(String totalOperationsAbsent) {
		this.totalOperationsAbsent = totalOperationsAbsent;
	}

	/**
	 * @param totalOperationsIncorrect the totalOperationsIncorrect to set
	 */
	public void setTotalOperationsIncorrect(String totalOperationsIncorrect) {
		this.totalOperationsIncorrect = totalOperationsIncorrect;
	}

	/**
	 * @param traceLog the traceLog to set
	 */
	public void setTraceLog(String traceLog) {
		this.traceLog = traceLog;
	}

	//	/**
	//	 * @param reseau the reseau to set
	//	 */
	//	public void setReseau(String reseau) {
	//		this.reseau = reseau;
	//	}

	/**
	 * @param traceXml the traceXml to set
	 */
	public void setTraceXml(String traceXml) {
		this.traceXml = traceXml;
	}

	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @param typeOperationAbsent the typeOperationAbsent to set
	 */
	public void setTypeOperationAbsent(String typeOperationAbsent) {
		this.typeOperationAbsent = typeOperationAbsent;
	}

	/**
	 * @param typeOperationIncorrect the typeOperationIncorrect to set
	 */
	public void setTypeOperationIncorrect(String typeOperationIncorrect) {
		this.typeOperationIncorrect = typeOperationIncorrect;
	}

	/**
	 * @param typeReglmntsouhaiteAbsent the typeReglmntsouhaiteAbsent to set
	 */
	public void setTypeReglmntsouhaiteAbsent(String typeReglmntsouhaiteAbsent) {
		this.typeReglmntsouhaiteAbsent = typeReglmntsouhaiteAbsent;
	}

	/**
	 * @param typeReglmntsouhaiteIncorrect the typeReglmntsouhaiteIncorrect to set
	 */
	public void setTypeReglmntsouhaiteIncorrect(String typeReglmntsouhaiteIncorrect) {
		this.typeReglmntsouhaiteIncorrect = typeReglmntsouhaiteIncorrect;
	}

	/**
	 * @param typi the typi to set
	 */
	public void setTypi(String typi) {
		this.typi = typi;
	}

	/**
	 * @param urlPostEdoc the urlPostEdoc to set
	 */
	public void setUrlPostEdoc(String urlPostEdoc) {
		this.urlPostEdoc = urlPostEdoc;
	}

	/**
	 * @param userAbsent the userAbsent to set
	 */
	public void setUserAbsent(String userAbsent) {
		this.userAbsent = userAbsent;
	}

	/**
	 * @param userIdAbsent the userIdAbsent to set
	 */
	public void setUserIdAbsent(String userIdAbsent) {
		this.userIdAbsent = userIdAbsent;
	}

	/**
	 * @param userIdEdoc the userIdEdoc to set
	 */
	public void setUserIdEdoc(String userIdEdoc) {
		this.userIdEdoc = userIdEdoc;
	}

	/**
	 * @param usertypeAbsent the usertypeAbsent to set
	 */
	public void setUsertypeAbsent(String usertypeAbsent) {
		this.usertypeAbsent = usertypeAbsent;
	}

	/**
	 * @param userTypeSelfCare the userTypeSelfCare to set
	 */
	public void setUserTypeSelfCare(String userTypeSelfCare) {
		this.userTypeSelfCare = userTypeSelfCare;
	}



}
