package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

public class MaquetteIdentification {
	@ApiModelProperty(value = "identifiant de la maquette éditique", required = true)
	private String maquette;
	@ApiModelProperty(value = "Champs VIRTUO", required = true)
	private String dataMatrix;
	@ApiModelProperty(value = "model du courrier", required = true)
	private String modeleCourrier;
	/**
	 *
	 */
	public MaquetteIdentification() {
		super();

	}
	/**
	 * @param maquette
	 * @param dataMatrix
	 * @param modeleCourrier
	 */
	public MaquetteIdentification(String maquette, String dataMatrix,
			String modeleCourrier) {
		this.maquette = maquette;
		this.dataMatrix = dataMatrix;
		this.modeleCourrier = modeleCourrier;
	}
	/**
	 * @return the dataMatrix
	 */
	public String getDataMatrix() {
		return dataMatrix;
	}
	/**
	 * @return the maquette
	 */
	public String getMaquette() {
		return maquette;
	}
	/**
	 * @return the modeleCourrier
	 */
	public String getModeleCourrier() {
		return modeleCourrier;
	}
	/**
	 * @param dataMatrix the dataMatrix to set
	 */
	public void setDataMatrix(String dataMatrix) {
		this.dataMatrix = dataMatrix;
	}
	/**
	 * @param maquette the maquette to set
	 */
	public void setMaquette(String maquette) {
		this.maquette = maquette;
	}
	/**
	 * @param modeleCourrier the modeleCourrier to set
	 */
	public void setModeleCourrier(String modeleCourrier) {
		this.modeleCourrier = modeleCourrier;
	}
}
