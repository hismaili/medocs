package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IMotifRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.NoDataAvailableException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Repository
public class MotifRepository implements IMotifRepository {

	private MotifJpaRepository jpaRepository;

	public MotifRepository(MotifJpaRepository jpaRepository) {
		this.jpaRepository = jpaRepository;
	}

	@Override
	@Cacheable(value = "motifs")
	public List<MotifContestation> getAllMotifs() {
		List<MotifEntity> motifs = this.jpaRepository.findAll();
		if(CollectionUtils.isEmpty(motifs)) {
			throw new NoDataAvailableException("La liste des motifs est vide!");
		}
		return MotifMapper.mapListEntitiesToListDomainBeans(motifs);
	}

	/**
	 * @return the jpaRepository
	 */
	public MotifJpaRepository getJpaRepository() {
		return jpaRepository;
	}

	@Override
	@Cacheable(value = "motifsByCode", key = "#code")
	public MotifContestation getMotif(String code) {
		final Optional<MotifEntity> motifEntity = this.jpaRepository.findById(code);
		MotifContestation motif = null;
		if(motifEntity.isPresent()) {
			motif = MotifMapper.mapEntityToDomainBean(motifEntity.get());
		}
		return motif;
	}

    @Override
    public List<MotifContestation> getAppliedReasons(TypeOperation operationType, Boolean cardLost, Integer numberOfOperations) throws Exception {
        TypeOperationEntity typeOpe = this.getTypeOperationEntity(operationType);
        Optional<List<MotifEntity>> reasons = this.jpaRepository.findByTypeOperationApplicableAndAppliedToCardLostOnly(typeOpe, cardLost);

        List<MotifContestation> resultReasons = null;
        if (reasons.isPresent()) {
            resultReasons = MotifMapper.mapListEntitiesToListDomainBeans(reasons.get());
        }
        return resultReasons;
    }

	@Override
	@Cacheable(value = "motifsByOpeType", key = "#operationType")
	public List<MotifContestation> getMotifsByOperationType(TypeOperation operationType) {
		List<MotifContestation> result = null;
		TypeOperationEntity typeOperationAppliable = getTypeOperationEntity(operationType);
		Optional<List<MotifEntity>> motifs = this.jpaRepository.findByTypeOperationApplicable(typeOperationAppliable);
		if(motifs.isPresent()) {
			result = MotifMapper.mapListEntitiesToListDomainBeans(motifs.get());
		}
		return result;
	}

    private TypeOperationEntity getTypeOperationEntity(TypeOperation operationType) {
		TypeOperationEntity typeOperationAppliable;
		switch (operationType) {
		case RETRAIT: typeOperationAppliable=TypeOperationEntity.RETRAIT;break;
		case PAIEMENT:typeOperationAppliable=TypeOperationEntity.PAIEMENT;break;
		default:typeOperationAppliable=TypeOperationEntity.LESDEUX;break;
		}
		return typeOperationAppliable;
	}

	/**
	 * @param jpaRepository the jpaRepository to set
	 */
    public void setJpaRepository(MotifJpaRepository jpaRepository) {
        this.jpaRepository = jpaRepository;
    }
}
