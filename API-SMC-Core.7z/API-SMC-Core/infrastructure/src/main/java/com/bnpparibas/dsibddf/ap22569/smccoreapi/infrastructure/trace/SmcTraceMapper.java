package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import org.springframework.beans.BeanUtils;

public class SmcTraceMapper {

	public static SmcTrace mapJpaEntityToModelEntity(SmcTraceEntity smcTraceEntity) {
		SmcTrace smcTrace = new SmcTrace();

		if(smcTraceEntity !=null){
			BeanUtils.copyProperties(smcTraceEntity, smcTrace, "id");
		}

		return smcTrace;
	}

	public static SmcTraceEntity mapModelEntityToJpaEntity(SmcTrace smcTrace) {

		SmcTraceEntity smcTraceEntity = new SmcTraceEntity();

		if(smcTrace !=null){
			BeanUtils.copyProperties(smcTrace, smcTraceEntity, "id");
		}

		//        DefaultEntityId entityId = new DefaultEntityId(Objects.requireNonNull(UUID.randomUUID()));
		//        smcTraceEntity.setEntityId(entityId);
		return smcTraceEntity;
	}
}
