package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;
/**
 *
 *
 *
 */
public class OperationIn {

	/** Coidop de l'opération */
	@ApiModelProperty(value = "coidop de l'opération", required = true)
	private String codeOperation;

	/** Le type d'opération : retrait, VAD,  */
	@ApiModelProperty(value = "type de l'opération", required = true, example = "Retrait, Vente à distance...")
	private TypeOperation typeOperation;

	/** Le montant de l'opération */
	@ApiModelProperty(value = "montant de l'opération", required = true)
	private BigDecimal montantOperation;

	/** La date de l'opération */
	@ApiModelProperty(value = "Date de l'opération", required = true)
	private LocalDateTime dateOperation;

	/** Le libellé de l'opération */
	@ApiModelProperty(value = "libellé de l'opération", required = true)
	private String libelleOperation;
	/**
	 *
	 * @return
	 */
	public String getCodeOperation() {
		return codeOperation;
	}
	/**
	 *
	 * @return
	 */
	public LocalDateTime getDateOperation() {
		return dateOperation;
	}
	/**
	 *
	 * @return
	 */
	public String getLibelleOperation() {
		return libelleOperation;
	}
	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantOperation() {
		return montantOperation;
	}
	/**
	 *
	 * @return
	 */
	public TypeOperation getTypeOperation() {
		return typeOperation;
	}
	/**
	 *
	 * @param codeOperation
	 */
	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}
	/**
	 *
	 * @param dateOperation
	 */
	public void setDateOperation(LocalDateTime dateOperation) {
		this.dateOperation = dateOperation;
	}
	/**
	 *
	 * @param libelleOperation
	 */
	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}
	/**
	 *
	 * @param montantOperation
	 */
	public void setMontantOperation(BigDecimal montantOperation) {
		this.montantOperation = montantOperation;
	}
	/**
	 *
	 * @param typeOperation
	 */
	public void setTypeOperation(TypeOperation typeOperation) {
		this.typeOperation = typeOperation;
	}
}
