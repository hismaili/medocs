--QUALIFICATION
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q001','Contestation Perte/VOL', 'P');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q002','Contestation Contrefaçon', 'F');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q003','Contestation', 'C');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q099','Autres');

--Nature
---- perte-vol
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N001','Carte Perdue', 'PER','Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N002','Carte Volée Sans violence', 'VOL', 'Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N003','Carte extorquée avec violence', 'VEM', 'Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N004','Carte non parvenue au porteur', 'NPA', 'Q001');
---- Contrefaçon
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N005','Carte Contrefaite', 'FAL', 'Q002');
----Autres (Contestation)
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N006','Facture contestée', 'FCT', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N007','Traitement en double', 'DOU', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N008','Service non rendu ou marchandise non reçue ou défectueuse', 'SNR', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N009','DAB billets non délivrés', 'BND', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N010','DAB billets partiellement délivrés', 'BPD', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N011','Montant erroné', 'MER', 'Q003');



--Motif
-- Motifs
---- perte-vol
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description)
 VALUES
('M001','M001.label',1,0, 0,'facultatif',1,'obligatoire',390, 100, 'M001.DISCLAIMER', 'LESDEUX','N001','Q001', 'M001.DESCRIPTION');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M002','M002.label',1,0, 0,'recommande',1,'obligatoire',390, 100, 'M002.DISCLAIMER', 'LESDEUX','N002','Q001', 'M002.DESCRIPTION');
-- FRAUDE
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M006','M006.label',0,0, 0,'facultatif',0,'facultatif',390, 100, 'M006.DISCLAIMER', 'LESDEUX','N006','Q002', 'M006.DESCRIPTION');

-- Debit multiple
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M007','M007.label',0,0, 0,'facultatif',0,'facultatif',390, 100, 'M007.DISCLAIMER', 'LESDEUX','N007','Q002', 'M007.DESCRIPTION');
-- Litige commercial
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M008','M008.label',0,0, 0,'recommande',0,'obligatoire',70, 100, 'M008.DISCLAIMER', 'PAIEMENT','N008','Q099', 'M008.DESCRIPTION');
-- Billets partiellement ou non d\u00e9livr\u00e9s
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M009','M009.label',0,1, 1,'facultatif',0,'facultatif',390, 1, 'M009.DISCLAIMER', 'RETRAIT','N009','Q099', 'M009.DESCRIPTION');

-- Montant erron\u00e9
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M011','M011.label',0,1, 1,'obligatoire',0,'facultatif',390, 1, 'M011.DISCLAIMER', 'PAIEMENT','N011','Q099', 'M011.DESCRIPTION');

---Justificatif clients à demander
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('q0Umf+vVSDiJVCR1ra5uAg', 'Contrat de location', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('0QdGs72/RWeKln/F+tK1JA', 'Facture', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('T/jAumuaTnKrhZdmmGds2g', 'Billet de réservation de place', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('eax0DCEGRdmkhceeLdCyhg', 'Description service ou marchandise', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('DWg4zGG/RLO1S982Ux7mKQ', 'PV de police', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('rFCx9O/LTTaECHv7TPZWRA', 'Ticket', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('0A/UtsFGRreBKmTBQPX0xQ', 'Facturette', '20019256');

--Jutificatifs par motif
--- Vol
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('DWg4zGG/RLO1S982Ux7mKQ','M002');
--- Litige commercial
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('q0Umf+vVSDiJVCR1ra5uAg','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code)VALUES('0QdGs72/RWeKln/F+tK1JA','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('T/jAumuaTnKrhZdmmGds2g','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('eax0DCEGRdmkhceeLdCyhg','M008');
---montant erroné
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('rFCx9O/LTTaECHv7TPZWRA','M011');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('0A/UtsFGRreBKmTBQPX0xQ','M011');



---insert Anonymized card
insert into Carte_Alias (type_produit,card_id, masked_pan, num_compte, pan, date_fin_validite, statut_carte, date_opposition, date_cloture, id) 
values('Produit','CA10928309835','448************00','30004','4484124900001566000',TO_TIMESTAMP('09/09/2019','dd/mm/yyyy'),'VALIDE',TO_TIMESTAMP('09/07/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/08/2019','dd/mm/yyyy'),'CARD0005');

insert into Carte_Alias (type_produit,card_id, masked_pan, num_compte, pan, date_fin_validite, statut_carte, date_opposition, date_cloture, id) 
values('Produit','CA10928309836','448************00','30004','0004974104260695501',TO_TIMESTAMP('09/09/2019','dd/mm/yyyy'),'VALIDE',TO_TIMESTAMP('09/07/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/08/2019','dd/mm/yyyy'),'CARD0006');

insert into OPERATIONTMP(id_telematic,user_id,date_creation, date_maj,code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation,id) 
values ('345615789521','01280000176000000',TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'OPC01',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'OP004');


----Insertion des statuts de dossier
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC001',1,'BROUILLON');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC002',2,'CREE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC003',3,'En Cours');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC004',4,'TRAITE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC005',5,'CLOTURE');

--Etat des cartes
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'BLOQUE');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'EN COURS');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'DISPONIBLE');

 --insertion des cartes

insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('31/03/2019','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT001','VOL DE CARTE','PIERRE','4974028305717800','VISA','CA001');

insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2020','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT002','VOL DE CARTE','CHARLES','4974108217705420','VISA','CA002');


insert into carte (date_creation, date_maj, date_expir, date_oppo, etat_carte, motif_oppo, nom_estampe, pan, type_carte, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('30/09/2021','dd/mm/yyyy'),TO_TIMESTAMP('08/05/2019','dd/mm/yyyy'),'ETAT003','VOL DE CARTE','CARL','4974028130208163','MASTER CARD','CA003');
 
 
 
 
 Insert into EMETEUR (ID,DATE_CREATION,DATE_MAJ,ADRESSE1,ADRESSE2,ADRESSE3,ADRESSE4,ADRESSE5,CODE_UO_AGENCE,CODE_UO_SUR,HELLO_BANK,MONACO,TELEPHONE)
  values ('8x5IVvxhTIaJXcL6hqQJzQ',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'BNP PARIBAS',null,null,null,'string','00058','00058','0','0','string');
 
 
 
 Insert into DESTINATAIRE (ID,DATE_CREATION,DATE_MAJ,ADRESSE1,ADRESSE2,ADRESSE3,ADRESSE4,ADRESSE6,CIVILITE)
  values ('s2IOwZMbR+yZqWGinPNpNA',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'MME LE CIIHRA APYZUE PYGHUVEU RANYHI','21 RESIDENCE LE CLOS AMANDINE','RUE MAURICE RAVEL',null,'77340 PONTAULT COMBAULT','3');
 

 insert into edition (id,status,num_sequence,date_creation,date_maj,adr_retour,autres_donnees,canal,code_ape,code_chefdefiledest,code_chefdefileemet,code_motifipaye,code_type_doc,codebanque_dom,codebanque_mempracc,codebanque_memprtit,contact_dest,contact_emet,date_appel,date_creation_smc,date_opposition,date_reglmntinitial,date_rglmntimpaye,date_rglmntrepres,date_traitement,dateheure_transaction,delais_reponse,editique_central,email_dest,email_emet,fax_dest,fax_emet,id_user,lib_type_doc,loc_depart,maquette_id,montant_brut,montant_compense,montant_conteste,nature_dossier,nature_dossier_libelle,nom_porteur,nom_service,nombre_operations,num_carte_masque,num_client,num_distributeur,num_dossier,num_siret,numero_carte,prenom_porteur,qualification_dossier,raison_sociale,reference_archivage,telephone_dest,telephone_emet,top_clientele,total_operations,type_operation,type_reglmntsouhaite,destinataire,emeteur)
 
 
  values ('YgpTShtMSU2IyuU2CtYI2g','NONTRAITER',1,TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'string','string','1','1','1','250','string','string','250','250','300','string','01 45 32 88 20','11/12/2018','11/12/2018','11/12/2018','11/12/2018','11/12/2018','11/12/2018','11/12/2018','11/12/2018','0','1','string','user@example.com','string','string','string','string','250','trby9con','string','string','string','123','Facture contestée','LE CIIHRA','Service Contestations Cartes','2','4970 XXXX XXXX 5142','string','250','E201812147522369','250','0004974074205032328','APYZUE PYGHUVEU RANYHI','2','xxxxx','250','string',null,'1','0','string','250','s2IOwZMbR+yZqWGinPNpNA','8x5IVvxhTIaJXcL6hqQJzQ');
 
 
  Insert into OPERATION_EDITION (ID,DATE_CREATION,DATE_MAJ,DATE_COMPENSATION,DATE_VENTE,MONTANT_IMPUTE,RAISON_SOCIALE,EDITION_ID) 
  values ('W37f5p5sTtWlyeQF+ZUcbg',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'11/12/2018','11/12/2018','8','string','YgpTShtMSU2IyuU2CtYI2g');
 
 Insert into PARAGRAPHE (ID,DATE_CREATION,DATE_MAJ,INDEX_PARAGRAPHE,EDITION_ID) values ('elwfuvxTQ7G5Yj9njum7HQ',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'0','YgpTShtMSU2IyuU2CtYI2g');
--
 
 Insert into PHRASE (ID,DATE_CREATION,DATE_MAJ,INDEX_PHRASE,TEXTE_PHRASE,PARAGRAPHE_ID)
 values ('IzenaZscQoyQXximtTvGXA',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'2','Amazon du 10.10.2018 de 15,00 ? régularisée le 18.10.2018','elwfuvxTQ7G5Yj9njum7HQ');
 
 Insert into PHRASE (ID,DATE_CREATION,DATE_MAJ,INDEX_PHRASE,TEXTE_PHRASE,PARAGRAPHE_ID) 
 values ('dcOmIN8qSA6jSR0iqluWIg',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'0','Nous avons procédé à l''analyse de votre dossier daté du 12.11.2018 concernant 20 opération[s] pour un montant total de 2 458,81 ?.','elwfuvxTQ7G5Yj9njum7HQ');


Insert into PHRASE (ID,DATE_CREATION,DATE_MAJ,INDEX_PHRASE,TEXTE_PHRASE,PARAGRAPHE_ID)
 values ('Layol2kFQyGZz1gV18Rd+Q',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'1','- l''(es) opération(s) ci-dessous a (ont) fait l''objet d''un remboursement :','elwfuvxTQ7G5Yj9njum7HQ');

insert into postscriptum (edition_id, post_scriptum) values ('YgpTShtMSU2IyuU2CtYI2g', 'postcriupm mime');

insert into commentaires (edition_id, commentaires) values ('YgpTShtMSU2IyuU2CtYI2g','mon commentaire');

insert into edition_entity_sne_maquette(edition_entity_id,sne_maquette,sne_maquette_key)
 values ('YgpTShtMSU2IyuU2CtYI2g','20180103AA','MONSMCDILDBHC0101');
insert into edition_entity_sne_maquette(edition_entity_id,sne_maquette,sne_maquette_key)
 values ('YgpTShtMSU2IyuU2CtYI2g','20180103AB','MONSMCDIAXBHC0101');




----1 JDD avec 1 contestation historisée avec plusieurs documents joints
insert into contestation (date_creation, date_maj, carte_id, carte_perdue, dernier_statut, description_faits, id_porteur, id_telematique, mail, montant_conteste, montant_reconnu_porteur, montant_remboursement, motif_contestation, motif_rejet, nombre_operations, notif_mail, notif_push, notifsms, pan, reference_dossier_smc, is_purged, telephone, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CA003',1,'SC001','Contestation de vole de carte','01700021073900000','3865814351','bnp1@pbpparispas.com', 73.0, 13.0 , 16.0 ,'M001','Refus pour absence de justificatif',3, 0, 0, 0,'4974028130208163','NUMDOSSIER080',0,'0612525744', 'C00041');

insert into operation (date_creation, date_maj, code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation, contestation_id, id) 
values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'CODE4',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',73.0, 13.0,'HENRY','DEBIT',0,'C00041','OP041');



insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001mu','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC006');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m5','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC007');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m9','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC008');

insert into document_attachement (date_creation, date_maj, format, id_gdn, nom_doc, reference_dossier_smc, type_doc_gdn,contestation_id, id)
 values (TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'PDF','GD11100jnlx2i0j000001m7','PAYEMENT','NUMDOSSIER080','20180110','C00041','DOC009');
 
 

