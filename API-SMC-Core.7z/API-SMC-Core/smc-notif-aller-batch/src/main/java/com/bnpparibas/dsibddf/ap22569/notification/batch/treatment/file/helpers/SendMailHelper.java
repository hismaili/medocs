package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.helpers;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.SendMailException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.NotificationDetailValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.RejectDetail;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file.FileValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

@Component
public class SendMailHelper {


    @Value("${file.input}")
    private FileSystemResource inputResource;


    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private TemplateEngine emailTemplateEngine;

    @Autowired
    @Qualifier("errorMessageResourceBundle")
    private ResourceBundle resourceBundle;

    @Value("${mail.templates.location}")
    private String mailTemplatesLocation;


    public void sendDetailRejectsMail(List<Throwable> detailRejectExceptions) throws SendMailException {
        if(!CollectionUtils.isEmpty(detailRejectExceptions)) {
            try {
                List<RejectDetail> rejectsDetails = detailRejectExceptions.stream().map(rej -> {
                    NotificationDetailValidationException ex = (NotificationDetailValidationException) rej;
                    NotificationLine notificationLine = ex.getNotificationLine();
                    RejectDetail rejectDetail = new RejectDetail(notificationLine.getDossierSmc(),
                            notificationLine.getCodeNotif(),
                            resourceBundle.getString("notif.label." + notificationLine.getCodeNotif()),
                            ex.getInvalidData(), ex.getInvalidDataValue(), resourceBundle.getString("reject.message." + ex.getErrorCode()));
                    return rejectDetail;
                }).collect(Collectors.toList());

                IContext ctx = new Context();
                ((Context) ctx).setVariable("numberOfRejects", rejectsDetails.size());
                ((Context) ctx).setVariable("fileDate", LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
                ((Context) ctx).setVariable("fileName", inputResource.getFilename());
                ((Context) ctx).setVariable("rejectList", rejectsDetails);
                String emailText = emailTemplateEngine.process(mailTemplatesLocation + "/html/rejet-details.html", ctx);
                System.out.println(emailText);
            } catch(Exception e) {
                throw new SendMailException(e);
            }

        }
    }

    public void sendFileRejectMail(List<Throwable> fileRejectExceptions) {

        if(!CollectionUtils.isEmpty(fileRejectExceptions)) {
            Throwable ex = fileRejectExceptions.get(0);
            if(ex instanceof FileValidationException) {
                final FileValidationException ex1 = (FileValidationException) ex;
                String errorCode = ex1.getErrorCode();
                IContext ctx = new Context();
                ((Context) ctx).setVariable("fileName", ex1.getFileName());
                ((Context) ctx).setVariable("fileDate", ex1.getFileDate() != null ? ex1.getFileDate().format(DateTimeFormatter.ISO_DATE) : "");
                ((Context) ctx).setVariable("rejectReason", resourceBundle.getString("reject.message."+errorCode));
                String emailText = emailTemplateEngine.process(mailTemplatesLocation+"/text/rejet-file", ctx);
                System.out.println(emailText);
            }
        }



    }
}
