package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public final class SmcErrorMessage {
    public static final String MANDATORY_FIELD_MISSED_CODE = "9010";
    public static final String MANDATORY_FIELD_MISSED_LABEL = "Le champ %s doit être renseigné";
    public static final String ONE_OPERATION_REQUIRED_LABEL = "Une et une seule opération autorisée pour le motif %s.";
    public static final String ONE_OPERATION_REQUIRED_CODE = "9011";
    public static final String RECOGNIZED_AMOUNT_REQUIRED_LABEL = "Le montant reconnu est obligatoire pour le motif %s.";
    public static final String RECOGNIZED_AMOUNT_REQUIRED_CODE = "9012";
    public static final String MANDATORY_OPE_FIELD_MISSED_CODE = "9013";
    public static final String MANDATORY_OPE_FIELD_MISSED_LABEL = "La donnée %s doit être renseignée pour toute les opérations.";
}
