/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.SensOperation;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "OPERATIONTMP")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class OperationTmpEntity extends AbstractEntity<DefaultEntityId>  {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** Coidop de l'opération */
	@Column(name="code_peration")
	private String codeOperation;

	/** l'ikpi de l'utulisateur appartenant l'opération*/
	@Column(name="user_id")
	private String userId;

	/** id telematic de l'utilisateur */
	@Column(name="id_telematic")
	private String idTelematic;

	/** numéro de carte de l'opération */
	@Column(name="numero_carte")
	private String numCarte;

	/** Le type d'opération : retrait, VAD,  */
	@Column(name="type_operation")
	private TypeOperation typeOperation;

	/** Le montant de l'opération */
	@Column(name="montant_operation")
	private BigDecimal montantOperation;

	/** La date de l'opération */
	@Column(name="date_operation")
	private LocalDate dateOperation;

	/** Le libellé de l'opération */
	@Column(name="libelle_operation")
	private String libelleOperation;

	/** Le montant reconnu par l'utilisateur pour les contestations pour des montants erronés */
	@Column(name="montant_reconnu")
	private BigDecimal montantReconnu;

	@Column(name="Nom_Commercant")
	private String nomCommercant;
	@Column(name="date_vente")
	private LocalDate dateVente;

	@Enumerated(EnumType.STRING)
	private SensOperation sensOperation;

	@Column(name="devise_operation")
	private String deviseOperation;

	/**
	 * @return the codeOperation
	 */
	public String getCodeOperation() {
		return codeOperation;
	}

	/**
	 * @return the dateOperation
	 */
	public LocalDate getDateOperation() {
		return dateOperation;
	}

	/**
	 * @return the dateVente
	 */
	public LocalDate getDateVente() {
		return dateVente;
	}

	/**
	 * @return the deviseOperation
	 */
	public String getDeviseOperation() {
		return deviseOperation;
	}

	/**
	 * @return the idTelematic
	 */
	public String getIdTelematic() {
		return idTelematic;
	}

	/**
	 * @return the libelleOperation
	 */
	public String getLibelleOperation() {
		return libelleOperation;
	}

	/**
	 * @return the montantOperation
	 */
	public BigDecimal getMontantOperation() {
		return montantOperation;
	}

	/**
	 * @return the montantReconnu
	 */
	public BigDecimal getMontantReconnu() {
		return montantReconnu;
	}

	/**
	 * @return the nomCommercant
	 */
	public String getNomCommercant() {
		return nomCommercant;
	}

	/**
	 * @return the numCarte
	 */
	public String getNumCarte() {
		return numCarte;
	}

	/**
	 * @return the sensOperation
	 */
	public SensOperation getSensOperation() {
		return sensOperation;
	}

	/**
	 * @return the typeOperation
	 */
	public TypeOperation getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param codeOperation the codeOperation to set
	 */
	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}

	/**
	 * @param dateOperation the dateOperation to set
	 */
	public void setDateOperation(LocalDate dateOperation) {
		this.dateOperation = dateOperation;
	}

	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(LocalDate dateVente) {
		this.dateVente = dateVente;
	}

	/**
	 * @param deviseOperation the deviseOperation to set
	 */
	public void setDeviseOperation(String deviseOperation) {
		this.deviseOperation = deviseOperation;
	}

	/**
	 * @param idTelematic the idTelematic to set
	 */
	public void setIdTelematic(String idTelematic) {
		this.idTelematic = idTelematic;
	}

	/**
	 * @param libelleOperation the libelleOperation to set
	 */
	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	/**
	 * @param montantOperation the montantOperation to set
	 */
	public void setMontantOperation(BigDecimal montantOperation) {
		this.montantOperation = montantOperation;
	}

	/**
	 * @param montantReconnu the montantReconnu to set
	 */
	public void setMontantReconnu(BigDecimal montantReconnu) {
		this.montantReconnu = montantReconnu;
	}

	/**
	 * @param nomCommercant the nomCommercant to set
	 */
	public void setNomCommercant(String nomCommercant) {
		this.nomCommercant = nomCommercant;
	}

	/**
	 * @param numCarte the numCarte to set
	 */
	public void setNumCarte(String numCarte) {
		this.numCarte = numCarte;
	}

	/**
	 * @param sensOperation the sensOperation to set
	 */
	public void setSensOperation(SensOperation sensOperation) {
		this.sensOperation = sensOperation;
	}

	/**
	 * @param typeOperation the typeOperation to set
	 */
	public void setTypeOperation(TypeOperation typeOperation) {
		this.typeOperation = typeOperation;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

}
