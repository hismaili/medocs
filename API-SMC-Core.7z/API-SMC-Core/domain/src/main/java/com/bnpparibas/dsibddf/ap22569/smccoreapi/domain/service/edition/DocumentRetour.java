/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import org.springframework.util.CollectionUtils;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author c65344
 *
 */
public class DocumentRetour {
	private String numDossier;
	private BigInteger idDocSmc;
	private String idGDN;
	private LocalDate dateRetrait;

	private boolean topSecurisation;

	private String originalLine;

	private Integer lineNumber;

	private InfoFileArchivage info;

	/**
	 * @return the dateRetrait
	 */
	public LocalDate getDateRetrait() {
		return dateRetrait;
	}

	/**
	 * @return the idDocSmc
	 */
	public BigInteger getIdDocSmc() {
		return idDocSmc;
	}

	/**
	 * @return the idGDN
	 */
	public String getIdGDN() {
		return idGDN;
	}

	/**
	 * @return the info
	 */
	public InfoFileArchivage getInfo() {
		return info;
	}


	/**
	 * @return the lineNumber
	 */
	public Integer getLineNumber() {
		return lineNumber;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the originalLine
	 */
	public String getOriginalLine() {
		return originalLine;
	}

	/**
	 * check if is there data null
	 * @return
	 */
	public boolean isNull(){
		boolean value =true;
		List<Object> data = new ArrayList<>();

		data.add(numDossier);
		data.add(idDocSmc);
		data.add(idGDN);
		data.add(dateRetrait);
		data.add(originalLine);
		data.add(lineNumber);
		data.add(info);
		if(!CollectionUtils.isEmpty(data)){
			long count = data.stream()
					.filter(d -> d == null)
					.map(object -> object)
					.count();
			value = count != 0;
		}

		return value;
	}

	/**
	 * @return the topSecurisation
	 */
	public boolean isTopSecurisation() {
		return topSecurisation;
	}

	/**
	 * @param dateRetrait the dateRetrait to set
	 */
	public void setDateRetrait(LocalDate dateRetrait) {
		this.dateRetrait = dateRetrait;
	}

	/**
	 * @param idDocSmc the idDocSmc to set
	 */
	public void setIdDocSmc(BigInteger idDocSmc) {
		this.idDocSmc = idDocSmc;
	}

	/**
	 * @param idGDN the idGDN to set
	 */
	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}

	/**
	 * @param info the info to set
	 */
	public void setInfo(InfoFileArchivage info) {
		this.info = info;
	}

	/**
	 * @param lineNumber the lineNumber to set
	 */
	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}
	/**
	 * @param originalLine the originalLine to set
	 */
	public void setOriginalLine(String originalLine) {
		this.originalLine = originalLine;
	}

	/**
	 * @param topSecurisation the topSecurisation to set
	 */
	public void setTopSecurisation(boolean topSecurisation) {
		this.topSecurisation = topSecurisation;
	}
}
