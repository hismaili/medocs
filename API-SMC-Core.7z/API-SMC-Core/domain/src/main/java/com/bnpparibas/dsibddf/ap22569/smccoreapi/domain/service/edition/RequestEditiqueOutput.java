package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;
/**
 *
 * @author c65344
 *
 */
public class RequestEditiqueOutput {
	private String pdfresult;
	private String pdfvers;
	private String prodname;
	private String prodversion;
	private String dateedition;
	private String nombreDePage;
	private String fileType;
	/**
	 *
	 */
	public RequestEditiqueOutput() {
		super();
	}
	/**
	 * @param pdfresult
	 * @param pdfvers
	 * @param prodname
	 * @param prodversion
	 * @param dateedition
	 * @param nombreDePage
	 */
	public RequestEditiqueOutput(String pdfresult, String pdfvers,
			String prodname, String prodversion, String dateedition,
			String nombreDePage) {
		this.pdfresult = pdfresult;
		this.pdfvers = pdfvers;
		this.prodname = prodname;
		this.prodversion = prodversion;
		this.dateedition = dateedition;
		this.nombreDePage = nombreDePage;
	}
	/**
	 * @return the dateedition
	 */
	public String getDateedition() {
		return dateedition;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @return the nombreDePage
	 */
	public String getNombreDePage() {
		return nombreDePage;
	}
	/**
	 * @return the pdfresult
	 */
	public String getPdfresult() {
		return pdfresult;
	}
	/**
	 * @return the pdfvers
	 */
	public String getPdfvers() {
		return pdfvers;
	}
	/**
	 * @return the prodname
	 */
	public String getProdname() {
		return prodname;
	}
	/**
	 * @return the prodversion
	 */
	public String getProdversion() {
		return prodversion;
	}
	/**
	 * @param dateedition the dateedition to set
	 */
	public void setDateedition(String dateedition) {
		this.dateedition = dateedition;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @param nombreDePage the nombreDePage to set
	 */
	public void setNombreDePage(String nombreDePage) {
		this.nombreDePage = nombreDePage;
	}
	/**
	 * @param pdfresult the pdfresult to set
	 */
	public void setPdfresult(String pdfresult) {
		this.pdfresult = pdfresult;
	}
	/**
	 * @param pdfvers the pdfvers to set
	 */
	public void setPdfvers(String pdfvers) {
		this.pdfvers = pdfvers;
	}
	/**
	 * @param prodname the prodname to set
	 */
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	/**
	 * @param prodversion the prodversion to set
	 */
	public void setProdversion(String prodversion) {
		this.prodversion = prodversion;
	}
}
