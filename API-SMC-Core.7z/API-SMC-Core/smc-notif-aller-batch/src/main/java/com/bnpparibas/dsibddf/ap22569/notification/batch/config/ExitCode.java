package com.bnpparibas.dsibddf.ap22569.notification.batch.config;

public class ExitCode {
    public static final String EXIT_CODE_NOTIF_REJECTS = "7";
    public static final String EXIT_CODE_FILE_REJECT = "8";
    public static final String EXIT_CODE_UNEXPECTED_ERROR = "9";
    public static final String EXIT_CODE_DB_UPDATE_FILE_OK = "5";
    public static final String EXIT_CODE_DB_UPDATE_FILE_KO = "6";
    public static final String EXIT_CODE_SEND_ALERT_MAIL_KO = "4";
    public static final String EXIT_CODE_ERR_MOVE_FILE_OK = "3";
    public static final String EXIT_CODE_ERR_MOVE_FILE_KO = "2";
}
