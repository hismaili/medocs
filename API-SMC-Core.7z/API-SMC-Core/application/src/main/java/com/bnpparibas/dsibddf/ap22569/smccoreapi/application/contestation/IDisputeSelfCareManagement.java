/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.AttachmentDataInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.DisputeResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;

/**
 * @author c65344
 *
 */
public interface IDisputeSelfCareManagement {

	/**
	 * Permet de rattacher des fichiers à un dossier de contestation à partir du numéro de dossier
	 * et des identifiants GED.
	 *
	 * @param attach
	 * @return
	 */
	DisputeResponse attachedDocuments(AttachmentDataInput attach) throws MandatoryException;

	/**
	 * generère le recapitulatif selfcare
	 *
	 * @param dispute
	 */
	void generateAndSaveRecap(Contestation dispute) throws ContestationException, ContestationValidationException ;


	/**
	 * Créer un dossier SelfCare
	 *
	 * @param dispute
	 * @return
	 */
	DisputeResponse sendDisputeToSmc(Contestation dispute) throws MandatoryException;
}
