package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons.MaskUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class CardService implements ICardService {

	@Autowired(required=false)
	private transient ICardRepository cardRepository;

//	private Map<String, AnonymizedCard> cards;

	//	{
	//		cards = new HashMap<>();
	//		AnonymizedCard anonymizedCard = new AnonymizedCard();
	//		CartePorteur carte = new CartePorteur();
	//		carte.setDateFinValiditeInput(LocalDate.of(2021, 12, 31));
	//		carte.setIkpi("2455387645359");
	//		carte.setNumCarteInput("4484124900001566000");
	//		carte.setTypeProduit("PREMIUM");
	//		carte.setNumCompte("30004");
	//		//carte.set
	//		anonymizedCard.setCarte(carte);
	//		anonymizedCard.setMaskedPan(MaskUtils.maskPan("4484124900001566000"));
	//		cards.put("CA10928309835", anonymizedCard);
	//	}

	@Override
	public List<AnonymizedCard> anonymizeCartes(List<CartePorteur> cartes) throws CardException {
		List<AnonymizedCard> result = null;
		//TODO throw exception if empty
		if (!CollectionUtils.isEmpty(cartes)) {
			result = cartes.stream().map(carte -> {
				AnonymizedCard card = new AnonymizedCard();
				//TODO nom du porteur de la carte
				String cardId = UUID.randomUUID().toString();
				card.setCardId(cardId);
				card.setMaskedPan(MaskUtils.maskPan(carte.getNumCarteInput()));
				card.setCarte(carte);
				return card;
			}).collect(Collectors.toList());
		}
		return result;
	}

	@Override
	public AnonymizedCard getCardByCardId(String cardId) throws CardException {

		return cardRepository.getCardByCardId(cardId);
	}

	@Override
	public List<AnonymizedCard> getCartesAnonymiseesPourCompte(List<String> ribs) throws CardException {
		List<AnonymizedCard> anonymizedCards = this.cardRepository.getAnonymizedCards(ribs);
		if(CollectionUtils.isEmpty(anonymizedCards)) {
			List<CartePorteur> cartes = cardRepository.getCartesPourComptes(ribs);
			anonymizedCards = anonymizeCartes(cartes);
			this.cardRepository.saveAnonymizedCards(anonymizedCards);
		}
		return anonymizedCards;
	}

	@Override
	public List<CartePorteur> getCartesPorteur(String iKpi) throws CardException {
		return cardRepository.getCartesPorteur(iKpi);
	}

	@Override
	public List<CartePorteur> getCartesPourCompte(List<String> ribs) throws CardException {
		return cardRepository.getCartesPourComptes(ribs);
	}

	@Override
	public InfoCarte getInfoCard(String pan) throws CardException {
		return cardRepository.getInfoCard(pan);
	}
}
