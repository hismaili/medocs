package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Données permettant d&#39;identifier et renseigner les données du pdf
 */
@ApiModel(description = "Données permettant d'identifier et renseigner les données du pdf")
public class GeneratePDFRequestMaquetteDef   {
	@ApiModelProperty(required = true, value = "editiqueCentrale")
	private Boolean editiqueCentrale;

	@ApiModelProperty(required = true, value = "maquetteIdentification")
	private PDFRequestMaquetteIdentification maquetteIdentification;

	@ApiModelProperty(required = true, value = "donneesMaquette")
	private PDFRequestDonneesMaquette donneesMaquette;

	/**
	 *
	 */
	public GeneratePDFRequestMaquetteDef() {
		super();

	}

	/**
	 * @param editiqueCentrale
	 * @param maquetteIdentification
	 * @param donneesMaquette
	 */
	public GeneratePDFRequestMaquetteDef(Boolean editiqueCentrale,
			PDFRequestMaquetteIdentification maquetteIdentification,
			PDFRequestDonneesMaquette donneesMaquette) {
		this.editiqueCentrale = editiqueCentrale;
		this.maquetteIdentification = maquetteIdentification;
		this.donneesMaquette = donneesMaquette;
	}



	/**
	 * @return the donneesMaquette
	 */
	public PDFRequestDonneesMaquette getDonneesMaquette() {
		return donneesMaquette;
	}

	/**
	 * @return the editiqueCentrale
	 */
	public Boolean getEditiqueCentrale() {
		return editiqueCentrale;
	}

	/**
	 * @return the maquetteIdentification
	 */
	public PDFRequestMaquetteIdentification getMaquetteIdentification() {
		return maquetteIdentification;
	}

	/**
	 * @param donneesMaquette the donneesMaquette to set
	 */
	public void setDonneesMaquette(PDFRequestDonneesMaquette donneesMaquette) {
		this.donneesMaquette = donneesMaquette;
	}

	/**
	 * @param editiqueCentrale the editiqueCentrale to set
	 */
	public void setEditiqueCentrale(Boolean editiqueCentrale) {
		this.editiqueCentrale = editiqueCentrale;
	}

	/**
	 * @param maquetteIdentification the maquetteIdentification to set
	 */
	public void setMaquetteIdentification(
			PDFRequestMaquetteIdentification maquetteIdentification) {
		this.maquetteIdentification = maquetteIdentification;
	}


}

