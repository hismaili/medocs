package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class DisputeSummaryDTO {

    private String factsSummary ;

    private String identifiantInterne ;

    private BigDecimal disputedAmount ;

    private BigDecimal recognizedAmount ;

    private String reason ;

    private Integer numberOfOperations ;

    private String disputeFolderReference ;

    private String currentStatus ;

    private String maskedPan ;

    private String cardType ;

    private LocalDate dateOpposition ;

    private LocalDateTime disputeFolderCreationDate ;

    public String getFactsSummary() {
        return factsSummary;
    }

    public void setFactsSummary(String factsSummary) {
        this.factsSummary = factsSummary;
    }

    public String getIdentifiantInterne() {
        return identifiantInterne;
    }

    public void setIdentifiantInterne(String identifiantInterne) {
        this.identifiantInterne = identifiantInterne;
    }

    public BigDecimal getDisputedAmount() {
        return disputedAmount;
    }

    public void setDisputedAmount(BigDecimal disputedAmount) {
        this.disputedAmount = disputedAmount;
    }

    public BigDecimal getRecognizedAmount() {
        return recognizedAmount;
    }

    public void setRecognizedAmount(BigDecimal recognizedAmount) {
        this.recognizedAmount = recognizedAmount;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Integer getNumberOfOperations() {
        return numberOfOperations;
    }

    public void setNumberOfOperations(Integer numberOfOperations) {
        this.numberOfOperations = numberOfOperations;
    }

    public String getDisputeFolderReference() {
        return disputeFolderReference;
    }

    public void setDisputeFolderReference(String disputeFolderReference) {
        this.disputeFolderReference = disputeFolderReference;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getMaskedPan() {
        return maskedPan;
    }

    public void setMaskedPan(String maskedPan) {
        this.maskedPan = maskedPan;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public LocalDate getDateOpposition() {
        return dateOpposition;
    }

    public void setDateOpposition(LocalDate dateOpposition) {
        this.dateOpposition = dateOpposition;
    }

    public LocalDateTime getDisputeFolderCreationDate() {
        return disputeFolderCreationDate;
    }

    public void setDisputeFolderCreationDate(LocalDateTime disputeFolderCreationDate) {
        this.disputeFolderCreationDate = disputeFolderCreationDate;
    }
}
