/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author c65344
 *
 */
public class IdentifiantDocument {

	@JsonProperty("idGed")
	private String idGDN;
	@JsonProperty("formatDoc")
	private String formatDocument;
	@JsonProperty("fileName")
	private String  nomDocument;
	@JsonProperty("typeDoc")
	private String typeDocGDN;
	/**
	 * @return the formatDocument
	 */
	public String getFormatDocument() {
		return formatDocument;
	}
	/**
	 * @return the idGDN
	 */
	public String getIdGDN() {
		return idGDN;
	}
	/**
	 * @return the nomDocument
	 */
	public String getNomDocument() {
		return nomDocument;
	}
	/**
	 * @return the typeDocGDN
	 */
	public String getTypeDocGDN() {
		return typeDocGDN;
	}
	/**
	 * @param formatDocument the formatDocument to set
	 */
	public void setFormatDocument(String formatDocument) {
		this.formatDocument = formatDocument;
	}
	/**
	 * @param idGDN the idGDN to set
	 */
	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}
	/**
	 * @param nomDocument the nomDocument to set
	 */
	public void setNomDocument(String nomDocument) {
		this.nomDocument = nomDocument;
	}
	/**
	 * @param typeDocGDN the typeDocGDN to set
	 */
	public void setTypeDocGDN(String typeDocGDN) {
		this.typeDocGDN = typeDocGDN;
	}

}
