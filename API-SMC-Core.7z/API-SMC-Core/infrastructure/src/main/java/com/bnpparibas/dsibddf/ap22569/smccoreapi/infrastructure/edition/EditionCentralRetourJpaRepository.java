/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author c65344
 *
 */
@Component
public interface EditionCentralRetourJpaRepository extends JpaRepository<DocumentGdnReturnEntity, String>  {

	/**
	 *
	 * @return
	 */
	List<DocumentGdnReturnEntity> findBySendFalse();


}
