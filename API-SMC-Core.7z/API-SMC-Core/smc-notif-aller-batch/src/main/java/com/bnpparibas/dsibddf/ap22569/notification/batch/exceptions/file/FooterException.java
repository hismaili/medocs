package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file;

import java.time.LocalDate;

public class FooterException extends FileValidationException {

    private int numberOfRecordsFotter;
    private int count;

    public FooterException(String errorCode, int numberOfRecordsFotter, int count, String fileName, LocalDate fileDate, String errorMessage) {
        super(errorMessage, errorCode, fileName, fileDate, errorMessage);
        this.numberOfRecordsFotter = numberOfRecordsFotter;
        this.count = count;
    }



    public int getNumberOfRecordsFotter() {
        return numberOfRecordsFotter;
    }

    public int getCount() {
        return count;
    }
}
