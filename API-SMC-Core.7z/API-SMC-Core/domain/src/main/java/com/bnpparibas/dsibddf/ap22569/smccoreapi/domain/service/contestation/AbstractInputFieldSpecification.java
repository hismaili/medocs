package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public abstract class AbstractInputFieldSpecification<T> implements IInputValidationSpecification {

	private final IInputValidationSpecification[] specifications;

	public AbstractInputFieldSpecification(IInputValidationSpecification... specifications) {

		IInputValidationSpecification[] specification =null;
		if(specifications !=null){
			specification = specifications.clone();
		}
		this.specifications = specification;
	}

	@Override
	public boolean and(IInputValidationSpecification specification) {
		return false;
	}

	public IInputValidationSpecification[] getSpecifications() {
		IInputValidationSpecification[] specification = null;

		if(specifications !=null){
			specification = specifications;
		}
		return specification;
	}

	@Override
	public boolean not(IInputValidationSpecification specification) {
		return false;
	}

	@Override
	public boolean or(IInputValidationSpecification specification) {
		return false;
	}
}
