/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.commons;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.commons.MaskUtils;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.DocumentAttache;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.OperationSelfCare1;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.OperationSelfCare2;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.IinfoPersonne;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class MapperEditionSelfCare {
	private static final Logger LOG = LoggerFactory.getLogger(MapperEditionSelfCare.class);

	//private final static String NUMDOSSIERPROVISOIR = "NUM0000001528";
	private final static String PATTERN = "dd/MM/yyyy";

	@Autowired(required = false)
	private transient IinfoPersonne personneService;


	@Autowired
	private transient ICardServicesManagement cardServicesManagement;


	@Autowired
	@Qualifier("i18nMessages")
	private transient MessageSource messageSource;



	/**
	 * @param contestation
	 * @return
	 * @throws ContestationException
	 */
	public RequestEditiqueInput generateRequestEditique(
			Contestation contestation)
					throws ContestationException {
		RequestEditiqueInput request = new RequestEditiqueInput();

		request.setNumCarteMasque(MaskUtils.maskPan(contestation.getNumCarte()));

		DateTimeFormatter formater =DateTimeFormatter.ofPattern(PATTERN);

		request.setNumDossier(contestation.getNumDossierSMC());

		if (contestation.getDateDeCreationDossier() !=null) {
			request.setDateCreationSmc(contestation.getDateDeCreationDossier().format(formater));
		}

		/**
		 * On recupère la date du jour comme date de traitement pour l'edition du selfCare
		 */
		request.setDateTraitement(LocalDate.now().format(formater));


		if(contestation.getCarte() !=null){
			request.setTypeCarte(contestation.getCarte().getTypeProduit());
		}

		MotifContestation motif = contestation.getMotif();
		if(motif !=null){
			request.setMotifContestation(motif.getCode());

			request.setLibelleMotifContestation(getMessage(motif.getLibelle()));
		}

		if(contestation.getDernierStatutDossier() !=null){
			request.setStatutDossier(contestation.getDernierStatutDossier().getLibelleStatut());
		}

		List<Operation> operations = contestation.getOperations();
		if(!CollectionUtils.isEmpty(operations)){

			BigDecimal montantTotal = new BigDecimal(0.00f);

			request.setOperationSelfCare1(operations.stream().map(operation -> {
				return getOperationSelf1(montantTotal, operation);
			}).collect(Collectors.toList()));


			request.setOperationSelfCare2(operations.stream().map(operation -> {
				return getOperationSelf2(montantTotal, operation);
			}).collect(Collectors.toList()));

			request.setTotalOperations(montantTotal.intValue());
		}

		List<DocumentAttache> documentAttaches = contestation.getDocumentAttaches();

		if(!CollectionUtils.isEmpty(documentAttaches)){
			request.setFichierJoints(documentAttaches.stream().filter(doc -> doc !=null && !StringUtils.isEmpty(doc)).map(doc -> doc.getNomDocument())
					.collect(Collectors.toList()));
		}
		String description = contestation.getDescription();
		List<String> descriptionFaits = Arrays.asList(description);
		request.setDescriptifFaits(descriptionFaits);
		try {
			//			InfoCarte infoCarteInputEmeteur = cardServicesManagement.getInfoCarte(contestation.getNumCarte());
			//			String idClientEmeteur = infoCarteInputEmeteur.getIdUniqueClientInput();
			InfoPersonneOutput infoEmeteur = personneService.getInfoPersonneRP(contestation.getIdPorteur());
			request.setNomPorteur(infoEmeteur.getClientName());
			request.setPrenomPorteur(infoEmeteur.getClientFirstname());
		} catch (PorteurException e) {
			LOG.error(e.getMessage(),e);
			throw new ContestationException(e);
		}
		return request;
	}
	/**
	 *
	 * @param messageKey
	 * @return
	 */
	private String getMessage(String messageKey) {
		String messageValue = messageSource.getMessage(
				messageKey, null, null);
		if (StringUtils.isEmpty(messageValue)) {
			LOG.error("Texte introuvable : " + messageKey);
			messageValue = "";
		}
		return messageValue;
	}

	/**
	 * @param montantTotal
	 * @param operation
	 * @return
	 */
	private OperationSelfCare1 getOperationSelf1(BigDecimal montantTotal,
			Operation operation) {
		OperationSelfCare1 opSelf1 = new OperationSelfCare1();

		if(operation.getDateOperation() !=null){
			opSelf1.setDateDebit(operation.getDateOperation().toString());
		}


		opSelf1.setLibelleOperation(operation.getLibelleOperation());
		if(operation.getMontantOperation() !=null){
			opSelf1.setMontantOperation(operation.getMontantOperation().toString());
		}

		if(operation.getDateVente() !=null){
			opSelf1.setDateVente(operation.getDateVente().toString());
		}

		montantTotal.add(operation.getMontantOperation());
		return opSelf1;
	}

	/**
	 * @param montantTotal
	 * @param operation
	 * @return
	 */
	private OperationSelfCare2 getOperationSelf2(BigDecimal montantTotal,
			Operation operation) {
		OperationSelfCare2 opSelf2 = new OperationSelfCare2();

		if(operation.getDateOperation() !=null){
			opSelf2.setDateDebit(operation.getDateOperation().toString());
		}

		if(operation.getDateVente() !=null){
			opSelf2.setDateVente(operation.getDateVente().toString());
		}
		opSelf2.setLibelleOperation(operation.getLibelleOperation());
		if(operation.getMontantOperation() !=null){
			opSelf2.setMontantOperation(operation.getMontantOperation().toString());
		}
		if(operation.getMontantReconnu() !=null){
			opSelf2.setMontantReconnu(operation.getMontantReconnu().toString());
		}

		montantTotal.add(operation.getMontantOperation());
		return opSelf2;
	}



}
