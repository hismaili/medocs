package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;

import java.util.List;

public interface IContestationManagement {

	//void createContestation(ContestationElements contestationElements) throws SmcBusinessException, SmcTechnicalException;

	/**
	 * consulter une contestation identifiée par sa référence dossier SMC
	 */
	Contestation consulterContestation(String referenceDossier,String codeStatus) throws ContestationException,MandatoryException, DonneIncorectException;
	/** consulter une contestation identifiée par son identifiant interne CCM*/
	Contestation consulterContestationParIdInterne(String identifiantInterne) throws ContestationException;

	DisputeSummaryDTO createDispute(DisputeDataDTO disputeData) throws ContestationException, ContestationValidationException;

	List<MotifContestation> getAllMotifs();

	CustomerContactInfos getCustomerContactInfos(String telematicId, String userId) throws ContestationException, ContestationValidationException;

	List<Contestation> getHistoriqueContestations(String identifiant,Integer offset,Integer limit) throws ContestationException;

	List<MotifContestation> getMotifsApplicables(TypeOperation operationType, Boolean cardLost, Integer numberOfOperations) throws Exception;

	List<MotifContestation> getMotifsForOperationType(TypeOperation operationType);

	List<AccountWithCardsDTO> getUserAccountsAndCard(String telematicId,String userId) throws ContestationException, ContestationValidationException;
	/**
	 *
	 * @param idGdn
	 * @param idTelematic
	 * @return
	 */
	boolean isAuthorized(String idGdn, String idTelematic);
}
