package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * AccountWithCards
 */
public class AccountWithCards   {
	@JsonProperty("account")
	private AccountVO account;

	@JsonProperty("cards")
	@Valid
	private List<CardVO> cards;

	public AccountWithCards account(AccountVO account) {
		this.account = account;
		return this;
	}
	/**
	 *
	 * @param cardsItem
	 * @return
	 */
	public AccountWithCards addCardsItem(CardVO cardsItem) {
		if (this.cards == null) {
			this.cards = new ArrayList<CardVO>();
		}
		this.cards.add(cardsItem);
		return this;
	}
	/**
	 *
	 * @param cards
	 * @return
	 */
	public AccountWithCards cards(List<CardVO> cards) {
		this.cards = cards;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		AccountWithCards accountWithCards = (AccountWithCards) o;
		return Objects.equals(this.account, accountWithCards.account) &&
				Objects.equals(this.cards, accountWithCards.cards);
	}

	/**
	 * Get account
	 *
	 * @return account
	 **/
	@ApiModelProperty(value = "")
	@Valid
	public AccountVO getAccount() {
		return account;
	}

	/**
	 * Get cards
	 *
	 * @return cards
	 **/
	@ApiModelProperty(value = "")
	@Valid
	public List<CardVO> getCards() {
		return cards;
	}

	@Override
	public int hashCode() {
		return Objects.hash(account, cards);
	}

	/**
	 *
	 * @param account
	 */
	public void setAccount(AccountVO account) {
		this.account = account;
	}
	/**
	 *
	 * @param cards
	 */
	public void setCards(List<CardVO> cards) {
		this.cards = cards;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class AccountWithCards {\n");

		sb.append("    account: ").append(toIndentedString(account)).append("\n");
		sb.append("    cards: ").append(toIndentedString(cards)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

