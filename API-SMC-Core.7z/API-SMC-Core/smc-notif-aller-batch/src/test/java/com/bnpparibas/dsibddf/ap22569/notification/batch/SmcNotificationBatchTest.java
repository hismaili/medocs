package com.bnpparibas.dsibddf.ap22569.notification.batch;

import org.assertj.core.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SmcNotificationBatchTest {

    //rejets globals
    //code retour
    public void rejectFileWhenSequenceNumberAlreadyProcessedForTheDayTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectFileWhenSequenceNumberIsUnexpectedForTheDayTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectFileWhenNumberOfRecordsIsWrongTest() {
        Assertions.fail("Not yet implemented");
    }

    //rejets partiels
    public void rejectNotificationWhenDisputeFolderNumberNotFoundTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectNotificationWhenRecordCodeIsWrongTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectNotificationWhenAgencyCodeIsBlankTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectNotificationWhenRecordCodeIsBlankTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectNotificationWhenFolderCallDateIsBlankOrMalformattedTest() {
        Assertions.fail("Not yet implemented");
    }

    public void rejectNotificationWhenFolderCreationDateIsBlankOrMalformattedTest() {
        Assertions.fail("Not yet implemented");
    }

    public void dontRejectNotificationWhenMailAdressNotGivenOrMalFormedTest() {
        Assertions.fail("Not yet implemented");
    }

    public void dontRejectNotificationWhenPhoneNumberNotGivenOrMalFormedTest() {
        Assertions.fail("Not yet implemented");
    }

    public void dontRejectNotificationWhenNoChannelProvidedTest() {
        Assertions.fail("Not yet implemented");
    }
}
