/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author c65344
 *
 */
@Component
public class ConfigInfrastructure {

	/**
	 * controle edition central
	 */
	@Value("${EDITION_IKPI_INCORRECT}")
	private String ikpiIncorrect;
	@Value("${EDITION_IKPI_ABSENT}")
	private String ikpiAbsent;


	@Value("${EDITION_CODEUOAGENCE_INCORRECT}")
	private String codeUoAgenceIncorrect;
	@Value("${EDITION_CODEUOSUR_INCORRECT}")
	private String codeUoSurIncorrect;


	@Value("${EDITION_TOPCLIENT_ABSENT}")
	private String topClientAbsent;
	@Value("${EDITION_TOPCLIENT_INCORRECT}")
	private String topClientIncorrect;


	@Value("${EDITION_IDCONTRATMONETIQUEPORTEUR_ABSENT}")
	private String idContratMonetiquePorteurAbsent;
	@Value("${EDITION_IDCONTRATMONETIQUEPORTEUR_INCORRECT}")
	private String idContratMonetiquePorteurIncorrect;


	@Value("${EDITION_RIBOPERATION_ABSENT}")
	private String ribOperationAbsent;
	@Value("${EDITION_RIBOPERATION_INCORRECT}")
	private String ribOperationIncorrect;

	@Value("${EDITION_RIBCOTISATION_ABSENT}")
	private String ribCotisationAbsent;
	@Value("${EDITION_RIBCOTISATION_INCORRECT}")
	private String ribCotisationIncorrect;

	@Value("${EDITION_FIRSTNAME_ABSENT}")
	private String clientFirstnameAbsent;
	@Value("${EDITION_FIRSTNAME_INCORRECT}")
	private String clientFirstnameIncorrect;

	@Value("${EDITION_NAME_ABSENT}")
	private String clientNameAbsent;
	@Value("${EDITION_NAME_INCORRECT}")
	private String clientNameIncorrect;


	@Value("${EDITION_BIRTHDAY_ABSENT}")
	private String birthDayAbsent;
	@Value("${EDITION_BIRTHDAY_INCORRECT}")
	private String birthDayIncorrect;

	@Value("${EDITION_CLIENTNATUREID_ABSENT}")
	private String clientNatureIdAbsent;
	@Value("${EDITION_CLIENTNATUREID_INCORRECT}")
	private String clientNatureIdIncorrect;


	@Value("${EDITION_SIREN_ABSENT}")
	private String sirenAbsent;
	@Value("${EDITION_SIREN_INCORRECT}")
	private String sirenIncorrect;


	@Value("${EDITION_CODEPAYS_ABSENT}")
	private String codePaysAbsent;
	@Value("${EDITION_CODEPAYS_INCORRECT}")
	private String codePaysIncorrect;


	@Value("${EDITION_CODEPOSTAL_ABSENT}")
	private String codePostalAbsent;
	@Value("${EDITION_CODEPOSTAL_INCORRECT}")
	private String codePostalIncorrect;


	@Value("${EDITION_CIVILITE_ABSENT}")
	private String civiliteAbsent;
	@Value("${EDITION_CIVILITE_INCORRECT}")
	private String civiliteIncorrect;


	@Value("${EDITION_ADRESSEEMETEUR_INCORRECT}")
	private String adresseEmeteurIncorrect;




	@Value("${CHANNEL_EDOC}")
	private String channelEdoc;
	@Value("${USERID_EDOC}")
	private String userIdEdoc;
	@Value("${MEDIA_EDOC}")
	private String mediaEdoc;
	@Value("${URL_PUT_EDOC}")
	private String urlPutEdoc;
	/**
	 * uniquement pour les tests unitaire
	 */
	@Value("${URL_POST_EDOC}")
	private String urlPostEdoc;
	/**
	 * jwt authorisation
	 */
	@Value("${TYPE_AUTHORIZATION}")
	private String TypAuthorization;
	@Value("${ALG_JWT}")
	private String algJwt;
	@Value("${VERSION_JWT}")
	private String versionJwt;
	@Value("${ROOT_SERVICE}")
	private String rootService;
	@Value("${MINUTE_LIVE_JWT}")
	private int minuteLiveJwt;
	@Value("${CHAN_JWT}")
	private String chanJwt;
	@Value("${APPID_JWT}")
	private String idApplication;
	@Value("${PATH_KEYSTORE}")
	private String pathKeyStore;
	@Value("${PATH_CERTIFICATION}")
	private String pathCertif;
	@Value("${PASSWORD_KEYSTORE}")
	private String passwordKeyStore;
	@Value("${INSTANCE_X_CERTIF}")
	private String instanceXcertif;
	@Value("${ALIAS_KEYSTORE}")
	private String aliasKeystore;
	/**
	 * selfcare pdf maquette
	 */
	@Value("${MAQUETTE.SELFCARE}")
	private String maquetteSelfCare;
	@Value("${DATAMATRIX.SELFCARE}")
	private String dataMatrixSelfCare;
	/**
	 * Selfcare
	 */
	@Value("${URL_ATTACHMENT_SELFCARE}")
	private String urlAttachmentSelf;
	@Value("${URL_GETSTATUS_SELFCARE}")
	private String urlGetStatuSelf;
	@Value("${URL_CREATEFOLDER_SELFCARE}")
	private String urlCreateSelf;
	@Value("${BANK_NUMBER_ABSENT}")
	private String bankNumberAbsent;
	@Value("${CARD_NUMBER_ABSENT}")
	private String cardNumberAbsent;
	@Value("${QUALIFICATION_ABSENT}")
	private String qualificationAbsent;
	@Value("${NATURE_ABSENT}")
	private String natureAbsent;
	@Value("${MAIL_ABSENT}")
	private String mailAbsent;
	@Value("${PHONE_ABSENT}")
	private String phoneAbsent;
	@Value("${LIST_OPERATION_ABSENT}")
	private String operationsAbsent;
	/**
	 * donnees static info banque
	 */
	@Value("${BNP_PARI_BAS}")
	private String bnpParisBas;
	@Value("${HELLO_BANQUE}")
	private String helloBanque;
	@Value("${HELLO_BANK_BD}")
	private String bd;
	@Value("${BANQUE_DE_DETAIL_BDDF}")
	private String bddf;
	@Value("${ADRESSE_MONACO_2}")
	private String adresseMonaco2;
	@Value("${ADRESSE_MONACO_3}")
	private String adresseMonaco3;
	@Value("${ADRESSE_MONACO_5}")
	private String adresseMonaco5;
	/**
	 * Liste des données datamatrix et maquette
	 *
	 */
	/**
	 * cloture sans suite
	 */
	@Value("${MAQUETTE.CLOTURE}")
	private String maquetteClo;
	@Value("${DATAMATRIX.CLOTURE}")
	private String dataMatrixClo;
	/**
	 * contestation carte
	 */


	@Value("${MAQUETTE1.CONTESTATION.CARTE.CENTRAL}")
	private String maquette1ContestationCarteCentral;
	@Value("${MAQUETTE2.CONTESTATION.CARTE.CENTRAL}")
	private String maquette2ContestationCarteCentral;
	@Value("${DATAMATRIX1.CONTESTATION.CARTE.CENTRAL}")
	private String datamatrix1ContestationCarteCentral;
	@Value("${DATAMATRIX2.CONTESTATION.CARTE.CENTRAL}")
	private String datamatrix2ContestationCarteCentral;
	@Value("${MAQUETTE1.CONTESTATION.CARTE}")
	private String maquette1ContestationCarte;
	@Value("${MAQUETTE2.CONTESTATION.CARTE}")
	private String maquette2ContestationCarte;
	@Value("${DATAMATRIX1.CONTESTATION.CARTE}")
	private String datamatrix1ContestationCarte;
	@Value("${DATAMATRIX2.CONTESTATION.CARTE}")
	private String datamatrix2ContestationCarte;
	/**
	 * courrier generique
	 */
	@Value("${MAQUETTE.COURRIER.GENERIQUE.CENTRAL}")
	private String maquetteCourrierGeneriqueCentral;
	@Value("${DATAMATRIX.COURRIER.GENERIQUE.CENTRAL}")
	private String datamatrixCourrierGeneriqueCentral;
	@Value("${MAQUETTE.COURRIER.GENERIQUE}")
	private String maquetteCourrierGenerique;
	@Value("${DATAMATRIX.COURRIER.GENERIQUE}")
	private String datamatrixCourrierGenerique;
	/**
	 * formulaire payement
	 */
	@Value("${MAQUETTE.FORM.PAYEMENT}")
	private String maquetteFormPay;
	@Value("${DATAMATRIX.FORM.PAYEMENT}")
	private String datamatrixFormPay;
	/**
	 * Formulaire retrait
	 */
	@Value("${MAQUETTE.FORM.RETRAIT}")
	private String maquetteFormRetrait;
	@Value("${DATAMATRIX.FORM.RETRAIT}")
	private String datamatrixRetrait;
	/**
	 * Fiche de liaison
	 */
	@Value("${MAQUETTE.FICHE.DE.LIAISON}")
	private String maquetteDeliaison;
	@Value("${DATAMATRIX.FICHE.DE.LIAISON}")
	private String datamatrixDeLiaison;
	@Value("${ERROR.GENERIQUE.CONTESTATION.NOTFOUND}")
	private String errorGeneriqueContestation;

	@Value("${service.body.archivingContext.indexingData.publicationTop}")
	private String publicationTop;















	@Value("${service.closefolder.reponse.success}")
	private String reponseSuccessSecureDoc;

	@Value("${service.body.normLevel}")
	private  String normLevel;

	@Value("${service.body.storageLevel}")
	private  String storageLevel;

	@Value("${service.body.classificationNatureId}")
	private  String classificationNatureId;
	@Value("${service.body.owningApplication}")
	private  String owningApplication;




	@Value("${service.body.descriptiveContext.lotId}")
	private  String lotId;
	@Value("${service.body.descriptiveContext.lotLabel}")
	private  String lotLabel;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname1}")
	private  String indexname1;
	@Value("${service.body.descriptiveContext.indexingData.index.indexvalue1}")
	private String indexvalue1;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname2}")
	private String indexname2;
	@Value("${service.body.descriptiveContext.indexingData.index.indexname3}")
	private String indexname3;
	@Value("${service.header.calling-application}")
	private String callingApplication;
	@Value("${service.body.archivingContext.indexingData.clientNatureId}")
	private String clientNatureId;
	@Value("${service.body.archivingContext.indexingData.clientName}")
	private String clientName;
	@Value("${service.body.archivingContext.indexingData.clientFirstname}")
	private String clientFirstname;

	@Value("${service.body.archivingContext.indexingData.birthDate}")
	private String birthDate;
	@Value("${service.body.archivingContext.indexingData.clientId}")
	private String clientId;
	@Value("${service.body.archivingContext.indexingData.sirenNumber}")
	private String sirenNumber;
	@Value("${service.body.archivingContext.indexingData.contractId}")
	private String contractId;
	@Value("${service.body.archivingContext.indexingData.contractIdTypeCode}")
	private String contractIdTypeCode;
	@Value("${service.body.archivingContext.indexingData.contractIdTypeLabel}")
	private String contractIdTypeLabel;
	@Value("${contestation.monetique.code.type.document}")
	private String codeTypeDocumentContestation;


	@Value("${justificatif.client.code.type.document}")
	private String codeTypeDocumentJustificatif;


	@Value("${message.error.type.document}")
	private String messageErrorIdTypeDocument;


	@Value("${message.purge.success}")
	private String messagePurgeSuccess;


	@Value("${CODE.CONTESTATION.NOTFOUND.ERROR}")
	private String codeNotFoundContestion;


	@Value("${MESSAGE.CONTESTATION.NOTFOUND.FOLDER.NUMBER}")
	private String  messageNotFoundContestaionByFolderNumber;


	@Value("${MESSAGE.CONTESTATION.NOTFOUND.TELEMATICID}")
	private String  messageNotFoundContestaionByTelematicId;


	@Value("${MESSAGE.CONTESTATION.NOTFOUND.FOLDER.NUMBER}")
	private String  messageNotFoundContestaionByIdentifier;


	@Value("${MESSAGE.CODE.STATUS.ABSENT}")
	private String messageDisputStatusAbsent;


	@Value("${MESSAGE.CODE.STATUS.INCORRECT}")
	private String messageDisputStatusIncorrect;


	@Value("${ERROR.GDN.DONNE.CALLINGUSER.MANQUANTE}")
	private String callingUserAbsent;


	/**
	 * config de la partie editique
	 */
	//@Value("${EDITIQUE.RESEAU}")
	//private String reseau;


	//@Value("${EDITIQUE.CANAL}")
	//private String canal;
	@Value("${EDITIQUE.FILE.TYPE}")
	private String editiqueFileType;


	@Value("${EDITIQUE.ENVIRONNEMENT}")
	private String environnement;


	@Value("${EDITIQUE.TYPE}")
	private String type;


	@Value("${EDITIQUE.FORMATSORTIE}")
	private String formatSortie;


	@Value("${EDITIQUE.APPLICATION}")
	private String application;


	@Value("${EDITIQUE.TRANSACTION}")
	private String transaction;


	@Value("${EDITIQUE.DESCRIPTION}")
	private String description;


	@Value("${EDITIQUE.TRACEXML}")
	private String traceXml;


	@Value("${EDITIQUE.TRACELOG}")
	private String traceLog;


	@Value("${EDITIQUE.IDOC}")
	private String idoc;


	@Value("${EDITIQUE.PRIORITE}")
	private String priorite;


	/**
	 *
	 */
	@Value("${EDITIQUE.SNEATTR.CTYPE}")
	private String ctype;


	@Value("${EDITIQUE.SNEATTR.LFORMAT}")
	private String lformat;

	@Value("${EDITIQUE.SNEATTR.CLANGUEKPI}")
	private String clanguekpi;
	@Value("${EDITIQUE.SNEATTR.SEPIALG}")
	private String sepialg;
	@Value("${EDITIQUE.SNEATTR.SEPIAML}")
	private String sepiaml;
	@Value("${EDITIQUE.SNETECH.TYPI}")
	private String typi;
	@Value("${MESSAGE.ERROR.TECHNIQUE}")
	private String messageErrorTechnique;
	@Value("${MESSAGE.CODEUO.ABSENT}")
	private String messageCodeUOAbsent;


	@Value("${MESSAGE.NUMEROPAN.ABSENT}")
	private String messageNumeroPanAbsent;
	@Value("${RP.IKPI.ABSENT}")
	private String messageIkpiAbsent;
	@Value("${MESSAGE.REPONSENULL.RP}")
	private String reponseNullRP;
	@Value("${ERROR.EDITION.REPONSE.INCORRECT}")
	private String reponseIncorect;
	@Value("${ERROR.GDN.REPONSE.INCORRECT}")
	private String reponseIncorectGDN;

	@Value("${COMMONS.PHRASE}")
	private String commonsPhrase;

	@Value("${RP.REPONSE.INCORRECT}")
	private String responseIncorectRP;
	@Value("${GDN.DOC.NO.SECURISED}")
	private String noSecurised;
	/**
	 * Les codes erreurs
	 */
	@Value("${CODE.ERROR.INTERNE.EDITION}")
	private String codeErreurServeurEdition;

	@Value("${CODE.ERROR.INTERNE.RP}")
	private String codeErreurServeurRP;
	@Value("${CODE.ERROR.INTERNE.REFO}")
	private String codeErreurServeurRefo;
	@Value("${CODE.ERROR.INTERNE.GDN}")
	private String codeErreurServeurGdn;
	@Value("${CODE.ERROR.INTERNE.BCMP}")
	private String codeErreurServeurBcmp;
	@Value("${CODE.ERROR.ABSENT}")
	private String codeAbsentDonne;
	@Value("${CODE.ERROR.ABSENT.UI}")
	private String codeAbsentDonneUI;
	@Value("${CODE.ERROR.DONNE.INCORRECT}")
	private String codeDonneIncorrect;

	@Value("${CODE.ERROR.DONNE.INCORRECT.UI}")
	private String codeDonneIncorrectUI;

	@Value("${CODE.FORMAT.INCORRECT}")
	private String codeFormatIncorrect;


	/**
	 * données manquant dans smccore de la gdn
	 */
	@Value("${ERROR.GDN.DONNE.DOCUMENTID.MANQUANTE}")
	private String documentIdAbsent;

	@Value("${ERROR.GDN.DONNE.ARCHIVINGREFERENCEDATE.MANQUANTE}")
	private String archivingreferencedateAbsent;

	@Value("${ERROR.GDN.DONNE.TITRE.MANQUANTE}")
	private String titreAbsent;

	@Value("${ERROR.GDN.DONNE.FILENAME.MANQUANTE}")
	private String filenameAbsent;

	@Value("${ERROR.GDN.DONNE.ARCHIVEFORMAT.MANQUANTE}")
	private String archiveformatAbsent;

	@Value("${ERROR.GDN.DONNE.MIMETYPE.MANQUANTE}")
	private String mimetypeAbsent;

	@Value("${ERROR.GDN.DONNE.DATA.MANQUANTE}")
	private String dataAbsent;

	@Value("${ERROR.GDN.DONNE.COMPRESS.MANQUANTE}")
	private String compressAbsent;

	@Value("${ERROR.GDN.DONNE.ENCODING.MANQUANTE}")
	private String encodingAbsent;

	@Value("${ERROR.GDN.DONNE.DOCUMENTTYPEID.MANQUANTE}")
	private String documentTypeIdAbsent;

	@Value("$ERROR.GDN.DONNE.LISTEIDDOCUMENT.MANQUANTE}")
	private String listeIdDocsAbsent;

	@Value("${ERROR.GDN.DONNE.USERTYPE.MANQUANTE}")
	private String usertypeAbsent;

	@Value("${ERROR.GDN.DONNE.USER.MANQUANTE}")//TODO a supprimer ?
	private String userAbsent;

	/**
	 *
	 *
	 *
	 * Gestion des erreurs données absente Editique
	 *
	 *
	 *
	 *
	 *
	 */
	@Value("${ERROR.EDITION.NUMCARTE.MANQUANTE}")
	private String numCarteManquante;

	@Value("${ERROR.EDITION.MAQUETTE.MANQUANTE}")
	private String maquetteManquante;

	@Value("${ERROR.EDITION.DATAMATRIX.MANQUANTE}")
	private String datamaTrixManquante;

	@Value("${ERROR.EDITION.LIBNATURE.MANQUANTE}")
	private String libnatureManquante;

	@Value("${ERROR.EDITION.NUMCARTEMASQUE.MANQUANTE}")
	private String numcartemasqueManquante;

	@Value("${ERROR.EDITION.NUMDOSSIER.MANQUANTE}")
	private String numdossierManquante;
	@Value("${ERROR.EDITION.LISTEPARAGRAPHE.MANQUANTE}")
	private String listeparagrapheManquante;
	@Value("${ERROR.EDITION.ADRESSE.EMETEUR.MANQUANTE}")
	private String adresseEmeteurManquant;

	@Value("${ERROR.EDITION.TELEPHONE.EMETTEUR.MANQUANTE}")
	private String telEmeteurManquant;

	@Value("${ERROR.EDITION.DATE.DE.TRAITEMENT.MANQUANTE}")
	private String dateDetraitementManquant;
	@Value("${ERROR.EDITION.CANAL.MANQUANTE}")
	private String canalAbsent;

	@Value("${ERROR.EDITION.BOOLEAN.CENTRAL.MANQUANTE}")
	private String booleanEditionAbsent;

	/**
	 *
	 *
	 * Gestions des erreurs formats
	 *
	 *
	 */
	@Value("${ERROR.MIMETYPE.ERROR.FORMAT}")
	private String mimeTypeErrorFormat;

	@Value("${EXEMPLE.MIMETYPE1}")
	private String mimeTypeformat1;


	@Value("${EXEMPLE.MIMETYPE2}")
	private String mimeTypeformat2;
	@Value("${ERROR.DATE.ERROR.FORMAT}")
	private String formatDateError;

	@Value("${ERROR.NUMCARTE.ERROR.FORMAT}")
	private String formatCarteBancaireError;

	/**
	 * @return the adresseEmeteurIncorrect
	 */
	public String getAdresseEmeteurIncorrect() {
		return adresseEmeteurIncorrect;
	}

	/**
	 * @return the adresseEmeteurManquant
	 */
	public String getAdresseEmeteurManquant() {
		return adresseEmeteurManquant;
	}

	//	@Value("${EDITIQUE.SNEDATA.PARAGRAPHE}")
	//	private String lignepar;


	//	@Value("${EDITIQUE.SNEDATA.LIGNEPARTAB}")
	//	private String lignepartab;
	//
	//	@Value("${EDITIQUE.SNEDATA.LIGNETAB}")
	//	private String lignetab;

	/**
	 * @return the adresseMonaco2
	 */
	public String getAdresseMonaco2() {
		return adresseMonaco2;
	}

	/**
	 * @return the adresseMonaco3
	 */
	public String getAdresseMonaco3() {
		return adresseMonaco3;
	}

	/**
	 * @return the adresseMonaco5
	 */
	public String getAdresseMonaco5() {
		return adresseMonaco5;
	}
	/**
	 * @return the algJwt
	 */
	public String getAlgJwt() {
		return algJwt;
	}
	/**
	 * @return the aliasKeystore
	 */
	public String getAliasKeystore() {
		return aliasKeystore;
	}
	/**
	 * @return the application
	 */
	public String getApplication() {
		return application;
	}
	/**
	 * @return the archiveformatAbsent
	 */
	public String getArchiveformatAbsent() {
		return archiveformatAbsent;
	}
	/**
	 * @return the archivingreferencedateAbsent
	 */
	public String getArchivingreferencedateAbsent() {
		return archivingreferencedateAbsent;
	}
	/**
	 * @return the bankNumberAbsent
	 */
	public String getBankNumberAbsent() {
		return bankNumberAbsent;
	}
	/**
	 * @return the bd
	 */
	public String getBd() {
		return bd;
	}
	/**
	 * @return the bddf
	 */
	public String getBddf() {
		return bddf;
	}
	/**
	 * @return the birthDate
	 */
	public String getBirthDate() {
		return birthDate;
	}
	/**
	 * @return the birthDayAbsent
	 */
	public String getBirthDayAbsent() {
		return birthDayAbsent;
	}
	/**
	 * @return the birthDayIncorrect
	 */
	public String getBirthDayIncorrect() {
		return birthDayIncorrect;
	}
	/**
	 * @return the bnpParisBas
	 */
	public String getBnpParisBas() {
		return bnpParisBas;
	}
	/**
	 * @return the booleanEditionAbsent
	 */
	public String getBooleanEditionAbsent() {
		return booleanEditionAbsent;
	}
	/**
	 * @return the callingApplication
	 */
	public String getCallingApplication() {
		return callingApplication;
	}
	/**
	 * @return the callingUserAbsent
	 */
	public String getCallingUserAbsent() {
		return callingUserAbsent;
	}
	//	/**
	//	 * @return the canal
	//	 */
	//	public String getCanal() {
	//		return canal;
	//	}
	/**
	 * @return the canalAbsent
	 */
	public String getCanalAbsent() {
		return canalAbsent;
	}

	/**
	 * @return the cardNumberAbsent
	 */
	public String getCardNumberAbsent() {
		return cardNumberAbsent;
	}

	/**
	 * @return the chanJwt
	 */
	public String getChanJwt() {
		return chanJwt;
	}
	/**
	 * @return the channelEdoc
	 */
	public String getChannelEdoc() {
		return channelEdoc;
	}

	/**
	 * @return the civiliteAbsent
	 */
	public String getCiviliteAbsent() {
		return civiliteAbsent;
	}
	/**
	 * @return the civiliteIncorrect
	 */
	public String getCiviliteIncorrect() {
		return civiliteIncorrect;
	}
	/**
	 * @return the clanguekpi
	 */
	public String getClanguekpi() {
		return clanguekpi;
	}
	/**
	 * @return the classificationNatureId
	 */
	public String getClassificationNatureId() {
		return classificationNatureId;
	}
	/**
	 * @return the clientFirstname
	 */
	public String getClientFirstname() {
		return clientFirstname;
	}
	/**
	 * @return the clientFirstnameAbsent
	 */
	public String getClientFirstnameAbsent() {
		return clientFirstnameAbsent;
	}

	/**
	 * @return the clientFirstnameIncorrect
	 */
	public String getClientFirstnameIncorrect() {
		return clientFirstnameIncorrect;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @return the clientNameAbsent
	 */
	public String getClientNameAbsent() {
		return clientNameAbsent;
	}
	/**
	 * @return the clientNameIncorrect
	 */
	public String getClientNameIncorrect() {
		return clientNameIncorrect;
	}
	/**
	 * @return the clientNatureId
	 */
	public String getClientNatureId() {
		return clientNatureId;
	}
	/**
	 * @return the clientNatureIdAbsent
	 */
	public String getClientNatureIdAbsent() {
		return clientNatureIdAbsent;
	}
	/**
	 * @return the clientNatureIdIncorrect
	 */
	public String getClientNatureIdIncorrect() {
		return clientNatureIdIncorrect;
	}
	/**
	 * @return the codeAbsentDonne
	 */
	public String getCodeAbsentDonne() {
		return codeAbsentDonne;
	}
	/**
	 * @return the codeAbsentDonneUI
	 */
	public String getCodeAbsentDonneUI() {
		return codeAbsentDonneUI;
	}
	/**
	 * @return the codeDonneIncorrect
	 */
	public String getCodeDonneIncorrect() {
		return codeDonneIncorrect;
	}
	/**
	 * @return the codeDonneIncorrectUI
	 */
	public String getCodeDonneIncorrectUI() {
		return codeDonneIncorrectUI;
	}
	/**
	 * @return the codeErreurServeurBcmp
	 */
	public String getCodeErreurServeurBcmp() {
		return codeErreurServeurBcmp;
	}
	/**
	 * @return the codeErreurServeurEdition
	 */
	public String getCodeErreurServeurEdition() {
		return codeErreurServeurEdition;
	}


	/**
	 * @return the codeErreurServeurGdn
	 */
	public String getCodeErreurServeurGdn() {
		return codeErreurServeurGdn;
	}
	/**
	 * @return the codeErreurServeurRefo
	 */
	public String getCodeErreurServeurRefo() {
		return codeErreurServeurRefo;
	}

	/**
	 * @return the codeErreurServeurRP
	 */
	public String getCodeErreurServeurRP() {
		return codeErreurServeurRP;
	}
	/**
	 * @return the codeFormatIncorrect
	 */
	public String getCodeFormatIncorrect() {
		return codeFormatIncorrect;
	}
	/**
	 * @return the codeErrorContestion
	 */
	public String getCodeNotFoundContestion() {
		return codeNotFoundContestion;
	}
	/**
	 * @return the codePaysAbsent
	 */
	public String getCodePaysAbsent() {
		return codePaysAbsent;
	}
	/**
	 * @return the codePaysIncorrect
	 */
	public String getCodePaysIncorrect() {
		return codePaysIncorrect;
	}
	/**
	 * @return the codePostalAbsent
	 */
	public String getCodePostalAbsent() {
		return codePostalAbsent;
	}
	/**
	 * @return the codePostalIncorrect
	 */
	public String getCodePostalIncorrect() {
		return codePostalIncorrect;
	}
	/**
	 * @return the codeTypeDocumentContestation
	 */
	public String getCodeTypeDocumentContestation() {
		return codeTypeDocumentContestation;
	}
	/**
	 * @return the codeTypeDocumentJustificatif
	 */
	public String getCodeTypeDocumentJustificatif() {
		return codeTypeDocumentJustificatif;
	}
	/**
	 * @return the codeUoAgenceIncorrect
	 */
	public String getCodeUoAgenceIncorrect() {
		return codeUoAgenceIncorrect;
	}
	/**
	 * @return the codeUoSurIncorrect
	 */
	public String getCodeUoSurIncorrect() {
		return codeUoSurIncorrect;
	}
	/**
	 * @return the commonsPhrase
	 */
	public String getCommonsPhrase() {
		return commonsPhrase;
	}
	/**
	 * @return the compressAbsent
	 */
	public String getCompressAbsent() {
		return compressAbsent;
	}
	/**
	 * @return the contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @return the contractIdTypeCode
	 */
	public String getContractIdTypeCode() {
		return contractIdTypeCode;
	}
	/**
	 * @return the contractIdTypeLabel
	 */
	public String getContractIdTypeLabel() {
		return contractIdTypeLabel;
	}
	/**
	 * @return the ctype
	 */
	public String getCtype() {
		return ctype;
	}
	/**
	 * @return the dataAbsent
	 */
	public String getDataAbsent() {
		return dataAbsent;
	}
	/**
	 * @return the datamatrix1ContestationCarte
	 */
	public String getDatamatrix1ContestationCarte() {
		return datamatrix1ContestationCarte;
	}
	/**
	 * @return the datamatrix1ContestationCarteCentral
	 */
	public String getDatamatrix1ContestationCarteCentral() {
		return datamatrix1ContestationCarteCentral;
	}
	/**
	 * @return the datamatrix2ContestationCarte
	 */
	public String getDatamatrix2ContestationCarte() {
		return datamatrix2ContestationCarte;
	}
	/**
	 * @return the datamatrix2ContestationCarteCentral
	 */
	public String getDatamatrix2ContestationCarteCentral() {
		return datamatrix2ContestationCarteCentral;
	}

	/**
	 * @return the dataMatrixClo
	 */
	public String getDataMatrixClo() {
		return dataMatrixClo;
	}
	/**
	 * @return the datamatrixCourrierGenerique
	 */
	public String getDatamatrixCourrierGenerique() {
		return datamatrixCourrierGenerique;
	}

	/**
	 * @return the datamatrixCourrierGeneriqueCentral
	 */
	public String getDatamatrixCourrierGeneriqueCentral() {
		return datamatrixCourrierGeneriqueCentral;
	}

	/**
	 * @return the datamatrixDeLiaison
	 */
	public String getDatamatrixDeLiaison() {
		return datamatrixDeLiaison;
	}

	/**
	 * @return the datamatrixFormPay
	 */
	public String getDatamatrixFormPay() {
		return datamatrixFormPay;
	}

	/**
	 * @return the datamaTrixManquante
	 */
	public String getDatamaTrixManquante() {
		return datamaTrixManquante;
	}

	/**
	 * @return the datamatrixRetrait
	 */
	public String getDatamatrixRetrait() {
		return datamatrixRetrait;
	}

	/**
	 * @return the dataMatrixSelfCare
	 */
	public String getDataMatrixSelfCare() {
		return dataMatrixSelfCare;
	}

	/**
	 * @return the dateDetraitementManquant
	 */
	public String getDateDetraitementManquant() {
		return dateDetraitementManquant;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return the documentIdAbsent
	 */
	public String getDocumentIdAbsent() {
		return documentIdAbsent;
	}

	/**
	 * @return the documentTypeIdAbsent
	 */
	public String getDocumentTypeIdAbsent() {
		return documentTypeIdAbsent;
	}

	/**
	 * @return the editiqueFileType
	 */
	public String getEditiqueFileType() {
		return editiqueFileType;
	}

	/**
	 * @return the encodingAbsent
	 */
	public String getEncodingAbsent() {
		return encodingAbsent;
	}

	/**
	 * @return the environnement
	 */
	public String getEnvironnement() {
		return environnement;
	}

	/**
	 * @return the errorGeneriqueContestation
	 */
	public String getErrorGeneriqueContestation() {
		return errorGeneriqueContestation;
	}


	/**
	 * @return the filenameAbsent
	 */
	public String getFilenameAbsent() {
		return filenameAbsent;
	}

	/**
	 * @return the formatCarteBancaireError
	 */
	public String getFormatCarteBancaireError() {
		return formatCarteBancaireError;
	}

	/**
	 * @return the formatDateError
	 */
	public String getFormatDateError() {
		return formatDateError;
	}

	/**
	 * @return the formatSortie
	 */
	public String getFormatSortie() {
		return formatSortie;
	}

	/**
	 * @return the helloBanque
	 */
	public String getHelloBanque() {
		return helloBanque;
	}

	/**
	 * @return the idApplication
	 */
	public String getIdApplication() {
		return idApplication;
	}

	/**
	 * @return the idContratMonetiquePorteurAbsent
	 */
	public String getIdContratMonetiquePorteurAbsent() {
		return idContratMonetiquePorteurAbsent;
	}


	/**
	 * @return the idContratMonetiquePorteurIncorrect
	 */
	public String getIdContratMonetiquePorteurIncorrect() {
		return idContratMonetiquePorteurIncorrect;
	}

	/**
	 * @return the idoc
	 */
	public String getIdoc() {
		return idoc;
	}


	/**
	 * @return the ikpiAbsent
	 */
	public String getIkpiAbsent() {
		return ikpiAbsent;
	}

	/**
	 * @return the ikpiIncorrect
	 */
	public String getIkpiIncorrect() {
		return ikpiIncorrect;
	}

	/**
	 * @return the indexname1
	 */
	public String getIndexname1() {
		return indexname1;
	}


	/**
	 * @return the indexname2
	 */
	public String getIndexname2() {
		return indexname2;
	}
	/**
	 * @return the indexname3
	 */
	public String getIndexname3() {
		return indexname3;
	}
	/**
	 * @return the indexvalue1
	 */
	public String getIndexvalue1() {
		return indexvalue1;
	}

	/**
	 * @return the instanceXcertif
	 */
	public String getInstanceXcertif() {
		return instanceXcertif;
	}

	/**
	 * @return the lformat
	 */
	public String getLformat() {
		return lformat;
	}

	/**
	 * @return the libnatureManquante
	 */
	public String getLibnatureManquante() {
		return libnatureManquante;
	}

	/**
	 * @return the listeIdDocsAbsent
	 */
	public String getListeIdDocsAbsent() {
		return listeIdDocsAbsent;
	}

	/**
	 * @return the listeparagrapheManquante
	 */
	public String getListeparagrapheManquante() {
		return listeparagrapheManquante;
	}

	/**
	 * @return the lotId
	 */
	public String getLotId() {
		return lotId;
	}

	/**
	 * @return the lotLabel
	 */
	public String getLotLabel() {
		return lotLabel;
	}
	/**
	 * @return the mailAbsent
	 */
	public String getMailAbsent() {
		return mailAbsent;
	}
	/**
	 * @return the maquette1ContestationCarte
	 */
	public String getMaquette1ContestationCarte() {
		return maquette1ContestationCarte;
	}

	/**
	 * @return the maquette1ContestationCarteCentral
	 */
	public String getMaquette1ContestationCarteCentral() {
		return maquette1ContestationCarteCentral;
	}

	/**
	 * @return the maquette2ContestationCarte
	 */
	public String getMaquette2ContestationCarte() {
		return maquette2ContestationCarte;
	}
	/**
	 * @return the maquette2ContestationCarteCentral
	 */
	public String getMaquette2ContestationCarteCentral() {
		return maquette2ContestationCarteCentral;
	}

	/**
	 * @return the maquetteClo
	 */
	public String getMaquetteClo() {
		return maquetteClo;
	}
	/**
	 * @return the maquetteCourrierGenerique
	 */
	public String getMaquetteCourrierGenerique() {
		return maquetteCourrierGenerique;
	}

	/**
	 * @return the maquetteCourrierGeneriqueCentral
	 */
	public String getMaquetteCourrierGeneriqueCentral() {
		return maquetteCourrierGeneriqueCentral;
	}

	/**
	 * @return the maquetteDeliaison
	 */
	public String getMaquetteDeliaison() {
		return maquetteDeliaison;
	}
	/**
	 * @return the maquetteFormPay
	 */
	public String getMaquetteFormPay() {
		return maquetteFormPay;
	}

	/**
	 * @return the maquetteFormRetrait
	 */
	public String getMaquetteFormRetrait() {
		return maquetteFormRetrait;
	}

	/**
	 * @return the maquetteManquante
	 */
	public String getMaquetteManquante() {
		return maquetteManquante;
	}
	/**
	 * @return the maquetteSelfCare
	 */
	public String getMaquetteSelfCare() {
		return maquetteSelfCare;
	}
	/**
	 * @return the mediaEdoc
	 */
	public String getMediaEdoc() {
		return mediaEdoc;
	}
	/**
	 * @return the messageCodeUOAbsent
	 */
	public String getMessageCodeUOAbsent() {
		return messageCodeUOAbsent;
	}

	/**
	 * @return the messageDisputStatusAbsent
	 */
	public String getMessageDisputStatusAbsent() {
		return messageDisputStatusAbsent;
	}
	/**
	 * @return the messageDisputStatusIncorrect
	 */
	public String getMessageDisputStatusIncorrect() {
		return messageDisputStatusIncorrect;
	}
	/**
	 * @return the messageErrorIdTypeDocument
	 */
	public String getMessageErrorIdTypeDocument() {
		return messageErrorIdTypeDocument;
	}
	/**
	 * @return the messageErrorTechnique
	 */
	public String getMessageErrorTechnique() {
		return messageErrorTechnique;
	}
	/**
	 * @return the messageIkpiAbsent
	 */
	public String getMessageIkpiAbsent() {
		return messageIkpiAbsent;
	}
	/**
	 * @return the messageNotFoundContestaionByFolderNumber
	 */
	public String getMessageNotFoundContestaionByFolderNumber() {
		return messageNotFoundContestaionByFolderNumber;
	}
	/**
	 * @return the messageNotFoundContestaionByIdentifier
	 */
	public String getMessageNotFoundContestaionByIdentifier() {
		return messageNotFoundContestaionByIdentifier;
	}
	/**
	 * @return the messageNotFoundContestaionByTelematicId
	 */
	public String getMessageNotFoundContestaionByTelematicId() {
		return messageNotFoundContestaionByTelematicId;
	}
	/**
	 * @return the messageNumeroPanAbsent
	 */
	public String getMessageNumeroPanAbsent() {
		return messageNumeroPanAbsent;
	}
	/**
	 * @return the messagePurgeSuccess
	 */
	public String getMessagePurgeSuccess() {
		return messagePurgeSuccess;
	}
	//	/**
	//	 * @return the messageXsdValidation
	//	 */
	//	public String getMessageXsdValidation() {
	//		return messageXsdValidation;
	//	}
	/**
	 * @return the mimetypeAbsent
	 */
	public String getMimetypeAbsent() {
		return mimetypeAbsent;
	}


	/**
	 * @return the mimeTypeErrorFormat
	 */
	public String getMimeTypeErrorFormat() {
		return mimeTypeErrorFormat;
	}


	/**
	 * @return the mimeTypeformat1
	 */
	public String getMimeTypeformat1() {
		return mimeTypeformat1;
	}
	/**
	 * @return the mimeTypeformat2
	 */
	public String getMimeTypeformat2() {
		return mimeTypeformat2;
	}
	/**
	 * @return the minuteLiveJwt
	 */
	public int getMinuteLiveJwt() {
		return minuteLiveJwt;
	}

	/**
	 * @return the natureAbsent
	 */
	public String getNatureAbsent() {
		return natureAbsent;
	}


	/**
	 * @return the normLevel
	 */
	public String getNormLevel() {
		return normLevel;
	}

	/**
	 * @return the noSecurised
	 */
	public String getNoSecurised() {
		return noSecurised;
	}

	//	/**
	//	 * @return the lignepar
	//	 */
	//	public String getLignepar() {
	//		return lignepar;
	//	}

	//	/**
	//	 * @return the lignepartab
	//	 */
	//	public String getLignepartab() {
	//		return lignepartab;
	//	}
	//
	//	/**
	//	 * @return the lignetab
	//	 */
	//	public String getLignetab() {
	//		return lignetab;
	//	}


	/**
	 * @return the numCarteManquante
	 */
	public String getNumCarteManquante() {
		return numCarteManquante;
	}

	/**
	 * @return the numcartemasqueManquante
	 */
	public String getNumcartemasqueManquante() {
		return numcartemasqueManquante;
	}
	/**
	 * @return the numdossierManquante
	 */
	public String getNumdossierManquante() {
		return numdossierManquante;
	}
	/**
	 * @return the operationsAbsent
	 */
	public String getOperationsAbsent() {
		return operationsAbsent;
	}

	/**
	 * @return the owningApplication
	 */
	public String getOwningApplication() {
		return owningApplication;
	}
	/**
	 * @return the passwordKeyStore
	 */
	public String getPasswordKeyStore() {
		return passwordKeyStore;
	}
	/**
	 * @return the pathCertif
	 */
	public String getPathCertif() {
		return pathCertif;
	}
	/**
	 * @return the pathKeyStore
	 */
	public String getPathKeyStore() {
		return pathKeyStore;
	}
	/**
	 * @return the phoneAbsent
	 */
	public String getPhoneAbsent() {
		return phoneAbsent;
	}
	/**
	 * @return the priorite
	 */
	public String getPriorite() {
		return priorite;
	}

	/**
	 * @return the publicationTop
	 */
	public String getPublicationTop() {
		return publicationTop;
	}

	/**
	 * @return the qualificationAbsent
	 */
	public String getQualificationAbsent() {
		return qualificationAbsent;
	}

	/**
	 * @return the reponseIncorect
	 */
	public String getReponseIncorect() {
		return reponseIncorect;
	}
	/**
	 * @return the reponseIncorectGDN
	 */
	public String getReponseIncorectGDN() {
		return reponseIncorectGDN;
	}
	/**
	 * @return the reponseNullRP
	 */
	public String getReponseNullRP() {
		return reponseNullRP;
	}
	/**
	 * @return the reponseSuccessSecureDoc
	 */
	public String getReponseSuccessSecureDoc() {
		return reponseSuccessSecureDoc;
	}
	/**
	 * @return the responseIncorectRP
	 */
	public String getResponseIncorectRP() {
		return responseIncorectRP;
	}

	/**
	 * @return the ribCotisationAbsent
	 */
	public String getRibCotisationAbsent() {
		return ribCotisationAbsent;
	}
	/**
	 * @return the ribCotisationIncorrect
	 */
	public String getRibCotisationIncorrect() {
		return ribCotisationIncorrect;
	}

	/**
	 * @return the ribOperationAbsent
	 */
	public String getRibOperationAbsent() {
		return ribOperationAbsent;
	}
	/**
	 * @return the ribOperationIncorrect
	 */
	public String getRibOperationIncorrect() {
		return ribOperationIncorrect;
	}

	/**
	 * @return the rootService
	 */
	public String getRootService() {
		return rootService;
	}
	/**
	 * @return the sepialg
	 */
	public String getSepialg() {
		return sepialg;
	}

	/**
	 * @return the sepiaml
	 */
	public String getSepiaml() {
		return sepiaml;
	}


	/**
	 * @return the sirenAbsent
	 */
	public String getSirenAbsent() {
		return sirenAbsent;
	}

	/**
	 * @return the sirenIncorrect
	 */
	public String getSirenIncorrect() {
		return sirenIncorrect;
	}

	/**
	 * @return the sirenNumber
	 */
	public String getSirenNumber() {
		return sirenNumber;
	}

	/**
	 * @return the storageLevel
	 */
	public String getStorageLevel() {
		return storageLevel;
	}

	/**
	 * @return the telEmeteurManquant
	 */
	public String getTelEmeteurManquant() {
		return telEmeteurManquant;
	}

	/**
	 * @return the titreAbsent
	 */
	public String getTitreAbsent() {
		return titreAbsent;
	}

	/**
	 * @return the topClientAbsent
	 */
	public String getTopClientAbsent() {
		return topClientAbsent;
	}
	/**
	 * @return the topClientIncorrect
	 */
	public String getTopClientIncorrect() {
		return topClientIncorrect;
	}

	/**
	 * @return the traceLog
	 */
	public String getTraceLog() {
		return traceLog;
	}
	/**
	 * @return the traceXml
	 */
	public String getTraceXml() {
		return traceXml;
	}

	/**
	 * @return the transaction
	 */
	public String getTransaction() {
		return transaction;
	}

	/**
	 * @return the typAuthorization
	 */
	public String getTypAuthorization() {
		return TypAuthorization;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return the typi
	 */
	public String getTypi() {
		return typi;
	}
	/**
	 * @return the urlAttachmentSelf
	 */
	public String getUrlAttachmentSelf() {
		return urlAttachmentSelf;
	}

	/**
	 * @return the urlCreateSelf
	 */
	public String getUrlCreateSelf() {
		return urlCreateSelf;
	}

	/**
	 * @return the urlGetStatuSelf
	 */
	public String getUrlGetStatuSelf() {
		return urlGetStatuSelf;
	}
	/**
	 * @return the urlPostEdoc
	 */
	public String getUrlPostEdoc() {
		return urlPostEdoc;
	}
	/**
	 * @return the urlPutEdoc
	 */
	public String getUrlPutEdoc() {
		return urlPutEdoc;
	}
	/**
	 * @return the userAbsent
	 */
	public String getUserAbsent() {
		return userAbsent;
	}

	/**
	 * @return the userIdEdoc
	 */
	public String getUserIdEdoc() {
		return userIdEdoc;
	}

	/**
	 * @return the usertypeAbsent
	 */
	public String getUsertypeAbsent() {
		return usertypeAbsent;
	}

	/**
	 * @return the versionJwt
	 */
	public String getVersionJwt() {
		return versionJwt;
	}

	/**
	 * @param adresseEmeteurIncorrect the adresseEmeteurIncorrect to set
	 */
	public void setAdresseEmeteurIncorrect(String adresseEmeteurIncorrect) {
		this.adresseEmeteurIncorrect = adresseEmeteurIncorrect;
	}


	/**
	 * @param adresseEmeteurManquant the adresseEmeteurManquant to set
	 */
	public void setAdresseEmeteurManquant(String adresseEmeteurManquant) {
		this.adresseEmeteurManquant = adresseEmeteurManquant;
	}

	/**
	 * @param adresseMonaco2 the adresseMonaco2 to set
	 */
	public void setAdresseMonaco2(String adresseMonaco2) {
		this.adresseMonaco2 = adresseMonaco2;
	}

	/**
	 * @param adresseMonaco3 the adresseMonaco3 to set
	 */
	public void setAdresseMonaco3(String adresseMonaco3) {
		this.adresseMonaco3 = adresseMonaco3;
	}


	/**
	 * @param adresseMonaco5 the adresseMonaco5 to set
	 */
	public void setAdresseMonaco5(String adresseMonaco5) {
		this.adresseMonaco5 = adresseMonaco5;
	}
	/**
	 * @param algJwt the algJwt to set
	 */
	public void setAlgJwt(String algJwt) {
		this.algJwt = algJwt;
	}

	/**
	 * @param aliasKeystore the aliasKeystore to set
	 */
	public void setAliasKeystore(String aliasKeystore) {
		this.aliasKeystore = aliasKeystore;
	}
	/**
	 * @param application the application to set
	 */
	public void setApplication(String application) {
		this.application = application;
	}
	/**
	 * @param archiveformatAbsent the archiveformatAbsent to set
	 */
	public void setArchiveformatAbsent(String archiveformatAbsent) {
		this.archiveformatAbsent = archiveformatAbsent;
	}
	/**
	 * @param archivingreferencedateAbsent the archivingreferencedateAbsent to set
	 */
	public void setArchivingreferencedateAbsent(String archivingreferencedateAbsent) {
		this.archivingreferencedateAbsent = archivingreferencedateAbsent;
	}
	/**
	 * @param bankNumberAbsent the bankNumberAbsent to set
	 */
	public void setBankNumberAbsent(String bankNumberAbsent) {
		this.bankNumberAbsent = bankNumberAbsent;
	}
	/**
	 * @param bd the bd to set
	 */
	public void setBd(String bd) {
		this.bd = bd;
	}

	/**
	 * @param bddf the bddf to set
	 */
	public void setBddf(String bddf) {
		this.bddf = bddf;
	}

	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @param birthDayAbsent the birthDayAbsent to set
	 */
	public void setBirthDayAbsent(String birthDayAbsent) {
		this.birthDayAbsent = birthDayAbsent;
	}

	/**
	 * @param birthDayIncorrect the birthDayIncorrect to set
	 */
	public void setBirthDayIncorrect(String birthDayIncorrect) {
		this.birthDayIncorrect = birthDayIncorrect;
	}

	/**
	 * @param bnpParisBas the bnpParisBas to set
	 */
	public void setBnpParisBas(String bnpParisBas) {
		this.bnpParisBas = bnpParisBas;
	}

	/**
	 * @param booleanEditionAbsent the booleanEditionAbsent to set
	 */
	public void setBooleanEditionAbsent(String booleanEditionAbsent) {
		this.booleanEditionAbsent = booleanEditionAbsent;
	}

	/**
	 * @param callingApplication the callingApplication to set
	 */
	public void setCallingApplication(String callingApplication) {
		this.callingApplication = callingApplication;
	}

	/**
	 * @param callingUserAbsent the callingUserAbsent to set
	 */
	public void setCallingUserAbsent(String callingUserAbsent) {
		this.callingUserAbsent = callingUserAbsent;
	}

	//	/**
	//	 * @param canal the canal to set
	//	 */
	//	public void setCanal(String canal) {
	//		this.canal = canal;
	//	}
	/**
	 * @param canalAbsent the canalAbsent to set
	 */
	public void setCanalAbsent(String canalAbsent) {
		this.canalAbsent = canalAbsent;
	}


	//	@Value("${ERROR.EDITION.CIVILITE.MANQUANTE}")
	//	private String cvltManquant;
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE1.MANQUANTE}")
	//	private String adresseDesti1Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE2.MANQUANTE}")
	//	private String adresseDesti2Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE3.MANQUANTE}")
	//	private String adresseDesti3Manquant;
	//
	//	@Value("${ERROR.EDITION.ADRESSE.DESTINATAIRE6.MANQUANTE}")
	//	private String adresseDesti6Manquant;

	/**
	 * @param cardNumberAbsent the cardNumberAbsent to set
	 */
	public void setCardNumberAbsent(String cardNumberAbsent) {
		this.cardNumberAbsent = cardNumberAbsent;
	}


	/**
	 * @param chanJwt the chanJwt to set
	 */
	public void setChanJwt(String chanJwt) {
		this.chanJwt = chanJwt;
	}


	/**
	 * @param channelEdoc the channelEdoc to set
	 */
	public void setChannelEdoc(String channelEdoc) {
		this.channelEdoc = channelEdoc;
	}

	/**
	 * @param civiliteAbsent the civiliteAbsent to set
	 */
	public void setCiviliteAbsent(String civiliteAbsent) {
		this.civiliteAbsent = civiliteAbsent;
	}


	/**
	 * @param civiliteIncorrect the civiliteIncorrect to set
	 */
	public void setCiviliteIncorrect(String civiliteIncorrect) {
		this.civiliteIncorrect = civiliteIncorrect;
	}

	/**
	 * @param clanguekpi the clanguekpi to set
	 */
	public void setClanguekpi(String clanguekpi) {
		this.clanguekpi = clanguekpi;
	}

	/**
	 * @param classificationNatureId the classificationNatureId to set
	 */
	public void setClassificationNatureId(String classificationNatureId) {
		this.classificationNatureId = classificationNatureId;
	}

	/**
	 * @param clientFirstname the clientFirstname to set
	 */
	public void setClientFirstname(String clientFirstname) {
		this.clientFirstname = clientFirstname;
	}

	/**
	 * @param clientFirstnameAbsent the clientFirstnameAbsent to set
	 */
	public void setClientFirstnameAbsent(String clientFirstnameAbsent) {
		this.clientFirstnameAbsent = clientFirstnameAbsent;
	}

	/**
	 * @param clientFirstnameIncorrect the clientFirstnameIncorrect to set
	 */
	public void setClientFirstnameIncorrect(String clientFirstnameIncorrect) {
		this.clientFirstnameIncorrect = clientFirstnameIncorrect;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @param clientNameAbsent the clientNameAbsent to set
	 */
	public void setClientNameAbsent(String clientNameAbsent) {
		this.clientNameAbsent = clientNameAbsent;
	}

	/**
	 * @param clientNameIncorrect the clientNameIncorrect to set
	 */
	public void setClientNameIncorrect(String clientNameIncorrect) {
		this.clientNameIncorrect = clientNameIncorrect;
	}

	/**
	 * @param clientNatureId the clientNatureId to set
	 */
	public void setClientNatureId(String clientNatureId) {
		this.clientNatureId = clientNatureId;
	}

	/**
	 * @param clientNatureIdAbsent the clientNatureIdAbsent to set
	 */
	public void setClientNatureIdAbsent(String clientNatureIdAbsent) {
		this.clientNatureIdAbsent = clientNatureIdAbsent;
	}

	/**
	 * @param clientNatureIdIncorrect the clientNatureIdIncorrect to set
	 */
	public void setClientNatureIdIncorrect(String clientNatureIdIncorrect) {
		this.clientNatureIdIncorrect = clientNatureIdIncorrect;
	}

	/**
	 * @param codeAbsentDonne the codeAbsentDonne to set
	 */
	public void setCodeAbsentDonne(String codeAbsentDonne) {
		this.codeAbsentDonne = codeAbsentDonne;
	}

	/**
	 * @param codeAbsentDonneUI the codeAbsentDonneUI to set
	 */
	public void setCodeAbsentDonneUI(String codeAbsentDonneUI) {
		this.codeAbsentDonneUI = codeAbsentDonneUI;
	}

	//	/**
	//	 * @param codeDataMissing the codeDataMissing to set
	//	 */
	//	public void setCodeDataMissing(String codeDataMissing) {
	//		this.codeDataMissing = codeDataMissing;
	//	}
	/**
	 * @param codeDonneIncorrect the codeDonneIncorrect to set
	 */
	public void setCodeDonneIncorrect(String codeDonneIncorrect) {
		this.codeDonneIncorrect = codeDonneIncorrect;
	}

	//	/**
	//	 * @return the codeEchecService
	//	 */
	//	public String getCodeEchecService() {
	//		return codeEchecService;
	//	}

	/**
	 * @param codeDonneIncorrectUI the codeDonneIncorrectUI to set
	 */
	public void setCodeDonneIncorrectUI(String codeDonneIncorrectUI) {
		this.codeDonneIncorrectUI = codeDonneIncorrectUI;
	}

	//	/**
	//	 * @return the codeErrorTechnique
	//	 */
	//	public String getCodeErrorTechnique() {
	//		return codeErrorTechnique;
	//	}

	//	/**
	//	 * @return the codeErrorTypeDocument
	//	 */
	//	public String getCodeErrorTypeDocument() {
	//		return codeErrorTypeDocument;
	//	}

	/**
	 * @param codeErreurServeurBcmp the codeErreurServeurBcmp to set
	 */
	public void setCodeErreurServeurBcmp(String codeErreurServeurBcmp) {
		this.codeErreurServeurBcmp = codeErreurServeurBcmp;
	}

	/**
	 * @param codeErreurServeurEdition the codeErreurServeurEdition to set
	 */
	public void setCodeErreurServeurEdition(String codeErreurServeurEdition) {
		this.codeErreurServeurEdition = codeErreurServeurEdition;
	}



	/**
	 * @param codeErreurServeurGdn the codeErreurServeurGdn to set
	 */
	public void setCodeErreurServeurGdn(String codeErreurServeurGdn) {
		this.codeErreurServeurGdn = codeErreurServeurGdn;
	}


	/**
	 * @param codeErreurServeurRefo the codeErreurServeurRefo to set
	 */
	public void setCodeErreurServeurRefo(String codeErreurServeurRefo) {
		this.codeErreurServeurRefo = codeErreurServeurRefo;
	}

	/**
	 * @param codeErreurServeurRP the codeErreurServeurRP to set
	 */
	public void setCodeErreurServeurRP(String codeErreurServeurRP) {
		this.codeErreurServeurRP = codeErreurServeurRP;
	}

	/**
	 * @param codeFormatIncorrect the codeFormatIncorrect to set
	 */
	public void setCodeFormatIncorrect(String codeFormatIncorrect) {
		this.codeFormatIncorrect = codeFormatIncorrect;
	}

	/**
	 * @param codeErrorContestion the codeErrorContestion to set
	 */
	public void setCodeNotFoundContestion(String codeNotFoundContestion) {
		this.codeNotFoundContestion = codeNotFoundContestion;
	}
	/**
	 * @param codePaysAbsent the codePaysAbsent to set
	 */
	public void setCodePaysAbsent(String codePaysAbsent) {
		this.codePaysAbsent = codePaysAbsent;
	}

	/**
	 * @param codePaysIncorrect the codePaysIncorrect to set
	 */
	public void setCodePaysIncorrect(String codePaysIncorrect) {
		this.codePaysIncorrect = codePaysIncorrect;
	}

	/**
	 * @param codePostalAbsent the codePostalAbsent to set
	 */
	public void setCodePostalAbsent(String codePostalAbsent) {
		this.codePostalAbsent = codePostalAbsent;
	}

	/**
	 * @param codePostalIncorrect the codePostalIncorrect to set
	 */
	public void setCodePostalIncorrect(String codePostalIncorrect) {
		this.codePostalIncorrect = codePostalIncorrect;
	}

	/**
	 * @param codeTypeDocumentContestation the codeTypeDocumentContestation to set
	 */
	public void setCodeTypeDocumentContestation(String codeTypeDocumentContestation) {
		this.codeTypeDocumentContestation = codeTypeDocumentContestation;
	}

	/**
	 * @param codeTypeDocumentJustificatif the codeTypeDocumentJustificatif to set
	 */
	public void setCodeTypeDocumentJustificatif(String codeTypeDocumentJustificatif) {
		this.codeTypeDocumentJustificatif = codeTypeDocumentJustificatif;
	}

	/**
	 * @param codeUoAgenceIncorrect the codeUoAgenceIncorrect to set
	 */
	public void setCodeUoAgenceIncorrect(String codeUoAgenceIncorrect) {
		this.codeUoAgenceIncorrect = codeUoAgenceIncorrect;
	}




	//	/**
	//	 * @return the errorDonneManquante
	//	 */
	//	public String getErrorDonneManquante() {
	//		return errorDonneManquante;
	//	}

	/**
	 * @param codeUoSurIncorrect the codeUoSurIncorrect to set
	 */
	public void setCodeUoSurIncorrect(String codeUoSurIncorrect) {
		this.codeUoSurIncorrect = codeUoSurIncorrect;
	}

	/**
	 * @param commonsPhrase the commonsPhrase to set
	 */
	public void setCommonsPhrase(String commonsPhrase) {
		this.commonsPhrase = commonsPhrase;
	}

	/**
	 * @param compressAbsent the compressAbsent to set
	 */
	public void setCompressAbsent(String compressAbsent) {
		this.compressAbsent = compressAbsent;
	}

	/**
	 * @param contractId the contractId to set
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	//	/**
	//	 * @return the messageDataMissing
	//	 */
	//	public String getMessageDataMissing() {
	//		return messageDataMissing;
	//	}

	/**
	 * @param contractIdTypeCode the contractIdTypeCode to set
	 */
	public void setContractIdTypeCode(String contractIdTypeCode) {
		this.contractIdTypeCode = contractIdTypeCode;
	}

	/**
	 * @param contractIdTypeLabel the contractIdTypeLabel to set
	 */
	public void setContractIdTypeLabel(String contractIdTypeLabel) {
		this.contractIdTypeLabel = contractIdTypeLabel;
	}

	/**
	 * @param ctype the ctype to set
	 */
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	/**
	 * @param dataAbsent the dataAbsent to set
	 */
	public void setDataAbsent(String dataAbsent) {
		this.dataAbsent = dataAbsent;
	}
	/**
	 * @param datamatrix1ContestationCarte the datamatrix1ContestationCarte to set
	 */
	public void setDatamatrix1ContestationCarte(String datamatrix1ContestationCarte) {
		this.datamatrix1ContestationCarte = datamatrix1ContestationCarte;
	}
	/**
	 * @param datamatrix1ContestationCarteCentral the datamatrix1ContestationCarteCentral to set
	 */
	public void setDatamatrix1ContestationCarteCentral(
			String datamatrix1ContestationCarteCentral) {
		this.datamatrix1ContestationCarteCentral = datamatrix1ContestationCarteCentral;
	}
	/**
	 * @param datamatrix2ContestationCarte the datamatrix2ContestationCarte to set
	 */
	public void setDatamatrix2ContestationCarte(String datamatrix2ContestationCarte) {
		this.datamatrix2ContestationCarte = datamatrix2ContestationCarte;
	}
	/**
	 * @param datamatrix2ContestationCarteCentral the datamatrix2ContestationCarteCentral to set
	 */
	public void setDatamatrix2ContestationCarteCentral(
			String datamatrix2ContestationCarteCentral) {
		this.datamatrix2ContestationCarteCentral = datamatrix2ContestationCarteCentral;
	}
	/**
	 * @param dataMatrixClo the dataMatrixClo to set
	 */
	public void setDataMatrixClo(String dataMatrixClo) {
		this.dataMatrixClo = dataMatrixClo;
	}



	/**
	 * @param datamatrixCourrierGenerique the datamatrixCourrierGenerique to set
	 */
	public void setDatamatrixCourrierGenerique(String datamatrixCourrierGenerique) {
		this.datamatrixCourrierGenerique = datamatrixCourrierGenerique;
	}

	/**
	 * @param datamatrixCourrierGeneriqueCentral the datamatrixCourrierGeneriqueCentral to set
	 */
	public void setDatamatrixCourrierGeneriqueCentral(
			String datamatrixCourrierGeneriqueCentral) {
		this.datamatrixCourrierGeneriqueCentral = datamatrixCourrierGeneriqueCentral;
	}

	/**
	 * @param datamatrixDeLiaison the datamatrixDeLiaison to set
	 */
	public void setDatamatrixDeLiaison(String datamatrixDeLiaison) {
		this.datamatrixDeLiaison = datamatrixDeLiaison;
	}

	/**
	 * @param datamatrixFormPay the datamatrixFormPay to set
	 */
	public void setDatamatrixFormPay(String datamatrixFormPay) {
		this.datamatrixFormPay = datamatrixFormPay;
	}

	/**
	 * @param datamaTrixManquante the datamaTrixManquante to set
	 */
	public void setDatamaTrixManquante(String datamaTrixManquante) {
		this.datamaTrixManquante = datamaTrixManquante;
	}

	/**
	 * @param datamatrixRetrait the datamatrixRetrait to set
	 */
	public void setDatamatrixRetrait(String datamatrixRetrait) {
		this.datamatrixRetrait = datamatrixRetrait;
	}

	/**
	 * @param dataMatrixSelfCare the dataMatrixSelfCare to set
	 */
	public void setDataMatrixSelfCare(String dataMatrixSelfCare) {
		this.dataMatrixSelfCare = dataMatrixSelfCare;
	}

	/**
	 * @param dateDetraitementManquant the dateDetraitementManquant to set
	 */
	public void setDateDetraitementManquant(String dateDetraitementManquant) {
		this.dateDetraitementManquant = dateDetraitementManquant;
	}

	//	/**
	//	 * @return the reseau
	//	 */
	//	public String getReseau() {
	//		return reseau;
	//	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @param documentIdAbsent the documentIdAbsent to set
	 */
	public void setDocumentIdAbsent(String documentIdAbsent) {
		this.documentIdAbsent = documentIdAbsent;
	}
	/**
	 * @param documentTypeIdAbsent the documentTypeIdAbsent to set
	 */
	public void setDocumentTypeIdAbsent(String documentTypeIdAbsent) {
		this.documentTypeIdAbsent = documentTypeIdAbsent;
	}

	/**
	 * @param editiqueFileType the editiqueFileType to set
	 */
	public void setEditiqueFileType(String editiqueFileType) {
		this.editiqueFileType = editiqueFileType;
	}

	/**
	 * @param encodingAbsent the encodingAbsent to set
	 */
	public void setEncodingAbsent(String encodingAbsent) {
		this.encodingAbsent = encodingAbsent;
	}

	/**
	 * @param environnement the environnement to set
	 */
	public void setEnvironnement(String environnement) {
		this.environnement = environnement;
	}

	/**
	 * @param errorGeneriqueContestation the errorGeneriqueContestation to set
	 */
	public void setErrorGeneriqueContestation(String errorGeneriqueContestation) {
		this.errorGeneriqueContestation = errorGeneriqueContestation;
	}

	/**
	 * @param filenameAbsent the filenameAbsent to set
	 */
	public void setFilenameAbsent(String filenameAbsent) {
		this.filenameAbsent = filenameAbsent;
	}

	/**
	 * @param formatCarteBancaireError the formatCarteBancaireError to set
	 */
	public void setFormatCarteBancaireError(String formatCarteBancaireError) {
		this.formatCarteBancaireError = formatCarteBancaireError;
	}








	/**
	 * @param formatDateError the formatDateError to set
	 */
	public void setFormatDateError(String formatDateError) {
		this.formatDateError = formatDateError;
	}

	/**
	 * @param formatSortie the formatSortie to set
	 */
	public void setFormatSortie(String formatSortie) {
		this.formatSortie = formatSortie;
	}

	/**
	 * @param helloBanque the helloBanque to set
	 */
	public void setHelloBanque(String helloBanque) {
		this.helloBanque = helloBanque;
	}

	/**
	 * @param idApplication the idApplication to set
	 */
	public void setIdApplication(String idApplication) {
		this.idApplication = idApplication;
	}

	/**
	 * @param idContratMonetiquePorteurAbsent the idContratMonetiquePorteurAbsent to set
	 */
	public void setIdContratMonetiquePorteurAbsent(
			String idContratMonetiquePorteurAbsent) {
		this.idContratMonetiquePorteurAbsent = idContratMonetiquePorteurAbsent;
	}

	/**
	 * @param idContratMonetiquePorteurIncorrect the idContratMonetiquePorteurIncorrect to set
	 */
	public void setIdContratMonetiquePorteurIncorrect(
			String idContratMonetiquePorteurIncorrect) {
		this.idContratMonetiquePorteurIncorrect = idContratMonetiquePorteurIncorrect;
	}

	/**
	 * @param idoc the idoc to set
	 */
	public void setIdoc(String idoc) {
		this.idoc = idoc;
	}

	/**
	 * @param ikpiAbsent the ikpiAbsent to set
	 */
	public void setIkpiAbsent(String ikpiAbsent) {
		this.ikpiAbsent = ikpiAbsent;
	}
	/**
	 * @param ikpiIncorrect the ikpiIncorrect to set
	 */
	public void setIkpiIncorrect(String ikpiIncorrect) {
		this.ikpiIncorrect = ikpiIncorrect;
	}

	/**
	 * @param indexname1 the indexname1 to set
	 */
	public void setIndexname1(String indexname1) {
		this.indexname1 = indexname1;
	}

	/**
	 * @param indexname2 the indexname2 to set
	 */
	public void setIndexname2(String indexname2) {
		this.indexname2 = indexname2;
	}

	/**
	 * @param indexname3 the indexname3 to set
	 */
	public void setIndexname3(String indexname3) {
		this.indexname3 = indexname3;
	}

	/**
	 * @param indexvalue1 the indexvalue1 to set
	 */
	public void setIndexvalue1(String indexvalue1) {
		this.indexvalue1 = indexvalue1;
	}

	/**
	 * @param instanceXcertif the instanceXcertif to set
	 */
	public void setInstanceXcertif(String instanceXcertif) {
		this.instanceXcertif = instanceXcertif;
	}
	/**
	 * @param lformat the lformat to set
	 */
	public void setLformat(String lformat) {
		this.lformat = lformat;
	}
	/**
	 * @param libnatureManquante the libnatureManquante to set
	 */
	public void setLibnatureManquante(String libnatureManquante) {
		this.libnatureManquante = libnatureManquante;
	}
	//	/**
	//	 * @param lignepartab the lignepartab to set
	//	 */
	//	public void setLignepartab(String lignepartab) {
	//		this.lignepartab = lignepartab;
	//	}
	//
	//	/**
	//	 * @param lignetab the lignetab to set
	//	 */
	//	public void setLignetab(String lignetab) {
	//		this.lignetab = lignetab;
	//	}
	/**
	 * @param listeIdDocsAbsent the listeIdDocsAbsent to set
	 */
	public void setListeIdDocsAbsent(String listeIdDocsAbsent) {
		this.listeIdDocsAbsent = listeIdDocsAbsent;
	}
	/**
	 * @param listeparagrapheManquante the listeparagrapheManquante to set
	 */
	public void setListeparagrapheManquante(String listeparagrapheManquante) {
		this.listeparagrapheManquante = listeparagrapheManquante;
	}

	/**
	 * @param lotId the lotId to set
	 */
	public void setLotId(String lotId) {
		this.lotId = lotId;
	}

	/**
	 * @param lotLabel the lotLabel to set
	 */
	public void setLotLabel(String lotLabel) {
		this.lotLabel = lotLabel;
	}

	/**
	 * @param mailAbsent the mailAbsent to set
	 */
	public void setMailAbsent(String mailAbsent) {
		this.mailAbsent = mailAbsent;
	}

	/**
	 * @param maquette1ContestationCarte the maquette1ContestationCarte to set
	 */
	public void setMaquette1ContestationCarte(String maquette1ContestationCarte) {
		this.maquette1ContestationCarte = maquette1ContestationCarte;
	}

	/**
	 * @param maquette1ContestationCarteCentral the maquette1ContestationCarteCentral to set
	 */
	public void setMaquette1ContestationCarteCentral(
			String maquette1ContestationCarteCentral) {
		this.maquette1ContestationCarteCentral = maquette1ContestationCarteCentral;
	}

	/**
	 * @param maquette2ContestationCarte the maquette2ContestationCarte to set
	 */
	public void setMaquette2ContestationCarte(String maquette2ContestationCarte) {
		this.maquette2ContestationCarte = maquette2ContestationCarte;
	}

	//	/**
	//	 * @param lignepar the lignepar to set
	//	 */
	//	public void setLignepar(String lignepar) {
	//		this.lignepar = lignepar;
	//	}

	/**
	 * @param maquette2ContestationCarteCentral the maquette2ContestationCarteCentral to set
	 */
	public void setMaquette2ContestationCarteCentral(
			String maquette2ContestationCarteCentral) {
		this.maquette2ContestationCarteCentral = maquette2ContestationCarteCentral;
	}
	/**
	 * @param maquetteClo the maquetteClo to set
	 */
	public void setMaquetteClo(String maquetteClo) {
		this.maquetteClo = maquetteClo;
	}


	/**
	 * @param maquetteCourrierGenerique the maquetteCourrierGenerique to set
	 */
	public void setMaquetteCourrierGenerique(String maquetteCourrierGenerique) {
		this.maquetteCourrierGenerique = maquetteCourrierGenerique;
	}

	/**
	 * @param maquetteCourrierGeneriqueCentral the maquetteCourrierGeneriqueCentral to set
	 */
	public void setMaquetteCourrierGeneriqueCentral(
			String maquetteCourrierGeneriqueCentral) {
		this.maquetteCourrierGeneriqueCentral = maquetteCourrierGeneriqueCentral;
	}

	/**
	 * @param maquetteDeliaison the maquetteDeliaison to set
	 */
	public void setMaquetteDeliaison(String maquetteDeliaison) {
		this.maquetteDeliaison = maquetteDeliaison;
	}

	/**
	 * @param maquetteFormPay the maquetteFormPay to set
	 */
	public void setMaquetteFormPay(String maquetteFormPay) {
		this.maquetteFormPay = maquetteFormPay;
	}

	/**
	 * @param maquetteFormRetrait the maquetteFormRetrait to set
	 */
	public void setMaquetteFormRetrait(String maquetteFormRetrait) {
		this.maquetteFormRetrait = maquetteFormRetrait;
	}

	/**
	 * @param maquetteManquante the maquetteManquante to set
	 */
	public void setMaquetteManquante(String maquetteManquante) {
		this.maquetteManquante = maquetteManquante;
	}

	//	/**
	//	 * @param codeEchecService the codeEchecService to set
	//	 */
	//	public void setCodeEchecService(String codeEchecService) {
	//		this.codeEchecService = codeEchecService;
	//	}

	/**
	 * @param maquetteSelfCare the maquetteSelfCare to set
	 */
	public void setMaquetteSelfCare(String maquetteSelfCare) {
		this.maquetteSelfCare = maquetteSelfCare;
	}

	//	/**
	//	 * @param codeErrorTechnique the codeErrorTechnique to set
	//	 */
	//	public void setCodeErrorTechnique(String codeErrorTechnique) {
	//		this.codeErrorTechnique = codeErrorTechnique;
	//	}

	//	/**
	//	 * @param codeErrorTypeDocument the codeErrorTypeDocument to set
	//	 */
	//	public void setCodeErrorTypeDocument(String codeErrorTypeDocument) {
	//		this.codeErrorTypeDocument = codeErrorTypeDocument;
	//	}

	/**
	 * @param mediaEdoc the mediaEdoc to set
	 */
	public void setMediaEdoc(String mediaEdoc) {
		this.mediaEdoc = mediaEdoc;
	}

	/**
	 * @param messageCodeUOAbsent the messageCodeUOAbsent to set
	 */
	public void setMessageCodeUOAbsent(String messageCodeUOAbsent) {
		this.messageCodeUOAbsent = messageCodeUOAbsent;
	}

	/**
	 * @param messageDisputStatusAbsent the messageDisputStatusAbsent to set
	 */
	public void setMessageDisputStatusAbsent(String messageDisputStatusAbsent) {
		this.messageDisputStatusAbsent = messageDisputStatusAbsent;
	}

	/**
	 * @param messageDisputStatusIncorrect the messageDisputStatusIncorrect to set
	 */
	public void setMessageDisputStatusIncorrect(String messageDisputStatusIncorrect) {
		this.messageDisputStatusIncorrect = messageDisputStatusIncorrect;
	}

	/**
	 * @param messageErrorIdTypeDocument the messageErrorIdTypeDocument to set
	 */
	public void setMessageErrorIdTypeDocument(String messageErrorIdTypeDocument) {
		this.messageErrorIdTypeDocument = messageErrorIdTypeDocument;
	}

	/**
	 * @param messageErrorTechnique the messageErrorTechnique to set
	 */
	public void setMessageErrorTechnique(String messageErrorTechnique) {
		this.messageErrorTechnique = messageErrorTechnique;
	}

	/**
	 * @param messageIkpiAbsent the messageIkpiAbsent to set
	 */
	public void setMessageIkpiAbsent(String messageIkpiAbsent) {
		this.messageIkpiAbsent = messageIkpiAbsent;
	}

	/**
	 * @param messageNotFoundContestaionByFolderNumber the messageNotFoundContestaionByFolderNumber to set
	 */
	public void setMessageNotFoundContestaionByFolderNumber(
			String messageNotFoundContestaionByFolderNumber) {
		this.messageNotFoundContestaionByFolderNumber = messageNotFoundContestaionByFolderNumber;
	}

	/**
	 * @param messageNotFoundContestaionByIdentifier the messageNotFoundContestaionByIdentifier to set
	 */
	public void setMessageNotFoundContestaionByIdentifier(
			String messageNotFoundContestaionByIdentifier) {
		this.messageNotFoundContestaionByIdentifier = messageNotFoundContestaionByIdentifier;
	}

	/**
	 * @param messageNotFoundContestaionByTelematicId the messageNotFoundContestaionByTelematicId to set
	 */
	public void setMessageNotFoundContestaionByTelematicId(
			String messageNotFoundContestaionByTelematicId) {
		this.messageNotFoundContestaionByTelematicId = messageNotFoundContestaionByTelematicId;
	}

	/**
	 * @param messageNumeroPanAbsent the messageNumeroPanAbsent to set
	 */
	public void setMessageNumeroPanAbsent(String messageNumeroPanAbsent) {
		this.messageNumeroPanAbsent = messageNumeroPanAbsent;
	}
	/**
	 * @param messagePurgeSuccess the messagePurgeSuccess to set
	 */
	public void setMessagePurgeSuccess(String messagePurgeSuccess) {
		this.messagePurgeSuccess = messagePurgeSuccess;
	}

	/**
	 * @param mimetypeAbsent the mimetypeAbsent to set
	 */
	public void setMimetypeAbsent(String mimetypeAbsent) {
		this.mimetypeAbsent = mimetypeAbsent;
	}

	/**
	 * @param mimeTypeErrorFormat the mimeTypeErrorFormat to set
	 */
	public void setMimeTypeErrorFormat(String mimeTypeErrorFormat) {
		this.mimeTypeErrorFormat = mimeTypeErrorFormat;
	}

	/**
	 * @param mimeTypeformat1 the mimeTypeformat1 to set
	 */
	public void setMimeTypeformat1(String mimeTypeformat1) {
		this.mimeTypeformat1 = mimeTypeformat1;
	}

	/**
	 * @param mimeTypeformat2 the mimeTypeformat2 to set
	 */
	public void setMimeTypeformat2(String mimeTypeformat2) {
		this.mimeTypeformat2 = mimeTypeformat2;
	}

	/**
	 * @param minuteLiveJwt the minuteLiveJwt to set
	 */
	public void setMinuteLiveJwt(int minuteLiveJwt) {
		this.minuteLiveJwt = minuteLiveJwt;
	}

	//	/**
	//	 * @param errorDonneManquante the errorDonneManquante to set
	//	 */
	//	public void setErrorDonneManquante(String errorDonneManquante) {
	//		this.errorDonneManquante = errorDonneManquante;
	//	}

	/**
	 * @param natureAbsent the natureAbsent to set
	 */
	public void setNatureAbsent(String natureAbsent) {
		this.natureAbsent = natureAbsent;
	}

	/**
	 * @param normLevel the normLevel to set
	 */
	public void setNormLevel(String normLevel) {
		this.normLevel = normLevel;
	}

	/**
	 * @param noSecurised the noSecurised to set
	 */
	public void setNoSecurised(String noSecurised) {
		this.noSecurised = noSecurised;
	}

	/**
	 * @param numCarteManquante the numCarteManquante to set
	 */
	public void setNumCarteManquante(String numCarteManquante) {
		this.numCarteManquante = numCarteManquante;
	}

	/**
	 * @param numcartemasqueManquante the numcartemasqueManquante to set
	 */
	public void setNumcartemasqueManquante(String numcartemasqueManquante) {
		this.numcartemasqueManquante = numcartemasqueManquante;
	}

	/**
	 * @param numdossierManquante the numdossierManquante to set
	 */
	public void setNumdossierManquante(String numdossierManquante) {
		this.numdossierManquante = numdossierManquante;
	}

	/**
	 * @param operationsAbsent the operationsAbsent to set
	 */
	public void setOperationsAbsent(String operationsAbsent) {
		this.operationsAbsent = operationsAbsent;
	}

	/**
	 * @param owningApplication the owningApplication to set
	 */
	public void setOwningApplication(String owningApplication) {
		this.owningApplication = owningApplication;
	}

	/**
	 * @param passwordKeyStore the passwordKeyStore to set
	 */
	public void setPasswordKeyStore(String passwordKeyStore) {
		this.passwordKeyStore = passwordKeyStore;
	}

	/**
	 * @param pathCertif the pathCertif to set
	 */
	public void setPathCertif(String pathCertif) {
		this.pathCertif = pathCertif;
	}

	/**
	 * @param pathKeyStore the pathKeyStore to set
	 */
	public void setPathKeyStore(String pathKeyStore) {
		this.pathKeyStore = pathKeyStore;
	}

	/**
	 * @param phoneAbsent the phoneAbsent to set
	 */
	public void setPhoneAbsent(String phoneAbsent) {
		this.phoneAbsent = phoneAbsent;
	}

	/**
	 * @param priorite the priorite to set
	 */
	public void setPriorite(String priorite) {
		this.priorite = priorite;
	}



	/**
	 * @param publicationTop the publicationTop to set
	 */
	public void setPublicationTop(String publicationTop) {
		this.publicationTop = publicationTop;
	}
	/**
	 * @param qualificationAbsent the qualificationAbsent to set
	 */
	public void setQualificationAbsent(String qualificationAbsent) {
		this.qualificationAbsent = qualificationAbsent;
	}
	/**
	 * @param reponseIncorect the reponseIncorect to set
	 */
	public void setReponseIncorect(String reponseIncorect) {
		this.reponseIncorect = reponseIncorect;
	}

	/**
	 * @param reponseIncorectGDN the reponseIncorectGDN to set
	 */
	public void setReponseIncorectGDN(String reponseIncorectGDN) {
		this.reponseIncorectGDN = reponseIncorectGDN;
	}

	/**
	 * @param reponseNullRP the reponseNullRP to set
	 */
	public void setReponseNullRP(String reponseNullRP) {
		this.reponseNullRP = reponseNullRP;
	}



	/**
	 * @param reponseSuccessSecureDoc the reponseSuccessSecureDoc to set
	 */
	public void setReponseSuccessSecureDoc(String reponseSuccessSecureDoc) {
		this.reponseSuccessSecureDoc = reponseSuccessSecureDoc;
	}

	/**
	 * @param responseIncorectRP the responseIncorectRP to set
	 */
	public void setResponseIncorectRP(String responseIncorectRP) {
		this.responseIncorectRP = responseIncorectRP;
	}

	/**
	 * @param ribCotisationAbsent the ribCotisationAbsent to set
	 */
	public void setRibCotisationAbsent(String ribCotisationAbsent) {
		this.ribCotisationAbsent = ribCotisationAbsent;
	}

	/**
	 * @param ribCotisationIncorrect the ribCotisationIncorrect to set
	 */
	public void setRibCotisationIncorrect(String ribCotisationIncorrect) {
		this.ribCotisationIncorrect = ribCotisationIncorrect;
	}

	/**
	 * @param ribOperationAbsent the ribOperationAbsent to set
	 */
	public void setRibOperationAbsent(String ribOperationAbsent) {
		this.ribOperationAbsent = ribOperationAbsent;
	}

	/**
	 * @param ribOperationIncorrect the ribOperationIncorrect to set
	 */
	public void setRibOperationIncorrect(String ribOperationIncorrect) {
		this.ribOperationIncorrect = ribOperationIncorrect;
	}

	/**
	 * @param rootService the rootService to set
	 */
	public void setRootService(String rootService) {
		this.rootService = rootService;
	}

	/**
	 * @param sepialg the sepialg to set
	 */
	public void setSepialg(String sepialg) {
		this.sepialg = sepialg;
	}

	/**
	 * @param sepiaml the sepiaml to set
	 */
	public void setSepiaml(String sepiaml) {
		this.sepiaml = sepiaml;
	}

	/**
	 * @param sirenAbsent the sirenAbsent to set
	 */
	public void setSirenAbsent(String sirenAbsent) {
		this.sirenAbsent = sirenAbsent;
	}

	/**
	 * @param sirenIncorrect the sirenIncorrect to set
	 */
	public void setSirenIncorrect(String sirenIncorrect) {
		this.sirenIncorrect = sirenIncorrect;
	}

	/**
	 * @param sirenNumber the sirenNumber to set
	 */
	public void setSirenNumber(String sirenNumber) {
		this.sirenNumber = sirenNumber;
	}

	/**
	 * @param storageLevel the storageLevel to set
	 */
	public void setStorageLevel(String storageLevel) {
		this.storageLevel = storageLevel;
	}

	/**
	 * @param telEmeteurManquant the telEmeteurManquant to set
	 */
	public void setTelEmeteurManquant(String telEmeteurManquant) {
		this.telEmeteurManquant = telEmeteurManquant;
	}

	/**
	 * @param titreAbsent the titreAbsent to set
	 */
	public void setTitreAbsent(String titreAbsent) {
		this.titreAbsent = titreAbsent;
	}

	/**
	 * @param topClientAbsent the topClientAbsent to set
	 */
	public void setTopClientAbsent(String topClientAbsent) {
		this.topClientAbsent = topClientAbsent;
	}



	/**
	 * @param topClientIncorrect the topClientIncorrect to set
	 */
	public void setTopClientIncorrect(String topClientIncorrect) {
		this.topClientIncorrect = topClientIncorrect;
	}


	/**
	 * @param traceLog the traceLog to set
	 */
	public void setTraceLog(String traceLog) {
		this.traceLog = traceLog;
	}
	/**
	 * @param traceXml the traceXml to set
	 */
	public void setTraceXml(String traceXml) {
		this.traceXml = traceXml;
	}
	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	/**
	 * @param typAuthorization the typAuthorization to set
	 */
	public void setTypAuthorization(String typAuthorization) {
		TypAuthorization = typAuthorization;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @param typi the typi to set
	 */
	public void setTypi(String typi) {
		this.typi = typi;
	}

	/**
	 * @param urlAttachmentSelf the urlAttachmentSelf to set
	 */
	public void setUrlAttachmentSelf(String urlAttachmentSelf) {
		this.urlAttachmentSelf = urlAttachmentSelf;
	}

	/**
	 * @param urlCreateSelf the urlCreateSelf to set
	 */
	public void setUrlCreateSelf(String urlCreateSelf) {
		this.urlCreateSelf = urlCreateSelf;
	}

	/**
	 * @param urlGetStatuSelf the urlGetStatuSelf to set
	 */
	public void setUrlGetStatuSelf(String urlGetStatuSelf) {
		this.urlGetStatuSelf = urlGetStatuSelf;
	}

	/**
	 * @param urlPostEdoc the urlPostEdoc to set
	 */
	public void setUrlPostEdoc(String urlPostEdoc) {
		this.urlPostEdoc = urlPostEdoc;
	}

	/**
	 * @param urlPutEdoc the urlPutEdoc to set
	 */
	public void setUrlPutEdoc(String urlPutEdoc) {
		this.urlPutEdoc = urlPutEdoc;
	}

	/**
	 * @param userAbsent the userAbsent to set
	 */
	public void setUserAbsent(String userAbsent) {
		this.userAbsent = userAbsent;
	}

	/**
	 * @param userIdEdoc the userIdEdoc to set
	 */
	public void setUserIdEdoc(String userIdEdoc) {
		this.userIdEdoc = userIdEdoc;
	}


	/**
	 * @param usertypeAbsent the usertypeAbsent to set
	 */
	public void setUsertypeAbsent(String usertypeAbsent) {
		this.usertypeAbsent = usertypeAbsent;
	}

	/**
	 * @param versionJwt the versionJwt to set
	 */
	public void setVersionJwt(String versionJwt) {
		this.versionJwt = versionJwt;
	}



}
