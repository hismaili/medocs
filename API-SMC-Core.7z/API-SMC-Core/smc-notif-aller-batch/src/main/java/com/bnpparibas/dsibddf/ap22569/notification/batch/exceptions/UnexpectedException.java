package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file.FileValidationException;

import java.time.LocalDate;

public class UnexpectedException extends FileValidationException {


    public UnexpectedException(String code, String message, String fileName, LocalDate fileDate, String errorMessage) {
        super(message, code, fileName, fileDate, errorMessage);
    }
}
