/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author c65344
 *
 */
public class Document {

	@ApiModelProperty(value = "Nom du fichier", required = true)
	private String fileName;
	@ApiModelProperty(value = "Format du document électronique", required = true)
	private String archiveFormat;
	@ApiModelProperty(value = "données du Document électronique", required = true)
	private Objectsmc object;
	/**
	 *
	 */
	public Document() {
		super();

	}
	/**
	 * @param fileName
	 * @param archiveFormat
	 * @param object
	 */
	public Document(String fileName, String archiveFormat, Objectsmc object) {
		this.fileName = fileName;
		this.archiveFormat = archiveFormat;
		this.object = object;
	}
	/**
	 * @return the archiveFormat
	 */
	public String getArchiveFormat() {
		return archiveFormat;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @return the object
	 */
	public Objectsmc getObject() {
		return object;
	}
	/**
	 * @param archiveFormat the archiveFormat to set
	 */
	public void setArchiveFormat(String archiveFormat) {
		this.archiveFormat = archiveFormat;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @param object the object to set
	 */
	public void setObject(Objectsmc object) {
		this.object = object;
	}

}
