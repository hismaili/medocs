/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.List;

/**
 * @author c65344
 *
 */
public class DonneIncorectException extends Exception {


	private static final long serialVersionUID = 1L;
	private List<String> errors;
	/**
	 *
	 */
	public DonneIncorectException() {
		super();

	}
	/**
	 * @param errors
	 */
	public DonneIncorectException(List<String> errors) {
		this.errors = errors;
	}
	/**
	 * @param message
	 */
	public DonneIncorectException(String message) {
		super(message);

	}
	/**
	 * @param errors
	 */
	public DonneIncorectException(String message, List<String> errors) {
		super(message);
		this.errors = errors;
	}
	/**
	 * @param message
	 * @param cause
	 */
	public DonneIncorectException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param cause
	 */
	public DonneIncorectException(Throwable cause) {
		super(cause);

	}
	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}


}
