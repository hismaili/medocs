package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.math.BigDecimal;
import java.util.Objects;

/**
 *
 *
 *
 */
public class Amount {

	private BigDecimal amount;

	private String currency;

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		Amount amount1 = (Amount) o;
		return amount.equals(amount1.amount) &&
				currency.equals(amount1.currency);
	}
	/**
	 *
	 * @return
	 */
	public BigDecimal getAmount() {
		return amount;
	}
	/**
	 *
	 * @return
	 */
	public String getCurrency() {
		return currency;
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, currency);
	}
	/**
	 *
	 * @param amount
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	/**
	 *
	 * @param currency
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
}
