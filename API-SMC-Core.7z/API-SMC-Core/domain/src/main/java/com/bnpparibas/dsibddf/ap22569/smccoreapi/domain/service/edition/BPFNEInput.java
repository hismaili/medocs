/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 * @author c65344
 *
 */
public class BPFNEInput {
	private String attpfne;

	private String iklo;

	private String ctypeadr;

	private String lvalcpstnadrp1;

	private String lvalcpstnadrp2;

	private String lvalcpstnadrp3;

	private String lvalcpstnadrp4;

	private String lvalcpstnadrp5;

	private String lvalcpstnadrp6;

	private String cnormeadrp;

	private String libnpai;

	private String forcagepfne;

	/**
	 *
	 */
	public BPFNEInput() {
		super();
	}

	/**
	 * @param attpfne
	 * @param iklo
	 * @param ctypeadr
	 * @param lvalcpstnadrp1
	 * @param lvalcpstnadrp2
	 * @param lvalcpstnadrp3
	 * @param lvalcpstnadrp4
	 * @param lvalcpstnadrp5
	 * @param lvalcpstnadrp6
	 * @param cnormeadrp
	 * @param libnpai
	 * @param forcagepfne
	 */
	public BPFNEInput(String attpfne, String iklo, String ctypeadr,
			String lvalcpstnadrp1, String lvalcpstnadrp2,
			String lvalcpstnadrp3, String lvalcpstnadrp4,
			String lvalcpstnadrp5, String lvalcpstnadrp6, String cnormeadrp,
			String libnpai, String forcagepfne) {
		this.attpfne = attpfne;
		this.iklo = iklo;
		this.ctypeadr = ctypeadr;
		this.lvalcpstnadrp1 = lvalcpstnadrp1;
		this.lvalcpstnadrp2 = lvalcpstnadrp2;
		this.lvalcpstnadrp3 = lvalcpstnadrp3;
		this.lvalcpstnadrp4 = lvalcpstnadrp4;
		this.lvalcpstnadrp5 = lvalcpstnadrp5;
		this.lvalcpstnadrp6 = lvalcpstnadrp6;
		this.cnormeadrp = cnormeadrp;
		this.libnpai = libnpai;
		this.forcagepfne = forcagepfne;
	}

	/**
	 * @return the attpfne
	 */
	public String getAttpfne() {
		return attpfne;
	}

	/**
	 * @return the cnormeadrp
	 */
	public String getCnormeadrp() {
		return cnormeadrp;
	}

	/**
	 * @return the ctypeadr
	 */
	public String getCtypeadr() {
		return ctypeadr;
	}

	/**
	 * @return the forcagepfne
	 */
	public String getForcagepfne() {
		return forcagepfne;
	}

	/**
	 * @return the iklo
	 */
	public String getIklo() {
		return iklo;
	}

	/**
	 * @return the libnpai
	 */
	public String getLibnpai() {
		return libnpai;
	}

	/**
	 * @return the lvalcpstnadrp1
	 */
	public String getLvalcpstnadrp1() {
		return lvalcpstnadrp1;
	}

	/**
	 * @return the lvalcpstnadrp2
	 */
	public String getLvalcpstnadrp2() {
		return lvalcpstnadrp2;
	}

	/**
	 * @return the lvalcpstnadrp3
	 */
	public String getLvalcpstnadrp3() {
		return lvalcpstnadrp3;
	}

	/**
	 * @return the lvalcpstnadrp4
	 */
	public String getLvalcpstnadrp4() {
		return lvalcpstnadrp4;
	}

	/**
	 * @return the lvalcpstnadrp5
	 */
	public String getLvalcpstnadrp5() {
		return lvalcpstnadrp5;
	}

	/**
	 * @return the lvalcpstnadrp6
	 */
	public String getLvalcpstnadrp6() {
		return lvalcpstnadrp6;
	}

	/**
	 * @param attpfne the attpfne to set
	 */
	public void setAttpfne(String attpfne) {
		this.attpfne = attpfne;
	}

	/**
	 * @param cnormeadrp the cnormeadrp to set
	 */
	public void setCnormeadrp(String cnormeadrp) {
		this.cnormeadrp = cnormeadrp;
	}

	/**
	 * @param ctypeadr the ctypeadr to set
	 */
	public void setCtypeadr(String ctypeadr) {
		this.ctypeadr = ctypeadr;
	}

	/**
	 * @param forcagepfne the forcagepfne to set
	 */
	public void setForcagepfne(String forcagepfne) {
		this.forcagepfne = forcagepfne;
	}

	/**
	 * @param iklo the iklo to set
	 */
	public void setIklo(String iklo) {
		this.iklo = iklo;
	}

	/**
	 * @param libnpai the libnpai to set
	 */
	public void setLibnpai(String libnpai) {
		this.libnpai = libnpai;
	}

	/**
	 * @param lvalcpstnadrp1 the lvalcpstnadrp1 to set
	 */
	public void setLvalcpstnadrp1(String lvalcpstnadrp1) {
		this.lvalcpstnadrp1 = lvalcpstnadrp1;
	}

	/**
	 * @param lvalcpstnadrp2 the lvalcpstnadrp2 to set
	 */
	public void setLvalcpstnadrp2(String lvalcpstnadrp2) {
		this.lvalcpstnadrp2 = lvalcpstnadrp2;
	}

	/**
	 * @param lvalcpstnadrp3 the lvalcpstnadrp3 to set
	 */
	public void setLvalcpstnadrp3(String lvalcpstnadrp3) {
		this.lvalcpstnadrp3 = lvalcpstnadrp3;
	}

	/**
	 * @param lvalcpstnadrp4 the lvalcpstnadrp4 to set
	 */
	public void setLvalcpstnadrp4(String lvalcpstnadrp4) {
		this.lvalcpstnadrp4 = lvalcpstnadrp4;
	}

	/**
	 * @param lvalcpstnadrp5 the lvalcpstnadrp5 to set
	 */
	public void setLvalcpstnadrp5(String lvalcpstnadrp5) {
		this.lvalcpstnadrp5 = lvalcpstnadrp5;
	}

	/**
	 * @param lvalcpstnadrp6 the lvalcpstnadrp6 to set
	 */
	public void setLvalcpstnadrp6(String lvalcpstnadrp6) {
		this.lvalcpstnadrp6 = lvalcpstnadrp6;
	}
}
