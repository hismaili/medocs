package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.ISmcTraceRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTraceException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 *
 *
 *
 */
@Service
//@Transactional
public class TraceManagementImpl implements ITraceManagement {
	@Autowired
	private transient ISmcTraceRepository traceRepository;
	/**
	 *
	 * @param traceRepository
	 */
	public TraceManagementImpl(ISmcTraceRepository traceRepository) {
		this.traceRepository = traceRepository;
	}

	/**
	 * Tracer les appels des services web de l'application
	 *
	 * @param traceDTO : elements à tracer
	 * @throws SmcTraceException : levée si une erreur a lieu
	 */
	@Override
	public void trace(TraceDTO traceDTO) throws SmcTraceException {
		SmcTrace smcTrace = new SmcTrace();
		//TODO vérifier le cas ou traceDTO est null, penser à le faire sur tout les mappers
		BeanUtils.copyProperties(traceDTO, smcTrace);
		traceRepository.createTrace(smcTrace);
	}
}
