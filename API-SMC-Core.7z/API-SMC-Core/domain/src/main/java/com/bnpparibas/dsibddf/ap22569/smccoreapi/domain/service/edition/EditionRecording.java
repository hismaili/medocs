/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import java.util.List;

/**
 * @author c65344
 *
 */
public class EditionRecording {
	private int numSequence;
	private DetailCourrier detailCourrier;
	private List<Operation> operations;
	private List<String> ps;
	private List<Paragraphe> paragraphes;
	/**
	 * @return the detailCourrier
	 */
	public DetailCourrier getDetailCourrier() {
		return detailCourrier;
	}
	/**
	 * @return the numSequence
	 */
	public int getNumSequence() {
		return numSequence;
	}
	/**
	 * @return the operations
	 */
	public List<Operation> getOperations() {
		return operations;
	}
	/**
	 * @return the paragraphes
	 */
	public List<Paragraphe> getParagraphes() {
		return paragraphes;
	}
	/**
	 * @return the ps
	 */
	public List<String> getPs() {
		return ps;
	}
	/**
	 * @param detailCourrier the detailCourrier to set
	 */
	public void setDetailCourrier(DetailCourrier detailCourrier) {
		this.detailCourrier = detailCourrier;
	}
	/**
	 * @param numSequence the numSequence to set
	 */
	public void setNumSequence(int numSequence) {
		this.numSequence = numSequence;
	}
	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<Operation> operations) {
		this.operations = operations;
	}
	/**
	 * @param paragraphes the paragraphes to set
	 */
	public void setParagraphes(List<Paragraphe> paragraphes) {
		this.paragraphes = paragraphes;
	}
	/**
	 * @param ps the ps to set
	 */
	public void setPs(List<String> ps) {
		this.ps = ps;
	}
}
