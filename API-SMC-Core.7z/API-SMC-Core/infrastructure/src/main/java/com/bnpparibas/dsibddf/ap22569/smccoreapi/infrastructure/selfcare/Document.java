package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Document
 */
public class Document   {
	@JsonProperty("idGed")
	private String idGed;

	@JsonProperty("documentType")
	private String documentType;

	@JsonProperty("docuementName")
	private String docuementName;

	/**
	 *
	 */
	public Document() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param idGed
	 * @param documentType
	 * @param docuementName
	 */
	public Document(String idGed, String documentType, String docuementName) {
		this.idGed = idGed;
		this.documentType = documentType;
		this.docuementName = docuementName;
	}

	/**
	 * @return the docuementName
	 */
	public String getDocuementName() {
		return docuementName;
	}

	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @return the idGed
	 */
	public String getIdGed() {
		return idGed;
	}

	/**
	 * @param docuementName the docuementName to set
	 */
	public void setDocuementName(String docuementName) {
		this.docuementName = docuementName;
	}

	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * @param idGed the idGed to set
	 */
	public void setIdGed(String idGed) {
		this.idGed = idGed;
	}



}

