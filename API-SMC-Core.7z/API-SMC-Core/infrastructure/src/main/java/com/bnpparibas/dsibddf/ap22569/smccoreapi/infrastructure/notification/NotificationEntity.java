/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "NOTIFICATION")
@Access(AccessType.FIELD)
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class NotificationEntity extends AbstractEntity<DefaultEntityId> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column(length = 2)
	private String recordCode;
	@Column(length=6)
	private String codeAgence;
	@Column(length=60)
	private String idTechnique;
	@Column(length=60)
	private String dossierSmc;
	@Column(length=60)
	private String numCarteDossier;
	@Column
	private String  dateCall;
	@Column(length=1)
	private String  notifSms;
	@Column(length=1)
	private String  notifMail;
	@Column(length=20)
	private String  numTel;
	@Column(length=150)
	private String  mailClient;
	@Column(length=3)
	private String  codeNotif;
	@Column(length=500)
	private String  contenuNotif;
	@Column(length=500)
	private String  objetDuMail;
	@Column(length=6)
	private String civilite;
	@Column(length=60)
	private String nom;
	@Column(length=60)
	private String prenom;

	@ManyToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name="notif_file")
	private NotificationFileEntity informationFile;

	@Column
	private LocalDateTime processingDate;

	@Column
	@Enumerated(EnumType.STRING)
	private NotificationProcessingStatus processingStatus;

	@Column
	private LocalDateTime ackDate;

	@Column
	@Enumerated(EnumType.STRING)
	private NotificationProcessingStatus ackStatus;

	@Column(length = 50)
	private String numClient;

	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}
	/**
	 * @return the codeAgence
	 */
	public String getCodeAgence() {
		return codeAgence;
	}
	/**
	 * @return the codeNotif
	 */
	public String getCodeNotif() {
		return codeNotif;
	}
	/**
	 * @return the recordCode
	 */
	public String getRecordCode() {
		return recordCode;
	}
	/**
	 * @return the contenuNotif
	 */
	public String getContenuNotif() {
		return contenuNotif;
	}
	/**
	 * @return the dateCall
	 */
	public String getDateCall() {
		return dateCall;
	}
	/**
	 * @return the dossierSmc
	 */
	public String getDossierSmc() {
		return dossierSmc;
	}
	/**
	 * @return the idTechnique
	 */
	public String getIdTechnique() {
		return idTechnique;
	}
	/**
	 * @return the informationFile
	 */
	public NotificationFileEntity getInformationFile() {
		return informationFile;
	}
	/**
	 * @return the mailClient
	 */
	public String getMailClient() {
		return mailClient;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @return the notifMail
	 */
	public String getNotifMail() {
		return notifMail;
	}
	/**
	 * @return the notifSms
	 */
	public String getNotifSms() {
		return notifSms;
	}
	/**
	 * @return the numCarteDossier
	 */
	public String getNumCarteDossier() {
		return numCarteDossier;
	}
	/**
	 * @return the numTel
	 */
	public String getNumTel() {
		return numTel;
	}
	/**
	 * @return the objetDuMail
	 */
	public String getObjetDuMail() {
		return objetDuMail;
	}
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	/**
	 * @param codeAgence the codeAgence to set
	 */
	public void setCodeAgence(String codeAgence) {
		this.codeAgence = codeAgence;
	}
	/**
	 * @param codeNotif the codeNotif to set
	 */
	public void setCodeNotif(String codeNotif) {
		this.codeNotif = codeNotif;
	}
	/**
	 * @param recordCode the recordCode to set
	 */
	public void setRecordCode(String recordCode) {
		this.recordCode = recordCode;
	}
	/**
	 * @param contenuNotif the contenuNotif to set
	 */
	public void setContenuNotif(String contenuNotif) {
		this.contenuNotif = contenuNotif;
	}
	/**
	 * @param dateCall the dateCall to set
	 */
	public void setDateCall(String dateCall) {
		this.dateCall = dateCall;
	}
	/**
	 * @param dossierSmc the dossierSmc to set
	 */
	public void setDossierSmc(String dossierSmc) {
		this.dossierSmc = dossierSmc;
	}
	/**
	 * @param idTechnique the idTechnique to set
	 */
	public void setIdTechnique(String idTechnique) {
		this.idTechnique = idTechnique;
	}
	/**
	 * @param informationFile the informationFile to set
	 */
	public void setInformationFile(NotificationFileEntity informationFile) {
		this.informationFile = informationFile;
	}
	/**
	 * @param mailClient the mailClient to set
	 */
	public void setMailClient(String mailClient) {
		this.mailClient = mailClient;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @param notifMail the notifMail to set
	 */
	public void setNotifMail(String notifMail) {
		this.notifMail = notifMail;
	}
	/**
	 * @param notifSms the notifSms to set
	 */
	public void setNotifSms(String notifSms) {
		this.notifSms = notifSms;
	}
	/**
	 * @param numCarteDossier the numCarteDossier to set
	 */
	public void setNumCarteDossier(String numCarteDossier) {
		this.numCarteDossier = numCarteDossier;
	}
	/**
	 * @param numTel the numTel to set
	 */
	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}
	/**
	 * @param objetDuMail the objetDuMail to set
	 */
	public void setObjetDuMail(String objetDuMail) {
		this.objetDuMail = objetDuMail;
	}
	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public LocalDateTime getProcessingDate() {
		return processingDate;
	}

	public void setProcessingDate(LocalDateTime processingDate) {
		this.processingDate = processingDate;
	}

	public NotificationProcessingStatus getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(NotificationProcessingStatus processingStatus) {
		this.processingStatus = processingStatus;
	}

	public LocalDateTime getAckDate() {
		return ackDate;
	}

	public void setAckDate(LocalDateTime ackDate) {
		this.ackDate = ackDate;
	}

	public NotificationProcessingStatus getAckStatus() {
		return ackStatus;
	}

	public void setAckStatus(NotificationProcessingStatus ackStatus) {
		this.ackStatus = ackStatus;
	}

	public String getNumClient() {
		return numClient;
	}

	public void setNumClient(String numClient) {
		this.numClient = numClient;
	}

	enum NotificationProcessingStatus {
		READ_SUCCESS, //valid notification red from file
		READ_REJECT, // valid notification red from file
		SEND_IN_PROGRESS, //SEND to digicon in progress
		SEND_FAILED, ////SEND to digicon failed
		SEND_SUCEEDED //SEND to digicon succeeded
	}
}


