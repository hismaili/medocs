package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.ISmcTraceRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@EntityScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace"})
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
public class SmcTraceRepositoryImplTest {

	@Autowired
	private ISmcTraceRepository repository;

	@Test
	public void testCreateTrace() {

		SmcTrace trace = new SmcTrace();
		trace.setApplicationAppelante("AP22615");
		trace.setDateAppel(LocalDateTime.now());
		trace.setIdContestation("562148793");
		trace.setService("ArchivageController.newFolder(..)");
		trace.setSens("IN");
		trace.setParamIn("[{\"callingUser\":\"456215\",\"numCarteBancaire\":null,\"idContestationSmc\":\"25642323859\"}]");
		repository.createTrace(trace);
	}
}