package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
/**
 *
 *
 *
 */
public class ContestationInfos {

	/** Le numero de la carte bancaire (PAN) */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "numéro de la carte bancaire (PAN)", required = true)
	private String numeroCarte;

	/** L'identifiant iKpi du client */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "iKpi du client à l'origine de la demande de contestation", required = true)
	private String ikpiClient;

	/** L'identifiant télématique du client */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "id télématique du client à l'origine de la demande  de contestation", required = true)
	private String idTelematiqueClient;

	/** La liste des opérations contestées */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "la liste des opérations à contester", required = true)
	private List<OperationIn> operations;

	/** Le montant reconnu par le client dans le cas de billets partiellement délivrées (DAB)
	 * ou montant erroné (achat) */
	@ApiModelProperty(value = "le montant reconnu par l'utilisateur. Obligatoire pour les motifs où l'utilisateur conteste pour montant erroné")
	private BigDecimal montantReconnu;

	/** Le client souhaite être notifié par SMS ou non */
	@ApiModelProperty(value = "Le client préfère-t-il être notifié par SMS ou non")
	private Boolean notifSMS;

	/** Le client souhaite être notifié par mail */
	@ApiModelProperty(value = "Le client préfère-t-il être notifié par Mail ou non")
	private Boolean notifMail;

	/** Le client souhaite être notifié par mail */
	@ApiModelProperty(value = "Le client préfère-t-il être notifié en push ou non")
	private Boolean notifPush;

	/** Motif de la contestation */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "Motif de la contestation")
	private String motif;

	/** description des faits */
	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "Description des faits")
	private String desciption;


	@Override
	public boolean equals(Object o) {

		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		ContestationInfos that = (ContestationInfos) o;
		return Objects.equals(numeroCarte, that.numeroCarte) &&
				Objects.equals(ikpiClient, that.ikpiClient) &&
				Objects.equals(idTelematiqueClient, that.idTelematiqueClient) &&
				Objects.equals(operations, that.operations) &&
				Objects.equals(montantReconnu, that.montantReconnu) &&
				Objects.equals(notifSMS, that.notifSMS) &&
				Objects.equals(notifMail, that.notifMail) &&
				Objects.equals(notifPush, that.notifPush) &&
				Objects.equals(motif, that.motif) &&
				Objects.equals(desciption, that.desciption);
	}
	/**
	 *
	 * @return
	 */
	public String getDesciption() {
		return desciption;
	}
	/**
	 *
	 * @return
	 */
	public String getIdTelematiqueClient() {
		return idTelematiqueClient;
	}
	/**
	 *
	 * @return
	 */
	public String getIkpiClient() {
		return ikpiClient;
	}
	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantReconnu() {
		return montantReconnu;
	}
	/**
	 *
	 * @return
	 */
	public String getMotif() {
		return motif;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifMail() {
		return notifMail;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifPush() {
		return notifPush;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifSMS() {
		return notifSMS;
	}
	/**
	 *
	 * @return
	 */
	public String getNumeroCarte() {
		return numeroCarte;
	}
	/**
	 *
	 * @return
	 */
	public List<OperationIn> getOperations() {
		return operations;
	}

	@Override
	public int hashCode() {
		return Objects.hash(numeroCarte, ikpiClient, idTelematiqueClient, operations, montantReconnu, notifSMS, notifMail, notifPush, motif, desciption);
	}
	/**
	 *
	 * @param desciption
	 */
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	/**
	 *
	 * @param idTelematiqueClient
	 */
	public void setIdTelematiqueClient(String idTelematiqueClient) {
		this.idTelematiqueClient = idTelematiqueClient;
	}
	/**
	 *
	 * @param ikpiClient
	 */
	public void setIkpiClient(String ikpiClient) {
		this.ikpiClient = ikpiClient;
	}
	/**
	 *
	 * @param montantReconnu
	 */
	public void setMontantReconnu(BigDecimal montantReconnu) {
		this.montantReconnu = montantReconnu;
	}
	/**
	 *
	 * @param motif
	 */
	public void setMotif(String motif) {
		this.motif = motif;
	}
	/**
	 *
	 * @param notifMail
	 */
	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}
	/**
	 *
	 * @param notifPush
	 */
	public void setNotifPush(Boolean notifPush) {
		this.notifPush = notifPush;
	}
	/**
	 *
	 * @param notifSMS
	 */
	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}
	/**
	 *
	 * @param numeroCarte
	 */
	public void setNumeroCarte(String numeroCarte) {
		this.numeroCarte = numeroCarte;
	}
	/**
	 *
	 * @param operations
	 */
	public void setOperations(List<OperationIn> operations) {
		this.operations = operations;
	}
}
