package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

import java.util.List;

/**
 * recupère les information cartes
 * @author c65344
 *
 */
public interface ICardService {

	/**
	 * recupère la Liste des cartes d'un utilisateur
	 * @param iKpi
	 * @return
	 */
	List<CartePorteur> getCartesPorteur(String iKpi) throws CardException;

	/**
	 * recupère les informations de la carte
	 * @param pan
	 * @return
	 */
	InfoCarte getInfoCard(String pan) throws CardException;

	/**
	 *  Récupérer la liste des cartes rattachés à un rib
	 *
	 * @param ribs
	 * @return
	 * @throws CardException
	 */
	List<CartePorteur> getCartesPourCompte(List<String> ribs) throws CardException;

	/**
	 *  Récupérer la liste des cartes rattachés à un rib et les anonymiser
	 *
	 * @param ribs
	 * @return
	 * @throws CardException
	 */
	List<AnonymizedCard> getCartesAnonymiseesPourCompte(List<String> ribs) throws CardException;

	List<AnonymizedCard> anonymizeCartes(List<CartePorteur> cartes) throws CardException;

	AnonymizedCard getCardByCardId(String cardId)  throws CardException;

}
