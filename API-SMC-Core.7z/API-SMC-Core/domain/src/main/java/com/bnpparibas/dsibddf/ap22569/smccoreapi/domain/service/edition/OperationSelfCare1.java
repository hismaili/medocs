/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 * @author c65344
 *
 */
public class OperationSelfCare1 {
	private String dateDebit;

	private String libelleOperation;

	private String dateVente;

	private String montantOperation;

	/**
	 *
	 */
	public OperationSelfCare1() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param dateDebit
	 * @param libelleOperation
	 * @param dateVente
	 * @param montantOperation
	 */
	public OperationSelfCare1(String dateDebit, String libelleOperation,
			String dateVente, String montantOperation) {
		this.dateDebit = dateDebit;
		this.libelleOperation = libelleOperation;
		this.dateVente = dateVente;
		this.montantOperation = montantOperation;
	}

	/**
	 * @return the dateDebit
	 */
	public String getDateDebit() {
		return dateDebit;
	}

	/**
	 * @return the dateVente
	 */
	public String getDateVente() {
		return dateVente;
	}

	/**
	 * @return the libelleOperation
	 */
	public String getLibelleOperation() {
		return libelleOperation;
	}

	/**
	 * @return the montantOperation
	 */
	public String getMontantOperation() {
		return montantOperation;
	}

	/**
	 * @param dateDebit the dateDebit to set
	 */
	public void setDateDebit(String dateDebit) {
		this.dateDebit = dateDebit;
	}

	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(String dateVente) {
		this.dateVente = dateVente;
	}

	/**
	 * @param libelleOperation the libelleOperation to set
	 */
	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	/**
	 * @param montantOperation the montantOperation to set
	 */
	public void setMontantOperation(String montantOperation) {
		this.montantOperation = montantOperation;
	}
}
