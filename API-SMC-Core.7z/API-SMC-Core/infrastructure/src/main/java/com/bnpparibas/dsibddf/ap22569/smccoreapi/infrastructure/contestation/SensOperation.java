package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

public enum SensOperation {
    DEBIT, CREDIT
}
