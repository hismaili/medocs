package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;
/**
 *
 * @author c65344
 *
 */
public class Phrase {
	private Integer indexPhrase;

	private String textePhrase;

	/**
	 *
	 */
	public Phrase() {
		super();
	}

	/**
	 * @param indexPhrase
	 * @param textePhrase
	 */
	public Phrase(Integer indexPhrase, String textePhrase) {
		this.indexPhrase = indexPhrase;
		this.textePhrase = textePhrase;
	}

	/**
	 * @return the indexPhrase
	 */
	public Integer getIndexPhrase() {
		return indexPhrase;
	}

	/**
	 * @return the textePhrase
	 */
	public String getTextePhrase() {
		return textePhrase;
	}

	/**
	 * @param indexPhrase the indexPhrase to set
	 */
	public void setIndexPhrase(Integer indexPhrase) {
		this.indexPhrase = indexPhrase;
	}

	/**
	 * @param textePhrase the textePhrase to set
	 */
	public void setTextePhrase(String textePhrase) {
		this.textePhrase = textePhrase;
	}
}
