/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author c65344
 *
 */
public class NewDocDTO {


	@ApiModelProperty(value = "Code type du document", required = true)
	private String documentTypeId;
	@ApiModelProperty(value = "MIME Type", required = true)
	private String mimeType;
	@ApiModelProperty(value = "Le Titre", required = true)
	private String titre;
	@ApiModelProperty(value = "Document à enregistrer", required = true)
	private  Document document;

	@ApiModelProperty(value = "Utilisateur appelant", required = true)
	private String callingUser;
	@ApiModelProperty(value = "Id de la contestation")
	private String idContestationSmc;


	/**
	 *
	 */
	public NewDocDTO() {
		super();

	}


	/**
	 * @param documentTypeId
	 * @param mimeType
	 * @param titre
	 * @param document
	 */
	public NewDocDTO(String documentTypeId, String mimeType, String titre,
			Document document) {
		this.documentTypeId = documentTypeId;
		this.mimeType = mimeType;
		this.titre = titre;
		this.document = document;
	}


	/**
	 * @param documentTypeId
	 * @param mimeType
	 * @param titre
	 * @param document
	 * @param callingUser
	 */
	public NewDocDTO(String documentTypeId, String mimeType, String titre,
			Document document, String callingUser) {
		this.documentTypeId = documentTypeId;
		this.mimeType = mimeType;
		this.titre = titre;
		this.document = document;
		this.callingUser = callingUser;
	}


	public String getCallingUser() {
		return callingUser;
	}


	/**
	 * @return the document
	 */
	public Document getDocument() {
		return document;
	}


	/**
	 * @return the documentTypeId
	 */
	public String getDocumentTypeId() {
		return documentTypeId;
	}


	/**
	 * @return the idContestationSmc
	 */
	public String getIdContestationSmc() {
		return idContestationSmc;
	}


	/**
	 * @return the mimeType
	 */
	public String getMimeType() {
		return mimeType;
	}


	/**
	 * @return the titre
	 */
	public String getTitre() {
		return titre;
	}


	public void setCallingUser(String callingUser) {
		this.callingUser = callingUser;
	}


	/**
	 * @param document the document to set
	 */
	public void setDocument(Document document) {
		this.document = document;
	}


	/**
	 * @param documentTypeId the documentTypeId to set
	 */
	public void setDocumentTypeId(String documentTypeId) {
		this.documentTypeId = documentTypeId;
	}


	/**
	 * @param idContestationSmc the idContestationSmc to set
	 */
	public void setIdContestationSmc(String idContestationSmc) {
		this.idContestationSmc = idContestationSmc;
	}

	/**
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	/**
	 * @param titre the titre to set
	 */
	public void setTitre(String titre) {
		this.titre = titre;
	}
}
