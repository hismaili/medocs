package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte.ICardServicesManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.personne.IInfoPersonneManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.refo.IRefoManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.RefoException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence.ResponseRefo;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.InfoCarte;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;



/**
 *
 * @author c65344
 *
 */
@Component
public class EditionManagementImpl implements IEditionManagement {
	private static final Logger LOG = LoggerFactory.getLogger(EditionManagementImpl.class);
	private static final  String  PERSONNEPHYSIQUE = "01"; //$NON-NLS-1$
	private static final  String  PERSONNEMORALE = "02"; //$NON-NLS-1$
	private static final String EMPTY=" "; //$NON-NLS-1$
	private static final String MONSIEUR = "M";
	private static final String MADAMME  = "MME";
	private static final String CONTRATPARTICULIER = "1";
	private static final String CONTRATENTREPRISE  = "2";

	private static final String CONTRATPROFESSIONNEL = "3";

	private static final String FICHEDELIAISON = "trby9lia";
	private static final String FORMRETRAIT = "trby9ret";
	private static final String FORMPAYEMENT = "trby9pai";
	private static final String CLOTURE = "trby9clo";
	private static final String GENERIQUE = "trby9gen";
	private static final String CONTESTATAION = "trby9con";

	@Autowired
	private transient IEditionDocument iEditiondocument;

	@Autowired(required=false)
	private transient IInfoPersonneManagement infoPersonnews;
	@Autowired(required=false)
	private transient ICardServicesManagement cardServicesManagement;
	@Autowired(required=false)
	private transient IRefoManagement refoManagement;


	/**
	 * Ajoute les informations de RP de BCMP et de REFO à notre requette
	 *
	 * @param request
	 * @return
	 * @throws EditingException
	 */
	private RequestEditiqueInput completInformation(RequestEditiqueInput request) throws EditingException{
		Destinataire destinataire = new Destinataire();
		Emeteur emeteur = new Emeteur();

		if(request !=null){
			/**
			 * Information Emeteur
			 */
			InfoCarte infoCarte = null;
			try {
				infoCarte = cardServicesManagement.getInfoCarte(request.getNumeroCarte());

				if(infoCarte !=null){

					String ikpi = infoCarte.getIdUniqueClientInput();

					emeteur.setCodeUoAgence(infoCarte.getCodeAgenceRattachementInput());
					emeteur.setCodeUoSur(infoCarte.getCodeAgenceRattachementInput());

					String codeTypeDecontratBcmP = infoCarte.getCodeTypContratInput();

					if(!StringUtils.isEmpty(codeTypeDecontratBcmP)){

						if("00".equals(codeTypeDecontratBcmP)){
							request.setTopClientele(CONTRATPARTICULIER);
						}else if("01".equals(codeTypeDecontratBcmP) || "02".equals(codeTypeDecontratBcmP)){
							request.setTopClientele(CONTRATENTREPRISE);
						}else if("03".equals(codeTypeDecontratBcmP)){
							request.setTopClientele(CONTRATPROFESSIONNEL);
						}
					}
					request.setIkpi(ikpi);
					request.setIdContratMonetiquePorteur(infoCarte.getIdContratMonetiquePorteurInput());
					request.setRibOperation(infoCarte.getRibOperationInput());
					request.setRibCotisation(infoCarte.getRibCotisationInput());

					InfoPersonneOutput infoEmeteur = infoPersonnews.getInfopersonne(ikpi);

					if(infoEmeteur !=null){

						request.setPrenomPorteur(infoEmeteur.getClientFirstname());
						request.setNomPorteur(infoEmeteur.getClientName());
						request.setBirthDay(infoEmeteur.getBirthDay());
						request.setClientNatureId(infoEmeteur.getClientNatureId());
						request.setSirenNumber(infoEmeteur.getSirenNumber());
						request.setCodePays(infoEmeteur.getCodePays());
						request.setCodePostal(infoEmeteur.getCodePostal());
						destinataire.setCivilite(infoEmeteur.getCivilite());

						String civilite = null;

						if("1".equals(infoEmeteur.getCivilite())){
							civilite = MONSIEUR;
						}else if("2".equals(infoEmeteur.getCivilite()) || "3".equals(infoEmeteur.getCivilite())){
							civilite = MADAMME;
						}


						/**
						 * 1ère Ligne d’adresse « destinataire » RP Voir RG dans 3.4.1
						 * Si la personne est une personne physique alors on prend le client name
						 *
						 */
						String adresse1 = civilite+EMPTY+infoEmeteur.getClientName() +EMPTY+infoEmeteur.getClientFirstname();
						if(adresse1.length() > 38){
							adresse1 = adresse1.substring(0,38);
						}

						String adresse12 = infoEmeteur.getAdresse1();
						if(!StringUtils.isEmpty(adresse12) && adresse12.length() > 38 ){
							adresse12 = adresse12.substring(0,38);
						}

						String adresse2 = infoEmeteur.getAdresse2();
						if(!StringUtils.isEmpty(adresse2) && adresse2.length() > 38 ){
							adresse2 = adresse2.substring(0,38);
						}


						String adresse3 = infoEmeteur.getAdresse3();
						if(!StringUtils.isEmpty(adresse3) && adresse3.length() > 38 ){
							adresse3 = adresse3.substring(0,38);
						}

						if(PERSONNEPHYSIQUE.equals(infoEmeteur.getClientNatureId())){

							destinataire.setAdresse1(adresse1);
							destinataire.setAdresse2(adresse12);
							destinataire.setAdresse3(adresse2);

							destinataire.setAdresse4(adresse3);

						}else if(PERSONNEMORALE.equals(infoEmeteur.getClientNatureId())){
							destinataire.setAdresse1(infoEmeteur.getRaisonSociale());
							destinataire.setAdresse2(adresse1);
							destinataire.setAdresse3(adresse12);
							destinataire.setAdresse4(adresse2);
						}
						/**
						 * Dernière Ligne d’adresse « destinataire » obligatoire Voir RG dans 3.4.1
						 */
						destinataire.setAdresse6(infoEmeteur.getCodePostal()+EMPTY+infoEmeteur.getCommunePersonne());
					}
					ResponseRefo responseRefo = refoManagement.getTypeBank(infoCarte.getCodeAgenceRattachementInput());


					if(responseRefo !=null){
						emeteur.setHelloBank(responseRefo.isHelloBank());
						emeteur.setMonaco(responseRefo.isMonaco());
					}

				}

				Emeteur emeteur2 = request.getEmeteur();
				if (emeteur2 != null) {
					emeteur.setAdresse(emeteur2.getAdresse());
					emeteur.setTelephone(emeteur2.getTelephone());
				}

				request.setEmeteur(emeteur);
				request.setDestinataire(destinataire);



			} catch (RefoException e) {
				LOG.error(e.getMessage(),e);
				throw new EditingException(e.getMessage());
			} catch (PorteurException e) {
				LOG.error(e.getMessage(),e);
				throw new EditingException(e.getMessage());
			} catch (CardException e) {
				LOG.error(e.getMessage(),e);
				throw new EditingException(e.getMessage());
			}

		}

		return request;

	}


	@Override
	public RequestEditiqueOutput getDocumentPDF(RequestEditiqueInput request)
			throws EditingException, MandatoryException, FormatErrorException,
			DonneIncorectException {


		if(request!=null){

			if( CONTESTATAION.equals(request.getMaquetteId())){

				return iEditiondocument.creerContestationCartePDF(completInformation(request));
			}

			if( FORMPAYEMENT.equals(request.getMaquetteId())){
				return iEditiondocument.creerFormPayPDF(completInformation(request));
			}

			if( CLOTURE.equals(request.getMaquetteId())){
				return iEditiondocument.creerCloturePDF(completInformation(request));
			}

			if(GENERIQUE.equals(request.getMaquetteId())){

				return iEditiondocument.creerCourrierGenericPDF(completInformation(request));
			}

			if( FORMRETRAIT.equals(request.getMaquetteId())){
				return iEditiondocument.creerFormRetraitPDF(completInformation(request));
			}

			if( FICHEDELIAISON.equals(request.getMaquetteId())){
				return iEditiondocument.creerFicheDeLiaisonPDF(completInformation(request));
			}
		}

		return null;

	}


	@Override
	public EditionRecording getEditionRecording() {

		return iEditiondocument.getEditionRecording();
	}


	@Override
	public int getLastNumSeqEditiqueToSmc() {

		return iEditiondocument.getLastNumSeqEditiqueToSmc();
	}


	@Override
	public int getLastNumSequence() {
		return iEditiondocument.getLastNumSequence();
	}


	@Override
	public List<EditionRecording> getRecordingEditionTreated(boolean istreated) {

		return iEditiondocument.getRecordingEditionTreated(istreated);
	}


	@Override
	public String getXmlFileSmcFromEditique() {
		return iEditiondocument.getXmlFileSmcFromEditique();
	}


	@Override
	public void isTreated(int numSequence) {
		iEditiondocument.isTreated(numSequence);
	}


	@Override
	public void saveDocumentReturnCentral(DocumentRetour document) {
		iEditiondocument.saveDocumentReturnCentral(document);
	}


	@Override
	public void saveInfoFileReturnCentral(InfoFileArchivage infoFile) {
		iEditiondocument.saveInfoFileReturnCentral(infoFile);
	}




}
