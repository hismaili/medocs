package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;


import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import sun.misc.BASE64Decoder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;


@SpringBootTest(classes = SpringBootApp.class)
@RunWith(SpringRunner.class)
@ActiveProfiles({"local","test"})
@Ignore
public class EditionDocumentImplTest {
	private static final Logger LOG = LoggerFactory.getLogger(EditionDocumentImplTest.class);
	@Autowired
	private transient EditionDocumentImpl editionDocumentImpl;

	@Autowired
	private transient IEditionRepository editionCentral;

	Emeteur emeteur = new Emeteur();

	Destinataire destinataire = new Destinataire();

	private void createDocument(String name,String document) throws IOException{
		System.out.println("Le document est :"+document);
		BASE64Decoder decoder = new BASE64Decoder();
		byte[] decodedBytes = decoder.decodeBuffer(document);

		File file = new File("src/test/resources/document/"+name+".pdf");
		FileOutputStream fop = new FileOutputStream(file);

		fop.write(decodedBytes);
		fop.flush();
		fop.close();
	}


	@Before
	public void getCommonsBefore(){

		emeteur.setAdresse("Service Contestations Cartes");

		emeteur.setCodeUoAgence("25");
		emeteur.setCodeUoSur("25");
		emeteur.setHelloBank(true);
		emeteur.setMonaco(true);
		emeteur.setTelephone("01 45 32 88 20");

		destinataire.setAdresse1("Monsieur Pierre Martin");
		destinataire.setAdresse2("33, avenue Charles de Gaulle");
		destinataire.setAdresse3("bat. A");
		destinataire.setAdresse6("94170 LE PERREUX SUR MARNE");
		destinataire.setCivilite("1");

	}




	@Test
	public void testCloture() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException{

		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setDateTraitement("11/07/2019");
		request.setNatureDossierLibelle("COURRIER DU JOUR");
		request.setNumDossier("E201812147522369");
		request.setNumeroCarte("0100000267630000000");
		request.setDateCreationSmc("11/07/2019");
		request.setMontantConteste("185");
		request.setNombreOperations(12);



		request.setEditiqueCentral(true);
		RequestEditiqueOutput reponse = editionDocumentImpl.creerCloturePDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() ==null);

		List<EditionEntity> listRequest = editionCentral.findAll();

		assertTrue(!CollectionUtils.isEmpty(listRequest));


	}


	@Test
	public void testGenerateContestationCard() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException {
		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setTelephoneEmet("01 45 32 88 20");
		request.setDateTraitement("11/07/2019");

		request.setTopClientele("1");
		request.setQualificationDossier("2");
		request.setNomPorteur("JOHN");
		request.setPrenomPorteur("MARC");
		request.setNumCarteMasque("4970 XXXX XXXX 5142");
		request.setDateOpposition("11/12/1995");
		request.setTotalOperations(4);
		request.setNatureDossier("123");
		request.setDateAppel("11/12/1995");
		request.setDelaisReponse(4);
		request.setNumDossier("E201812147522369");

		List<Operation> operations = Arrays.asList(new Operation("11/12/1992", "dddd", "15/12/1992", "15"),new Operation("11/12/1992", "dddd", "15/12/1992", "15"));

		request.setOperations(operations);
		emeteur.setMonaco(false);
		emeteur.setAdresse("Service Contestations Cartes,VALMY 2, 4 ème étages");
		request.setEmeteur(emeteur);
		request.setDestinataire(destinataire);
		request.setEditiqueCentral(false);



		RequestEditiqueOutput reponse = editionDocumentImpl.creerContestationCartePDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() !=null);
		assertTrue(!reponse.getPdfresult().isEmpty());


		//		request.setEditiqueCentral(true);
		//		reponse = editionDocumentImpl.creerContestationCartePDF(request);
		//		assertTrue(reponse !=null);
		//assertTrue(reponse.getPdfresult() ==null);

		//		List<EditionEntity> listRequest = editionCentral.findAll();
		//
		//		assertTrue(!CollectionUtils.isEmpty(listRequest));

		try {
			createDocument("contestation", reponse.getPdfresult());
		} catch (IOException e) {
			LOG.error(e.getMessage(),e);
		}
	}


	@Test
	public void testGenerateCourrierGenerique() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException {

		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setTelephoneEmet("01 45 32 88 20");
		request.setDateTraitement("11/07/2019");


		request.setTopClientele("1");
		request.setDateTraitement("11/12/1995");
		request.setNatureDossierLibelle("COURRIER DU JOUR");
		request.setNumDossier("E201812147522369");
		request.setNumCarteMasque("4970 XXXX XXXX 5142");

		List<Paragraphe> paragraphes = new ArrayList<Paragraphe>();



		List<Phrase> listPrases = new ArrayList<>();
		listPrases.add(new Phrase(1, "Nous avons procédé à l'analyse de votre dossier daté du 12.11.2018 concernant 20 opération[s] pour un montant total de 2 458,81 ."));
		listPrases.add(new Phrase(2, "- l'(es) opération(s) ci-dessous a (ont) fait l'objet d'un remboursement :"));
		listPrases.add(new Phrase(3, "Amazon du 10.10.2018 de 15,00  régularisée le 18.10.2018"));

		paragraphes.add(new Paragraphe(1, listPrases));

		request.setParagraphes(paragraphes);
		request.setPs(Arrays.asList("A repondre au plus vite"));


		request.setEmeteur(emeteur);
		request.setDestinataire(destinataire);
		request.setEditiqueCentral(false);



		RequestEditiqueOutput reponse = editionDocumentImpl.creerCourrierGenericPDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() !=null);
		assertTrue(!reponse.getPdfresult().isEmpty());




		request.setEditiqueCentral(true);
		reponse = editionDocumentImpl.creerCourrierGenericPDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() ==null);

		List<EditionEntity> listRequest = editionCentral.findAll();

		assertTrue(!CollectionUtils.isEmpty(listRequest));
	}


	@Test
	public void testGenerateFicheLiaison() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException{


		String idoc = "";

		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setTelephoneEmet("01 45 32 88 20");
		request.setDateTraitement("11/07/2019");



		request.setDateTraitement("11/12/1995");
		request.setContactEmet("ANTOINE");
		request.setIdUser("c65344");
		request.setNumDossier("E201812147522369");
		request.setNumClient("4970");


		request.setCommentaires(Arrays.asList("regularisation de votre compte"));

		request.setEmeteur(emeteur);
		request.setDestinataire(destinataire);
		request.setEditiqueCentral(false);

		RequestEditiqueOutput reponse = editionDocumentImpl.creerFicheDeLiaisonPDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() !=null);
		assertTrue(!reponse.getPdfresult().isEmpty());
	}


	@Test
	public void testGenerateFormPay() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException{

		String idoc = "";

		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setTelephoneEmet("01 45 32 88 20");
		request.setDateTraitement("11/07/2019");

		request.setCodeChefdefileemet("250");
		request.setContactEmet("51 RUE VALMY 4 ");
		request.setTelephoneEmet("07522584");
		request.setFaxEmet("07522584");
		request.setEmailEmet("gervaisolsen33@gmail.com");
		request.setCodeChefdefiledest("555");
		request.setContactDest("51 RUE VALMY 2");
		request.setTelephoneDest("07522589");
		request.setFaxDest("07522584");
		request.setEmailDest("gervaisolsenBnp@gmail.com");
		request.setTypeOperation("vole de carte");
		request.setDateTraitement("11/08/2019");
		request.setCodebanqueMempracc("5888");
		request.setCodebanqueDom("82525");
		request.setNumSiret("155888");
		request.setLocDepart("DEPART");
		request.setRaisonSociale("188888");
		request.setCodeApe("1818");
		request.setCodebanqueMemprtit("8888");
		request.setNumCarteMasque("4970 XXXX XXXX 5142");
		request.setCodeMotifipaye("aucune raison de vous payé");
		request.setMontantBrut("12000");
		request.setMontantCompense("14000");
		request.setDateheureTransaction("11/12/2019");
		request.setDateReglmntinitial("11/12/2019");
		request.setDateRglmntimpaye("11/12/2019");
		request.setReferenceArchivage("REFERENCE");
		request.setAutresDonnees("Aucune");
		request.setTypeReglmntsouhaite("10000");


		request.setCommentaires(Arrays.asList("regularisation de votre compte"));

		request.setEmeteur(emeteur);
		request.setDestinataire(destinataire);
		request.setEditiqueCentral(false);

		RequestEditiqueOutput reponse = editionDocumentImpl.creerFormPayPDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() !=null);
		assertTrue(!reponse.getPdfresult().isEmpty());



	}

	@Test
	public void testGenerateFormRetrait() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException{


		String idoc = "";

		RequestEditiqueInput request = new RequestEditiqueInput();
		request.setTelephoneEmet("01 45 32 88 20");
		request.setDateTraitement("11/07/2019");

		request.setCodeChefdefileemet("250");
		request.setContactEmet("51 RUE VALMY 4 ");
		request.setTelephoneEmet("07522584");
		request.setFaxEmet("07522584");
		request.setEmailEmet("gervaisolsen33@gmail.com");
		request.setCodeChefdefiledest("555");
		request.setContactDest("51 RUE VALMY 2");
		request.setTelephoneDest("07522589");
		request.setFaxDest("07522584");
		request.setEmailDest("gervaisolsenBnp@gmail.com");
		request.setTypeOperation("vole de carte");
		request.setDateTraitement("11/08/2019");
		request.setCodebanqueMempracc("5888");
		request.setCodebanqueDom("82525");
		request.setNumSiret("155888");
		request.setLocDepart("DEPART");

		request.setCodebanqueMemprtit("8888");
		request.setNumCarteMasque("4970 XXXX XXXX 5142");
		request.setCodeMotifipaye("aucune raison de vous payé");

		request.setMontantCompense("14000");
		request.setDateheureTransaction("11/12/2019:18");
		request.setDateReglmntinitial("11/12/2019");
		request.setDateRglmntimpaye("11/12/2019");

		request.setAutresDonnees("Aucune");
		request.setTypeReglmntsouhaite("10000");

		request.setNumDistributeur("12");

		request.setCommentaires(Arrays.asList("regularisation de votre compte"));

		request.setEmeteur(emeteur);
		request.setDestinataire(destinataire);
		request.setEditiqueCentral(false);

		RequestEditiqueOutput reponse = editionDocumentImpl.creerFormRetraitPDF(request);
		assertTrue(reponse !=null);
		assertTrue(reponse.getPdfresult() !=null);
		assertTrue(!reponse.getPdfresult().isEmpty());


	}


}
