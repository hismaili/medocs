package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;
/**
 *
 * @author c65344
 *
 */
public class ErrorsRP {
	private long codeError;
	private String messageError;
	/**
	 *
	 */
	public ErrorsRP() {
		super();

	}
	/**
	 * @param codeError
	 * @param messageError
	 */
	public ErrorsRP(long codeError, String messageError) {
		this.codeError = codeError;
		this.messageError = messageError;
	}
	/**
	 * @return the codeError
	 */
	public long getCodeError() {
		return codeError;
	}
	/**
	 * @return the messageError
	 */
	public String getMessageError() {
		return messageError;
	}
	/**
	 * @param codeError the codeError to set
	 */
	public void setCodeError(long codeError) {
		this.codeError = codeError;
	}
	/**
	 * @param messageError the messageError to set
	 */
	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}

}
