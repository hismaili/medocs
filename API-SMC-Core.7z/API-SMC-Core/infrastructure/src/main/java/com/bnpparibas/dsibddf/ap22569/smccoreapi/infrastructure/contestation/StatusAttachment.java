/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

/**
 * @author c65344
 *
 */
public enum StatusAttachment {
	SEND,TOSEND,REJECTED
}
