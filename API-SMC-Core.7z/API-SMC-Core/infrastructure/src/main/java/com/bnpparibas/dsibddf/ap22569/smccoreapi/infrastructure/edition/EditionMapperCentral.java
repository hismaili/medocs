/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcTechnicalException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class EditionMapperCentral {

	@Autowired
	private transient ConfigInfrastructure conf;


	/**
	 *mapping avec la base de donnée
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 *
	 */
	protected EditionEntity map(RequestEditiqueInput request) throws MandatoryException, FormatErrorException{

		EditionEntity edition = new EditionEntity();

		if(request !=null){

			Destinataire destinataireInput = request.getDestinataire();
			DestinataireEntity destinataire = new DestinataireEntity();

			if(destinataireInput !=null){

				BeanUtils.copyProperties(destinataireInput, destinataire);
			}

			Emeteur emeteurInput = request.getEmeteur();
			EmeteurEntity emeteur = new EmeteurEntity();
			if(emeteurInput !=null){

				BeanUtils.copyProperties(emeteurInput, emeteur);

				if(emeteurInput.isHelloBank()){
					emeteur.setAdresse1(conf.getHelloBanque());
				}else{
					emeteur.setAdresse1(conf.getBnpParisBas());
				}

				if(emeteurInput.isMonaco()){
					emeteur.setAdresse2(conf.getAdresseMonaco2());
					emeteur.setAdresse3(conf.getAdresseMonaco3());
					emeteur.setAdresse5(conf.getAdresseMonaco5());
				}else{
					String adresse = emeteurInput.getAdresse();

					List<String> adresses =	Arrays.asList(adresse.split("\\|")); //$NON-NLS-1$

					int size =  adresses.size()-1;

					if(size >= 0){

						emeteur.setAdresse5(adresses.get(size));

						if((size-1) >=0){
							emeteur.setAdresse4(adresses.get(size-1));

							if((size-2) >=0){
								emeteur.setAdresse3(adresses.get(size-2));

								if((size-3) >=0){
									emeteur.setAdresse2(adresses.get(size-3));
								}

							}
						}
					}
				}

			}

			BeanUtils.copyProperties(request, edition);
			edition.setEmeteur(emeteur);
			edition.setDestinataire(destinataire);
			edition.setStatus(Status.NONTRAITE);
			List<String> ps = request.getPs();

			if(!CollectionUtils.isEmpty(ps)){

				Set<String> postScriptum = new HashSet<String>();

				ps.stream().forEach(p -> {
					postScriptum.add(p);
				});

				edition.setPostScriptum(postScriptum);
			}

			List<String> commentaires = request.getCommentaires();
			if(!CollectionUtils.isEmpty(commentaires)){
				edition.setCommentaires(commentaires);
			}


			final List<Paragraphe> paragraphes = request.getParagraphes();

			if(!CollectionUtils.isEmpty(paragraphes)){

				Set<ParagrapheEntity> paragrapheEntities = new HashSet<ParagrapheEntity>();
				paragraphes.stream().forEach(paragrahpe ->{

					ParagrapheEntity paragrapheEntity = new ParagrapheEntity();
					paragrapheEntity.setIndexParagraphe(paragrahpe.getIndexparagraphe());
					List<Phrase> listephraseInput = paragrahpe.getPhrase();

					if(listephraseInput !=null){
						Set<PhraseEntity> phraseEntities = new HashSet<PhraseEntity>();
						listephraseInput.stream().forEach(phraseInput -> {
							PhraseEntity phrase = new PhraseEntity();
							phrase.setIndexPhrase(phraseInput.getIndexPhrase());
							phrase.setTextePhrase(phraseInput.getTextePhrase());
							phraseEntities.add(phrase);

						});

						paragrapheEntity.setPhrases(phraseEntities);
						paragrapheEntities.add(paragrapheEntity);
					}

				});

				edition.setParagraphes(paragrapheEntities);
			}




			List<Operation> opeartions = request.getOperations();

			if(!CollectionUtils.isEmpty(opeartions)){
				edition.setOperations(
						opeartions.stream().map(operation -> {
							OperationEditionEntity contest = new OperationEditionEntity();
							BeanUtils.copyProperties(operation, contest);
							return contest;
						}).collect(Collectors.toList()));
			}

			Map<String,String> sneMaquettes = request.getSneMaquette();

			if(!CollectionUtils.isEmpty(sneMaquettes)){
				edition.setSneMaquette(sneMaquettes);
			}
		}

		return  edition;

	}

	protected EditionRecording mapToEditionRecording(EditionEntity editionEntity){

		EditionRecording editionRecording = null;

		if(editionEntity !=null){

			editionRecording = new EditionRecording();
			DetailCourrier detailCourrier = new DetailCourrier();
			BeanUtils.copyProperties(editionEntity, detailCourrier);

			EmeteurEntity emeteurEntity = editionEntity.getEmeteur();

			if(emeteurEntity !=null){
				Emeteur emeteur = new Emeteur();
				BeanUtils.copyProperties(emeteurEntity, emeteur);
				detailCourrier.setEmeteur(emeteur);
			}
			detailCourrier.setSneMaquette(editionEntity.getSneMaquette());
			DestinataireEntity destinataireEntity = editionEntity.getDestinataire();

			if(destinataireEntity !=null){
				Destinataire destinataire = new Destinataire();
				BeanUtils.copyProperties(destinataireEntity, destinataire);

				detailCourrier.setDestinataire(destinataire);
			}

			editionRecording.setDetailCourrier(detailCourrier);

			Set<String> postScriptums = editionEntity.getPostScriptum();

			if(!CollectionUtils.isEmpty(postScriptums)){
				List<String> post = new ArrayList<String>();

				postScriptums.stream().forEach(ps -> {

					post.add(ps);
				});

				editionRecording.setPs(post);
			}

			List<OperationEditionEntity> operations = editionEntity.getOperations();

			if(!CollectionUtils.isEmpty(operations)){

				editionRecording.setOperations(operations.stream().map(oper -> {
					Operation operation = new Operation();
					BeanUtils.copyProperties(oper, operation);
					return operation;
				}).collect(Collectors.toList()));

			}

			Set<ParagrapheEntity> paragrapheEntities = editionEntity.getParagraphes();

			if(!CollectionUtils.isEmpty(paragrapheEntities)){

				editionRecording.setParagraphes(paragrapheEntities
						.stream()
						.map(entity -> {
							Paragraphe paragraphe = new Paragraphe();
							paragraphe.setIndexparagraphe(entity.getIndexParagraphe());

							Set<PhraseEntity> phraseEnties = entity.getPhrases();

							if(!CollectionUtils.isEmpty(phraseEnties)){

								paragraphe.setPhrase(phraseEnties
										.stream()
										.map(phraseEntity -> {
											return new Phrase(phraseEntity.getIndexPhrase(), phraseEntity.getTextePhrase());
										}).collect(Collectors.toList()));
							}
							return paragraphe;
						}).collect(Collectors.toList()));
			}
		}

		return editionRecording;
	}


}
