package com.bnpparibas.dsibddf.ap22569.notification.batch.config;

import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.SendMailException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.details.NotificationDetailValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions.file.FileValidationException;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.helpers.SendMailHelper;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.annotation.AfterJob;
import org.springframework.batch.core.annotation.BeforeJob;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Component
public class NotificationJobListener implements JobExecutionListener {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationJobListener.class);

    @Autowired
    private INotificationManagement notificationManagement;

    @Value("${file.input}")
    private FileSystemResource inputResource;

    @Autowired
    private SendMailHelper sendMailHelper;

    @Value("${file.treated}")
    private String treated;

    @Value("${file.rejected}")
    private String rejected;

    @BeforeJob
    public void beforeJob(JobExecution jobExecution) {
        LOG.info("executing the job "+jobExecution.getJobId());

    }

    @AfterJob
    public void afterJob(JobExecution jobExecution) {
        List<Throwable> failureExceptions = jobExecution.getFailureExceptions();
        //deal with failures
        ExitStatus exitStatus = getExitStatus(failureExceptions);

        //send error notification mail
        if(ExitCode.EXIT_CODE_NOTIF_REJECTS.equals(exitStatus.getExitCode())) {
            //Envoi de mail pour les rejets des notifs détails
            try {
                sendMailHelper.sendDetailRejectsMail(failureExceptions);
            } catch (SendMailException e) {
                LOG.error(e.getMessage(), e);
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_SEND_ALERT_MAIL_KO, "DETAILS_ALERT_MAIL_NOT_SENT");
            }
        }

        //manage File Status
        exitStatus = manageFileTreatmentStatus(jobExecution, exitStatus);

        jobExecution.setExitStatus(exitStatus);
        jobExecution.setStatus(ExitStatus.COMPLETED.equals(exitStatus) ? BatchStatus.COMPLETED : BatchStatus.FAILED);

    }

    private ExitStatus manageFileTreatmentStatus(JobExecution jobExecution, ExitStatus exitStatus) {
        Object infoFileObj = jobExecution.getExecutionContext().get(BatchConfiguration.FILE_INFO);

        if(ExitStatus.COMPLETED.equals(exitStatus)) {
            try {
                this.notificationManagement.flagNotificationFileTreatmentAsSucceeded((NotificationInfoFile) infoFileObj);
                moveFileTo(treated);
            } catch (NotificationException e) {
                LOG.error(e.getMessage(), e);
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_DB_UPDATE_FILE_OK, "UPDATE_OK_FLAG_ERROR");
            } catch (IOException e) {
                LOG.error(e.getMessage(), e);
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_ERR_MOVE_FILE_OK, "UPDATE_OK_FLAG_ERROR");
            }
        } else {
            try {
                this.notificationManagement.flagNotificationFileTreatmentAsFailed((NotificationInfoFile) infoFileObj);
                moveFileTo(rejected);
            } catch (NotificationException e) {
                LOG.error(e.getMessage(), e);
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_DB_UPDATE_FILE_KO, "ERROR_MOVE_TREATED_FILE");
            } catch (IOException e) {
                LOG.error(e.getMessage(), e);
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_ERR_MOVE_FILE_KO, "ERROR_MOVE_REJECTED_FILE");
            }
        }
        return exitStatus;
    }

    private void moveFileTo(String destDir) throws IOException {
        File in = inputResource.getFile();
        File out = new File(destDir +inputResource.getFilename());
        FileCopyUtils.copy(in, out);
    }

    private ExitStatus getExitStatus(List<Throwable> failureExceptions) {
        ExitStatus exitStatus = ExitStatus.COMPLETED;
        if(!CollectionUtils.isEmpty(failureExceptions)) {
            long detailRejectsCount = failureExceptions.stream().filter(ex -> ex instanceof NotificationDetailValidationException).count();
            if(detailRejectsCount == failureExceptions.size()) {
                exitStatus = new ExitStatus(ExitCode.EXIT_CODE_NOTIF_REJECTS, "COMPLETED_WITH_NOTIF_REJECTS");
            } else {
                long fileRejectsCount = failureExceptions.stream().filter(ex -> ex instanceof FileValidationException).count();
                if(fileRejectsCount > 0l) {
                    //there are at least one file validation error
                    exitStatus = new ExitStatus(ExitCode.EXIT_CODE_FILE_REJECT, "NOTIF_FILE_REJECTED");
                } else {
                    //there are at least one unexpected exception
                    exitStatus = new ExitStatus(ExitCode.EXIT_CODE_UNEXPECTED_ERROR, "UNEXPECTED_ERROR");
                }
            }
        }
        return exitStatus;
    }

}
