/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * @author c65344
 *
 */
public interface NotificationFileJpaRepository extends JpaRepository<NotificationFileEntity, String> {

    @Query("From NotificationFileEntity f Where f.dateFluxHeader = ?1 And f.numSeqHeader= (Select MAX(numSeqHeader) From NotificationFileEntity)")
    NotificationFileEntity getLastTreatedFileForDate(String dateFlux);

    NotificationFileEntity findByDateFluxHeaderAndNumSeqHeader(String dateFlux, String currentSequenceNumber);
}
