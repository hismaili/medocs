package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;
/**
 *
 * @author c65344
 *
 */
public class DetailsOperation {
	private String dateCompensation;
	private String raisonSociale;
	private String dateVente;
	private  float montantImpute;
	/**
	 *
	 */
	public DetailsOperation() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param dateCompensation
	 * @param raisonSociale
	 * @param dateVente
	 * @param montantImpute
	 */
	public DetailsOperation(String dateCompensation, String raisonSociale,
			String dateVente, float montantImpute) {
		this.dateCompensation = dateCompensation;
		this.raisonSociale = raisonSociale;
		this.dateVente = dateVente;
		this.montantImpute = montantImpute;
	}
	/**
	 * @return the dateCompensation
	 */
	public String getDateCompensation() {
		return dateCompensation;
	}
	/**
	 * @return the dateVente
	 */
	public String getDateVente() {
		return dateVente;
	}
	/**
	 * @return the montantImpute
	 */
	public float getMontantImpute() {
		return montantImpute;
	}
	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}
	/**
	 * @param dateCompensation the dateCompensation to set
	 */
	public void setDateCompensation(String dateCompensation) {
		this.dateCompensation = dateCompensation;
	}
	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(String dateVente) {
		this.dateVente = dateVente;
	}
	/**
	 * @param montantImpute the montantImpute to set
	 */
	public void setMontantImpute(float montantImpute) {
		this.montantImpute = montantImpute;
	}
	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}
}
