package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.INotificationService;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class NotificationManagementImpl implements INotificationManagement {
	@Autowired
	private transient INotificationService notificationService;

	@Override
	public void saveNotification(Notification notification)
			throws NotificationException {
		notificationService.saveNotification(notification);
	}

	@Override
	public void saveNotificationFileHeader(NotificationInfoFile infoFileHeader) throws NotificationException {
		notificationService.saveNotificationFileHeader(infoFileHeader);
	}

	@Override
	public void saveNotificationFileFooter(NotificationInfoFile infoFileFooter) throws NotificationException {
		notificationService.saveNotificationFileFooter(infoFileFooter);
	}

	@Override
	public NotificationInfoFile getLastTreatedFile(String dateflux) throws NotificationException {
		return notificationService.getLastTreatedFile(dateflux);
	}

	@Override
	public NotificationInfoFile getFileBySequenceNumber(String dateflux, String currentSequenceNumber) throws NotificationException {
		return notificationService.getFileBySequenceNumber(dateflux, currentSequenceNumber);
	}

	@Override
	public List<Notification> getPendingNotifications() throws NotificationException {
		return this.notificationService.getPendingNotifications();
	}

	@Override
	public void flagEventAsSucceeded(String notificationId) throws NotificationException {
		this.notificationService.flagEventAsSucceeded(notificationId);
	}

	@Override
	public void flagNotificationFileTreatmentAsSucceeded(NotificationInfoFile infoFile) throws NotificationException {
		this.notificationService.flagNotificationFileTreatmentAsSucceeded(infoFile);
	}

	@Override
	public void flagNotificationFileTreatmentAsFailed(NotificationInfoFile infoFile) throws NotificationException {
		this.notificationService.flagNotificationFileTreatmentAsFailed(infoFile);
	}
}
