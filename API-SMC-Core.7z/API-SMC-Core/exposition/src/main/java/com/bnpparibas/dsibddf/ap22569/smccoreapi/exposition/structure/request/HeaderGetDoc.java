package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
/**
 *
 * @author c65344
 *
 */
@Valid
public class HeaderGetDoc {
	@ApiModelProperty( value = "Type utilisateur collab ou client", required = true)
	private String userType;
	@Valid
	@ApiModelProperty( value = "Header du service GetDoc", required = true)
	private HeaderSmc headerSmc;

	/**
	 *
	 */
	public HeaderGetDoc() {
		super();
	}

	/**
	 * @param userType
	 * @param headerSmc
	 */
	public HeaderGetDoc(String userType, HeaderSmc headerSmc) {
		this.userType = userType;
		this.headerSmc = headerSmc;
	}

	/**
	 * @return the headerSmc
	 */
	public HeaderSmc getHeaderSmc() {
		return headerSmc;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @param headerSmc the headerSmc to set
	 */
	public void setHeaderSmc(HeaderSmc headerSmc) {
		this.headerSmc = headerSmc;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}
}
