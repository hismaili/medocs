/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

import java.time.LocalDate;

/**
 * @author c65344
 *
 */
public class CartePorteur {
	private String numCompte;
	private String numCarteInput;
	private LocalDate dateFinValiditeInput;
	private String statutCarteInput;
	private LocalDate datOppositionInput;
	private LocalDate dateColture;
	private String ikpi;
	private String typeProduit;
	private String codeMotifOpposition;
	private String libelleMotifOpposition;
	private String nomPorteur;


	/**
	 *
	 */
	public CartePorteur() {
		super();

	}
	/**
	 * @param numCarteInput
	 * @param dateFinValiditeInput
	 * @param statutCarteInput
	 * @param datOppositionInput
	 */
	public CartePorteur(String numCarteInput,
			LocalDate dateFinValiditeInput, String statutCarteInput,
			LocalDate datOppositionInput) {
		this.numCarteInput = numCarteInput;
		this.dateFinValiditeInput = dateFinValiditeInput;
		this.statutCarteInput = statutCarteInput;
		this.datOppositionInput = datOppositionInput;
	}
	public String getCodeMotifOpposition() {
		return codeMotifOpposition;
	}
	public LocalDate getDateColture() {
		return dateColture;
	}
	/**
	 * @return the dateFinValiditeInput
	 */
	public LocalDate getDateFinValiditeInput() {
		return dateFinValiditeInput;
	}
	/**
	 * @return the datOppositionInput
	 */
	public LocalDate getDatOppositionInput() {
		return datOppositionInput;
	}
	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}
	public String getLibelleMotifOpposition() {
		return libelleMotifOpposition;
	}
	/**
	 * @return the numCarteInput
	 */
	public String getNumCarteInput() {
		return numCarteInput;
	}
	public String getNumCompte() {
		return numCompte;
	}

	/**
	 * @return the statutCarteInput
	 */
	public String getStatutCarteInput() {
		return statutCarteInput;
	}

	public String getTypeProduit() {
		return typeProduit;
	}

	public void setCodeMotifOpposition(String codeMotifOpposition) {
		this.codeMotifOpposition = codeMotifOpposition;
	}

	public void setDateColture(LocalDate dateColture) {
		this.dateColture = dateColture;
	}



	/**
	 * @param dateFinValiditeInput the dateFinValiditeInput to set
	 */
	public void setDateFinValiditeInput(LocalDate dateFinValiditeInput) {
		this.dateFinValiditeInput = dateFinValiditeInput;
	}
	/**
	 * @param datOppositionInput the datOppositionInput to set
	 */
	public void setDatOppositionInput(LocalDate datOppositionInput) {
		this.datOppositionInput = datOppositionInput;
	}
	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}

	public void setLibelleMotifOpposition(String libelleMotifOpposition) {
		this.libelleMotifOpposition = libelleMotifOpposition;
	}

	/**
	 * @param numCarteInput the numCarteInput to set
	 */
	public void setNumCarteInput(String numCarteInput) {
		this.numCarteInput = numCarteInput;
	}

	public void setNumCompte(String numCompte) {
		this.numCompte = numCompte;
	}

	/**
	 * @param statutCarteInput the statutCarteInput to set
	 */
	public void setStatutCarteInput(String statutCarteInput) {
		this.statutCarteInput = statutCarteInput;
	}

	public void setTypeProduit(String typeProduit) {
		this.typeProduit = typeProduit;
	}

	public String getNomPorteur() {
		return nomPorteur;
	}

	public void setNomPorteur(String nomPorteur) {
		this.nomPorteur = nomPorteur;
	}
}
