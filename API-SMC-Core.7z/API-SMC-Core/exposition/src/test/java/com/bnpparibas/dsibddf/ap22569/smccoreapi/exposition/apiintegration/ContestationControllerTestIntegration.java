package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.apiintegration;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IContestationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.ContestationMonetiqueApplication;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ContestationDetailsResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.HistoriqueContestationsResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcResponseError;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.UUID;

import static org.junit.Assert.assertTrue;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = ContestationMonetiqueApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Profile("test-int")
public class  ContestationControllerTestIntegration{
	private static final Logger LOG = LoggerFactory.getLogger(ContestationControllerTestIntegration.class);
	private static byte[] toByteArray(UUID uuid) {
		byte[] byteArray = new byte[(Long.SIZE / Byte.SIZE) * 2];
		ByteBuffer buffer = ByteBuffer.wrap(byteArray);
		LongBuffer longBuffer = buffer.asLongBuffer();
		longBuffer.put(new long[] { uuid.getMostSignificantBits(),
				uuid.getLeastSignificantBits() });
		return byteArray;
	}
	@Autowired
	private transient IContestationRepository repositoy;

	@LocalServerPort
	private int port = 8080;


	@Autowired
	private TestRestTemplate restTemplate;


	@Test
	public void testRecupererContestationsErreurMetier(){

		HttpHeaders header = new HttpHeaders();


		header.set("Accept", "application/json");
		header.add("Content-Type", "application/json");
		header.set("telematicId","19");
		header.set("X-B3-TraceId","22569");
		header.set("X-B3-SpanId","22569");
		header.set("userId","22569");
		header.set("channel","_72");
		header.set("applicationCode","ap22569");
		header.set("offset","0");
		header.set("limit","10");

		HttpEntity<String> request = new HttpEntity<String>(header);
		String url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<ContestationDetailsResponse> responseContestationDetailsResponse;

		/**
		 * recherche de l'ensemble des contestation d'un utilisateur avec un mauvais telematicId
		 */

		url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<SmcResponseError> response = restTemplate.exchange(url, HttpMethod.GET, request,SmcResponseError.class);

		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		Assertions.assertThat(response.getBody().getErrors().get(0)).isNotNull();


		/**
		 * recherche de la contestation par un mauvais identifiant interne
		 *
		 */
		url = "http://localhost:" + port + "/v1/disputes?identifiantInterne=xxx";

		response = restTemplate.exchange(url, HttpMethod.GET, request,SmcResponseError.class);

		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		Assertions.assertThat(response.getBody().getErrors().get(0)).isNotNull();


		/**
		 * recherche de la contestation par un mauvais disputstaus(a l'état brouillon) sans identifiant interne
		 *
		 */
		url = "http://localhost:" + port + "/v1/disputes?disputeReference=010000026763000009&disputeStatus=SC001";

		response = restTemplate.exchange(url, HttpMethod.GET, request,SmcResponseError.class);

		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		Assertions.assertThat(response.getBody().getErrors().get(0)).isNotNull();
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors().get(0).getDetails().size()).isEqualTo(1);


	}





	@Test
	public void testRecupererContestationsSuccess() throws JsonProcessingException {

		HttpHeaders header = new HttpHeaders();


		header.set("Accept", "application/json");
		header.add("Content-Type", "application/json");
		header.set("telematicId","2289627126");
		header.set("X-B3-TraceId","4");
		header.set("X-B3-SpanId","4");
		header.set("userId","01630005685900000");
		header.set("channel","_72");
		header.set("applicationCode","ap22569");
		header.set("offset","0");
		header.set("limit","10");

		HttpEntity<String> request = new HttpEntity<String>(header);
		String url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<ContestationDetailsResponse> responseContestationDetailsResponse;


		/**
		 * recherche de la contestation par identifiant interne
		 *
		 */
		url = "http://localhost:" + port + "/v1/disputes?offset="+0+"&limit="+10+"&identifiantInterne=CT0013";

		responseContestationDetailsResponse = restTemplate.exchange(url, HttpMethod.GET, request, ContestationDetailsResponse.class);
		LOG.error("reponse : "+responseContestationDetailsResponse);

		Assertions.assertThat(responseContestationDetailsResponse).isNotNull();
		LOG.error("status : "+responseContestationDetailsResponse.getStatusCode());
		assertTrue(responseContestationDetailsResponse.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responseContestationDetailsResponse.getBody()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation().getDisputeInternalIdentifier()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation().getAttachedOperations()).isNotNull();

		/**
		 * recherche de l'ensemble des contestation d'un utilisateur
		 */

		url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<HistoriqueContestationsResponse> responseHistoryContestation = restTemplate.exchange(url, HttpMethod.GET, request, HistoriqueContestationsResponse.class);

		Assertions.assertThat(responseHistoryContestation).isNotNull();
		assertTrue(responseHistoryContestation.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responseHistoryContestation.getBody()).isNotNull();
		Assertions.assertThat(responseHistoryContestation.getBody().getContestations()).isNotNull();
		Assertions.assertThat(responseHistoryContestation.getBody().getContestations().get(0)).isNotNull();

		/**
		 * recherche de la contestation avec un codeStatus a l'etat non brouillon et non creer,
		 * Donc La recherche se fera toujours par numero de dossier
		 */
		url = "http://localhost:" + port + "/v1/disputes?disputeReference=NUMDOSSIER045&disputeStatus=SC003";

		responseContestationDetailsResponse = restTemplate.exchange(url, HttpMethod.GET, request, ContestationDetailsResponse.class);

		Assertions.assertThat(responseContestationDetailsResponse).isNotNull();
		assertTrue(responseContestationDetailsResponse.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responseContestationDetailsResponse.getBody()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation().getDisputeInternalIdentifier()).isNotNull();
		Assertions.assertThat(responseContestationDetailsResponse.getBody().getContestation().getAttachedOperations()).isNotNull();

	}

	/**
	 * datas absent
	 */
	@Test
	public void testRecuperrerContestationDataAbsente(){
		HttpHeaders header = new HttpHeaders();

		header.add("Content-Type", "application/json");
		header.set("Accept", "application/json");
		header.set("xB3TraceId","ap22569");
		header.set("xB3SpanId","ap22569");
		header.set("offset","0");
		header.set("limit","10");

		HttpEntity<String> request = new HttpEntity<String>(header);
		String url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<ContestationDetailsResponse> responseContestationDetailsResponse;

		url = "http://localhost:" + port + "/v1/disputes";
		ResponseEntity<SmcResponseError> response = restTemplate.exchange(url, HttpMethod.GET, request, SmcResponseError.class);

		Assertions.assertThat(response).isNotNull();
		assertTrue(response.getStatusCode().is4xxClientError());
		Assertions.assertThat(response.getBody()).isNotNull();
		Assertions.assertThat(response.getBody().getErrors()).isNotNull();
		assertTrue(response.getBody().getErrors().size() == 1);
		assertTrue(response.getBody().getErrors().get(0).getDetails().size() == 4);

	}

}
