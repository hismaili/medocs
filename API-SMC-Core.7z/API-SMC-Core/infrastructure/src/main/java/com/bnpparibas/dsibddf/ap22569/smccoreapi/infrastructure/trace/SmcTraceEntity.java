package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;

@Entity
@Table(name = "SMC_TRACE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class SmcTraceEntity extends AbstractEntity<DefaultEntityId> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column( length = 50 )
	private String idContestation;
	@NotNull
	@Column( length = 100 )
	private String service;
	@NotNull
	private LocalDateTime dateAppel;
	@Column( length = 100 )
	private String applicationAppelante;
	@Column( length = 3000 )
	private String paramIn;
	@Column( length = 3000 )
	private String paramOut;
	@Column( length = 20 )
	private String sens;
	private int statusCode;
	@Column( length = 100 )
	private String traceId;

	public String getApplicationAppelante() {
		return applicationAppelante;
	}

	public LocalDateTime getDateAppel() {

		return dateAppel;
	}

	public String getIdContestation() {
		return idContestation;
	}

	public String getParamIn() {
		return paramIn;
	}

	public String getParamOut() {
		return paramOut;
	}

	public String getSens() {
		return sens;
	}

	public String getService() {
		return service;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setApplicationAppelante(String applicationAppelante) {
		this.applicationAppelante = applicationAppelante;
	}

	public void setDateAppel(LocalDateTime dateAppel) {
		this.dateAppel = dateAppel;
	}

	public void setIdContestation(String idContestation) {
		this.idContestation = idContestation;
	}

	public void setParamIn(String paramIn) {
		this.paramIn = paramIn;
	}

	public void setParamOut(String paramOut) {
		this.paramOut = paramOut;
	}

	public void setSens(String sens) {
		this.sens = sens;
	}

	public void setService(String service) {
		this.service = service;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}

	@Override
	public String toString() {
		return "SmcTraceEntity{"+
				"idContestation='" + idContestation + '\'' +
				", service='" + service + '\'' +
				", dateAppel=" + dateAppel +
				", applicationAppelante='" + applicationAppelante + '\'' +
				", paramIn='" + paramIn + '\'' +
				", paramOut='" + paramOut + '\'' +
				", sens='" + sens + '\'' +
				'}';
	}
}
