package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

/**
 *
 * @author c65344
 *
 */
public class ArchivingContext {
	@ApiModelProperty( value = "Identifiant de l’unité de conservation", required = true)
	private String conservUnitId;
	@ApiModelProperty( value = "Libellé de l’unité de conservation", required = true)
	private String  conservUnitLabel;
	@ApiModelProperty( value = "Date de référence de l’archivage", required = true)
	private String  archivingReferenceDate;
	/**
	 *
	 */
	public ArchivingContext() {
		super();

	}
	/**
	 * @param conservUnitId
	 * @param conservUnitLabel
	 * @param archivingReferenceDate
	 */
	public ArchivingContext(String conservUnitId, String conservUnitLabel,
			String archivingReferenceDate) {
		this.conservUnitId = conservUnitId;
		this.conservUnitLabel = conservUnitLabel;
		this.archivingReferenceDate = archivingReferenceDate;
	}
	/**
	 * @return the archivingReferenceDate
	 */
	public String getArchivingReferenceDate() {
		return archivingReferenceDate;
	}
	/**
	 * @return the conservUnitId
	 */
	public String getConservUnitId() {
		return conservUnitId;
	}
	/**
	 * @return the conservUnitLabel
	 */
	public String getConservUnitLabel() {
		return conservUnitLabel;
	}
	/**
	 * @param archivingReferenceDate the archivingReferenceDate to set
	 */
	public void setArchivingReferenceDate(String archivingReferenceDate) {
		this.archivingReferenceDate = archivingReferenceDate;
	}
	/**
	 * @param conservUnitId the conservUnitId to set
	 */
	public void setConservUnitId(String conservUnitId) {
		this.conservUnitId = conservUnitId;
	}
	/**
	 * @param conservUnitLabel the conservUnitLabel to set
	 */
	public void setConservUnitLabel(String conservUnitLabel) {
		this.conservUnitLabel = conservUnitLabel;
	}

}
