package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import org.springframework.stereotype.Component;
/**
 *
 * Interface des methodes d'archivage application
 *
 */
@Component
public interface IArchivageManagement {
	/**
	 * ferme un dossier en le securisant
	 * @param closeFolderInput
	 * @return
	 * @throws ArchivingException
	 */
	String closeFolder(CloseFolderInput closeFolderInput) throws ArchivingException, MandatoryException, FormatErrorException, DonneIncorectException;

	/**
	 * supprime un document dans la Gdn
	 * @param deleteDocInput
	 * @return
	 * @throws ArchivingException
	 */
	String deleteDoc(DeleteDocInput deleteDocInput) throws ArchivingException,MandatoryException ;

	/**
	 * recupère un document dans la GDN
	 * @param getDocInput
	 * @return
	 * @throws ArchivingException
	 */
	DocOutput getDoc(DocInput docInput) throws ArchivingException,MandatoryException;

	/**
	 * Enregistre un document dans la GDN
	 * @param newDocInput
	 * @return
	 * @throws ArchivingException
	 */
	String newDoc(NewDocInput newDocInput)  throws ArchivingException, MandatoryException, FormatErrorException;

	/**
	 * Cree un nouveau Id Dossier dans la GDN
	 * @param newFolderInput
	 * @return
	 * @throws ArchivingException
	 */
	String newFolder(NewFolderInput newFolderInput) throws ArchivingException, MandatoryException;

	String purgeFolder(PurgeFolderInput purgeFolderInput) throws ContestationException;
}
