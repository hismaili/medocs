package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.InfoPersonneOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne.PorteurException;
import org.springframework.stereotype.Component;

import java.net.URISyntaxException;


/**
 *
 * @author c65344
 *
 */
@Component
public interface IInfoPersonneManagement {

	/**
	 * recupère les informations personne
	 * @param ikpi
	 * @return
	 * @throws URISyntaxException
	 */
	InfoPersonneOutput getInfopersonne(String ikpi)  throws PorteurException;
}
