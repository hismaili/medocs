/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 * @author c65344
 *
 */
public class Operation {
	private String dateCompensation;
	private String raisonSociale;
	private String dateVente;
	private String montantImpute;
	/**
	 *
	 */
	public Operation() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param dateCompensation
	 * @param raisonSociale
	 * @param dateVente
	 * @param montantImpute
	 */
	public Operation(String dateCompensation, String raisonSociale,
			String dateVente, String montantImpute) {
		this.dateCompensation = dateCompensation;
		this.raisonSociale = raisonSociale;
		this.dateVente = dateVente;
		this.montantImpute = montantImpute;
	}
	/**
	 * @return the dateCompensation
	 */
	public String getDateCompensation() {
		return dateCompensation;
	}
	/**
	 * @return the dateVente
	 */
	public String getDateVente() {
		return dateVente;
	}
	/**
	 * @return the montantImpute
	 */
	public String getMontantImpute() {
		return montantImpute;
	}
	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}
	/**
	 * @param dateCompensation the dateCompensation to set
	 */
	public void setDateCompensation(String dateCompensation) {
		this.dateCompensation = dateCompensation;
	}
	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(String dateVente) {
		this.dateVente = dateVente;
	}
	/**
	 * @param montantImpute the montantImpute to set
	 */
	public void setMontantImpute(String montantImpute) {
		this.montantImpute = montantImpute;
	}
	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}
}
