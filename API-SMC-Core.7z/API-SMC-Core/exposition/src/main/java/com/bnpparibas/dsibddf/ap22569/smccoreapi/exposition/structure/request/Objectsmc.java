/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author c65344
 *
 */
public class Objectsmc {
	@ApiModelProperty( value = "Compression du document", required = true)
	private String compress;
	@ApiModelProperty( value = "Encodage du document", required = true)
	private String encoding;
	@ApiModelProperty( value = "Données en byte du document", required = true)
	private String data;
	/**
	 *
	 */
	public Objectsmc() {
		super();

	}
	/**
	 * @param compress
	 * @param encoding
	 * @param data
	 */
	public Objectsmc(String compress, String encoding, String data) {
		this.compress = compress;
		this.encoding = encoding;
		this.data = data;
	}
	/**
	 * @return the compress
	 */
	public String getCompress() {
		return compress;
	}
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @return the encoding
	 */
	public String getEncoding() {
		return encoding;
	}
	/**
	 * @param compress the compress to set
	 */
	public void setCompress(String compress) {
		this.compress = compress;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @param encoding the encoding to set
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

}
