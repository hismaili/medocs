package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.apiintegration;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.EditingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.ContestationMonetiqueApplication;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.EditionResponse;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import sun.misc.BASE64Decoder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;



/**
 *
 * @author c65344
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ContestationMonetiqueApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Profile("test-int")
public class EditionControlerTestIntegration {

	//	@Configuration
	//	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons","com.bnpparibas.dsibddf.ap22569.smctorefoapi.goal","com.bnpparibas.dsibddf.ap22569.smccoreapi", "com.bnpparibas.dsibddf.ap22569.smctogdnapi","com.bnpparibas.dsibddf.ap22569.smctorp.mbppzppm","com.bnpparibas.dsibddf.ap22569.smctobcmp",
	//			"com.bnpparibas.dsibddf.ap22569.smccoreapi.application","com.bnpparibas.dsibddf.ap22569.smctoeditique.service","com.bnpparibas.dsibddf.ap22569.smctoeditique.service.builder","com.bnpparibas.dsibddf.ap22569.smctoeditique.commons","com.bnpparibas.dsibddf.ap22569.smctoeditique.model.conf","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration"})
	//	static class TestConfig{
	//
	//	}

	@LocalServerPort
	private int port = 8080;

	@Autowired
	private TestRestTemplate restTemplate;
	HttpHeaders headerHttp = new HttpHeaders();
	String url = null;

	//HttpEntity<GeneratePDFRequest> RequestPdf = null;

	//ResponseEntity<EditionResponse> responsePDF =null;


	private void createDocument(String name,String document) throws IOException{
		System.out.println("Le document est :"+document);
		BASE64Decoder decoder = new BASE64Decoder();
		byte[] decodedBytes = decoder.decodeBuffer(document);

		File file = new File("src/test/resources/document/"+name+".pdf");
		FileOutputStream fop = new FileOutputStream(file);

		fop.write(decodedBytes);
		fop.flush();
		fop.close();
	}





	@Before
	public void getCommonsBefore(){


		headerHttp.set("Accept", "application/json");
		headerHttp.set("Channel", "1");
		headerHttp.set("codeApplication", "ap22569");
		headerHttp.set("X-B3-SpanId", "4");
		headerHttp.set("X-B3-TraceId", "4");
		url = "http://localhost:" + port + "/v1/contestation/edition/document";



	}


	@Test
	public void testGenerateContestationCard() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException {
		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();


		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");

		String idoc = "";


		donneesMaquette.setQualificationDossier("2");

		donneesMaquette.setNumCarteMasque("4970 XXXX XXXX 5142");
		donneesMaquette.setDateOpposition("11/12/1995");
		donneesMaquette.setTotalOperations(4);
		donneesMaquette.setNatureDossier("123");
		donneesMaquette.setDateAppel("11/12/1995");
		donneesMaquette.setNumeroCarte("0004974074205032328");
		donneesMaquette.setDelaisReponse(4);
		donneesMaquette.setNumDossier("E201812147522369");

		//List<DetailOperation> operations = Arrays.asList(new DetailOperation("11/12/1992", "dddd", "15/12/1992", new BigDecimal(15)), new DetailOperation("11/12/1992", "dddd", "15/12/1992", new BigDecimal(15)));




		//donneesMaquette.setDetailsOperations(operations);
		maquetteIdentification.setMaquette("trby9con");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);


		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);

		Assertions.assertThat(responsePDF).isNotNull();
		Assertions.assertThat(responsePDF.getBody()).isNotNull();
		assertTrue(responsePDF.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responsePDF.getBody().getDocument()).isNotNull();

		createDocument("contestationCarte", responsePDF.getBody().getDocument());

	}


	@Test
	public void testGenerateContestationCardFail() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException {
		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();


		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");

		String idoc = "";


		donneesMaquette.setQualificationDossier("2");

		donneesMaquette.setNumCarteMasque("4970 XXXX XXXX 5142");
		donneesMaquette.setDateOpposition("11/12/1995");
		donneesMaquette.setTotalOperations(4);
		donneesMaquette.setNatureDossier("123");
		donneesMaquette.setDateAppel("11/12/1995");
		donneesMaquette.setNumeroCarte("0004974074205032328");
		donneesMaquette.setDelaisReponse(4);
		donneesMaquette.setNumDossier("E201812147522369");

		List<DetailOperation> operations = Arrays.asList(new DetailOperation("2019-03-12T09:38:33.914Z", "dddd", "2019-03-12T09:38:33.914Z", new BigDecimal(15)), new DetailOperation("2019-03-12T09:38:33.914Z", "dddd", "2019-03-12T09:38:33.914Z",  new BigDecimal(15)));




		donneesMaquette.setDetailsOperations(operations);
		maquetteIdentification.setMaquette("trby9con");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);


		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);
		assertTrue(responsePDF.getStatusCode().is4xxClientError());

		//createDocument("contestationCarte", responsePDF.getBody().getDocument());

	}

	@Test
	public void testGenerateCourrierGenerique() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException {

		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();




		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");

		String idoc = "";

		donneesMaquette.setDateTraitement("11/12/1995");
		donneesMaquette.setNatureDossierLibelle("COURRIER DU JOUR");
		donneesMaquette.setNumDossier("E201812147522369");
		donneesMaquette.setNumCarteMasque("4970 XXXX XXXX 5142");
		donneesMaquette.setNumeroCarte("0004974074205032328");

		/**
		 * ajout paragraphes
		 */
		List<PDFRequestDonneesMaquetteChampsLibres> paragraphes = new ArrayList<>();
		List<PDFRequestDonneesMaquettePhrases> phrases = new ArrayList<>();

		phrases.add(new PDFRequestDonneesMaquettePhrases(1, "Nous avons procédé à l'analyse de votre dossier daté du 12.11.2018 concernant 20 opération[s] pour un montant total de 2 458,81 ."));
		phrases.add(new PDFRequestDonneesMaquettePhrases(2, "- l'(es) opération(s) ci-dessous a (ont) fait l'objet d'un remboursement :"));
		phrases.add(new PDFRequestDonneesMaquettePhrases(3, "Amazon du 10.10.2018 de 15,00  régularisée le 18.10.2018"));

		PDFRequestDonneesMaquetteChampsLibres paragraphe = new PDFRequestDonneesMaquetteChampsLibres();

		paragraphe.setIndexParagraphe(1);
		paragraphe.setPhrases(phrases);

		paragraphes.add(paragraphe);

		donneesMaquette.setChampsLibres(paragraphes);
		donneesMaquette.setPostScriptum(Arrays.asList("A repondre au plus vite"));

		maquetteIdentification.setMaquette("trby9gen");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);



		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);


		Assertions.assertThat(responsePDF).isNotNull();
		Assertions.assertThat(responsePDF.getBody()).isNotNull();
		assertTrue(responsePDF.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responsePDF.getBody().getDocument()).isNotNull();

		////createDocument("courrierGenerique", responsePDF.getBody().getDocument());
	}





	@Test
	public void testGenerateFicheLiaison() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException{


		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();




		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");


		donneesMaquette.setContactEmet("ANTOINE");
		donneesMaquette.setIdUser("c65344");
		donneesMaquette.setNumDossier("E201812147522369");
		donneesMaquette.setNumClient("4970");
		donneesMaquette.setNumeroCarte("0004974074205032328");

		donneesMaquette.setComent(Arrays.asList("regularisation de votre compte"));

		maquetteIdentification.setMaquette("trby9lia");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);



		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);

		Assertions.assertThat(responsePDF).isNotNull();
		Assertions.assertThat(responsePDF.getBody()).isNotNull();
		assertTrue(responsePDF.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responsePDF.getBody().getDocument()).isNotNull();

		////createDocument("ficheDeLiaison", responsePDF.getBody().getDocument());
	}



	@Test
	public void testGenerateFormPay() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException{

		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();




		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");



		donneesMaquette.setCodeChefdefileemet("250");
		donneesMaquette.setContactEmet("51 RUE VALMY 4 ");
		donneesMaquette.setTelephoneEmet("07522584");
		donneesMaquette.setFaxEmet("07522584");
		donneesMaquette.setEmailEmet("gervaisolsen33@gmail.com");
		donneesMaquette.setCodeChefdefiledest("555");
		donneesMaquette.setContactDest("51 RUE VALMY 2");
		donneesMaquette.setTelephoneDest("07522589");
		donneesMaquette.setFaxDest("07522584");
		donneesMaquette.setEmailDest("gervaisolsenBnp@gmail.com");
		donneesMaquette.setTypeOperation("vole de carte");
		donneesMaquette.setDateTraitement("11/08/2019");
		donneesMaquette.setCodebanqueMempracc("5888");
		donneesMaquette.setCodebanqueDom("82525");
		donneesMaquette.setNumSiret("155888");
		donneesMaquette.setLocDepart("DEPART");
		donneesMaquette.setRaisonSociale("188888");
		donneesMaquette.setCodeApe("1818");
		donneesMaquette.setCodebanqueMemprtit("8888");
		donneesMaquette.setNumCarteMasque("4970 XXXX XXXX 5142");
		donneesMaquette.setCodeMotifipaye("aucune raison de vous payé");
		donneesMaquette.setMontantBrut("12000");
		donneesMaquette.setMontantCompense("14000");
		donneesMaquette.setDateheureTransaction("11/12/2019");
		donneesMaquette.setDateReglmntinitial("11/12/2019");
		donneesMaquette.setDateRglmntimpaye("11/12/2019");
		donneesMaquette.setReferenceArchivage("REFERENCE");
		donneesMaquette.setAutresDonnees("Aucune");
		donneesMaquette.setTypeReglmntsouhaite("10000");
		donneesMaquette.setNumeroCarte("0004974074205032328");


		donneesMaquette.setComent(Arrays.asList("regularisation de votre compte"));

		maquetteIdentification.setMaquette("trby9pai");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);



		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);

		Assertions.assertThat(responsePDF).isNotNull();
		Assertions.assertThat(responsePDF.getBody()).isNotNull();
		assertTrue(responsePDF.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responsePDF.getBody().getDocument()).isNotNull();

		//createDocument("FormulairePayement", responsePDF.getBody().getDocument());

	}

	@Test
	public void testGenerateFormRetrait() throws EditingException, MandatoryException, FormatErrorException, DonneIncorectException, IOException{

		GeneratePDFRequest requestGlobal = new GeneratePDFRequest();

		PDFRequestMaquetteIdentification maquetteIdentification = new PDFRequestMaquetteIdentification();

		GeneratePDFRequestMaquetteDef maquette = new GeneratePDFRequestMaquetteDef();

		PDFRequestDonneesMaquette donneesMaquette = new PDFRequestDonneesMaquette();


		donneesMaquette.setTelephoneEmet("01 45 32 88 20");
		donneesMaquette.setAdrRetour("Service Contestations Cartes");
		donneesMaquette.setDateTraitement("11/07/2019");



		donneesMaquette.setCodeChefdefileemet("250");
		donneesMaquette.setContactEmet("51 RUE VALMY 4 ");
		donneesMaquette.setTelephoneEmet("07522584");
		donneesMaquette.setFaxEmet("07522584");
		donneesMaquette.setEmailEmet("gervaisolsen33@gmail.com");
		donneesMaquette.setCodeChefdefiledest("555");
		donneesMaquette.setContactDest("51 RUE VALMY 2");
		donneesMaquette.setTelephoneDest("07522589");
		donneesMaquette.setFaxDest("07522584");
		donneesMaquette.setEmailDest("gervaisolsenBnp@gmail.com");
		donneesMaquette.setTypeOperation("vole de carte");
		donneesMaquette.setDateTraitement("11/08/2019");
		donneesMaquette.setCodebanqueMempracc("5888");
		donneesMaquette.setCodebanqueDom("82525");
		donneesMaquette.setNumSiret("155888");
		donneesMaquette.setLocDepart("DEPART");

		donneesMaquette.setCodebanqueMemprtit("8888");
		donneesMaquette.setNumCarteMasque("4970 XXXX XXXX 5142");
		donneesMaquette.setCodeMotifipaye("aucune raison de vous payé");

		donneesMaquette.setMontantCompense("14000");
		donneesMaquette.setDateheureTransaction("11/12/2019:18");
		donneesMaquette.setDateReglmntinitial("11/12/2019");
		donneesMaquette.setDateRglmntimpaye("11/12/2019");

		donneesMaquette.setAutresDonnees("Aucune");
		donneesMaquette.setTypeReglmntsouhaite("10000");

		donneesMaquette.setNumDistributeur("12");
		donneesMaquette.setNumeroCarte("0004974074205032328");


		//donneesMaquette.setComent(Arrays.asList("regularisation de votre compte"));

		maquetteIdentification.setMaquette("trby9ret");

		maquette.setDonneesMaquette(donneesMaquette);
		maquette.setMaquetteIdentification(maquetteIdentification);
		maquette.setEditiqueCentrale(false);
		requestGlobal.setMaquette(maquette);



		HttpEntity<GeneratePDFRequest> RequestPdf = new HttpEntity<GeneratePDFRequest>(requestGlobal,headerHttp);

		ResponseEntity<EditionResponse> responsePDF = restTemplate.exchange(url, HttpMethod.POST, RequestPdf, EditionResponse.class);

		Assertions.assertThat(responsePDF).isNotNull();
		Assertions.assertThat(responsePDF.getBody()).isNotNull();
		assertTrue(responsePDF.getStatusCode().is2xxSuccessful());
		Assertions.assertThat(responsePDF.getBody().getDocument()).isNotNull();

		//createDocument("FormulaireRetrait", responsePDF.getBody().getDocument());
	}

}
