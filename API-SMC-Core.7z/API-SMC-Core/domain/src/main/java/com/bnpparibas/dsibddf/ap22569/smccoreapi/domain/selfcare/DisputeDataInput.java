package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;

import java.util.List;



/**
 * DisputeInputData
 */
public class DisputeDataInput   {

	private String bankNumber;

	private String cardNumber;

	private String qualification;

	private String nature;

	private String mail;

	private String phone;

	private List<OperationInput> operations;

	private List<DocumentInput> documents;

	/**
	 * @return the bankNumber
	 */
	public String getBankNumber() {
		return bankNumber;
	}

	/**
	 * @return the cardNumber
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * @return the documents
	 */
	public List<DocumentInput> getDocuments() {
		return documents;
	}

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @return the nature
	 */
	public String getNature() {
		return nature;
	}

	/**
	 * @return the operations
	 */
	public List<OperationInput> getOperations() {
		return operations;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @return the qualification
	 */
	public String getQualification() {
		return qualification;
	}

	/**
	 * @param bankNumber the bankNumber to set
	 */
	public void setBankNumber(String bankNumber) {
		this.bankNumber = bankNumber;
	}

	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @param documents the documents to set
	 */
	public void setDocuments(List<DocumentInput> documents) {
		this.documents = documents;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * @param nature the nature to set
	 */
	public void setNature(String nature) {
		this.nature = nature;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<OperationInput> operations) {
		this.operations = operations;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @param qualification the qualification to set
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


}

