package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IMotifRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

@RunWith(SpringRunner.class)
@EntityScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure"})
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
@Ignore
public class MotifRepositoryTest {

	@Autowired
	private IMotifRepository motifRepository;

	@Test
	public void getAllMotifs() {


		List<MotifContestation> motifs = this.motifRepository.getAllMotifs();
		assertThat(motifs).isNotEmpty();
		assertThat(motifs.size()).isEqualTo(11);

		List<MotifContestation> temp = motifs.stream().filter(motifContestation -> motifContestation.getCode().equals("M009")).collect(Collectors.toList());
		assertThat(temp).isNotEmpty();
		assertThat(temp.size()).isEqualTo(1);
		MotifContestation motif1 = temp.get(0);
		assertThat(motif1.getCode()).isEqualTo("M009");
		assertThat(motif1.getLibelle()).isEqualTo("DAB Billets non delivres");
		assertThat(motif1.getTypeOperationApplicable()).isNotNull().isEqualTo(TypeOperation.RETRAIT);
		assertThat(motif1.getNatureContestation()).isNotNull();
		assertThat(motif1.getQualificationContestation()).isNotNull();
		assertThat(motif1.getQualificationContestation().getQualificationLibelle()).isEqualTo("Autres");
	}

	@Test
	public void getMotifsByOperationType() {

		List<MotifContestation> motifs = this.motifRepository.getMotifsByOperationType(TypeOperation.RETRAIT);
		assertThat(motifs).isNotEmpty();
		assertThat(motifs.size()).isEqualTo(9);
	}

	@Test
	public void testGetAppliedReasons() {
		try {
			// carte perdue ou volée
			List<MotifContestation> appliedReasons = this.motifRepository.getAppliedReasons(TypeOperation.RETRAIT, Boolean.TRUE, Integer.valueOf(5));
			assertThat(appliedReasons).isNotEmpty();
			assertThat(appliedReasons.size()).isEqualTo(4);
			// Porteur en possession de sa carte et nombre d'opération > 1
			appliedReasons = this.motifRepository.getAppliedReasons(TypeOperation.RETRAIT, Boolean.FALSE, Integer.valueOf(5));
			assertThat(appliedReasons).isNotEmpty();
			assertThat(appliedReasons.size()).isEqualTo(5);
			// Porteur en possession de sa carte et nombre d'opération = 1
			appliedReasons = this.motifRepository.getAppliedReasons(TypeOperation.RETRAIT, Boolean.FALSE, Integer.valueOf(1));
			assertThat(appliedReasons).isNotEmpty();
			assertThat(appliedReasons.size()).isEqualTo(5);
			//Récup des documents associés
			appliedReasons = this.motifRepository.getAppliedReasons(TypeOperation.PAIEMENT, Boolean.FALSE, Integer.valueOf(5));
			assertThat(appliedReasons).isNotEmpty();
			//			appliedReasons.stream().forEach(r -> {
			//				if(r.getExigenceAttachement().equals(ExigenceAjoutInformation.obligatoire)) {
			//					assertThat(r.getDocumentAssocies()).isNotEmpty();
			//				}
			//			});

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	public void testGetMotifsByOperationTypeCache() {

		List<MotifContestation> motifs = this.motifRepository.getMotifsByOperationType(TypeOperation.RETRAIT);
		assertThat(motifs).isNotEmpty();
		assertThat(motifs.size()).isEqualTo(9);
		try {
			Thread.sleep(5000l);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		motifs = this.motifRepository.getMotifsByOperationType(TypeOperation.RETRAIT);
		assertThat(motifs).isNotEmpty();
		assertThat(motifs.size()).isEqualTo(9);
	}
}