package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author c65344
 *
 */
@Entity
@Table(name = "EDITION")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class EditionEntity extends AbstractEntity<DefaultEntityId> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Donne la date de traitetement
	 */
	@Column
	private LocalDate treatedDate;
	/**
	 * Donne l'état de traitetement
	 */
	@Column
	@Enumerated(EnumType.STRING)
	private Status status;

	@Column
	private LocalDate birthDay;

	@Column
	private int numSequence;

	@Column(length = 2)
	private String	clientNatureId;

	@Column(length = 9)
	private BigInteger  sirenNumber;

	@Column(length = 17)
	private String ikpi;

	@Column(length = 17)
	private String idContratMonetiquePorteur;

	@Column(length = 23)
	private String ribOperation;

	@Column(length = 5)
	private String codePostal;

	@Column(length = 2)
	private String codePays;

	@Column(length = 19)
	private String idDocSmc;

	@Column
	private String maquetteId;

	@Column(length = 19)
	private String numeroCarte;

	@Column
	private boolean editiqueCentral;

	@Column
	private String canal;

	@Column
	private String dateTraitement;
	@Column
	private String idUser;
	@Column(length = 1)
	private String qualificationDossier;

	@Column(length = 3)
	private String natureDossier;

	@Column(length = 255)
	private String natureDossierLibelle;

	@Column(length=16)
	private String numDossier;

	@Column
	private String dateAppel;

	@Column(length = 16)
	private String telephoneEmet;

	@Column(length = 32)
	private String raisonSociale;

	@Column
	private String emailEmet;

	@Column(length = 2)
	private int delaisReponse;

	@Column
	private String dateOpposition;

	@Column(length = 19)
	private int totalOperations;

	@Column
	private String codeChefdefileemet;

	@Column
	private String contactEmet;

	@Column
	private String faxEmet;

	@Column
	private String codeChefdefiledest;

	@Column
	private String contactDest;

	@Column
	private String telephoneDest;

	@Column
	private String faxDest;

	@Column
	private String emailDest;

	@Column
	private String typeOperation;



	@Column
	private String codebanqueMempracc;
	@Column
	private String codebanqueDom;
	@Column
	private String numDistributeur;
	@Column
	private String locDepart;

	@Column
	private String codebanqueMemprtit;

	@Column(length = 19)
	private String numCarteMasque;

	@Column
	private String codeMotifipaye;

	@Column
	private String montantCompense;

	@Column
	private String dateheureTransaction;

	@Column
	private String dateReglmntinitial;

	@Column
	private String autresDonnees;

	@Column
	private String typeReglmntsouhaite;

	@Column
	private String numSiret;

	@Column
	private String codeApe;

	@Column
	private String dateRglmntimpaye;

	@Column
	private String dateRglmntrepres;

	@Column
	private String referenceArchivage;

	@Column
	private String montantBrut;

	@Column
	private String numClient;

	@Column
	private String dateCreationSmc;

	@Column
	private String montantConteste;

	@Column
	private int nombreOperations;

	@Column
	private String adrRetour;

	@Column
	private String nomService;

	@Column(length = 255)
	private String libTypeDoc;

	@Column(length = 8)
	private String codeTypeDoc;

	@Column
	private String nomPorteur;

	@Column
	private String prenomPorteur;

	@Column
	private String topClientele;

	@ElementCollection(fetch = FetchType.EAGER)
	private Map<String,String> sneMaquette;

	@OneToOne(cascade = {CascadeType.ALL}, targetEntity = EmeteurEntity.class)
	@JoinColumn(name = "EMETEUR")
	private EmeteurEntity emeteur;

	@OneToOne(cascade = {CascadeType.ALL}, targetEntity = DestinataireEntity.class)
	@JoinColumn(name = "DESTINATAIRE")
	private DestinataireEntity destinataire;

	@OneToMany(fetch = FetchType.EAGER,cascade = {CascadeType.PERSIST}, targetEntity = ParagrapheEntity.class)
	@JoinColumn(name = "EDITION_ID")
	Set<ParagrapheEntity> paragraphes;

	@OneToMany(fetch = FetchType.EAGER,cascade = {CascadeType.PERSIST}, targetEntity = OperationEditionEntity.class)
	@JoinColumn(name = "EDITION_ID")
	private List<OperationEditionEntity> operations;

	@ElementCollection
	@JoinTable(name = "COMMENTAIRES", joinColumns = {@JoinColumn(name="EDITION_ID")})
	private List<String> commentaires;

	@ElementCollection(fetch = FetchType.EAGER)
	@JoinTable(name = "POSTSCRIPTUM", joinColumns = {@JoinColumn(name="EDITION_ID")})
	private Set<String> postScriptum;

	/**
	 * @return the adrRetour
	 */
	public String getAdrRetour() {
		return adrRetour;
	}

	/**
	 * @return the autresDonnees
	 */
	public String getAutresDonnees() {
		return autresDonnees;
	}

	/**
	 * @return the birthDay
	 */
	public LocalDate getBirthDay() {
		return birthDay;
	}

	/**
	 * @return the canal
	 */
	public String getCanal() {
		return canal;
	}

	/**
	 * @return the clientNatureId
	 */
	public String getClientNatureId() {
		return clientNatureId;
	}

	/**
	 * @return the codeApe
	 */
	public String getCodeApe() {
		return codeApe;
	}

	/**
	 * @return the codebanqueDom
	 */
	public String getCodebanqueDom() {
		return codebanqueDom;
	}

	/**
	 * @return the codebanqueMempracc
	 */
	public String getCodebanqueMempracc() {
		return codebanqueMempracc;
	}

	/**
	 * @return the codebanqueMemprtit
	 */
	public String getCodebanqueMemprtit() {
		return codebanqueMemprtit;
	}

	/**
	 * @return the codeChefdefiledest
	 */
	public String getCodeChefdefiledest() {
		return codeChefdefiledest;
	}

	/**
	 * @return the codeChefdefileemet
	 */
	public String getCodeChefdefileemet() {
		return codeChefdefileemet;
	}

	/**
	 * @return the codeMotifipaye
	 */
	public String getCodeMotifipaye() {
		return codeMotifipaye;
	}

	/**
	 * @return the codePays
	 */
	public String getCodePays() {
		return codePays;
	}

	/**
	 * @return the codePostal
	 */
	public String getCodePostal() {
		return codePostal;
	}

	/**
	 * @return the codeTypeDoc
	 */
	public String getCodeTypeDoc() {
		return codeTypeDoc;
	}

	/**
	 * @return the commentaires
	 */
	public List<String> getCommentaires() {
		return commentaires;
	}

	/**
	 * @return the contactDest
	 */
	public String getContactDest() {
		return contactDest;
	}



	/**
	 * @return the contactEmet
	 */
	public String getContactEmet() {
		return contactEmet;
	}

	/**
	 * @return the dateAppel
	 */
	public String getDateAppel() {
		return dateAppel;
	}

	/**
	 * @return the dateCreationSmc
	 */
	public String getDateCreationSmc() {
		return dateCreationSmc;
	}

	/**
	 * @return the dateheureTransaction
	 */
	public String getDateheureTransaction() {
		return dateheureTransaction;
	}

	/**
	 * @return the dateOpposition
	 */
	public String getDateOpposition() {
		return dateOpposition;
	}

	/**
	 * @return the dateReglmntinitial
	 */
	public String getDateReglmntinitial() {
		return dateReglmntinitial;
	}

	/**
	 * @return the dateRglmntimpaye
	 */
	public String getDateRglmntimpaye() {
		return dateRglmntimpaye;
	}

	/**
	 * @return the dateRglmntrepres
	 */
	public String getDateRglmntrepres() {
		return dateRglmntrepres;
	}

	/**
	 * @return the dateTraitement
	 */
	public String getDateTraitement() {
		return dateTraitement;
	}

	/**
	 * @return the delaisReponse
	 */
	public int getDelaisReponse() {
		return delaisReponse;
	}

	/**
	 * @return the destinataire
	 */
	public DestinataireEntity getDestinataire() {
		return destinataire;
	}

	/**
	 * @return the emailDest
	 */
	public String getEmailDest() {
		return emailDest;
	}

	/**
	 * @return the emailEmet
	 */
	public String getEmailEmet() {
		return emailEmet;
	}

	/**
	 * @return the emeteur
	 */
	public EmeteurEntity getEmeteur() {
		return emeteur;
	}

	/**
	 * @return the faxDest
	 */
	public String getFaxDest() {
		return faxDest;
	}

	/**
	 * @return the faxEmet
	 */
	public String getFaxEmet() {
		return faxEmet;
	}

	/**
	 * @return the idContratMonetiquePorteur
	 */
	public String getIdContratMonetiquePorteur() {
		return idContratMonetiquePorteur;
	}

	/**
	 * @return the idDocSmc
	 */
	public String getIdDocSmc() {
		return idDocSmc;
	}

	/**
	 * @return the idUser
	 */
	public String getIdUser() {
		return idUser;
	}

	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}

	/**
	 * @return the libTypeDoc
	 */
	public String getLibTypeDoc() {
		return libTypeDoc;
	}

	/**
	 * @return the locDepart
	 */
	public String getLocDepart() {
		return locDepart;
	}

	/**
	 * @return the maquetteId
	 */
	public String getMaquetteId() {
		return maquetteId;
	}

	/**
	 * @return the montantBrut
	 */
	public String getMontantBrut() {
		return montantBrut;
	}

	/**
	 * @return the montantCompense
	 */
	public String getMontantCompense() {
		return montantCompense;
	}

	/**
	 * @return the montantConteste
	 */
	public String getMontantConteste() {
		return montantConteste;
	}

	/**
	 * @return the natureDossier
	 */
	public String getNatureDossier() {
		return natureDossier;
	}

	/**
	 * @return the natureDossierLibelle
	 */
	public String getNatureDossierLibelle() {
		return natureDossierLibelle;
	}

	/**
	 * @return the nombreOperations
	 */
	public int getNombreOperations() {
		return nombreOperations;
	}

	/**
	 * @return the nomPorteur
	 */
	public String getNomPorteur() {
		return nomPorteur;
	}

	/**
	 * @return the nomService
	 */
	public String getNomService() {
		return nomService;
	}

	/**
	 * @return the numCarteMasque
	 */
	public String getNumCarteMasque() {
		return numCarteMasque;
	}

	/**
	 * @return the numClient
	 */
	public String getNumClient() {
		return numClient;
	}

	/**
	 * @return the numDistributeur
	 */
	public String getNumDistributeur() {
		return numDistributeur;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the numeroCarte
	 */
	public String getNumeroCarte() {
		return numeroCarte;
	}

	/**
	 * @return the numSequence
	 */
	public int getNumSequence() {
		return numSequence;
	}

	/**
	 * @return the numSiret
	 */
	public String getNumSiret() {
		return numSiret;
	}

	/**
	 * @return the operations
	 */
	public List<OperationEditionEntity> getOperations() {
		return operations;
	}

	/**
	 * @return the paragraphes
	 */
	public Set<ParagrapheEntity> getParagraphes() {
		return paragraphes;
	}

	/**
	 * @return the postScriptum
	 */
	public Set<String> getPostScriptum() {
		return postScriptum;
	}

	/**
	 * @return the prenomPorteur
	 */
	public String getPrenomPorteur() {
		return prenomPorteur;
	}

	/**
	 * @return the qualificationDossier
	 */
	public String getQualificationDossier() {
		return qualificationDossier;
	}

	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}

	/**
	 * @return the referenceArchivage
	 */
	public String getReferenceArchivage() {
		return referenceArchivage;
	}

	/**
	 * @return the ribOperation
	 */
	public String getRibOperation() {
		return ribOperation;
	}

	/**
	 * @return the sirenNumber
	 */
	public BigInteger getSirenNumber() {
		return sirenNumber;
	}

	/**
	 * @return the sneMaquette
	 */
	public Map<String, String> getSneMaquette() {
		return sneMaquette;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @return the telephoneDest
	 */
	public String getTelephoneDest() {
		return telephoneDest;
	}

	/**
	 * @return the telephoneEmet
	 */
	public String getTelephoneEmet() {
		return telephoneEmet;
	}

	/**
	 * @return the topClientele
	 */
	public String getTopClientele() {
		return topClientele;
	}


	/**
	 * @return the totalOperations
	 */
	public int getTotalOperations() {
		return totalOperations;
	}

	/**
	 * @return the treatedDate
	 */
	public LocalDate getTreatedDate() {
		return treatedDate;
	}

	/**
	 * @return the typeOperation
	 */
	public String getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @return the typeReglmntsouhaite
	 */
	public String getTypeReglmntsouhaite() {
		return typeReglmntsouhaite;
	}

	/**
	 * @return the editiqueCentral
	 */
	public boolean isEditiqueCentral() {
		return editiqueCentral;
	}


	/**
	 * @param adrRetour the adrRetour to set
	 */
	public void setAdrRetour(String adrRetour) {
		this.adrRetour = adrRetour;
	}

	/**
	 * @param autresDonnees the autresDonnees to set
	 */
	public void setAutresDonnees(String autresDonnees) {
		this.autresDonnees = autresDonnees;
	}

	/**
	 * @param birthDay the birthDay to set
	 */
	public void setBirthDay(LocalDate birthDay) {
		this.birthDay = birthDay;
	}

	/**
	 * @param canal the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}

	/**
	 * @param clientNatureId the clientNatureId to set
	 */
	public void setClientNatureId(String clientNatureId) {
		this.clientNatureId = clientNatureId;
	}

	/**
	 * @param codeApe the codeApe to set
	 */
	public void setCodeApe(String codeApe) {
		this.codeApe = codeApe;
	}

	/**
	 * @param codebanqueDom the codebanqueDom to set
	 */
	public void setCodebanqueDom(String codebanqueDom) {
		this.codebanqueDom = codebanqueDom;
	}

	/**
	 * @param codebanqueMempracc the codebanqueMempracc to set
	 */
	public void setCodebanqueMempracc(String codebanqueMempracc) {
		this.codebanqueMempracc = codebanqueMempracc;
	}

	/**
	 * @param codebanqueMemprtit the codebanqueMemprtit to set
	 */
	public void setCodebanqueMemprtit(String codebanqueMemprtit) {
		this.codebanqueMemprtit = codebanqueMemprtit;
	}

	/**
	 * @param codeChefdefiledest the codeChefdefiledest to set
	 */
	public void setCodeChefdefiledest(String codeChefdefiledest) {
		this.codeChefdefiledest = codeChefdefiledest;
	}

	/**
	 * @param codeChefdefileemet the codeChefdefileemet to set
	 */
	public void setCodeChefdefileemet(String codeChefdefileemet) {
		this.codeChefdefileemet = codeChefdefileemet;
	}

	/**
	 * @param codeMotifipaye the codeMotifipaye to set
	 */
	public void setCodeMotifipaye(String codeMotifipaye) {
		this.codeMotifipaye = codeMotifipaye;
	}

	/**
	 * @param codePays the codePays to set
	 */
	public void setCodePays(String codePays) {
		this.codePays = codePays;
	}


	/**
	 * @param codePostal the codePostal to set
	 */
	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}

	/**
	 * @param codeTypeDoc the codeTypeDoc to set
	 */
	public void setCodeTypeDoc(String codeTypeDoc) {
		this.codeTypeDoc = codeTypeDoc;
	}

	/**
	 * @param commentaires the commentaires to set
	 */
	public void setCommentaires(List<String> commentaires) {
		this.commentaires = commentaires;
	}

	/**
	 * @param contactDest the contactDest to set
	 */
	public void setContactDest(String contactDest) {
		this.contactDest = contactDest;
	}

	/**
	 * @param contactEmet the contactEmet to set
	 */
	public void setContactEmet(String contactEmet) {
		this.contactEmet = contactEmet;
	}
	/**
	 * @param dateAppel the dateAppel to set
	 */
	public void setDateAppel(String dateAppel) {
		this.dateAppel = dateAppel;
	}
	/**
	 * @param dateCreationSmc the dateCreationSmc to set
	 */
	public void setDateCreationSmc(String dateCreationSmc) {
		this.dateCreationSmc = dateCreationSmc;
	}
	/**
	 * @param dateheureTransaction the dateheureTransaction to set
	 */
	public void setDateheureTransaction(String dateheureTransaction) {
		this.dateheureTransaction = dateheureTransaction;
	}
	/**
	 * @param dateOpposition the dateOpposition to set
	 */
	public void setDateOpposition(String dateOpposition) {
		this.dateOpposition = dateOpposition;
	}
	/**
	 * @param dateReglmntinitial the dateReglmntinitial to set
	 */
	public void setDateReglmntinitial(String dateReglmntinitial) {
		this.dateReglmntinitial = dateReglmntinitial;
	}
	/**
	 * @param dateRglmntimpaye the dateRglmntimpaye to set
	 */
	public void setDateRglmntimpaye(String dateRglmntimpaye) {
		this.dateRglmntimpaye = dateRglmntimpaye;
	}
	/**
	 * @param dateRglmntrepres the dateRglmntrepres to set
	 */
	public void setDateRglmntrepres(String dateRglmntrepres) {
		this.dateRglmntrepres = dateRglmntrepres;
	}
	/**
	 * @param dateTraitement the dateTraitement to set
	 */
	public void setDateTraitement(String dateTraitement) {
		this.dateTraitement = dateTraitement;
	}
	/**
	 * @param delaisReponse the delaisReponse to set
	 */
	public void setDelaisReponse(int delaisReponse) {
		this.delaisReponse = delaisReponse;
	}

	/**
	 * @param destinataire the destinataire to set
	 */
	public void setDestinataire(DestinataireEntity destinataire) {
		this.destinataire = destinataire;
	}
	/**
	 * @param editiqueCentral the editiqueCentral to set
	 */
	public void setEditiqueCentral(boolean editiqueCentral) {
		this.editiqueCentral = editiqueCentral;
	}
	/**
	 * @param emailDest the emailDest to set
	 */
	public void setEmailDest(String emailDest) {
		this.emailDest = emailDest;
	}
	/**
	 * @param emailEmet the emailEmet to set
	 */
	public void setEmailEmet(String emailEmet) {
		this.emailEmet = emailEmet;
	}
	/**
	 * @param emeteur the emeteur to set
	 */
	public void setEmeteur(EmeteurEntity emeteur) {
		this.emeteur = emeteur;
	}
	/**
	 * @param faxDest the faxDest to set
	 */
	public void setFaxDest(String faxDest) {
		this.faxDest = faxDest;
	}
	/**
	 * @param faxEmet the faxEmet to set
	 */
	public void setFaxEmet(String faxEmet) {
		this.faxEmet = faxEmet;
	}
	/**
	 * @param idContratMonetiquePorteur the idContratMonetiquePorteur to set
	 */
	public void setIdContratMonetiquePorteur(String idContratMonetiquePorteur) {
		this.idContratMonetiquePorteur = idContratMonetiquePorteur;
	}
	/**
	 * @param idDocSmc the idDocSmc to set
	 */
	public void setIdDocSmc(String idDocSmc) {
		this.idDocSmc = idDocSmc;
	}
	/**
	 * @param idUser the idUser to set
	 */
	public void setIdUser(String idUser) {
		this.idUser = idUser;
	}
	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}
	/**
	 * @param libTypeDoc the libTypeDoc to set
	 */
	public void setLibTypeDoc(String libTypeDoc) {
		this.libTypeDoc = libTypeDoc;
	}
	/**
	 * @param locDepart the locDepart to set
	 */
	public void setLocDepart(String locDepart) {
		this.locDepart = locDepart;
	}
	/**
	 * @param maquetteId the maquetteId to set
	 */
	public void setMaquetteId(String maquetteId) {
		this.maquetteId = maquetteId;
	}
	/**
	 * @param montantBrut the montantBrut to set
	 */
	public void setMontantBrut(String montantBrut) {
		this.montantBrut = montantBrut;
	}
	/**
	 * @param montantCompense the montantCompense to set
	 */
	public void setMontantCompense(String montantCompense) {
		this.montantCompense = montantCompense;
	}
	/**
	 * @param montantConteste the montantConteste to set
	 */
	public void setMontantConteste(String montantConteste) {
		this.montantConteste = montantConteste;
	}
	/**
	 * @param natureDossier the natureDossier to set
	 */
	public void setNatureDossier(String natureDossier) {
		this.natureDossier = natureDossier;
	}
	/**
	 * @param natureDossierLibelle the natureDossierLibelle to set
	 */
	public void setNatureDossierLibelle(String natureDossierLibelle) {
		this.natureDossierLibelle = natureDossierLibelle;
	}
	/**
	 * @param nombreOperations the nombreOperations to set
	 */
	public void setNombreOperations(int nombreOperations) {
		this.nombreOperations = nombreOperations;
	}
	/**
	 * @param nomPorteur the nomPorteur to set
	 */
	public void setNomPorteur(String nomPorteur) {
		this.nomPorteur = nomPorteur;
	}
	/**
	 * @param nomService the nomService to set
	 */
	public void setNomService(String nomService) {
		this.nomService = nomService;
	}
	/**
	 * @param numCarteMasque the numCarteMasque to set
	 */
	public void setNumCarteMasque(String numCarteMasque) {
		this.numCarteMasque = numCarteMasque;
	}
	/**
	 * @param numClient the numClient to set
	 */
	public void setNumClient(String numClient) {
		this.numClient = numClient;
	}
	/**
	 * @param numDistributeur the numDistributeur to set
	 */
	public void setNumDistributeur(String numDistributeur) {
		this.numDistributeur = numDistributeur;
	}
	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}
	/**
	 * @param numeroCarte the numeroCarte to set
	 */
	public void setNumeroCarte(String numeroCarte) {
		this.numeroCarte = numeroCarte;
	}
	/**
	 * @param numSequence the numSequence to set
	 */
	public void setNumSequence(int numSequence) {
		this.numSequence = numSequence;
	}
	/**
	 * @param numSiret the numSiret to set
	 */
	public void setNumSiret(String numSiret) {
		this.numSiret = numSiret;
	}
	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<OperationEditionEntity> operations) {
		this.operations = operations;
	}
	/**
	 * @param paragraphes the paragraphes to set
	 */
	public void setParagraphes(Set<ParagrapheEntity> paragraphes) {
		this.paragraphes = paragraphes;
	}
	/**
	 * @param postScriptum the postScriptum to set
	 */
	public void setPostScriptum(Set<String> postScriptum) {
		this.postScriptum = postScriptum;
	}
	/**
	 * @param prenomPorteur the prenomPorteur to set
	 */
	public void setPrenomPorteur(String prenomPorteur) {
		this.prenomPorteur = prenomPorteur;
	}
	/**
	 * @param qualificationDossier the qualificationDossier to set
	 */
	public void setQualificationDossier(String qualificationDossier) {
		this.qualificationDossier = qualificationDossier;
	}
	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}
	/**
	 * @param referenceArchivage the referenceArchivage to set
	 */
	public void setReferenceArchivage(String referenceArchivage) {
		this.referenceArchivage = referenceArchivage;
	}

	/**
	 * @param ribOperation the ribOperation to set
	 */
	public void setRibOperation(String ribOperation) {
		this.ribOperation = ribOperation;
	}
	/**
	 * @param sirenNumber the sirenNumber to set
	 */
	public void setSirenNumber(BigInteger sirenNumber) {
		this.sirenNumber = sirenNumber;
	}
	/**
	 * @param sneMaquette the sneMaquette to set
	 */
	public void setSneMaquette(Map<String, String> sneMaquette) {
		this.sneMaquette = sneMaquette;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}
	/**
	 * @param telephoneDest the telephoneDest to set
	 */
	public void setTelephoneDest(String telephoneDest) {
		this.telephoneDest = telephoneDest;
	}

	/**
	 * @param telephoneEmet the telephoneEmet to set
	 */
	public void setTelephoneEmet(String telephoneEmet) {
		this.telephoneEmet = telephoneEmet;
	}


	/**
	 * @param topClientele the topClientele to set
	 */
	public void setTopClientele(String topClientele) {
		this.topClientele = topClientele;
	}

	/**
	 * @param totalOperations the totalOperations to set
	 */
	public void setTotalOperations(int totalOperations) {
		this.totalOperations = totalOperations;
	}

	/**
	 * @param treatedDate the treatedDate to set
	 */
	public void setTreatedDate(LocalDate treatedDate) {
		this.treatedDate = treatedDate;
	}

	/**
	 * @param typeOperation the typeOperation to set
	 */
	public void setTypeOperation(String typeOperation) {
		this.typeOperation = typeOperation;
	}

	/**
	 * @param typeReglmntsouhaite the typeReglmntsouhaite to set
	 */
	public void setTypeReglmntsouhaite(String typeReglmntsouhaite) {
		this.typeReglmntsouhaite = typeReglmntsouhaite;
	}




}
