package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.agence;


/**
 *
 * @author c65344
 *
 */
public interface IRefo {
	/**
	 * Recupère le code agence et retourne Le type bank hello bank ou bnp
	 * @param codeUO
	 * @return String
	 */
	ResponseRefo getTypeBank(String codeUO) throws RefoException;

}
