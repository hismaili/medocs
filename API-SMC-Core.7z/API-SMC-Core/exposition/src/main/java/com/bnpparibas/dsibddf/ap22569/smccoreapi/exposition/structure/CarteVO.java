package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class CarteVO {


	private String maskedPan;

	private String cardId;

	private LocalDate dateFinValidite;

	private String typeProduit;

	private String etatCarte;

	/**
	 * date et heure
	 */
	private LocalDateTime dateOpposition;

	private String motifOpposition;

	@Override
	public boolean equals(Object o) {
		if (this == o){
			return true;
		}
		if (o == null || getClass() != o.getClass()){
			return false;
		}
		CarteVO carteVO = (CarteVO) o;
		return Objects.equals(maskedPan, carteVO.maskedPan) &&
				Objects.equals(dateFinValidite, carteVO.dateFinValidite) &&
				Objects.equals(typeProduit, carteVO.typeProduit) &&
				Objects.equals(etatCarte, carteVO.etatCarte) &&
				Objects.equals(dateOpposition, carteVO.dateOpposition) &&
				Objects.equals(motifOpposition, carteVO.motifOpposition);
	}

	public String getCardId() {
		return cardId;
	}

	public LocalDate getDateFinValidite() {
		return dateFinValidite;
	}

	public LocalDateTime getDateOpposition() {
		return dateOpposition;
	}

	public String getEtatCarte() {
		return etatCarte;
	}

	public String getMaskedPan() {
		return maskedPan;
	}

	public String getMotifOpposition() {
		return motifOpposition;
	}

	public String getTypeProduit() {
		return typeProduit;
	}

	@Override
	public int hashCode() {
		return Objects.hash(maskedPan, dateFinValidite, typeProduit, etatCarte, dateOpposition, motifOpposition);
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setDateFinValidite(LocalDate dateFinValidite) {
		this.dateFinValidite = dateFinValidite;
	}

	public void setDateOpposition(LocalDateTime dateOpposition) {
		this.dateOpposition = dateOpposition;
	}

	public void setEtatCarte(String etatCarte) {
		this.etatCarte = etatCarte;
	}

	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}

	public void setMotifOpposition(String motifOpposition) {
		this.motifOpposition = motifOpposition;
	}

	public void setTypeProduit(String typeProduit) {
		this.typeProduit = typeProduit;
	}
}
