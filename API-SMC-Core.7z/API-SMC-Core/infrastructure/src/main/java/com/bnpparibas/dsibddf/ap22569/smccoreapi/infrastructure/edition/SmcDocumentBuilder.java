/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.naming.NoNameCoder;
import com.thoughtworks.xstream.io.xml.DomDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class SmcDocumentBuilder {
	public static final Charset ISO_8859_15 = Charset.forName("ISO-8859-15"); // c'est ce charset qui prend en compte le symbole €
	public static final Charset UTF_8 = Charset.forName("UTF-8");
	private static final XStream XS = new XStream(new DomDriver("UTF_8", new NoNameCoder())); //$NON-NLS-1$

	@Autowired
	private EditionCentralRetourJpaRepository smcjpa;

	@Autowired(required = false)
	private transient EditionCentralRetourJpaRepository jpaEditionRetour;

	public String buildResponseSmc(){
		List<DocumentGdnReturnEntity> listsmcDocument = smcjpa.findBySendFalse();

		List<DocumentGdnReturnEntity> findAll = smcjpa.findAll();

		Lot lot = new Lot();
		if(!CollectionUtils.isEmpty(listsmcDocument)){
			lot.setDocument(listsmcDocument.stream().map(doc -> {

				String idGDN = doc.getIdGDN();
				BigInteger idDocSmc = doc.getIdDocSmc();

				DocumentSmc documentSmc = new DocumentSmc();

				documentSmc.setDonneUtilisateur("");
				documentSmc.setTypeDoc("DocumentSmart");
				documentSmc.setDocIdGdn(idGDN);

				List<Metadonnee> metadonnees = new ArrayList<>();
				//List<Metadonnee> metadonnees =Arrays.asList(new Metadonnee("KEY_PROCESSUS", "EMET"),new Metadonnee("KEY_ID_SMC",idDocSmc.toString()));

				metadonnees.add(new Metadonnee("KEY_PROCESSUS", "EMET"));
				metadonnees.add(new Metadonnee("KEY_ID_SMC",idDocSmc.toString()));
				documentSmc.setMetadonnees(metadonnees);
				doc.setSend(true);
				jpaEditionRetour.saveAndFlush(doc);
				return documentSmc;
			}).collect(Collectors.toList()));

		}

		return buildSmcXml(lot);
	}


	public String buildSmcXml(Lot lot){
		XS.processAnnotations(new Class[]{Metadonnee.class,DocumentSmc.class});

		XS.alias("document", DocumentSmc.class);
		XS.alias("lot", Lot.class);

		XS.addImplicitCollection(Lot.class, "document");
		String xml = XS.toXML(lot);
		return xml;
	}

}
