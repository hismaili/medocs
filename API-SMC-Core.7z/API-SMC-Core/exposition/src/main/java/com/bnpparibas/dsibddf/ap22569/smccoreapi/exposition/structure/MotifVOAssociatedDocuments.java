package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;

/**
 * MotifVOAssociatedDocuments
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-03-25T16:36:46.817Z")

public class MotifVOAssociatedDocuments   {
	/**
	 * Ajout d un document obligatoire, recommandé ou facultatif
	 */
	public enum TopAttachDocumentEnum {
		OBLIGATOIRE("obligatoire"),

		RECOMMANDEE("recommandee"),

		FACULTATIF("facultatif");

		@JsonCreator
		public static TopAttachDocumentEnum fromValue(String text) {
			for (TopAttachDocumentEnum b : TopAttachDocumentEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}

		private String value;

		TopAttachDocumentEnum(String value) {
			this.value = value;
		}

		@Override
		@JsonValue
		public String toString() {
			return String.valueOf(value);
		}
	}

	@JsonProperty("docType")
	private String docType;

	@JsonProperty("fileType")
	private String fileType;

	@JsonProperty("topAttachDocument")
	private TopAttachDocumentEnum topAttachDocument;

	public MotifVOAssociatedDocuments docType(String docType) {
		this.docType = docType;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		MotifVOAssociatedDocuments motifVOAssociatedDocuments = (MotifVOAssociatedDocuments) o;
		return Objects.equals(this.docType, motifVOAssociatedDocuments.docType) &&
				Objects.equals(this.fileType, motifVOAssociatedDocuments.fileType) &&
				Objects.equals(this.topAttachDocument, motifVOAssociatedDocuments.topAttachDocument);
	}
	/**
	 *
	 * @param fileType
	 * @return
	 */
	public MotifVOAssociatedDocuments fileType(String fileType) {
		this.fileType = fileType;
		return this;
	}

	/**
	 * type de document demandé
	 *
	 * @return docType
	 **/
	@ApiModelProperty(value = "type de document demandé")


	public String getDocType() {
		return docType;
	}

	/**
	 * type de document GDN
	 *
	 * @return fileType
	 **/
	@ApiModelProperty(value = "type de document GDN")


	public String getFileType() {
		return fileType;
	}

	/**
	 * Ajout d un document obligatoire, recommandé ou facultatif
	 *
	 * @return topAttachDocument
	 **/
	@ApiModelProperty(value = "Ajout d un document obligatoire, recommandé ou facultatif")
	public TopAttachDocumentEnum getTopAttachDocument() {
		return topAttachDocument;
	}

	@Override
	public int hashCode() {
		return Objects.hash(docType, fileType, topAttachDocument);
	}
	/**
	 *
	 * @param docType
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}
	/**
	 *
	 * @param fileType
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 *
	 * @param topAttachDocument
	 */
	public void setTopAttachDocument(TopAttachDocumentEnum topAttachDocument) {
		this.topAttachDocument = topAttachDocument;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
	/**
	 *
	 * @param topAttachDocument
	 * @return
	 */
	public MotifVOAssociatedDocuments topAttachDocument(TopAttachDocumentEnum topAttachDocument) {
		this.topAttachDocument = topAttachDocument;
		return this;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class MotifVOAssociatedDocuments {\n");

		sb.append("    docType: ").append(toIndentedString(docType)).append("\n");
		sb.append("    fileType: ").append(toIndentedString(fileType)).append("\n");
		sb.append("    topAttachDocument: ").append(toIndentedString(topAttachDocument)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

