package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 *
 *
 */
public class Operation {

	/** Coidop de l'opération */
	private String codeOperation;

	/** Le type d'opération : retrait, VAD,  */
	private TypeOperation typeOperation;

	/** Le montant de l'opération */
	private BigDecimal montantOperation;

	/** La date de l'opération */
	private LocalDate dateOperation;

	/** Le libellé de l'opération */
	private String libelleOperation;

	/** Le montant reconnu par l'utilisateur pour les contestations pour des montants erronés */
	private BigDecimal montantReconnu;

	/**
	 * montant de commission
	 */
	private BigDecimal montantCommission;

	/**
	 * La date de vente
	 */
	private LocalDate dateVente;

	/**
	 * Le nom du commerçant
	 */
	private String nomCommercant;

	/**
	 * Signe de l'opération : débit pu crédit
	 */
	private OperationSign signeOperation;

	private String deviseOperation;

	private boolean disputable;

	public Operation() {
	}

	public Operation(String codeOperation, TypeOperation typeOperation, BigDecimal montantOperation, LocalDate dateOperation, String libelleOperation, BigDecimal montantReconnu, LocalDate dateVente, String nomCommercant, OperationSign signeOperation, String deviseOperation) {
		this.codeOperation = codeOperation;
		this.typeOperation = typeOperation;
		this.montantOperation = montantOperation;
		this.dateOperation = dateOperation;
		this.libelleOperation = libelleOperation;
		this.montantReconnu = montantReconnu;
		this.dateVente = dateVente;
		this.nomCommercant = nomCommercant;
		this.signeOperation = signeOperation;
		this.deviseOperation = deviseOperation;
	}

	public String getCodeOperation() {
		return codeOperation;
	}

	public LocalDate getDateOperation() {
		return this.dateOperation;
	}

	public LocalDate getDateVente() {
		return dateVente;
	}

	public String getDeviseOperation() {
		return deviseOperation;
	}

	public String getLibelleOperation() {
		return libelleOperation;
	}

	/**
	 * @return the montantCommission
	 */
	public BigDecimal getMontantCommission() {
		return montantCommission;
	}

	public BigDecimal getMontantOperation() {
		return montantOperation;
	}

	public BigDecimal getMontantReconnu() {
		return montantReconnu;
	}

	public String getNomCommercant() {
		return nomCommercant;
	}

	public OperationSign getSigneOperation() {
		return signeOperation;
	}

	public TypeOperation getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @return the disputable
	 */
	public boolean isDisputable() {
		return disputable;
	}

	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}

	public void setDateOperation(LocalDate dateOperation) {
		this.dateOperation = dateOperation;
	}

	public void setDateVente(LocalDate dateVente) {
		this.dateVente = dateVente;
	}

	public void setDeviseOperation(String deviseOperation) {
		this.deviseOperation = deviseOperation;
	}

	/**
	 * @param disputable the disputable to set
	 */
	public void setDisputable(boolean disputable) {
		this.disputable = disputable;
	}

	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	/**
	 * @param montantCommission the montantCommission to set
	 */
	public void setMontantCommission(BigDecimal montantCommission) {
		this.montantCommission = montantCommission;
	}

	public void setMontantOperation(BigDecimal montantOperation) {
		this.montantOperation = montantOperation;
	}

	public void setMontantReconnu(BigDecimal montantReconnu) {
		this.montantReconnu = montantReconnu;
	}

	public void setNomCommercant(String nomCommercant) {
		this.nomCommercant = nomCommercant;
	}

	public void setSigneOperation(OperationSign signeOperation) {
		this.signeOperation = signeOperation;
	}

	public void setTypeOperation(TypeOperation typeOperation) {
		this.typeOperation = typeOperation;
	}
}
