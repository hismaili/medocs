package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import java.util.ArrayList;
import java.util.List;

public class DisputeDataDTO {

	private String factsSummary;

	private String telematicId;

	private Boolean cardLost;

	private String reason;

	private Boolean notifMail;

	private Boolean notifPush;

	private Boolean notifSMS;

	private String cardId;

	private List<DisputeDataOperationDTO> operations = new ArrayList<DisputeDataOperationDTO>();

	private String phoneNumber;

	private String mail;

	private Boolean topPhoneNumberModified;

	private Boolean topMailModified;

	private List<DisputeDataAttachedFileDTO> attachedFiles;

	private String customerIKpi;

	/**
	 * @return the attachedFiles
	 */
	public List<DisputeDataAttachedFileDTO> getAttachedFiles() {
		return attachedFiles;
	}

	/**
	 * @return the cardId
	 */
	public String getCardId() {
		return cardId;
	}

	/**
	 * @return the cardLost
	 */
	public Boolean getCardLost() {
		return cardLost;
	}

	/**
	 * @return the customerIKpi
	 */
	public String getCustomerIKpi() {
		return customerIKpi;
	}

	/**
	 * @return the factsSummary
	 */
	public String getFactsSummary() {
		return factsSummary;
	}

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @return the notifMail
	 */
	public Boolean getNotifMail() {
		return notifMail;
	}

	/**
	 * @return the notifPush
	 */
	public Boolean getNotifPush() {
		return notifPush;
	}

	/**
	 * @return the notifSMS
	 */
	public Boolean getNotifSMS() {
		return notifSMS;
	}

	/**
	 * @return the operations
	 */
	public List<DisputeDataOperationDTO> getOperations() {
		return operations;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @return the telematicId
	 */
	public String getTelematicId() {
		return telematicId;
	}

	/**
	 * @return the topMailModified
	 */
	public Boolean getTopMailModified() {
		return topMailModified;
	}

	/**
	 * @return the topPhoneNumberModified
	 */
	public Boolean getTopPhoneNumberModified() {
		return topPhoneNumberModified;
	}

	/**
	 * @param attachedFiles the attachedFiles to set
	 */
	public void setAttachedFiles(List<DisputeDataAttachedFileDTO> attachedFiles) {
		this.attachedFiles = attachedFiles;
	}

	/**
	 * @param cardId the cardId to set
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	/**
	 * @param cardLost the cardLost to set
	 */
	public void setCardLost(Boolean cardLost) {
		this.cardLost = cardLost;
	}

	/**
	 * @param customerIKpi the customerIKpi to set
	 */
	public void setCustomerIKpi(String customerIKpi) {
		this.customerIKpi = customerIKpi;
	}

	/**
	 * @param factsSummary the factsSummary to set
	 */
	public void setFactsSummary(String factsSummary) {
		this.factsSummary = factsSummary;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * @param notifMail the notifMail to set
	 */
	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}

	/**
	 * @param notifPush the notifPush to set
	 */
	public void setNotifPush(Boolean notifPush) {
		this.notifPush = notifPush;
	}

	/**
	 * @param notifSMS the notifSMS to set
	 */
	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<DisputeDataOperationDTO> operations) {
		this.operations = operations;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @param telematicId the telematicId to set
	 */
	public void setTelematicId(String telematicId) {
		this.telematicId = telematicId;
	}

	/**
	 * @param topMailModified the topMailModified to set
	 */
	public void setTopMailModified(Boolean topMailModified) {
		this.topMailModified = topMailModified;
	}

	/**
	 * @param topPhoneNumberModified the topPhoneNumberModified to set
	 */
	public void setTopPhoneNumberModified(Boolean topPhoneNumberModified) {
		this.topPhoneNumberModified = topPhoneNumberModified;
	}


}
