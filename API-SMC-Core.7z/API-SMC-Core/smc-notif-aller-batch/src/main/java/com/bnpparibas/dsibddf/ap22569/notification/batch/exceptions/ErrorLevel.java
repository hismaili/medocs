package com.bnpparibas.dsibddf.ap22569.notification.batch.exceptions;

public enum ErrorLevel {
    ERROR, WARN


}
