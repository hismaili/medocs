/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc;

/**
 * @author c65344
 *
 */
public class FieldErrors {
	private String field;
	private String message;
	private String objectName;
	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @return the objectName
	 */
	public String getObjectName() {
		return objectName;
	}
	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @param objectName the objectName to set
	 */
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
}
