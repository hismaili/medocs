package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.List;

/**
 *
 * @author c65344
 *
 */

public class DocumentSmc {
	@XStreamAlias("typeDoc")
	private String typeDoc;

	private List<Metadonnee> metadonnees;

	@XStreamAlias("donnee_utilisateur")
	private String donneUtilisateur;

	@XStreamAlias("DOCID")
	private String docIdGdn;


	/**
	 * @return the docIdGdn
	 */
	public String getDocIdGdn() {
		return docIdGdn;
	}

	/**
	 * @return the donneUtilisateur
	 */
	public String getDonneUtilisateur() {
		return donneUtilisateur;
	}
	/**
	 * @return the metadonnees
	 */
	public List<Metadonnee> getMetadonnees() {
		return metadonnees;
	}
	/**
	 * @return the typeDoc
	 */
	public String getTypeDoc() {
		return typeDoc;
	}


	/**
	 * @param docIdGdn the docIdGdn to set
	 */
	public void setDocIdGdn(String docIdGdn) {
		this.docIdGdn = docIdGdn;
	}
	/**
	 * @param donneUtilisateur the donneUtilisateur to set
	 */
	public void setDonneUtilisateur(String donneUtilisateur) {
		this.donneUtilisateur = donneUtilisateur;
	}
	/**
	 * @param metadonnees the metadonnees to set
	 */
	public void setMetadonnees(List<Metadonnee> metadonnees) {
		this.metadonnees = metadonnees;
	}

	/**
	 * @param typeDoc the typeDoc to set
	 */
	public void setTypeDoc(String typeDoc) {
		this.typeDoc = typeDoc;
	}
}
