package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "Carte_Alias")
@GenericGenerator(name = "SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class AnonymizedCardEntity extends AbstractEntity<DefaultEntityId> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column
	private String cardId;
	@Column
	private String maskedPan;
	@Column
	private String numCompte;
	@Column
	private String pan;
	@Column
	private String ikpi;
	@Column
	private LocalDate dateFinValidite;
	@Column
	private String statutCarte;
	@Column
	private LocalDate dateOpposition;
	@Column
	private LocalDate dateCloture;
	@Column
	private String typeProduit;

	@Column
	private String codeMotifOpposition;
	@Column
	private String libelleMotifOpposition;
	/**
	 * @return the cardId
	 */
	public String getCardId() {
		return cardId;
	}
	/**
	 * @return the codeMotifOpposition
	 */
	public String getCodeMotifOpposition() {
		return codeMotifOpposition;
	}
	/**
	 * @return the dateCloture
	 */
	public LocalDate getDateCloture() {
		return dateCloture;
	}
	/**
	 * @return the dateFinValidite
	 */
	public LocalDate getDateFinValidite() {
		return dateFinValidite;
	}
	/**
	 * @return the dateOpposition
	 */
	public LocalDate getDateOpposition() {
		return dateOpposition;
	}
	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}
	/**
	 * @return the libelleMotifOpposition
	 */
	public String getLibelleMotifOpposition() {
		return libelleMotifOpposition;
	}
	/**
	 * @return the maskedPan
	 */
	public String getMaskedPan() {
		return maskedPan;
	}
	/**
	 * @return the numCompte
	 */
	public String getNumCompte() {
		return numCompte;
	}
	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}
	/**
	 * @return the statutCarte
	 */
	public String getStatutCarte() {
		return statutCarte;
	}
	/**
	 * @return the typeProduit
	 */
	public String getTypeProduit() {
		return typeProduit;
	}
	/**
	 * @param cardId the cardId to set
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	/**
	 * @param codeMotifOpposition the codeMotifOpposition to set
	 */
	public void setCodeMotifOpposition(String codeMotifOpposition) {
		this.codeMotifOpposition = codeMotifOpposition;
	}
	/**
	 * @param dateCloture the dateCloture to set
	 */
	public void setDateCloture(LocalDate dateCloture) {
		this.dateCloture = dateCloture;
	}
	/**
	 * @param dateFinValidite the dateFinValidite to set
	 */
	public void setDateFinValidite(LocalDate dateFinValidite) {
		this.dateFinValidite = dateFinValidite;
	}
	/**
	 * @param dateOpposition the dateOpposition to set
	 */
	public void setDateOpposition(LocalDate dateOpposition) {
		this.dateOpposition = dateOpposition;
	}
	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}
	/**
	 * @param libelleMotifOpposition the libelleMotifOpposition to set
	 */
	public void setLibelleMotifOpposition(String libelleMotifOpposition) {
		this.libelleMotifOpposition = libelleMotifOpposition;
	}
	/**
	 * @param maskedPan the maskedPan to set
	 */
	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}
	/**
	 * @param numCompte the numCompte to set
	 */
	public void setNumCompte(String numCompte) {
		this.numCompte = numCompte;
	}
	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	/**
	 * @param statutCarte the statutCarte to set
	 */
	public void setStatutCarte(String statutCarte) {
		this.statutCarte = statutCarte;
	}
	/**
	 * @param typeProduit the typeProduit to set
	 */
	public void setTypeProduit(String typeProduit) {
		this.typeProduit = typeProduit;
	}


}
