/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.DetailOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.PDFRequestDonneesMaquette;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.PDFRequestDonneesMaquetteChampsLibres;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.DisputeData;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.DisputeDataOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


/**
 * @author c65344
 *
 */
@Service
public class ControlBuilder {

	private static final String MAQUETTEIDINCOORECT = "La MaquetteID est incoorect";
	private static final String FICHEDELIAISON = "trby9lia";
	private static final String FORMRETRAIT = "trby9ret";
	private static final String FORMPAYEMENT = "trby9pai";
	private static final String CLOTURE = "trby9clo";
	private static final String GENERIQUE = "trby9gen";
	private static final String CONTESTATAION = "trby9con";
	private static final String PATTERNDATE = "dd/MM/yyyy";
	private static final Logger LOG = LoggerFactory
			.getLogger(ControlBuilder.class);
	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$

	private static final String NULLVALUE = null;
	@Autowired
	private transient ConfigExposition conf;


	boolean a;

	/**
	 * check if data is null or empty
	 *
	 * @param data
	 * @param libelle
	 * @param listToadd
	 */
	protected String addError(String data, String libelle){

		if(StringUtils.isEmpty(data)){
			return libelle;
		}else{
			return null;
		}

	}

	/**
	 *
	 * @param disputeData
	 * @return
	 */
	public List<String> checkCreateDispute(DisputeData disputeData,String telematicId,String userId,String channel,String applicationCode){

		List<String> errors = new ArrayList<>();

		if(disputeData !=null){
			if(StringUtils.isEmpty(disputeData.getCardId())){
				errors.add(conf.getCardIdAbsent());
			}

			if(StringUtils.isEmpty(disputeData.getReason())){
				errors.add(conf.getReasonAbsent());
			}

			List<DisputeDataOperations> operations = disputeData.getOperations();
			if(CollectionUtils.isEmpty(operations)){
				errors.add(conf.getOperationsAbsent());
			}else{
				List<String> errorOperations = operations
						.stream()
						.filter(oper -> StringUtils.isEmpty(oper.getCodeOperation()) || oper.getRecognizedAmount() ==null)
						.map(oper -> "error")
						.collect(Collectors.toList());

				if(!CollectionUtils.isEmpty(errorOperations)){
					errors.add(conf.getCodeOrMountOpeAbsent());
				}
			}



		}else{
			errors.add(conf.getOperationsAbsent());
			errors.add(conf.getReasonAbsent());
			errors.add(conf.getCardIdAbsent());
		}


		if(StringUtils.isEmpty(telematicId)){
			errors.add(conf.getTelematicIdAbsent());
		}

		if(StringUtils.isEmpty(userId)){
			errors.add(conf.getUserIdAbsent());
		}

		return errors;
	}



	/**
	 * Verifie la donnée canal les valeur posibbles sont :{1,2,3,4,5,6}
	 *
	 *
	 * @param channel
	 * @param errorList
	 */
	private String checkDonneCanal(String channel){

		boolean isNiceFormat = false;
		if(channel !=null){
			for(int i = 1; i <= 6; i++){
				if(String.valueOf(i).equals(channel)){
					isNiceFormat = true;
				}
			}
		}
		if(!isNiceFormat){
			return conf.getCanalMauvaisFormat();
		}else{
			return null;
		}
	}


	/**
	 * La carte bancaire ne doit avoir que 16 ou 19 caracteres
	 *
	 * @param date
	 * @param numcarte
	 * @param errorList
	 */
	public String checkFormatCarte(String numcarte) {
		if(numcarte!=null && (numcarte.length() != 16 && numcarte.length() !=19)){
			LOG.error("DANGER : "+conf.getFormatCarteBancaireError());
			return conf.getFormatCarteBancaireError();
		}else{
			return null;
		}
	}

	/**
	 * La Date doit etre sous le format dd/MM/yyyy
	 *
	 * @param valeur
	 * @param errorList
	 */
	public String checkFormatDate(String valeur,String name) {
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); //$NON-NLS-1$
		if(!StringUtils.isEmpty(valeur)){
			try {
				date = sdf.parse(valeur);
				if (valeur.equals(sdf.format(date))) {
					valeur = sdf.format(date);
				}

			} catch (Exception e) {
				LOG.error(e.getMessage(), e);
				return conf.getFormatDateError()+" pour la donnée "+name;
			}
		}
		return null;
	}

	/**
	 * verifie si le documentypeId est l'une des donnée attendu
	 *
	 * @param documentTypeId
	 * @param errorList
	 */
	public void checkFormatDocumentTypeId(String documentTypeId,List<String> errorList){
		if(documentTypeId !=null){
			if ( !documentTypeId.equals(conf.getCodeTypeDocumentContestation()) &&  !documentTypeId.equals(conf.getCodeTypeDocumentJustificatif())) {
				errorList.add(conf.getMessageErrorIdTypeDocument());
			}
		}
	}


	/**
	 * verification des formats : seulement application/pdf et application/jpg
	 *
	 * @param mimeType
	 * @param listFormat
	 */
	public void checkFormatMimeType(String mimeType,List<String> listFormat){
		if(mimeType !=null){
			if(!mimeType.equals(conf.getMimeTypeformat1()) && !mimeType.equals(conf.getMimeTypeformat2())){
				listFormat.add(conf.getMimeTypeErrorFormat());
			}
		}
	}

	/**
	 * check if data is null or empty
	 *
	 * @param data
	 * @param libelle
	 * @param ErrorToAdd
	 */
	public void checkMandatoryFields(String data, String libelle, List<String> errorToAdd) {

		if (StringUtils.isEmpty(data)) {
			errorToAdd.add(libelle);
		}
	}

	/**
	 * verifie les erreurs non UI
	 *
	 * @param canal
	 * @param libelleNature
	 * @param numeroCarteMasque
	 * @param numDossier
	 * @param listParagraphes
	 * @return
	 */
	public List<String> checkMandatoryNoUI(String maquette,
			String adresseEmeteur, String numeroCarteMasque, String datamatrix,
			String libelleNature, String dateTraitement, String canal) {

		List<String> errorList2 = new ArrayList<>();

		checkMandatoryFields(canal, conf.getCanalAbsent(), errorList2);
		checkMandatoryFields(libelleNature, conf.getLibnatureManquante(), errorList2);
		checkMandatoryFields(numeroCarteMasque, conf.getNumcartemasqueManquante(),
				errorList2);

		checkMandatoryFields(adresseEmeteur, conf.getAdresseEmeteurManquant(), errorList2);
		checkMandatoryFields(maquette, conf.getMaquetteManquante(), errorList2);
		checkMandatoryFields(datamatrix, conf.getDatamaTrixManquante(), errorList2);
		checkMandatoryFields(dateTraitement, conf.getDateDetraitementManquant(), errorList2);

		return errorList2;
	}


	/**
	 * verifie les erreurs UI
	 *
	 * @param numDossier
	 * @param telEmeteur
	 * @param numCarte
	 * @param listParagraphes
	 * @return
	 */
	public List<String> checkMandatoryUI(String numDossier, String telEmeteur,
			String numCarte, List<PDFRequestDonneesMaquetteChampsLibres> listParagraphes) {

		List<String> errorList = new ArrayList<>();

		checkMandatoryFields(numDossier, conf.getNumdossierManquante(), errorList);
		checkMandatoryFields(telEmeteur, conf.getTelEmeteurManquant(), errorList);
		checkMandatoryFields(numCarte, conf.getNumCarteManquante(), errorList);

		if (listParagraphes == null || listParagraphes.isEmpty()) {
			errorList.add(conf.getListeparagrapheManquante());
		}

		return errorList;
	}


	/**
	 * recuperer la date au format dd/MM/YYYY
	 *
	 * @param dateEditique
	 * @return
	 *
	 */
	private boolean isInBadFormat(String dateEditique) {

		SimpleDateFormat sdf = new SimpleDateFormat(PATTERNDATE);

		try {
			Date date = sdf.parse(dateEditique);
			return false;

		} catch (ParseException e) {
			LOG.error(e.getMessage(), e);
			return true;
		}
	}


	/**
	 *  Validation de la taille de l'ensemble des données à de snedata
	 *
	 * @param donneesMaquette
	 * @return
	 */
	public List<String> validateDataPDFIncorrect(PDFRequestDonneesMaquette donneesMaquette,String canal,String maquetteID) {


		List<String> dataIncorrects = new ArrayList<>();
		List<DataTocheck> dataTochecks = Arrays.asList(
				new DataTocheck(donneesMaquette.getDateTraitement(), 10, conf.getDateTraitementIncorrect()),
				new DataTocheck(donneesMaquette.getIdUser(),255, conf.getIdUserIncorrect()),
				new DataTocheck(donneesMaquette.getQualificationDossier(),1, conf.getQualificationDossierIncorrect()),
				new DataTocheck(donneesMaquette.getNatureDossier(),3, conf.getNatureDossierIncorrect()),
				new DataTocheck(donneesMaquette.getNatureDossierLibelle(),255, conf.getNatureDossierLibelleAbsent()),
				new DataTocheck(donneesMaquette.getNumDossier(),16, conf.getNumDossierIncorrect()),
				new DataTocheck(donneesMaquette.getDateAppel(),10, conf.getDateAppelIncorrect()),
				new DataTocheck(donneesMaquette.getTelephoneEmet(), 16, conf.getTelephoneEmetIncorrect()),
				new DataTocheck(donneesMaquette.getEmailEmet(), 100, conf.getEmailEmetIncorrect()),
				new DataTocheck(donneesMaquette.getDateOpposition(),10, conf.getDateOppositionIncorrect()),
				new DataTocheck(donneesMaquette.getCodeChefdefileemet(),5, conf.getCodeChefdefileemetIncorrect()),
				new DataTocheck(donneesMaquette.getContactEmet(),511, conf.getContactEmetIncorrect()),
				new DataTocheck(donneesMaquette.getFaxEmet(),11, conf.getFaxEmetIncorrect()),
				new DataTocheck(donneesMaquette.getCodeChefdefiledest(),5, conf.getCodeChefdefiledestIncorrect()),
				new DataTocheck(donneesMaquette.getContactDest(),101, conf.getContactDestIncorrect()),
				new DataTocheck(donneesMaquette.getTelephoneDest(),16, conf.getTelephoneDestIncorrect()),
				new DataTocheck(donneesMaquette.getFaxDest(), 16, conf.getFaxDestIncorrect()),
				new DataTocheck(donneesMaquette.getEmailDest(),100, conf.getEmailDestIncorrect()),
				new DataTocheck(donneesMaquette.getTypeOperation(),255, conf.getTypeOperationIncorrect()),
				new DataTocheck(donneesMaquette.getCodebanqueMempracc(),5, conf.getCodebanqueMempraccIncorrect()),
				new DataTocheck(donneesMaquette.getCodebanqueDom(),5, conf.getCodebanqueDomIncorrect()),
				new DataTocheck(donneesMaquette.getNumDistributeur(),14, conf.getNumDistributeurIncorrect()),
				new DataTocheck(donneesMaquette.getLocDepart(),32, conf.getLocDepartIncorrect()),
				new DataTocheck(donneesMaquette.getCodebanqueMemprtit(),5, conf.getCodebanqueMemprtitIncorrect()),
				new DataTocheck(donneesMaquette.getNumCarteMasque(),19, conf.getNumCarteMasqueIncorrect()),
				new DataTocheck(donneesMaquette.getCodeMotifipaye(),255, conf.getCodeMotifipayeIncorrect()),
				new DataTocheck(donneesMaquette.getMontantCompense(),23, conf.getMontantCompenseIncorrect()),
				new DataTocheck(donneesMaquette.getDateheureTransaction(),16, conf.getDateheureTransactionIncorrect()),
				new DataTocheck(donneesMaquette.getDateReglmntinitial(),10, conf.getDateReglmntinitialIncorrect()),
				new DataTocheck(donneesMaquette.getAutresDonnees(),255, conf.getAutresDonneesIncorrect()),
				//new DataTocheck(donneesMaquette.getTypeReglmntsouhaite(),22, conf.getTypeReglmntsouhaiteIncorrect()),
				new DataTocheck(donneesMaquette.getNumSiret(), 14, conf.getNumSiretIncorrect()),
				new DataTocheck(donneesMaquette.getCodeApe(),4, conf.getCodeApeIncorrect()),
				new DataTocheck(donneesMaquette.getDateRglmntimpaye(), 10, conf.getDateRglmntimpayeIncorrect()),
				new DataTocheck(donneesMaquette.getDateRglmntrepres(), 10, conf.getDateRglmntrepresIncorrect()),
				new DataTocheck(donneesMaquette.getReferenceArchivage(),255, conf.getReferenceArchivageIncorrect()),
				new DataTocheck(donneesMaquette.getMontantBrut() ,23, conf.getMontantBrutIncorrect()),
				new DataTocheck(donneesMaquette.getNumClient(),20, conf.getNumClientIncorrect()),
				new DataTocheck(donneesMaquette.getDateCreationSmc(),10, conf.getDateCreationIncorrect()),
				new DataTocheck(donneesMaquette.getMontantConteste(),23, conf.getMontantContesteIncorrect()),

				new DataTocheck(donneesMaquette.getTelephoneEmet(),16, conf.getTelephoneEmetIncorrect()));

		boolean isMaquetteCorrect = false;

		List<String> idMaquettes = Arrays.asList(FICHEDELIAISON,FORMRETRAIT,FORMPAYEMENT,CLOTURE,GENERIQUE,CONTESTATAION);

		for(String idMaquette : idMaquettes){
			if(idMaquette.equals(maquetteID)){
				isMaquetteCorrect = true;
			}
		}


		if(!isMaquetteCorrect){
			dataIncorrects.add(MAQUETTEIDINCOORECT);
		}

		if(!CollectionUtils.isEmpty(dataTochecks)){

			List<String> dataToCheckIncorrect = dataTochecks.stream().
					filter(obj -> !StringUtils.isEmpty(obj.getData()) &&  !(obj.getData().length() <= obj.getLength())).
					map(obj -> obj.getLibelle())
					.collect(Collectors.toList());

			if(String.valueOf(donneesMaquette.getNombreOperations()).length() > 5 && donneesMaquette.getNombreOperations() !=0){
				dataToCheckIncorrect.add(conf.getNombreOperationsIncorrect());
			}

			if(String.valueOf(donneesMaquette.getTotalOperations()).length() > 19 && donneesMaquette.getTotalOperations() !=0){
				dataToCheckIncorrect.add(conf.getTotalOperationsIncorrect());
			}

			if(String.valueOf(donneesMaquette.getDelaisReponse()).length() > 2 && donneesMaquette.getDelaisReponse() !=0){
				dataToCheckIncorrect.add(conf.getDelaisReponseIncorrect());
			}


			if(!CollectionUtils.isEmpty(dataToCheckIncorrect)){
				dataIncorrects.addAll(dataToCheckIncorrect);
			}

		}

		if(!StringUtils.isEmpty(checkDonneCanal(canal))){
			dataIncorrects.add(checkDonneCanal(canal));
		}

		List<String> tabPs =donneesMaquette.getPostScriptum() ;

		List<DetailOperation> tabContest = donneesMaquette.getDetailsOperations();

		List<String> tabCommentaires = donneesMaquette.getComent();


		List<PDFRequestDonneesMaquetteChampsLibres> champsLibres = donneesMaquette.getChampsLibres();
		List<String> champsIncorrect = new ArrayList<>();
		if(!CollectionUtils.isEmpty(champsLibres)){
			champsLibres.stream().filter(champ -> champ !=null).forEach(paragraphe -> {
				champsIncorrect.addAll(paragraphe.getPhrases().stream().filter(phrase -> phrase !=null && !StringUtils.isEmpty(phrase.getTextPhrase()) && !(phrase.getTextPhrase().length() <= 850))
						.map( phrase -> phrase.getTextPhrase())
						.collect(Collectors.toList()));
			});

		}

		if(!CollectionUtils.isEmpty(champsIncorrect)){
			dataIncorrects.add(conf.getNombreDeCaractereDeLigneIncorrect());
		}



		if(!CollectionUtils.isEmpty(tabCommentaires)){

			List<String> lineIncorrects = tabCommentaires.stream().filter(obj -> !StringUtils.isEmpty(obj) && !(obj.length() <= 850))
					.map(obj -> obj)
					.collect(Collectors.toList());

			if(!CollectionUtils.isEmpty(lineIncorrects)){
				dataIncorrects.add(conf.getNombreDeCaractereDeLigneIncorrect());
			}

			if(!(tabCommentaires.size() <= 1000)){
				dataIncorrects.add(conf.getNombreDeLigneIncorect());
			}

		}

		if(!CollectionUtils.isEmpty(tabPs)){

			List<String> lineIncorrects = tabPs.stream().filter(obj -> !StringUtils.isEmpty(obj) && !(obj.length() <= 850))
					.map(obj -> obj)
					.collect(Collectors.toList());

			if(!CollectionUtils.isEmpty(lineIncorrects)){
				dataIncorrects.add(conf.getNombreDeCaractereDeLigneIncorrect());
			}

			if(!(tabPs.size() <= 1000)){
				dataIncorrects.add(conf.getNombreDeLigneIncorect());
			}

		}


		if(!CollectionUtils.isEmpty(tabContest)){

			List<DetailOperation> lineIncorrects = tabContest.stream().filter(obj -> (!StringUtils.isEmpty(obj.getDateCompensation()) &&  !(obj.getDateCompensation().length() <= 10))
					&& (!StringUtils.isEmpty(obj.getDateVente()) && !(obj.getDateVente().length() <= 10))
					&& (!StringUtils.isEmpty(obj.getRaisonSociale()) && !(obj.getRaisonSociale().length() <= 32)))
					.map(obj -> obj)
					.collect(Collectors.toList());


			List<String> dateBadFormatOperation = tabContest
					.stream()
					.filter(obj -> isInBadFormat(obj.getDateCompensation()) || isInBadFormat(obj.getDateVente()))
					.map(obj -> "error format date")
					.collect(Collectors.toList());

			if(!CollectionUtils.isEmpty(dateBadFormatOperation)){
				dataIncorrects.add("Dans l'ensemble des opérations , "+conf.getFormatDateError());
			}


			if(!CollectionUtils.isEmpty(lineIncorrects)){
				dataIncorrects.add(conf.getNombreDeCaractereDeLigneIncorrect());
			}

			if(!(tabContest.size() <= 1000)){
				dataIncorrects.add(conf.getNombreDeLigneIncorect());
			}

		}






		return dataIncorrects;
	}
}



class DataTocheck{

	private String data;
	private int length;
	private String libelle;
	/**
	 *
	 */
	public DataTocheck() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param data
	 * @param length
	 * @param libelle
	 */
	public DataTocheck(String data, int length, String libelle) {
		this.data = data;
		this.length = length;
		this.libelle = libelle;
	}
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @return the length
	 */
	public int getLength() {
		return length;
	}
	/**
	 * @return the libelle
	 */
	public String getLibelle() {
		return libelle;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @param length the length to set
	 */
	public void setLength(int length) {
		this.length = length;
	}
	/**
	 * @param libelle the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}



}

