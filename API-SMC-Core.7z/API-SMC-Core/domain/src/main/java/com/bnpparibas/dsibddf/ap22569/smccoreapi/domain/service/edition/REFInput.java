package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 *
 * @author c65344
 *
 */
public class REFInput {
	private String maquette;

	private String datamatrix;

	/**
	 *
	 */
	public REFInput() {
		super();
	}

	/**
	 * @param maquette
	 * @param datamatrix
	 */
	public REFInput(String maquette, String datamatrix) {
		this.maquette = maquette;
		this.datamatrix = datamatrix;
	}

	/**
	 * @return the datamatrix
	 */
	public String getDatamatrix() {
		return datamatrix;
	}

	/**
	 * @return the maquette
	 */
	public String getMaquette() {
		return maquette;
	}

	/**
	 * @param datamatrix the datamatrix to set
	 */
	public void setDatamatrix(String datamatrix) {
		this.datamatrix = datamatrix;
	}

	/**
	 * @param maquette the maquette to set
	 */
	public void setMaquette(String maquette) {
		this.maquette = maquette;
	}
}
