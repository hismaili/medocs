package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import brave.Tracer;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.edition.IEditionManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.EditingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.RequestEditiqueOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.SmcEditionException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.GeneratePDFRequest;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.EditionResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcApiError;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcResponseError;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

@RestController
@Validated
@RequestMapping("/v1/contestation/edition")
@Api(tags = {"API édition de courrier pour la contestation monétique"})
public class EditionController {

	private static final String STRING = " : ";
	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$
	private static final String ERROR = "ERREUR INTERNE DU SERVEUR"; //$NON-NLS-1$

	private static final String NULLVALUE = null;
	private static final Logger LOG = LoggerFactory.getLogger(EditionController.class);
	@Autowired
	private transient ControlBuilder control;
	@Autowired
	private transient Tracer tracer;
	@Autowired
	private transient IEditionManagement ieditionManagement;

	@Autowired
	private transient BuilderResponseSmc builderResponse;

	@Autowired
	private transient ConfigExposition conf;
	@Autowired
	private transient EditionErrorBuilder errorBuilder;
	@Autowired
	private transient EditionMaper editionMapper;

	/**
	 * produir un PDF en base64, des informations concernant le producteur et une variable exception.
	 *
	 * La donnée snedest est uniquement rempli dans la couche application avec RP.
	 *
	 * La donnée bpfne est uniquement rempli dans la couche application avec RP
	 *
	 * La donnée sneemet est rempli en partie dans exposition et dans le mapping de infrastructure grace aux données de la conf
	 *
	 * La donnée sneagce n'est rempli null part a cause de la regle de gestion
	 *
	 * La donnée sneattr est rempli en partie dans exposition pour la date de traitement et dans le mapping de infrastructure a partir des données de la conf
	 *
	 * La donnée snetech est rempli uniquement dans le mapping infrastructure
	 *
	 * La donnée snemaquette est rempli uniquement dans exposition
	 *
	 * @param infoDocument
	 * @return
	 */
	@ApiOperation(value = "", nickname = "edition", notes = "produir un PDF en base64, des informations concernant le producteur et une variable exception.", response = ArchivageResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Document édité", response = EditionResponse.class),
			@ApiResponse(code = 201, message = "Demande accepter", response = EditionResponse.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class)

	})

	@RequestMapping(value = "/document" ,produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
	public  ResponseEntity generateDocumentPDF(@ApiParam(value = "canal d’appel d’origine. Valeurs possibles 1 a 6 (1 = Agence, 2 = CRC, 3 = Web, 4 = PFNE, 5 = Mobile, 6 = CRPE)" ,required=true, allowableValues="1, 2, 3, 4, 5, 6") @RequestHeader(value="Channel", required=false) String channel, @ApiParam(value = "code de l'application appelante" ,required=true) @RequestHeader(value="codeApplication", required=false) String codeApplication, @ApiParam(value = "Les donnees permettant de generer le pdf chez l editique" ,required=true ) @RequestBody(required=false) GeneratePDFRequest infoDocument, @ApiParam(value = "Identifiant de correlation propage vers tous les services concernes par l’interaction." ) @RequestHeader(value="X-B3-TraceId", required=false) String xB3TraceId, @ApiParam(value = "id de correlation echange entre appelant et appele." ) @RequestHeader(value="X-B3-SpanId", required=false) String xB3SpanId){

		try {

			errorBuilder.checkError(infoDocument, channel);

			RequestEditiqueOutput responsePDF = ieditionManagement.getDocumentPDF(editionMapper.map(infoDocument, channel));

			if (responsePDF == null) {
				return new ResponseEntity<>(HttpStatus.ACCEPTED);
			}else{
				return new ResponseEntity<EditionResponse>(new EditionResponse(responsePDF.getPdfresult(),responsePDF.getFileType()), HttpStatus.OK);
			}


		} catch (MandatoryException e) {
			LOG.error(conf.getErrorGeneriqueAbsent(), e);
			/**
			 * donnée absente
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		} catch (FormatErrorException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée au mauvais format
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeFormatIncorrect(), conf.getErrorGeneriqueIncorect(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		} catch (DonneIncorectException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée incorecte
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeDonneIncorrect(), conf.getErrorGeneriqueIncorect(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		} catch (EditingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeErreurServeurEdition(), conf.getErrorGeneriqueInterne(), Arrays.asList(e.getMessage())))),HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (SmcEditionException e) {
			/**
			 * Erreur technique
			 */
			LOG.error(e.getMessage(),e);
			SmcResponseError smcResponseError = builderResponse.getResponseSmcError(e.getFormatIncorrect(),e.getDonnesAbsentUI(),e.getDonnesAbsentNoUI(),e.getDonnesIncorrect());
			return new ResponseEntity (smcResponseError,HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));

		}

	}

}
