/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare.AttachmentDataInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.MotifContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Service
public class MandatoryBuilder {
	private static final Logger LOG = LoggerFactory
			.getLogger(MandatoryBuilder.class);
	@Autowired
	private ConfigInfrastructure conf;

	/**
	 * check if data of Attachment documents is null or empty
	 *
	 * @param attachmentData
	 * @return
	 */
	protected List<String> checkAttachment(AttachmentDataInput attachmentData) {
		List<String> mandatory = null;

		if (attachmentData != null) {

			if (StringUtils.isEmpty(attachmentData.getFileIdSMC())) {
				mandatory = new ArrayList<>();
				mandatory.add(conf.getNumdossierManquante());
			}

			if (CollectionUtils.isEmpty(attachmentData.getDocuments())) {
				if (CollectionUtils.isEmpty(mandatory)) {
					mandatory = new ArrayList<>();
				}
				mandatory.add(conf.getListeIdDocsAbsent());
			}

		} else {
			mandatory = new ArrayList<>();
			mandatory.add(conf.getNumdossierManquante());
			mandatory.add(conf.getListeIdDocsAbsent());
		}

		return mandatory;
	}

	/**
	 * check a data mandatory of create dispute folder of SMC
	 *
	 * @param dispute
	 * @return
	 */
	protected List<String> checkMandatoryDisputInput(Contestation dispute) {
		List<String> dataMandatoty = null;

		if (dispute != null) {
			List<String> dataMandatoty1 = new ArrayList<>();
			dataMandatoty1.add(checkMandatoty(dispute.getNumCompte(),conf.getBankNumberAbsent()));
			dataMandatoty1.add(checkMandatoty(dispute.getNumCarte(), conf.getCardNumberAbsent()));
			if(dispute.getNotifMail()) {
				dataMandatoty1.add(checkMandatoty(dispute.getMail(), conf.getMailAbsent()));
			}
			if(dispute.getNotifSMS()) {
				dataMandatoty1.add(checkMandatoty(dispute.getNumeroTel(), conf.getPhoneAbsent()));
			}

			dataMandatoty = dataMandatoty1.stream()
					.filter(err -> !StringUtils.isEmpty(err)).collect(Collectors.toList());

			MotifContestation motif = dispute.getMotif();
			if (motif == null || motif.getCode() ==null) {
				if (CollectionUtils.isEmpty(dataMandatoty)) {
					dataMandatoty = new ArrayList<>();
				}
				dataMandatoty.add(conf.getNatureAbsent());
				dataMandatoty.add(conf.getQualificationAbsent());
			}


			if (CollectionUtils.isEmpty(dispute.getOperations())) {
				if (CollectionUtils.isEmpty(dataMandatoty)) {
					dataMandatoty = new ArrayList<>();
				}
				dataMandatoty.add(conf.getOperationsAbsent());
			}
		} else {
			dataMandatoty = new ArrayList<>();

			dataMandatoty.add(conf.getOperationsAbsent());
			dataMandatoty.add(conf.getListeIdDocsAbsent());
			dataMandatoty.add(conf.getQualificationAbsent());
			dataMandatoty.add(conf.getNatureAbsent());
			dataMandatoty.add(conf.getPhoneAbsent());
			dataMandatoty.add(conf.getMailAbsent());
			dataMandatoty.add(conf.getCardNumberAbsent());
			dataMandatoty.add(conf.getBankNumberAbsent());
		}

		return dataMandatoty;
	}



	/**
	 * check if data is null or empty
	 *
	 * @param data
	 * @param libelle
	 * @return
	 */
	protected String checkMandatoty(String data, String libelle) {
		if (StringUtils.isEmpty(data)) {
			LOG.error(libelle);
			return libelle;
		}
		return null;
	}

}
