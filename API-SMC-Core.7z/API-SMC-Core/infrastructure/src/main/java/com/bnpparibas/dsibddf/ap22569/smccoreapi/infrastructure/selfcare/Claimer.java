/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author c65344
 *
 */
public class Claimer {
	@JsonProperty("email")
	private String mail;

	@JsonProperty("phoneReference")
	private String phone;

	@JsonProperty("phoneCountryCode")
	private String phoneCountryCode;

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @return the phoneCountryCode
	 */
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @param phoneCountryCode the phoneCountryCode to set
	 */
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}
}
