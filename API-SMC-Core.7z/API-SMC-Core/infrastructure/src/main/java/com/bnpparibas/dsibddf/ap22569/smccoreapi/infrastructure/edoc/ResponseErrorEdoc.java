/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc;

import java.util.List;

/**
 * @author c65344
 *
 */
public class ResponseErrorEdoc {
	private String message;
	private String description;
	private List<FieldErrors> fieldErrors;
	private List<GlobalErrors> globalErrors;
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @return the fieldErrors
	 */
	public List<FieldErrors> getFieldErrors() {
		return fieldErrors;
	}
	/**
	 * @return the globalErrors
	 */
	public List<GlobalErrors> getGlobalErrors() {
		return globalErrors;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @param fieldErrors the fieldErrors to set
	 */
	public void setFieldErrors(List<FieldErrors> fieldErrors) {
		this.fieldErrors = fieldErrors;
	}
	/**
	 * @param globalErrors the globalErrors to set
	 */
	public void setGlobalErrors(List<GlobalErrors> globalErrors) {
		this.globalErrors = globalErrors;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
