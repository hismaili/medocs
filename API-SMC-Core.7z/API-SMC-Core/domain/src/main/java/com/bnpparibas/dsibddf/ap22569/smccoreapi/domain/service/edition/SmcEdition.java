/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 * @author c65344
 *
 */
public class SmcEdition {
	private String idGdn;
	private String idDocSmc;
	/**
	 * @return the idDocSmc
	 */
	public String getIdDocSmc() {
		return idDocSmc;
	}
	/**
	 * @return the idGdn
	 */
	public String getIdGdn() {
		return idGdn;
	}
	/**
	 * @param idDocSmc the idDocSmc to set
	 */
	public void setIdDocSmc(String idDocSmc) {
		this.idDocSmc = idDocSmc;
	}
	/**
	 * @param idGdn the idGdn to set
	 */
	public void setIdGdn(String idGdn) {
		this.idGdn = idGdn;
	}
}
