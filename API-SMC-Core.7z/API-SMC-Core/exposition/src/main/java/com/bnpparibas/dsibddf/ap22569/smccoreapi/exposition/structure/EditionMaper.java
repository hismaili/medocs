/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.*;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author c65344
 *
 */
@Component
public class EditionMaper {

	private static final String FICHEDELIAISON = "trby9lia";
	private static final String FORMRETRAIT = "trby9ret";
	private static final String FORMPAYEMENT = "trby9pai";
	private static final String CLOTURE = "trby9clo";
	private static final String GENERIQUE = "trby9gen";
	private static final String CONTESTATAION = "trby9con";
	private static final String EMPTY="";
	private static final String ZEROS="000";

	/**
	 * convertie la requette DTO editique en Requette Input
	 *
	 * @param infoDocument
	 * @return
	 */
	public RequestEditiqueInput map(GeneratePDFRequest infoDocument,String canal){
		RequestEditiqueInput request = new RequestEditiqueInput();
		Emeteur emeteur = new Emeteur();

		if(infoDocument !=null){
			GeneratePDFRequestMaquetteDef maquette = infoDocument.getMaquette();
			Boolean editiqueCentrale = maquette.getEditiqueCentrale();
			if(editiqueCentrale !=null){
				request.setEditiqueCentral(editiqueCentrale.booleanValue());
			}
			request.setCanal(canal);



			if(maquette !=null){

				PDFRequestMaquetteIdentification maquetteIdentification = maquette.getMaquetteIdentification();

				PDFRequestDonneesMaquette donneMaquette = maquette.getDonneesMaquette();


				if(donneMaquette !=null && maquetteIdentification !=null){


					/**
					 * recupération de toute les données de type String duDTO
					 */
					BeanUtils.copyProperties(donneMaquette, request);

					String numeroCarte = donneMaquette.getNumeroCarte();

					if(!StringUtils.isEmpty(numeroCarte)){
						/**
						 * suppression des espaces sur le numéro de carte
						 */
						numeroCarte = numeroCarte.replace(" ", "");

						if(numeroCarte.length() == 16){
							request.setNumeroCarte(ZEROS+numeroCarte);
						}else{
							request.setNumeroCarte(numeroCarte);
						}


					}


					String maquetteId = maquetteIdentification.getMaquette();

					if(CONTESTATAION.equals(maquetteId)){
						request.setTelephoneEmet(null);
						List<DetailOperation> operations = donneMaquette.getDetailsOperations();
						if(!CollectionUtils.isEmpty(operations)){
							request.setOperations(operations.stream().filter(opera -> opera.getMontantImpute() !=null ).map(operation -> {
								return new Operation(operation.getDateCompensation(),operation.getRaisonSociale(),operation.getDateVente(),operation.getMontantImpute().toString());
							}).collect(Collectors.toList()));
						}else{


							/**
							 * Evolution :Si demande d'édition Lettre de contestation sans opération, envoyer à l'éditique 10 opérations vides
							 */
							request.setOperations(Arrays.asList(new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY),
									new Operation(EMPTY, EMPTY,EMPTY,EMPTY)
									));
						}
					}

					if(GENERIQUE.equals(maquetteId)){
						request.setTelephoneEmet(null);
					}

					if(CLOTURE.equals(maquetteId)){
						request.setTelephoneEmet(null);
					}
					if(FICHEDELIAISON.equals(maquetteId)){
						request.setTelephoneEmet(null);
					}

					if(FORMPAYEMENT.equals(maquetteId)){
						request.setRaisonSociale("A renseigner");//TODO après l'évolution
					}

					request.setMaquetteId(maquetteId);
					emeteur.setAdresse(donneMaquette.getAdrRetour());
					emeteur.setTelephone(donneMaquette.getTelephoneEmet());
					request.setEmeteur(emeteur);
					request.setCommentaires(donneMaquette.getComent());
					request.setPs(donneMaquette.getPostScriptum());





					List<PDFRequestDonneesMaquetteChampsLibres> champsLibres = donneMaquette.getChampsLibres();

					if(!CollectionUtils.isEmpty(champsLibres)){
						request.setParagraphes(champsLibres.stream().map(paragraphe -> {
							List<Phrase> phrases = null;
							phrases = paragraphe.getPhrases().stream().
									map( phrase -> new Phrase(phrase.getIndexPhrase(),phrase.getTextPhrase()))
									.collect(Collectors.toList());
							return new Paragraphe(paragraphe.getIndexParagraphe(), phrases);
						}).collect(Collectors.toList()));

					}
				}
			}
		}
		return request;
	}
}
