package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.ExigenceAjoutInformation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

public final class MotifMapper {

    public static MotifContestation mapEntityToDomainBean(MotifEntity m) {
        if(m == null) {
            return  null;
        }
        MotifContestation mc = new MotifContestation();
        BeanUtils.copyProperties(m, mc);
        switch (m.getTypeOperationApplicable()) {
            case PAIEMENT:
                mc.setTypeOperationApplicable(TypeOperation.PAIEMENT);
                break;
            case RETRAIT:
                mc.setTypeOperationApplicable((TypeOperation.RETRAIT));
                break;
            default:
                mc.setTypeOperationApplicable(TypeOperation.LESDEUX);
                break;
        }
        Nature nature = new Nature();
        BeanUtils.copyProperties(m.getNatureContestation(), nature);
        mc.setNatureContestation(nature);
        Qualification qualification = new Qualification();
        BeanUtils.copyProperties(m.getQualificationContestation(), qualification);
        mc.setQualificationContestation(qualification);

        mc.setDisclaimerText(m.getTexteAvertissement());
        mc.setTopCardCancelled(m.isExigenceOppositionCarte());
        mc.setTopMentionFactDescription(ExigenceAjoutInformation.valueOf(m.getExigenceSaisieDescription().name()));
        mc.setTopMentionRecognizedAmount(m.isEcartMontant());

        List<DocumentJustificatif> documentsAssocies = null;
        final List<DocumentJustificatifEntity> documentAssociesEntity = m.getDocumentAssocies();
        if (!CollectionUtils.isEmpty(documentAssociesEntity)) {
            documentsAssocies = documentAssociesEntity.stream().map(doc -> {
                DocumentJustificatif docDto = null;
                if (doc != null) {
                    docDto = new DocumentJustificatif(doc.getLabelJustificatif(), doc.getTypeDocGDN());
                    BeanUtils.copyProperties(doc, docDto);
                }
                return docDto;
            }).collect(Collectors.toList());
        }
        mc.setDocumentAssocies(documentsAssocies);

        mc.setExigenceAttachement(ExigenceAjoutInformation.valueOf(m.getExigenceAttachement().name()));
        return mc;
    }

    public static List<MotifContestation> mapListEntitiesToListDomainBeans(List<MotifEntity> motifs) {
        List<MotifContestation> motifsR = motifs.stream().map(m -> MotifMapper.mapEntityToDomainBean(m)).collect(Collectors.toList());
        return motifsR;
    }

    public static MotifEntity mapDomainBeanToEntity(MotifContestation m) {
        MotifEntity mc = new MotifEntity();
        BeanUtils.copyProperties(m, mc);
        switch (m.getTypeOperationApplicable()) {
            case PAIEMENT:
                mc.setTypeOperationApplicable(TypeOperationEntity.PAIEMENT);
                break;
            case RETRAIT:
                mc.setTypeOperationApplicable((TypeOperationEntity.RETRAIT));
                break;
            default:
                mc.setTypeOperationApplicable(TypeOperationEntity.LESDEUX);
                break;
        }
        NatureEntity nature = new NatureEntity();
        BeanUtils.copyProperties(m.getNatureContestation(), nature);
        mc.setNatureContestation(nature);
        QualificationEntity qualification = new QualificationEntity();
        BeanUtils.copyProperties(m.getQualificationContestation(), qualification);
        mc.setQualificationContestation(qualification);

        mc.setTexteAvertissement(m.getDisclaimerText());
        mc.setExigenceOppositionCarte(m.getTopCardCancelled());
        mc.setExigenceSaisieDescription(com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ExigenceAjoutInformation.valueOf(m.getTopMentionFactDescription().name()));
        mc.setEcartMontant(m.getTopMentionRecognizedAmount());

        List<DocumentJustificatifEntity> documentsAssocies = null;
        final List<DocumentJustificatif> documentAssociesEntity = m.getDocumentAssocies();
        if (!CollectionUtils.isEmpty(documentAssociesEntity)) {
            documentsAssocies = documentAssociesEntity.stream().map(doc -> {
                DocumentJustificatifEntity docDto = null;
                if (doc != null) {
                    docDto = new DocumentJustificatifEntity();
                    BeanUtils.copyProperties(doc, docDto);
                }
                return docDto;
            }).collect(Collectors.toList());
        }
        mc.setDocumentAssocies(documentsAssocies);

        mc.setExigenceAttachement(com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation.ExigenceAjoutInformation.valueOf(m.getExigenceAttachement().name()));
        return mc;
    }
}
