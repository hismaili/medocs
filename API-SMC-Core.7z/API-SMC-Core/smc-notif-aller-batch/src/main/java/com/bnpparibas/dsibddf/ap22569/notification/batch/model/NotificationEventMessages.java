package com.bnpparibas.dsibddf.ap22569.notification.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;

@XStreamAlias("messagesList")
public class NotificationEventMessages {

    @XStreamImplicit
    private List<NotificationEvent> events;

    public NotificationEventMessages(List<NotificationEvent> events) {
        this.events = events;
    }

    public List<NotificationEvent> getEvents() {
        return events;
    }

    public void setEvents(List<NotificationEvent> events) {
        this.events = events;
    }
}


