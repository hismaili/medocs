package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * AttachmentInputData
 */
public class AttachmentData   {
	@JsonProperty("transactionsDisputeFolderId")
	private String fileIdSMC;

	@JsonProperty("documents")
	private List<Document> documents;

	/**
	 * @return the documents
	 */
	public List<Document> getDocuments() {
		return documents;
	}

	/**
	 * @return the fileIdSMC
	 */
	public String getFileIdSMC() {
		return fileIdSMC;
	}

	/**
	 * @param documents the documents to set
	 */
	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

	/**
	 * @param fileIdSMC the fileIdSMC to set
	 */
	public void setFileIdSMC(String fileIdSMC) {
		this.fileIdSMC = fileIdSMC;
	}

}

