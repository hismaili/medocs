package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatusContestationSmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte.CarteEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne.PorteurEntity;

/**
 *
 *
 *
 */
@Entity
@Table(name = "CONTESTATION")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class ContestationEntity extends AbstractEntity<DefaultEntityId> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/** Description des faits */
	@Column(name = "description_faits",length = 300)
	private String descriptionFaits;
	/** identifiant télématique du client */
	@Column(name = "ID_TELEMATIQUE",length = 300, nullable = false)
	private String idTelematique;
	/** Carte perdue, oui ou non  */
	@Column(name = "CARTE_PERDUE")
	private boolean cartePerdue;
	/** Motif de la contestation */
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="MOTIF_CONTESTATION", nullable = false)
	private MotifEntity motifContestation;
	/** numéro de téléphone de notification */
	@Column(length = 20)
	private String telephone;
	/** mail de notification */
	@Column(length = 100)
	private String mail;
	@Column(length = 20)
	private String phoneCountryCode;
	/** 5 premiers chiffres du rib  */
	@Column(length = 25)
	private String numCompte;
	/** Numéro de dossier SMC (Smart ContestationEntity)*/
	@Column(name = "reference_dossier_smc",unique=true, length = 50)
	private String numDossierSMC;
	/** Numéro de la carte bancaire : le PAN */
	@Column(name="pan", nullable = false)
	private String numCarte;
	/** identifiant porteur : client de la banque */
	@Column(name = "id_porteur", nullable = false)
	private String idPorteur;
	/** montant remboursement */
	@Column(name = "montant_remboursement", precision = 8, scale = 2)
	private BigDecimal montantRemboursement;
	/** montant reconnu porteur : montant reconnu par le porteur (dans le cas de contestation du nombre de billets distribués par un GAB) */
	@Column(name = "montant_reconnu_porteur", precision = 8, scale = 2)
	private BigDecimal montantReconnuPorteur;
	/** statut dossier */
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "dernier_statut", nullable = false)
	private StatutDossierContestationSelfCare dernierStatutDossier;
	/** Le client souhaite être notifié par SMS ou non */
	@Column
	private Boolean notifSMS;
	/** Le client souhaite être notifié par Mail ou non */
	@Column
	private Boolean notifMail;
	/** Le client souhaite être notifié par push ou non */
	@Column
	private Boolean notifPush;
	/** Le motif de rejet du dossier de contestation après son traitement */
	@Column
	private String motifRejet;

	/** Nombre d'opérations contestées */
	@Column(nullable = false)
	private Integer nombreOperations;

	/** Le montant contesté */
	@Column(precision = 22, nullable = false, scale = 2)
	private BigDecimal montantConteste;
	@Column(name = "IS_PURGED")
	private Boolean purged;
	@OneToMany(targetEntity = OperationEntity.class,cascade=CascadeType.PERSIST)
	@JoinColumn(name = "CONTESTATION_ID", nullable = false)
	private List<OperationEntity> listeOperation;
	@OneToMany(targetEntity = DocumentAttacheEntity.class,cascade={CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn(name = "CONTESTATION_ID")
	//@Fetch(value = FetchMode.SUBSELECT)
	private List<DocumentAttacheEntity> documentsAttaches;



	@ManyToOne(cascade=CascadeType.PERSIST)
	private CarteEntity carte;

	@ManyToOne(cascade=CascadeType.PERSIST)
	//@JoinColumn(name = "etat_carte")
	private PorteurEntity porteur;
	@Column(name = "date_creation_dossier_smc")
	private LocalDateTime dateCreationDossierSMC;

	@Column(name = "status_smc")
	@Enumerated(EnumType.STRING)
	private StatusContestationSmc statusSmc;
	/**
	 * ajout des données pour le batch HMP
	 */

	@Column(name = "date_de_contestation")
	private LocalDateTime dateDeContestation;


	@Column(name = "dossier_sans_analyse_auto")
	private String dossierSansAnalyseAuto;



	@Column
	private LocalDateTime lastDateOfsendToSmc;


	@Column
	private LocalDateTime lastDateTogenerateRecap;

	/**
	 *
	 */
	public ContestationEntity() {
	}

	/**
	 *
	 * @param entityId
	 */
	public ContestationEntity(DefaultEntityId entityId) {
		super(entityId);
	}





	/**
	 * ajoute un document aux documents de l'utilisateur
	 *
	 * @param documentAttacheEntity
	 */
	public void addDocumentAttach(DocumentAttacheEntity documentAttacheEntity){
		String idGDN = documentAttacheEntity.getIdGDN();

		if (!CollectionUtils.isEmpty(documentsAttaches)) {

			if(!StringUtils.isEmpty(idGDN)){
				List<DocumentAttacheEntity> documentAlreadySaved = documentsAttaches
						.stream()
						.filter(documentEntity ->  idGDN.equals(documentEntity
								.getIdGDN())).map(documentEntity -> documentEntity)
								.collect(Collectors.toList());


				if(CollectionUtils.isEmpty(documentAlreadySaved)){
					documentsAttaches.add(documentAttacheEntity);
				}
			}
		}else{
			documentsAttaches = new ArrayList<DocumentAttacheEntity>();
			documentsAttaches.add(documentAttacheEntity);
		}
	}

	public CarteEntity getCarte() {
		return carte;
	}

	public LocalDateTime getDateCreationDossierSMC() {
		return dateCreationDossierSMC;
	}

	/**
	 * @return the dateDeContestation
	 */
	public LocalDateTime getDateDeContestation() {
		return dateDeContestation;
	}

	/**
	 *
	 * @return
	 */
	public StatutDossierContestationSelfCare getDernierStatutDossier() {
		return dernierStatutDossier;
	}

	public String getDescriptionFaits() {
		return descriptionFaits;
	}

	/**
	 * @return the documentsAttaches
	 */
	public List<DocumentAttacheEntity> getDocumentsAttaches() {
		return documentsAttaches;
	}

	/**
	 * @return the dossierSansAnalyseAuto
	 */
	public String getDossierSansAnalyseAuto() {
		return dossierSansAnalyseAuto;
	}

	/**
	 *
	 * @return
	 */
	public String getIdPorteur() {
		return idPorteur;
	}

	public String getIdTelematique() {
		return idTelematique;
	}

	/**
	 * @return the lastDateOfsendToSmc
	 */
	public LocalDateTime getLastDateOfsendToSmc() {
		return lastDateOfsendToSmc;
	}

	/**
	 * @return the lastDateTogenerateRecap
	 */
	public LocalDateTime getLastDateTogenerateRecap() {
		return lastDateTogenerateRecap;
	}

	/**
	 * @return the listeOperation
	 */
	public List<OperationEntity> getListeOperation() {
		return listeOperation;
	}



	public String getMail() {
		return mail;
	}
	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantConteste() {
		return montantConteste;
	}


	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantReconnuPorteur() {
		return montantReconnuPorteur;
	}

	/**
	 *
	 * @return
	 */
	public BigDecimal getMontantRemboursement() {
		return montantRemboursement;
	}


	public MotifEntity getMotifContestation() {
		return motifContestation;
	}
	/**
	 *
	 * @return
	 */
	public String getMotifRejet() {
		return motifRejet;
	}

	/**
	 *
	 * @return
	 */
	public Integer getNombreOperations() {
		return nombreOperations;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getNotifMail() {
		return notifMail;
	}
	public Boolean getNotifPush() {
		return notifPush;
	}

	/**
	 *
	 * @return
	 */
	public Boolean getNotifSMS() {
		return notifSMS;
	}
	/**
	 *
	 * @return
	 */
	public String getNumCarte() {
		return numCarte;
	}
	/**
	 * @return the numCompte
	 */
	public String getNumCompte() {
		return numCompte;
	}

	/**
	 *
	 * @return
	 */
	public String getNumDossierSMC() {
		return numDossierSMC;
	}
	/**
	 * @return the phoneCountryCode
	 */
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}

	/**
	 * @return the porteur
	 */
	public PorteurEntity getPorteur() {
		return porteur;
	}


	/**
	 * @return the purged
	 */
	public Boolean getPurged() {
		return purged;
	}
	/**
	 * @return the statusSmc
	 */
	public StatusContestationSmc getStatusSmc() {
		return statusSmc;
	}
	public String getTelephone() {
		return telephone;
	}
	public boolean isCartePerdue() {
		return cartePerdue;
	}
	public void setCarte(CarteEntity carte) {
		this.carte = carte;
	}
	public void setCartePerdue(boolean cartePerdue) {
		this.cartePerdue = cartePerdue;
	}

	public void setDateCreationDossierSMC(LocalDateTime dateCreationDossierSMC) {
		this.dateCreationDossierSMC = dateCreationDossierSMC;
	}
	/**
	 * @param dateDeContestation the dateDeContestation to set
	 */
	public void setDateDeContestation(LocalDateTime dateDeContestation) {
		this.dateDeContestation = dateDeContestation;
	}
	/**
	 *
	 * @param dernierStatutDossier
	 */
	public void setDernierStatutDossier(StatutDossierContestationSelfCare dernierStatutDossier) {
		this.dernierStatutDossier = dernierStatutDossier;
	}

	public void setDescriptionFaits(String descriptionFaits) {
		this.descriptionFaits = descriptionFaits;
	}
	/**
	 * @param documentsAttaches the documentsAttaches to set
	 */
	public void setDocumentsAttaches(List<DocumentAttacheEntity> documentsAttaches) {
		this.documentsAttaches = documentsAttaches;
	}
	/**
	 * @param dossierSansAnalyseAuto the dossierSansAnalyseAuto to set
	 */
	public void setDossierSansAnalyseAuto(String dossierSansAnalyseAuto) {
		this.dossierSansAnalyseAuto = dossierSansAnalyseAuto;
	}
	/**
	 *
	 * @param idPorteur
	 */
	public void setIdPorteur(String idPorteur) {
		this.idPorteur = idPorteur;
	}
	public void setIdTelematique(String idTelematique) {
		this.idTelematique = idTelematique;
	}
	/**
	 * @param lastDateOfsendToSmc the lastDateOfsendToSmc to set
	 */
	public void setLastDateOfsendToSmc(LocalDateTime lastDateOfsendToSmc) {
		this.lastDateOfsendToSmc = lastDateOfsendToSmc;
	}

	/**
	 * @param lastDateTogenerateRecap the lastDateTogenerateRecap to set
	 */
	public void setLastDateTogenerateRecap(LocalDateTime lastDateTogenerateRecap) {
		this.lastDateTogenerateRecap = lastDateTogenerateRecap;
	}

	/**
	 * @param listeOperation the listeOperation to set
	 */
	public void setListeOperation(List<OperationEntity> listeOperation) {
		this.listeOperation = listeOperation;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 *
	 * @param montantConteste
	 */
	public void setMontantConteste(BigDecimal montantConteste) {
		this.montantConteste = montantConteste;
	}

	/**
	 *
	 * @param montantReconnuPorteur
	 */
	public void setMontantReconnuPorteur(BigDecimal montantReconnuPorteur) {
		this.montantReconnuPorteur = montantReconnuPorteur;
	}

	/**
	 *
	 * @param montantRemboursement
	 */
	public void setMontantRemboursement(BigDecimal montantRemboursement) {
		this.montantRemboursement = montantRemboursement;
	}

	public void setMotifContestation(MotifEntity motifContestation) {
		this.motifContestation = motifContestation;
	}

	/**
	 *
	 * @param motifRejet
	 */
	public void setMotifRejet(String motifRejet) {
		this.motifRejet = motifRejet;
	}

	/**
	 *
	 * @param nombreOperations
	 */
	public void setNombreOperations(Integer nombreOperations) {
		this.nombreOperations = nombreOperations;
	}

	/**
	 *
	 * @param notifMail
	 */
	public void setNotifMail(Boolean notifMail) {
		this.notifMail = notifMail;
	}

	public void setNotifPush(Boolean notifPush) {
		this.notifPush = notifPush;
	}

	/**
	 *
	 * @param notifSMS
	 */
	public void setNotifSMS(Boolean notifSMS) {
		this.notifSMS = notifSMS;
	}

	/**
	 *
	 * @param numCarte
	 */
	public void setNumCarte(String numCarte) {
		this.numCarte = numCarte;
	}

	/**
	 * @param numCompte the numCompte to set
	 */
	public void setNumCompte(String numCompte) {
		this.numCompte = numCompte;
	}



	/**
	 *
	 * @param numDossierSMC
	 */
	public void setNumDossierSMC(String numDossierSMC) {
		this.numDossierSMC = numDossierSMC;
	}


	/**
	 * @param phoneCountryCode the phoneCountryCode to set
	 */
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}

	/**
	 * @param porteur the porteur to set
	 */
	public void setPorteur(PorteurEntity porteur) {
		this.porteur = porteur;
	}


	/**
	 * @param purged the purged to set
	 */
	public void setPurged(Boolean purged) {
		this.purged = purged;
	}

	/**
	 * @param statusSmc the statusSmc to set
	 */
	public void setStatusSmc(StatusContestationSmc statusSmc) {
		this.statusSmc = statusSmc;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
}
