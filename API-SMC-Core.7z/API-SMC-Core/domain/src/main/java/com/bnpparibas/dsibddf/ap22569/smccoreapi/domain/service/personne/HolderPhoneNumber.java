package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;

/**
 *
 *
 *
 */
public class HolderPhoneNumber {
	private String phoneNumberId;
	private String countryCode;

	private String regionCode;

	private String phoneNumber;

	public String getCountryCode() {
		return countryCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @return the phoneNumberId
	 */
	public String getPhoneNumberId() {
		return phoneNumberId;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @param phoneNumberId the phoneNumberId to set
	 */
	public void setPhoneNumberId(String phoneNumberId) {
		this.phoneNumberId = phoneNumberId;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
}
