--QUALIFICATION
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q001','Contestation Perte/VOL', 'P');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q002','Contestation Contrefaçon', 'F');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle, qualification_code_smc) VALUES('Q003','Contestation', 'C');
INSERT INTO QUALIFICATION(qualifcation_code, qualification_libelle) VALUES('Q099','Autres');

--Nature
---- perte-vol
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N001','Carte Perdue', 'PER','Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N002','Carte Volée Sans violence', 'VOL', 'Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N003','Carte extorquée avec violence', 'VEM', 'Q001');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N004','Carte non parvenue au porteur', 'NPA', 'Q001');
---- Contrefaçon
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N005','Carte Contrefaite', 'FAL', 'Q002');
----Autres (Contestation)
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N006','Facture contestée', 'FCT', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N007','Traitement en double', 'DOU', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N008','Service non rendu ou marchandise non reçue ou défectueuse', 'SNR', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N009','DAB billets non délivrés', 'BND', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N010','DAB billets partiellement délivrés', 'BPD', 'Q003');
INSERT INTO NATURE_CONTESTATION(nature_code, nature_libelle, nature_code_smc, qualification) VALUES('N011','Montant erroné', 'MER', 'Q003');



--Motif
-- Motifs
---- perte-vol
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description)
 VALUES
('M001','M001.label',1,0, 0,'facultatif',1,'obligatoire',390, 100, 'M001.DISCLAIMER', 'LESDEUX','N001','Q001', 'M001.DESCRIPTION');
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M002','M002.label',1,0, 0,'recommande',1,'obligatoire',390, 100, 'M002.DISCLAIMER', 'LESDEUX','N002','Q001', 'M002.DESCRIPTION');
-- FRAUDE
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M006','M006.label',0,0, 0,'facultatif',0,'facultatif',390, 100, 'M006.DISCLAIMER', 'LESDEUX','N006','Q002', 'M006.DESCRIPTION');

-- Debit multiple
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M007','M007.label',0,0, 0,'facultatif',0,'facultatif',390, 100, 'M007.DISCLAIMER', 'LESDEUX','N007','Q002', 'M007.DESCRIPTION');
-- Litige commercial
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M008','M008.label',0,0, 0,'recommande',0,'obligatoire',70, 100, 'M008.DISCLAIMER', 'PAIEMENT','N008','Q099', 'M008.DESCRIPTION');
-- Billets partiellement ou non d\u00e9livr\u00e9s
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M009','M009.label',0,1, 1,'facultatif',0,'facultatif',390, 1, 'M009.DISCLAIMER', 'RETRAIT','N009','Q099', 'M009.DESCRIPTION');

-- Montant erron\u00e9
INSERT INTO MOTIF(code, libelle, applied_to_card_lost_only, applied_to_one_operation, ecart_montant, exig_justif, exigence_opposition_carte, exig_description_faits, historique, max_operations, texte_avertissement, type_operation_applicable, code_nature, code_qualif, description) VALUES
('M011','M011.label',0,1, 1,'obligatoire',0,'facultatif',390, 1, 'M011.DISCLAIMER', 'PAIEMENT','N011','Q099', 'M011.DESCRIPTION');

---Justificatif clients à demander
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('q0Umf+vVSDiJVCR1ra5uAg', 'Contrat de location', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('0QdGs72/RWeKln/F+tK1JA', 'Facture', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('T/jAumuaTnKrhZdmmGds2g', 'Billet de réservation de place', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('eax0DCEGRdmkhceeLdCyhg', 'Description service ou marchandise', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('DWg4zGG/RLO1S982Ux7mKQ', 'PV de police', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('rFCx9O/LTTaECHv7TPZWRA', 'Ticket', '20019256');
INSERT INTO JUSTIFS_CLIENT_DESC(id,label_justificatif,type_docgdn) VALUES('0A/UtsFGRreBKmTBQPX0xQ', 'Facturette', '20019256');

--Jutificatifs par motif
--- Vol
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('DWg4zGG/RLO1S982Ux7mKQ','M002');
--- Litige commercial
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('q0Umf+vVSDiJVCR1ra5uAg','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code)VALUES('0QdGs72/RWeKln/F+tK1JA','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('T/jAumuaTnKrhZdmmGds2g','M008');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('eax0DCEGRdmkhceeLdCyhg','M008');
---montant erroné
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('rFCx9O/LTTaECHv7TPZWRA','M011');
INSERT INTO motif_document_associes(document_associes_id, motif_entity_code) VALUES('0A/UtsFGRreBKmTBQPX0xQ','M011');



---insert Anonymized card
insert into Carte_Alias (type_produit,card_id, masked_pan, num_compte, pan, date_fin_validite, statut_carte, date_opposition, date_cloture, id) 
values('Produit','CA10928309835','448************00','30004','0004974018305888915',TO_TIMESTAMP('09/09/2019','dd/mm/yyyy'),'VALIDE',TO_TIMESTAMP('09/07/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/08/2019','dd/mm/yyyy'),'CARD0005');

insert into Carte_Alias (type_produit,card_id, masked_pan, num_compte, pan, date_fin_validite, statut_carte, date_opposition, date_cloture, id) 
values('Produit','CA10928309836','448************00','30004','0004974104260695501',TO_TIMESTAMP('09/09/2019','dd/mm/yyyy'),'VALIDE',TO_TIMESTAMP('09/07/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/08/2019','dd/mm/yyyy'),'CARD0006');

insert into OPERATIONTMP(id_telematic,user_id,date_creation, date_maj,code_peration, date_operation, date_vente, devise_operation, libelle_operation, montant_operation, montant_reconnu, nom_commercant, sens_operation, type_operation,id) 
values ('345615789521','01280000176000000',TO_TIMESTAMP('03/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'OPC01',TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),TO_TIMESTAMP('09/05/2019','dd/mm/yyyy'),'EURO','Retrait en banque',15.0, 17.0,'HENRY','DEBIT',0,'OP004');


----Insertion des statuts de dossier
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC001',1,'BROUILLON');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC002',2,'CREE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC003',3,'En Cours');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC004',4,'TRAITE');
INSERT INTO STATUT_DOSSIER_SELFCARE VALUES('SC005',5,'CLOTURE');

--Etat des cartes
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT001',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'BLOQUE');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT002',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'EN COURS');
INSERT INTO ETAT_CARTE_ENTITY VALUES('ETAT003',TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),TO_TIMESTAMP('04/15/2015','mm/dd/yyyy'),'DISPONIBLE');