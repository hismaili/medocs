package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.personne;

import java.math.BigInteger;
import java.time.LocalDate;

/**
 *
 * @author c65344
 *
 */
public class InfoPersonneOutput {

	private String	clientNatureId;
	private String civilite;
	private String clientName;
	private String clientFirstname;
	private LocalDate birthDay;
	private BigInteger  sirenNumber;
	private String identifiantAdressePostale;
	private String adresse1;
	private String adresse2;
	private String adresse3;
	private String codePostal;
	private String communePersonne;
	private String raisonSociale;
	private String raisonSocialeAbrege;
	private String codePays;
	private ErrorsRP error;
	/**
	 *
	 */
	public InfoPersonneOutput() {
		super();

	}
	/**
	 * @param clientNatureId
	 * @param civilite
	 * @param clientName
	 * @param clientFirstname
	 * @param birthDay
	 * @param sirenNumber
	 * @param identifiantAdressePostale
	 * @param adresse1
	 * @param adresse2
	 * @param adresse3
	 * @param codePostal
	 * @param communePersonne
	 * @param raisonSociale
	 * @param raisonSocialeAbrege
	 * @param codePays
	 * @param error
	 */
	public InfoPersonneOutput(String clientNatureId, String civilite,
			String clientName, String clientFirstname, LocalDate birthDay,
			BigInteger sirenNumber, String identifiantAdressePostale,
			String adresse1, String adresse2, String adresse3,
			String codePostal, String communePersonne, String raisonSociale,
			String raisonSocialeAbrege, String codePays, ErrorsRP error) {
		this.clientNatureId = clientNatureId;
		this.civilite = civilite;
		this.clientName = clientName;
		this.clientFirstname = clientFirstname;
		this.birthDay = birthDay;
		this.sirenNumber = sirenNumber;
		this.identifiantAdressePostale = identifiantAdressePostale;
		this.adresse1 = adresse1;
		this.adresse2 = adresse2;
		this.adresse3 = adresse3;
		this.codePostal = codePostal;
		this.communePersonne = communePersonne;
		this.raisonSociale = raisonSociale;
		this.raisonSocialeAbrege = raisonSocialeAbrege;
		this.codePays = codePays;
		this.error = error;
	}
	/**
	 * @return the adresse1
	 */
	public String getAdresse1() {
		return adresse1;
	}
	/**
	 * @return the adresse2
	 */
	public String getAdresse2() {
		return adresse2;
	}
	/**
	 * @return the adresse3
	 */
	public String getAdresse3() {
		return adresse3;
	}
	/**
	 * @return the birthDay
	 */
	public LocalDate getBirthDay() {
		return birthDay;
	}
	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}
	/**
	 * @return the clientFirstname
	 */
	public String getClientFirstname() {
		return clientFirstname;
	}
	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @return the clientNatureId
	 */
	public String getClientNatureId() {
		return clientNatureId;
	}
	/**
	 * @return the codePays
	 */
	public String getCodePays() {
		return codePays;
	}
	/**
	 * @return the codePostal
	 */
	public String getCodePostal() {
		return codePostal;
	}
	/**
	 * @return the communePersonne
	 */
	public String getCommunePersonne() {
		return communePersonne;
	}
	/**
	 * @return the error
	 */
	public ErrorsRP getError() {
		return error;
	}
	/**
	 * @return the identifiantAdressePostale
	 */
	public String getIdentifiantAdressePostale() {
		return identifiantAdressePostale;
	}
	/**
	 * @return the raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}
	/**
	 * @return the raisonSocialeAbrege
	 */
	public String getRaisonSocialeAbrege() {
		return raisonSocialeAbrege;
	}
	/**
	 * @return the sirenNumber
	 */
	public BigInteger getSirenNumber() {
		return sirenNumber;
	}
	/**
	 * @param adresse1 the adresse1 to set
	 */
	public void setAdresse1(String adresse1) {
		this.adresse1 = adresse1;
	}
	/**
	 * @param adresse2 the adresse2 to set
	 */
	public void setAdresse2(String adresse2) {
		this.adresse2 = adresse2;
	}
	/**
	 * @param adresse3 the adresse3 to set
	 */
	public void setAdresse3(String adresse3) {
		this.adresse3 = adresse3;
	}
	/**
	 * @param birthDay the birthDay to set
	 */
	public void setBirthDay(LocalDate birthDay) {
		this.birthDay = birthDay;
	}
	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	/**
	 * @param clientFirstname the clientFirstname to set
	 */
	public void setClientFirstname(String clientFirstname) {
		this.clientFirstname = clientFirstname;
	}
	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	/**
	 * @param clientNatureId the clientNatureId to set
	 */
	public void setClientNatureId(String clientNatureId) {
		this.clientNatureId = clientNatureId;
	}
	/**
	 * @param codePays the codePays to set
	 */
	public void setCodePays(String codePays) {
		this.codePays = codePays;
	}
	/**
	 * @param codePostal the codePostal to set
	 */
	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}
	/**
	 * @param communePersonne the communePersonne to set
	 */
	public void setCommunePersonne(String communePersonne) {
		this.communePersonne = communePersonne;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(ErrorsRP error) {
		this.error = error;
	}
	/**
	 * @param identifiantAdressePostale the identifiantAdressePostale to set
	 */
	public void setIdentifiantAdressePostale(String identifiantAdressePostale) {
		this.identifiantAdressePostale = identifiantAdressePostale;
	}
	/**
	 * @param raisonSociale the raisonSociale to set
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}
	/**
	 * @param raisonSocialeAbrege the raisonSocialeAbrege to set
	 */
	public void setRaisonSocialeAbrege(String raisonSocialeAbrege) {
		this.raisonSocialeAbrege = raisonSocialeAbrege;
	}
	/**
	 * @param sirenNumber the sirenNumber to set
	 */
	public void setSirenNumber(BigInteger sirenNumber) {
		this.sirenNumber = sirenNumber;
	}



}
