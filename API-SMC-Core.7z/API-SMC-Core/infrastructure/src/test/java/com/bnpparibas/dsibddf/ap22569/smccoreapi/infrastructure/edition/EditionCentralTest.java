/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.EditionRecording;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.SpringBootApp;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author c65344
 *
 */
@SpringBootTest(classes = SpringBootApp.class)
@RunWith(SpringRunner.class)
@ActiveProfiles({"local","test"})
@Ignore
public class EditionCentralTest {


	@Autowired
	private transient EditionDocumentImpl editionDocumentImpl;

	@Autowired
	private transient IEditionRepository editionCentral;

	@Autowired
	private transient SmcDocumentBuilder smc;

	@Test
	public void testgetRecording(){

		final EditionRecording editionRecording = editionDocumentImpl.getEditionRecording();

		Assertions.assertThat(editionRecording).isNotNull();


	}

	@Test
	public void testSendSmc(){

		String responseSmc = smc.buildResponseSmc();
		System.out.println(responseSmc);
		Assertions.assertThat(responseSmc).isNotNull();


	}



}
