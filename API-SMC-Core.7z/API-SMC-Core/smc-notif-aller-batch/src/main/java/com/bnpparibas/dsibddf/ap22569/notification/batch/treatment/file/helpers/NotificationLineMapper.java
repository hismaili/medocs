package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.helpers;

import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationFileMetadata;
import com.bnpparibas.dsibddf.ap22569.notification.batch.model.NotificationLine;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control.FooterCallbackHandler;
import com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control.HeaderCallbackHandler;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.NotificationInfoFile;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class NotificationLineMapper implements LineMapper<NotificationLine> {

    private String numSeqHeader;
    private String dateFluxHeader;
    private StepExecution stepExecution;

    @Value("${FIELDS_CSV_SEPARATOR}")
    private String fieldsSeparator;

    @Autowired
    @Qualifier("HeaderCallbackHandler")
    private transient LineCallbackHandler headerCallbackHandler;

    @Autowired
    @Qualifier("FooterCallbackHandler")
    private transient LineCallbackHandler footerCallbackHandler;

    private String fileName;

    @Override
    public NotificationLine mapLine(String line, int lineNumber) throws Exception {

        DefaultLineMapper<NotificationLine> lineMapper = configureNotificationLineMapper();
        NotificationLine notificationLine = null;

        if(StringUtils.startsWithIgnoreCase(line, "01")){ //$NON-NLS-1$
            headerCallbackHandler.handleLine(line);
            notificationLine = new NotificationLine();
            notificationLine.setCodeEnregistrement("01");

        } else if(StringUtils.startsWithIgnoreCase(line, "99")) { //$NON-NLS-1$
            footerCallbackHandler.handleLine(line);
            notificationLine = new NotificationLine();
            notificationLine.setCodeEnregistrement("99");
        } else {
            NotificationInfoFile infoFile = (NotificationInfoFile) this.stepExecution.getExecutionContext().get("FILE_INFO");
            NotificationFileMetadata fileInfo = new NotificationFileMetadata();
            BeanUtils.copyProperties(infoFile, fileInfo);

            notificationLine = lineMapper.mapLine(line, lineNumber);
            notificationLine.setFileInfo(fileInfo);

        }
        notificationLine.setOriginalLine(line);
        notificationLine.setLineNumber(lineNumber);
        return notificationLine;
    }

    private DefaultLineMapper<NotificationLine> configureNotificationLineMapper() {
        DefaultLineMapper<NotificationLine> lineMapper = new DefaultLineMapper<NotificationLine>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(";");
        lineTokenizer.setNames("codeEnregistrement", "idTechnique", "dossierSmc", "dateCreationNotification", "numCarteDossier", "dateAppel", "numClient", "codeAgence", "heureAppel", "notifSms", "notifMail", "numTel", "mailClient", "codeNotif", "contenuNotif", "objetDuMail", "civilite", "nom", "prenom", "dateCreationDossier", "empty");
        //lineTokenizer.setIncludedFields(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
        BeanWrapperFieldSetMapper<NotificationLine> fieldSetMapper = new BeanWrapperFieldSetMapper<NotificationLine>();
        fieldSetMapper.setTargetType(NotificationLine.class);
        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);

        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }

    public String getNumSeqHeader() {
        return numSeqHeader;
    }

    public void setNumSeqHeader(String numSeqHeader) {
        this.numSeqHeader = numSeqHeader;
    }

    public String getDateFluxHeader() {
        return dateFluxHeader;
    }

    public void setDateFluxHeader(String dateFluxHeader) {
        this.dateFluxHeader = dateFluxHeader;
    }

    public StepExecution getStepExecution() {
        return stepExecution;
    }

    public void setStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
        ((HeaderCallbackHandler)this.headerCallbackHandler).setStepExecution(stepExecution);
        ((FooterCallbackHandler)this.footerCallbackHandler).setStepExecution(stepExecution);
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
