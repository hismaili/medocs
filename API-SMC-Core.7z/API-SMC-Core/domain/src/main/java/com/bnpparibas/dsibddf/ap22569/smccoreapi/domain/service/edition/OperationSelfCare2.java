/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

/**
 * @author c65344
 *
 */
public class OperationSelfCare2 {
	private String dateDebit;

	private String libelleOperation;

	private String dateVente;

	private String montantOperation;

	private String montantReconnu;

	/**
	 *
	 */
	public OperationSelfCare2() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param dateDebit
	 * @param libelleOperation
	 * @param dateVente
	 * @param montantOperation
	 * @param montantReconnu
	 */
	public OperationSelfCare2(String dateDebit, String libelleOperation,
			String dateVente, String montantOperation, String montantReconnu) {
		this.dateDebit = dateDebit;
		this.libelleOperation = libelleOperation;
		this.dateVente = dateVente;
		this.montantOperation = montantOperation;
		this.montantReconnu = montantReconnu;
	}

	/**
	 * @return the dateDebit
	 */
	public String getDateDebit() {
		return dateDebit;
	}

	/**
	 * @return the dateVente
	 */
	public String getDateVente() {
		return dateVente;
	}

	/**
	 * @return the libelleOperation
	 */
	public String getLibelleOperation() {
		return libelleOperation;
	}

	/**
	 * @return the montantOperation
	 */
	public String getMontantOperation() {
		return montantOperation;
	}

	/**
	 * @return the montantReconnu
	 */
	public String getMontantReconnu() {
		return montantReconnu;
	}

	/**
	 * @param dateDebit the dateDebit to set
	 */
	public void setDateDebit(String dateDebit) {
		this.dateDebit = dateDebit;
	}

	/**
	 * @param dateVente the dateVente to set
	 */
	public void setDateVente(String dateVente) {
		this.dateVente = dateVente;
	}

	/**
	 * @param libelleOperation the libelleOperation to set
	 */
	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	/**
	 * @param montantOperation the montantOperation to set
	 */
	public void setMontantOperation(String montantOperation) {
		this.montantOperation = montantOperation;
	}

	/**
	 * @param montantReconnu the montantReconnu to set
	 */
	public void setMontantReconnu(String montantReconnu) {
		this.montantReconnu = montantReconnu;
	}
}
