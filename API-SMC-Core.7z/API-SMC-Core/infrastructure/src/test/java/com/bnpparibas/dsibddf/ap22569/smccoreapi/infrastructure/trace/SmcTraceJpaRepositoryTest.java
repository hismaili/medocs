package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@EntityScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace"})
@EnableJpaRepositories
@DataJpaTest
@ActiveProfiles("test")
public class SmcTraceJpaRepositoryTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmcTraceJpaRepositoryTest.class);

	@Autowired
	private SmcTraceJpaRepository smcTraceJpaRepository;

	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void testSaveSmcTraceOK() {
		SmcTraceEntity traceEntity = new SmcTraceEntity();
		traceEntity.setApplicationAppelante("AP12546");
		traceEntity.setIdContestation("25642323859");
		traceEntity.setDateAppel(LocalDateTime.now());
		traceEntity.setService("ArchivageController.newFolder(..)");
		traceEntity.setSens("IN");
		traceEntity.setParamIn("[{\"callingUser\":\"456215\",\"numCarteBancaire\":null,\"idContestationSmc\":\"25642323859\"}]");
//		traceEntity.setEntityId(new DefaultEntityId(UUID.randomUUID()));
		traceEntity = this.smcTraceJpaRepository.save(traceEntity);
		Assertions.assertThat(traceEntity).isNotNull();

		SmcTraceEntity dbEntity = entityManager.find(SmcTraceEntity.class, traceEntity.getEntityId());
		Assertions.assertThat(dbEntity).isNotNull();
		Assertions.assertThat(dbEntity.getEntityId()).isNotNull();
		LOGGER.info(dbEntity.toString());
	}

}