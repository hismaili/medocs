package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.compte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "COMPTE_ALIAS")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class AliasedAccountEntity extends AbstractEntity<DefaultEntityId> {

	@Column(length=60)
	private String accountId;

	@Column(length=50)
	private String maskedAccountNumber;

	@Column(length=30)
	private String rib;

	@Column(length=60)
	private String accountType;

	@Column(length=160)
	private String accountHolderName;

	@Column(length=20)
	private String telematicId;

	@Column(length=30)
	private String ikpi;

	@Column(length=60)
	private String iban;

	@Column(length=15)
	private String bic;

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public String getAccountId() {
		return accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public String getBic() {
		return bic;
	}

	public String getIban() {
		return iban;
	}


	/**
	 * @return the ikpi
	 */
	public String getIkpi() {
		return ikpi;
	}

	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}

	public String getRib() {
		return rib;
	}

	public String getTelematicId() {
		return telematicId;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}



	public void setIban(String iban) {
		this.iban = iban;
	}

	/**
	 * @param ikpi the ikpi to set
	 */
	public void setIkpi(String ikpi) {
		this.ikpi = ikpi;
	}

	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}

	public void setRib(String rib) {
		this.rib = rib;
	}

	public void setTelematicId(String telematicId) {
		this.telematicId = telematicId;
	}
}
