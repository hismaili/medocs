package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public class StatutDossierContestation {

    private String codeStatut;

    private String libelleStatut;

    public String getCodeStatut() {
        return codeStatut;
    }

    public void setCodeStatut(String codeStatut) {
        this.codeStatut = codeStatut;
    }

    public String getLibelleStatut() {
        return libelleStatut;
    }

    public void setLibelleStatut(String libelleStatut) {
        this.libelleStatut = libelleStatut;
    }

}
