package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition;


import java.time.LocalDateTime;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import brave.Tracer;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace.ITraceManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.trace.TraceDTO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 *
 *
 *
 */
@Aspect
@Configuration
@Lazy
@EnableAsync
public class SmcApiAuditAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmcApiAuditAspect.class);

	public static final int IN_LENGTH = 3000;
	public static final int OUT_LENGTH = 3000;
	public static final String SENS_IN = "IN";

	@Autowired
	private transient ObjectMapper objectMapper;

	@Autowired(required = false)
	private transient ITraceManagement traceManagement;

	@Autowired
	private transient Tracer tracer;

	@Around("execution (* com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api..ArchivageController.*(..)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public Object traceArchivageRequestAndResult(ProceedingJoinPoint joinPoint) throws Throwable {
		String output = null;
		try {
			Object[] args = joinPoint.getArgs();

			final String service = joinPoint.getSignature().toShortString();
			String input = objectMapper.writeValueAsString(args);

			JsonNode tree = objectMapper.valueToTree(args).get(0);
			final JsonNode idContestationSmc = tree.get("idContestationSmc");
			String numDossier = null;
			if(idContestationSmc !=null){
				numDossier = idContestationSmc.toString();
			}

			LOGGER.info(idContestationSmc + " "+ service +":"+ input);
			Object result = joinPoint.proceed(args);
			String traceId = null;
			int statusCode = -1;
			if(result instanceof ResponseEntity) {
				ResponseEntity response = (ResponseEntity) result;
				statusCode = response.getStatusCodeValue();
				List<String> traceIds = response.getHeaders().get("X-B3-TraceId");
				if(!CollectionUtils.isEmpty(traceIds)) {
					traceId = traceIds.get(0);
				}
				if (statusCode >= 200 && statusCode < 300) {
					output = objectMapper.writeValueAsString(response.getBody());
				}
				LOGGER.info(objectMapper.writeValueAsString(response.getBody()));
			}


			String applicationAppelante = null;
			if(args != null && args.length > 4) {
				applicationAppelante = (String) args[1];
			}

			traceCall(statusCode, traceId,output, service, input, numDossier, applicationAppelante);

			return result;
		} catch (Throwable throwable) {
			LOGGER.error(throwable.getMessage(), throwable);
			throw throwable;
		}
	}
	@Async
	private void traceCall(int statusCode, String traceId, String output, String service, String input, String numDossier, String applicationAppelante) {
		try {
			TraceDTO traceDTO = new TraceDTO();
			if(!StringUtils.isEmpty(input) && input.length() > IN_LENGTH) {
				input = input.substring(0, IN_LENGTH);
			}
			traceDTO.setParamIn(input);
			traceDTO.setTraceId(traceId);
			traceDTO.setStatusCode(statusCode);
			if(!StringUtils.isEmpty(output) && output.length() > OUT_LENGTH) {
				output = output.substring(0, OUT_LENGTH);
			}
			traceDTO.setParamOut(output);
			traceDTO.setDateAppel(LocalDateTime.now());
			traceDTO.setService(service);
			traceDTO.setIdContestation(numDossier);
			traceDTO.setApplicationAppelante(applicationAppelante);
			traceDTO.setSens(SENS_IN);
			traceManagement.trace(traceDTO);
		} catch (Throwable throwable) {
			LOGGER.error(throwable.getMessage(), throwable);
		}
	}

	@Around("execution (* com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api..ContestationController.*(..)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public Object traceContestationRequestAndResult(ProceedingJoinPoint joinPoint) throws Throwable {
		String output = null;
		try {
			Object[] args = joinPoint.getArgs();

			final String service = joinPoint.getSignature().toShortString();
			objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
			String input = objectMapper.writeValueAsString(args);


			//TODO la donnée qui contient l'id SMC doit être le premier params
			JsonNode tree = objectMapper.valueToTree(args).get(0);
			final JsonNode idContestationSmc = tree.get("idContestationSmc"); //$NON-NLS-1$
			String numDossier = null;
			if(idContestationSmc !=null){
				numDossier = idContestationSmc.toString();
			}

			LOGGER.info("Request - "+ service +":"+ input); //$NON-NLS-1$ //$NON-NLS-2$
			Object result = joinPoint.proceed(args);
			String traceId = null;
			int statusCode = -1;
			if(result instanceof ResponseEntity) {
				ResponseEntity response = (ResponseEntity) result;
				statusCode = response.getStatusCodeValue();
				List<String> traceIds = response.getHeaders().get("X-B3-TraceId");
				if(!CollectionUtils.isEmpty(traceIds)) {
					traceId = traceIds.get(0);
				} else {
					traceId = tracer.currentSpan().context().traceIdString();
				}
				final String responseBody = objectMapper.writeValueAsString(response.getBody());
				if (statusCode >= 200 && statusCode < 300) {
					output = responseBody;
				}
				LOGGER.info("Request - "+ service +":"+ responseBody);
			}


			String applicationAppelante = null;
			if(args != null && args.length > 4) {
				applicationAppelante = (String) args[4];
			}

			traceCall(statusCode, traceId,output, service, input, numDossier, applicationAppelante);

			return result;
		} catch (Throwable throwable) {
			LOGGER.error(throwable.getMessage(), throwable);
			throw throwable;
		}
	}




	@Around("execution (* com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api..EditionController.*(..)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public Object traceEditionRequestAndResult(ProceedingJoinPoint joinPoint) throws Throwable {
		String output = null;
		try {
			Object[] args = joinPoint.getArgs();

			final String service = joinPoint.getSignature().toShortString();
			String input = objectMapper.writeValueAsString(args);

			JsonNode tree = objectMapper.valueToTree(args).get(0);
			final JsonNode idContestationSmc = tree.get("idContestationSmc");
			String numDossier = null;
			if(idContestationSmc !=null){
				numDossier = idContestationSmc.toString();
			}

			LOGGER.info(idContestationSmc + " "+ service +":"+ input);
			Object result = joinPoint.proceed(args);
			String traceId = null;
			int statusCode = -1;
			if(result instanceof ResponseEntity) {
				ResponseEntity response = (ResponseEntity) result;
				statusCode = response.getStatusCodeValue();
				List<String> traceIds = response.getHeaders().get("X-B3-TraceId");
				if(!CollectionUtils.isEmpty(traceIds)) {
					traceId = traceIds.get(0);
				}
				if (statusCode >= 200 && statusCode < 300) {
					output = objectMapper.writeValueAsString(response.getBody());
				}
				LOGGER.info(objectMapper.writeValueAsString(response.getBody()));
			}


			String applicationAppelante = null;
			if(args != null && args.length > 4) {
				applicationAppelante = (String) args[1];
			}

			traceCall(statusCode, traceId,output, service, input, numDossier, applicationAppelante);

			return result;
		} catch (Throwable throwable) {
			LOGGER.error(throwable.getMessage(), throwable);
			throw throwable;
		}
	}
}
