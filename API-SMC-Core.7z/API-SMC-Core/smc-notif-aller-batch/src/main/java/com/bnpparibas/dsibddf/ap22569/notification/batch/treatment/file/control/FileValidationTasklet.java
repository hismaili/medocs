package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.control;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Component
public class FileValidationTasklet implements Tasklet {
    private static final Logger LOG = LoggerFactory.getLogger(FileValidationTasklet.class);

    @Autowired
    private ControlFileListener controlFileListener;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        final StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
        controlFileListener.beforeStep(stepExecution);

        List<Throwable> failureExceptions = stepExecution.getJobExecution().getFailureExceptions();
        if (!CollectionUtils.isEmpty(failureExceptions)) {
            failureExceptions.stream().forEach(th -> {
                LOG.error(th.getMessage());
            });

            stepExecution.setExitStatus(ExitStatus.FAILED);
            throw (Exception) failureExceptions.get(0);
        }

        return RepeatStatus.FINISHED;
    }


}
