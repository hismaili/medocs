/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte;

/**
 * @author c65344
 *
 */
public class CardException extends Exception{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public CardException() {
		super();

	}

	/**
	 * @param message
	 */
	public CardException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public CardException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public CardException(String message, Throwable cause,
						 boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public CardException(Throwable cause) {
		super(cause);

	}

}
