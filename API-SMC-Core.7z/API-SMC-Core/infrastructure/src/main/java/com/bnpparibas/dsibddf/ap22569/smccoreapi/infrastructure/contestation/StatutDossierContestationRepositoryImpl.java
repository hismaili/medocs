package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.IStatutDossierContestationRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.StatutDossierContestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.Arrays;

@Repository
public class StatutDossierContestationRepositoryImpl implements IStatutDossierContestationRepository {
	private static final Logger LOG = LoggerFactory.getLogger(StatutDossierContestationRepositoryImpl.class);

	@Autowired
	private transient StatutDossierContestationJpaRepository statutDossierContestationJpaRepository;
	@Autowired
	private transient ConfigInfrastructure conf;


	@Override
	@Cacheable(value = "statutsSelfcare", key = "#codeStatut")
	public StatutDossierContestation recupererStatutDossier(String codeStatut) throws ContestationException, DonneIncorectException, MandatoryException {

		try{
			if(codeStatut !=null){

				StatutDossierContestationSelfCare statutDossierContestationSelfCareByCodeStatut = statutDossierContestationJpaRepository.findStatutDossierContestationByCodeStatut(codeStatut);

				if(statutDossierContestationSelfCareByCodeStatut !=null){
					StatutDossierContestation statutDossierContestation = new StatutDossierContestation();
					BeanUtils.copyProperties(statutDossierContestationSelfCareByCodeStatut, statutDossierContestation);
					return statutDossierContestation;
				}else{
					throw new DonneIncorectException(String.format("Status [%s] not found ", codeStatut), Arrays.asList(conf.getMessageDisputStatusIncorrect()));
				}
			}else{//TODO add explicit message to the exception
				throw new MandatoryException(conf.getMessageDisputStatusAbsent(), Arrays.asList(conf.getMessageDisputStatusAbsent()));
			}

		} catch (MandatoryException e) {
			throw e;
		} catch (DonneIncorectException e) {
			throw e;
		}catch(Exception e){
			LOG.error(e.getMessage(),e);
			throw new ContestationException(conf.getMessageErrorTechnique(), e);
		}
	}
}
