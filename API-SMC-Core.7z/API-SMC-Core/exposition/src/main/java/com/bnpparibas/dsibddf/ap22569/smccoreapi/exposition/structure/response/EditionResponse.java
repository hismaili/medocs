package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import java.util.List;
/**
 *
 * @author c65344
 *
 */
public class EditionResponse {
	private String document;
	private String fileType;

	/**
	 *
	 */
	public EditionResponse() {
		super();

	}

	/**
	 * @param document
	 * @param fileType
	 */
	public EditionResponse(String document, String fileType) {
		if(document !=null){

			String pdfresult = document.replace("\n", "").replace("\r", "");

			this.document = pdfresult;
		}

		this.fileType = fileType;
	}
	/**
	 * @param document
	 * @param fileType
	 * @param errors
	 */
	public EditionResponse(String document, String fileType,
			List<SmcApiError> errors) {
		if(document !=null){
			String pdfresult = document.replace("\n", "").replace("\r", "");
			this.document = pdfresult;
		}
		this.fileType = fileType;
	}


	/**
	 * @return the document
	 */
	public String getDocument() {

		if(document !=null){
			String pdfresult = document.replace("\n", "").replace("\r", "");
			return pdfresult;
		}
		return document;
	}


	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(String document) {
		this.document = document;
	}

	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
}
