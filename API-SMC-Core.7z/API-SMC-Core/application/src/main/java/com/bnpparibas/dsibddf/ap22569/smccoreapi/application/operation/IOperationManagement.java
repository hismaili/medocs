package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardExistException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationTop;

import java.util.List;

public interface IOperationManagement {

	/**
	 * supprime les opérations temporaires stockées en base de donnée d'un utilisateur après la création de la contestation
	 * @param idTelematic
	 */
	void deleteOperationsTmp(String idTelematic,String userId);


	/**
	 * recupère les opérations d'un utilisateur
	 *
	 * @param cardAlias
	 * @param idTelematic
	 * @return
	 * @throws ContestationException
	 */
	List<OperationDTO> getCardOperations(String cardAlias,String idTelematic,String userId) throws ContestationException,CardExistException;


	/**
	 * recupère le dernier numéro de sequence top HMP
	 *
	 * @return
	 */
	int getLastNumSeqTopHmp();

	/**
	 * recupère une opération top HMP
	 *
	 * @return
	 */
	OperationTop getOperationTopHmp();

	/**
	 *recupère les opération top HMP
	 *
	 * @return
	 */
	List<OperationTop> getOperationTopHmps(boolean isTop);

	/**
	 * change l'état des opérations de tosend  à send
	 *
	 * @param numSequence
	 */
	void isTreated(int numSequence);

}
