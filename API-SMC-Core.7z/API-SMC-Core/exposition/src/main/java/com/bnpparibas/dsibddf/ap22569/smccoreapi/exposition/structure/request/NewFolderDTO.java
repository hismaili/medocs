/**
 * DTO représetant les éléments d'entreé du service
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @author c65344
 *
 */
public class NewFolderDTO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "UID de l'appelant", required = true)
	private String callingUser;
	@ApiModelProperty( value = "Id de la contestation", required = true)
	private String idContestationSmc;
	@ApiModelProperty(value = "numero de la carte bancaire", required = true)
	private String numCarteBancaire;

	/**
	 *
	 */
	public NewFolderDTO() {
		super();
	}


	/**
	 * @param callingUser
	 * @param idContestationSmc
	 * @param numCarteBancaire
	 */
	public NewFolderDTO(String callingUser, String idContestationSmc,
			String numCarteBancaire) {
		this.callingUser = callingUser;
		this.idContestationSmc = idContestationSmc;
		this.numCarteBancaire = numCarteBancaire;
	}

	/**
	 * @return the callingUser
	 */
	public String getCallingUser() {
		return callingUser;
	}


	/**
	 * @return the idContestationSmc
	 */
	public String getIdContestationSmc() {
		return idContestationSmc;
	}


	/**
	 * @return the numCarteBancaire
	 */
	public String getNumCarteBancaire() {
		return numCarteBancaire;
	}


	/**
	 * @param callingUser the callingUser to set
	 */
	public void setCallingUser(String callingUser) {
		this.callingUser = callingUser;
	}

	/**
	 * @param idContestationSmc the idContestationSmc to set
	 */
	public void setIdContestationSmc(String idContestationSmc) {
		this.idContestationSmc = idContestationSmc;
	}

	/**
	 * @param numCarteBancaire the numCarteBancaire to set
	 */
	public void setNumCarteBancaire(String numCarteBancaire) {
		this.numCarteBancaire = numCarteBancaire;
	}


}
