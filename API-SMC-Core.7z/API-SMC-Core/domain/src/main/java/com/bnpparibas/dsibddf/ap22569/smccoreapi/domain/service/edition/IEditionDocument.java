package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface IEditionDocument {
	/**
	 * Creation des documents pdf des courriers generique
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerCloturePDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;


	/**
	 * creation des documents pdf des contestations carte
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerContestationCartePDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;



	/**
	 * Creation des documents pdf des courriers generique
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerCourrierGenericPDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;


	/**
	 * creation des documents pdf des fiche de liaison
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerFicheDeLiaisonPDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;




	/**
	 * creation des documents pdf des formulaires paye
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerFormPayPDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;


	/**
	 * creation des documents pdf des formulaires retraits
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerFormRetraitPDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;



	/**
	 * creation du document pdf du recapitulatifSelfCare
	 *
	 * @param requestEditiqueInput
	 * @return
	 * @throws EditingException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 * @throws DonneIncorectException
	 */
	RequestEditiqueOutput creerRecapitulatifSelfCarePDF(RequestEditiqueInput requestEditiqueInput) throws EditingException,MandatoryException,FormatErrorException,DonneIncorectException;

	/**
	 * recupère un enregistrement Non traité
	 *
	 * @return
	 */
	EditionRecording getEditionRecording();

	int getLastNumSeqEditiqueToSmc();

	/**
	 * recupère le dernier numéro de sequence
	 * @return
	 */
	int getLastNumSequence();

	/**
	 * recupère les enregistrement en base de donné pour le batch aller editique centrale
	 * @return
	 */
	List<EditionRecording> getRecordingEditionTreated(boolean istreated);

	/**
	 *
	 * @return
	 */
	String getXmlFileSmcFromEditique();

	/**
	 * change l'état des fichiers non traité à traité
	 *
	 * @param numSequence
	 */
	void isTreated(int numSequence);

	/**
	 * enregistre les documents provenant de l'editique centrale
	 * @param document
	 */
	void saveDocumentReturnCentral(DocumentRetour document);


	/**
	 * enregistre les informations du header et du footer du document retour Editique centrale
	 */
	void saveInfoFileReturnCentral(InfoFileArchivage infoFile) ;


}
