package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;




/**
 *
 * @author c65344
 *
 */
public class InfoFileArchivage {

	private String idFileArchivage;

	private String codeAppEmetrice;
	private String fluxName;

	private String fluxDate;
	private int numSequence;
	private Integer recordNumber;


	/**
	 *
	 */
	public InfoFileArchivage() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param idFileArchivage
	 * @param codeAppEmetrice
	 * @param fluxName
	 * @param fluxDate
	 * @param numSequence
	 * @param recordNumber
	 */
	public InfoFileArchivage(String idFileArchivage, String codeAppEmetrice,
			String fluxName, String fluxDate, int numSequence,
			Integer recordNumber) {
		this.idFileArchivage = idFileArchivage;
		this.codeAppEmetrice = codeAppEmetrice;
		this.fluxName = fluxName;
		this.fluxDate = fluxDate;
		this.numSequence = numSequence;
		this.recordNumber = recordNumber;
	}


	/**
	 * @return the codeAppEmetrice
	 */
	public String getCodeAppEmetrice() {
		return codeAppEmetrice;
	}


	/**
	 * @return the fluxDate
	 */
	public String getFluxDate() {
		return fluxDate;
	}


	/**
	 * @return the fluxName
	 */
	public String getFluxName() {
		return fluxName;
	}


	/**
	 * @return the idFileArchivage
	 */
	public String getIdFileArchivage() {
		return idFileArchivage;
	}


	/**
	 * @return the numSequence
	 */
	public int getNumSequence() {
		return numSequence;
	}


	/**
	 * @return the recordNumber
	 */
	public Integer getRecordNumber() {
		return recordNumber;
	}


	/**
	 * @param codeAppEmetrice the codeAppEmetrice to set
	 */
	public void setCodeAppEmetrice(String codeAppEmetrice) {
		this.codeAppEmetrice = codeAppEmetrice;
	}


	/**
	 * @param fluxDate the fluxDate to set
	 */
	public void setFluxDate(String fluxDate) {
		this.fluxDate = fluxDate;
	}


	/**
	 * @param fluxName the fluxName to set
	 */
	public void setFluxName(String fluxName) {
		this.fluxName = fluxName;
	}


	/**
	 * @param idFileArchivage the idFileArchivage to set
	 */
	public void setIdFileArchivage(String idFileArchivage) {
		this.idFileArchivage = idFileArchivage;
	}


	/**
	 * @param numSequence the numSequence to set
	 */
	public void setNumSequence(int numSequence) {
		this.numSequence = numSequence;
	}


	/**
	 * @param recordNumber the recordNumber to set
	 */
	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}


}
