package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.ContestationMonetiqueApplication;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.ConfigExposition;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.Document;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.Objectsmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.*;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ContestationMonetiqueApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@ActiveProfiles({"local"})
@Ignore
public class ContestationControllerTest {
	@TestConfiguration
	static class CustomConfiguration {

	}



	private static final Logger LOG = LoggerFactory.getLogger(ContestationControllerTest.class);

	@Autowired
	private transient ConfigExposition conf;

	@Autowired
	private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

	@Autowired
	private MockMvc mvc;

	@Before
	public void beforeTest() {
		mappingJackson2HttpMessageConverter.getObjectMapper().disable(
				SerializationFeature.FAIL_ON_EMPTY_BEANS);
	}

	/**
	 * @throws java.lang.Exception
	 */
	private String getIdAttachment() throws Exception {
		HttpHeaders header = new HttpHeaders();

		header.set("Accept", "application/json");
		header.add("media", conf.getMediaEdoc());
		header.add("channel", conf.getChannelEdoc());
		header.add("userId", conf.getUserIdEdoc());
		header.setContentType(MediaType.MULTIPART_FORM_DATA);
		LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<>();

		map.add("file", new ClassPathResource("/Test.pdf"));

		HttpEntity<LinkedMultiValueMap<String, Object>> request = new HttpEntity<LinkedMultiValueMap<String, Object>>(
				map, header);

		String url = conf.getUrlPostEdoc();

		TestRestTemplate restTemplate = new TestRestTemplate();

		ResponseEntity<ResponseEdoc> result = restTemplate.exchange(url,
				HttpMethod.POST, request, ResponseEdoc.class);

		LOG.info(result.toString());
		Assertions.assertThat(result).isNotNull();
		HttpStatus statusCode = result.getStatusCode();
		Assertions.assertThat(statusCode).isNotNull();
		Assertions.assertThat(statusCode.is2xxSuccessful()).isNotNull();
		ResponseEdoc corps = result.getBody();
		Assertions.assertThat(corps).isNotNull();
		String idAttachment = corps.getIdAttachment();
		Assertions.assertThat(idAttachment).isNotNull();
		Assertions.assertThat(idAttachment).isNotEmpty();
		LOG.info("L'id attachement creer par Edoc est :" + idAttachment);

		return idAttachment;
	}

	@Test
	//@Ignore // à enlever une fois le service compte fonctionne
	public void testAccountsAndCards() {

		ObjectMapper objectMapper = new ObjectMapper();

		RequestBuilder requestBuilder = get("/v1/disputes/cards")
				.header("applicationCode", "AP22569")
				.header("userId", "01630005685900000").header("channel", "2")
				.header("telematicId", "3742002574")
				.header("xB3TraceId", "2289627126")
				.header("xB3SpanId", "2289627126");

		try {
			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();

			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();
			List<AccountWithCards> compteCards = objectMapper.readValue(
					contentAsString,
					new TypeReference<List<AccountWithCards>>() {
					});
			Assertions.assertThat(compteCards).isNotEmpty();
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}

	@Test
	public void testCardOperations() {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			RequestBuilder requestBuilder = get(
					"/v1/disputes/cards/CA10928309835/operations")
					.header("applicationCode", "AP22569")
					.header("userId", "593007").header("channel", "2")
					.header("telematicId", "4484124900001566000")
					.header("offset", "0").header("limit", "10")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();

			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();

			List<OperationVO> operations = objectMapper.readValue(
					contentAsString, new TypeReference<List<OperationVO>>() {
					});

			Assertions.assertThat(operations).isNotEmpty();

			operations.forEach(operation -> {

				//Assertions.assertThat(operation.getCurrecnyOfOperation()).isNotEmpty();
				Assertions.assertThat(operation.getMerchantName()).isNotEmpty();
				Assertions.assertThat(operation.getOperationCode()).isNotEmpty();
				Assertions.assertThat(operation.getOperationLabel()).isNotEmpty();
				Assertions.assertThat(operation.getOperationSign()).isNotNull();
				Assertions.assertThat(operation.getDateOfOperation()).isNotNull();
				Assertions.assertThat(operation.getDateOfSale()).isNotNull();
				Assertions.assertThat(operation.getOperationType()).isNotNull();
				Assertions.assertThat(operation.getOperationAmount()).isNotNull();


			});

		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}

	}

	/**
	 * faire 2 fois la meme requette
	 */
	@Test
	public void testCardOperationsTwice() {
		ObjectMapper objectMapper = new ObjectMapper();

		List<OperationVO> operations = null;
		try {
			RequestBuilder requestBuilder = get(
					"/v1/disputes/cards/CA10928309835/operations")
					.header("applicationCode", "AP22569")
					.header("userId", "593007").header("channel", "2")
					.header("telematicId", "4484124900001566000")
					.header("offset", "0").header("limit", "10")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();

			result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();

			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();

			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();

			operations = objectMapper.readValue(
					contentAsString, new TypeReference<List<OperationVO>>() {
					});


		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.assertThat(operations).isNotEmpty();

			operations.forEach(operation -> {

				//Assertions.assertThat(operation.getCurrecnyOfOperation()).isNotEmpty();
				Assertions.assertThat(operation.getMerchantName()).isNotEmpty();
				Assertions.assertThat(operation.getOperationCode()).isNotEmpty();
				Assertions.assertThat(operation.getOperationLabel()).isNotEmpty();
				Assertions.assertThat(operation.getOperationSign()).isNotNull();
				Assertions.assertThat(operation.getDateOfOperation()).isNotNull();
				Assertions.assertThat(operation.getDateOfSale()).isNotNull();
				Assertions.assertThat(operation.getOperationType()).isNotNull();
				Assertions.assertThat(operation.getOperationAmount()).isNotNull();


			});


		}

	}

	@Test
	public void testCreateDispute() {
		DisputeData disputeData = new DisputeData();
		disputeData.setCardId("CA10928309836");

		DisputeDataOperations operation = new DisputeDataOperations();
		operation.setCodeOperation("OPC01");

		operation.setRecognizedAmount(new BigDecimal(20));
		disputeData.setOperations(Arrays.asList(operation));
		disputeData.setFactsSummary("Contestation de vole de carte"); //$NON-NLS-1$
		try {
			disputeData
			.setAttachedFiles(Arrays
					.asList(new DisputeDataAttachedFiles()
					.filetype("20180110") //$NON-NLS-1$
					.fileName("PVPolice.pdf")
					.idGdn(getIdAttachment())));
		} catch (Exception e1) {
			LOG.error(e1.getMessage(), e1);
		}
		disputeData.setReason("M008");
		disputeData.setNotifMail(Boolean.FALSE);
		disputeData.setNotifSMS(Boolean.TRUE);
		disputeData.setCardLost(Boolean.TRUE);
		disputeData.setPhoneNumber("0665427854");
		disputeData.setMail("agjdf@gmail.com");
		disputeData.setTopPhoneNumberModified(true);
		disputeData.setTopMailModified(true);


		ObjectMapper objectMapper = new ObjectMapper();
		try {
			RequestBuilder requestBuilder = post("/v1/disputes")
					.header("applicationCode", "AP22569")
					.header("userId", "01280000176000000").header("channel", "2")
					.header("telematicId", "345615789521")
					.contentType(MediaType.APPLICATION_JSON_UTF8)
					.content(objectMapper.writeValueAsString(disputeData));

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();
			DisputeSummary values = objectMapper.readValue(contentAsString,
					DisputeSummary.class);
			assertThat(values).isNotNull();
			assertThat(values.getFactsSummary()).isNotNull();
			assertThat(values.getMaskedPan()).isNotNull();
			assertThat(values.getCardType()).isNotNull();
			assertThat(values.getDisputedAmount()).isNotNull();
			assertThat(values.getRecognizedAmount()).isNotNull();

			assertThat(values.getDisputedAmount()).isNotEqualByComparingTo(
					BigDecimal.ZERO);


			assertThat(values.getRecognizedAmount()).isNotEqualByComparingTo(
					values.getDisputedAmount());
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}

	@Test
	public void testCustomerContactsBadRequest() {

		ObjectMapper objectMapper = new ObjectMapper();
		try {

			ResultActions result = null;
			MockHttpServletResponse response = null;
			String contentAsString = null;
			SmcApiError values = null;
			RequestBuilder requestBuilder = null;

			/**
			 * case mandatory absent
			 *
			 */
			requestBuilder = get("/v1/disputes/contacts")
					.header("applicationCode", "AP22569")
					.header("userId", "01630005685900000")
					.header("channel", "2").header("xB3TraceId", "2289627126")
					.header("xB3SpanId", "2289627126")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is4xxClientError());

			response = result.andReturn().getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			contentAsString = response.getContentAsString();

			values = objectMapper.readValue(contentAsString, SmcApiError.class);
			assertThat(values).isNotNull();
			assertThat(values.getCode()).isEqualTo("ERR.CMC.FUNC.700");
			assertThat(values.getMessage()).isNotEmpty();

			// TODO a revoir Urgent le cas d'un idtelematic invalide

			/**
			 * case idtelematic and userId bad data
			 *
			 */
			requestBuilder = get("/v1/disputes/contacts")
					.header("applicationCode", "AP22569")
					.header("userId", "01").header("channel", "2")
					.header("telematicId", "1485")
					.header("xB3TraceId", "2289627126")
					.header("xB3SpanId", "2289627126")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is4xxClientError());

			response = result.andReturn().getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();

			contentAsString = response.getContentAsString();

			values = objectMapper.readValue(contentAsString,
					SmcApiError.class);
			assertThat(values).isNotNull();
			assertThat(values.getCode()).isEqualTo("ERR.CMC.FUNC.703");
			assertThat(values.getMessage()).isNotEmpty();

			assertThat(values.getMessage())
			.isEqualTo(
					"Aucun contact utilisateur trouvé pour le client recherché");

		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}

	@Test
	public void testCustomerContactsMailValidSuccess() {

		ObjectMapper objectMapper = new ObjectMapper();
		try {
			RequestBuilder requestBuilder = get("/v1/disputes/contacts")
					.header("applicationCode", "AP22569")
					.header("userId", "01000002676300000")
					.header("channel", "2").header("telematicId", "37")
					.header("xB3TraceId", "2289627126")
					.header("xB3SpanId", "2289627126")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();

			CustomerContacts values = objectMapper.readValue(contentAsString,
					CustomerContacts.class);
			assertThat(values).isNotNull();
			assertThat(values.getMailId()).isNotEmpty();
			assertThat(values.getPhoneNumberId()).isNull();
			assertThat(values.getMaskedPhoneNumber()).isNull();
			assertThat(values.getMaskedMail()).isNotEmpty();

		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}



	@Test
	public void testCustomerContactsSuccess() {

		ObjectMapper objectMapper = new ObjectMapper();
		try {
			RequestBuilder requestBuilder = get("/v1/disputes/contacts")
					.header("applicationCode", "AP22569")
					.header("userId", "01000002676300000")
					.header("channel", "2").header("telematicId", "3742002574")
					.header("xB3TraceId", "2289627126")
					.header("xB3SpanId", "2289627126")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();

			CustomerContacts values = objectMapper.readValue(contentAsString,
					CustomerContacts.class);
			assertThat(values).isNotNull();
			assertThat(values.getMailId()).isNotEmpty();
			assertThat(values.getPhoneNumberId()).isNotEmpty();
			assertThat(values.getMaskedPhoneNumber()).isNotEmpty();
			assertThat(values.getMaskedMail()).isNotEmpty();



		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}

	@Test
	public void testGetDocSelfCare() {

		HttpHeaders header = new HttpHeaders();

		header.set("Accept", "application/json");
		header.add("Content-Type", "application/json");
		header.add("media", conf.getMediaEdoc());
		header.add("channel", conf.getChannelEdoc());
		header.add("userId", conf.getUserIdEdoc());

		try {

			HttpEntity<String> request = new HttpEntity<String>(header);
			String idAttachment = getIdAttachment();
			String url = "http://exp-srv-metier-s1-rhel66.dev.echonet:10082/api/attachments/"
					+ idAttachment + "/validate";

			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<ResponseEdoc> resp;


			ObjectMapper objectMapper = new ObjectMapper();
			resp = restTemplate.exchange(URLDecoder.decode(url, "UTF-8"),
					HttpMethod.PUT, request, ResponseEdoc.class);

			ResponseEdoc body = resp.getBody();

			RequestBuilder requestBuilder = get(
					"/v1/disputes/document/" + body.getIdGDN())
					.header("applicationCode", "AP22569")
					.header("userId", "01000002676300000")
					.header("channel", "2").header("telematicId", "3742002574")
					.header("telematicId", "2289627126")
					.header("xB3TraceId", "2289627126")
					.header("xB3SpanId", "2289627126")
					.contentType(MediaType.APPLICATION_JSON_UTF8);

			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().is2xxSuccessful());

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();

			ArchivageResponseGetDoc values = objectMapper.readValue(contentAsString,
					ArchivageResponseGetDoc.class);
			assertThat(values).isNotNull();
			Document document = values.getDocument();
			assertThat(document).isNotNull();
			Objectsmc object = document.getObject();
			assertThat(object).isNotNull();
			assertThat(object.getData()).isNotEmpty();
			assertThat(object.getCompress()).isNotEmpty();
			assertThat(object.getEncoding()).isNotEmpty();
		} catch (RestClientException e1) {
			LOG.error(e1.getMessage(), e1);
			Assertions.fail(e1.getMessage());
		} catch (UnsupportedEncodingException e1) {
			LOG.error(e1.getMessage(), e1);
			Assertions.fail(e1.getMessage());
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}

	@Test
	@Ignore
	public void testHistoriqueContestation() {
		RequestBuilder requestBuilder = get("/v1/disputes")
				.header("applicationCode", "AP22569")
				.header("userId", "593007").header("channel", "2")
				.header("telematicId", "345615789521");
		try {
			ResultActions result = mvc.perform(requestBuilder);
			assertThat(result).isNotNull();
			result.andExpect(status().isOk());
			ObjectMapper objectMapper = new ObjectMapper();

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			assertThat(response.getHeader("X-B3-TraceId")).isNotNull();
			final String contentAsString = response.getContentAsString();
			List values = objectMapper.readValue(contentAsString, List.class);
			assertThat(values).isNotNull().isNotEmpty();
			assertThat(values.size()).isEqualTo(2);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}
	@Test
	@Ignore
	public void testReasons() {
		RequestBuilder requestBuilder = get(
				"/v1/disputes/reasons?typeOperation=RETRAIT&cardLost=false&numberOfOperations=1")
				.header("applicationCode", "AP22569")
				.header("userId", "593007").header("channel", "2")
				.header("telematicId", "345615789521");
		try {
			ResultActions result = mvc.perform(requestBuilder).andExpect(
					status().isOk());
			ObjectMapper objectMapper = new ObjectMapper();

			final MockHttpServletResponse response = result.andReturn()
					.getResponse();
			assertThat(response).isNotNull();
			List values = objectMapper.readValue(response.getContentAsString(),
					List.class);
			assertThat(values).isNotNull().isNotEmpty();
			assertThat(values.size()).isEqualTo(5);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			Assertions.fail(e.getMessage());
		}
	}
}
