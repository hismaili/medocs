/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author c65344
 *
 */
public interface PersonContactJpaRepository extends JpaRepository<PersonContactEntity, String>{

	PersonContactEntity findByMailId(String mailId);

	PersonContactEntity findByPhoneNumberId(String phoneNumberId);

	PersonContactEntity findByTelematicIdAndUserId(String telematicId, String UserId);

}
