package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;


import brave.Tracer;
import brave.propagation.TraceContext;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage.IArchivageManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.BuilderResponseSmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.ConfigExposition;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.ControlBuilder;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponse;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.ArchivageResponseGetDoc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcApiError;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcResponseError;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
/**
 *
 *
 *
 */
@RequestMapping("/v1/smc/archivage/")
@RestController
@Validated
@Api(tags = {"Gestion de l'archivage des documents dans GDN"})
public class ArchivageController {

	private static final Logger LOG = LoggerFactory.getLogger(ArchivageController.class);
	private static final Locale ADEFAULT = Locale.getDefault();
	private static final String STRING = " : ";
	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$
	private static final String ERROR = "ERREUR INTERNE DU SERVEUR"; //$NON-NLS-1$

	private static final String NULLVALUE = null;
	@Autowired
	private transient ControlBuilder control;
	@Autowired
	private transient Tracer tracer;

	@Autowired
	private transient BuilderResponseSmc builderResponse;


	@Autowired
	private final transient IArchivageManagement archivageManagement;
	@Autowired
	private transient ConfigExposition conf;


	/**
	 *
	 * @param archivageManagement
	 */
	public ArchivageController(IArchivageManagement archivageManagement) {
		this.archivageManagement = archivageManagement;
	}

	/**
	 * Ferme un dossier du système d'archivage
	 *
	 * @param closeFolderDTO
	 * @param head : header http
	 * @return
	 */
	@ApiOperation(value = "", nickname = "closeFolder", notes = "Ferme un dossier du système d'archivage", response = ArchivageResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fermeture effectuée.", response = ArchivageResponse.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class)})
	@RequestMapping(value = "/folder/close" ,produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
	public ResponseEntity closeFolder(@RequestBody(required=false) CloseFolderDTO closeFolderDTO,@RequestHeader(required=false) String codeApplication,@RequestHeader(required=false) String canal) {
		List<String> missingDatas = new ArrayList<String>();
		List<String> formatErrors = new ArrayList<String>();

		try {
			final TraceContext context = tracer.currentSpan().context();
			CloseFolderInput closeFolderInput = new CloseFolderInput();
			closeFolderInput.setLocaleCodeCloseFolderInput(ADEFAULT.getLanguage());
			closeFolderInput.setCountryCodeCloseFolderInput(ADEFAULT.getCountry());


			control.checkMandatoryFields(codeApplication, conf.getCodeApplicationAbsent(), missingDatas);
			control.checkMandatoryFields(canal , conf.getCanalAbsent(), missingDatas);

			if(closeFolderDTO !=null){

				/**
				 * controle sur la présence des données
				 */
				control.checkMandatoryFields(closeFolderDTO.getIdContestationSmc(), conf.getIdContestationSmcAbsent(), missingDatas);
				if(CollectionUtils.isEmpty(closeFolderDTO.getDocsIdsGDN())){
					missingDatas.add(conf.getListeIdDocsAbsent());
				}


				control.checkMandatoryFields(closeFolderDTO.getArchivingReferenceDate(), conf.getArchivingreferencedateAbsent(), missingDatas);
				control.checkMandatoryFields(closeFolderDTO.getDocumentTypeId(),conf.getDocumentTypeIdAbsent(), missingDatas);
				control.checkMandatoryFields(closeFolderDTO.getMimeType(), conf.getMimetypeAbsent(), missingDatas);
				control.checkMandatoryFields(closeFolderDTO.getTitre(), conf.getTitreAbsent(), missingDatas);

				if(closeFolderDTO.getDocument() !=null){
					control.checkMandatoryFields(closeFolderDTO.getDocument().getFileName(), conf.getFilenameAbsent(), missingDatas);
					control.checkMandatoryFields(closeFolderDTO.getDocument().getArchiveFormat(), conf.getArchiveformatAbsent(), missingDatas);
					closeFolderInput.setFileNameCloseFolderInput(closeFolderDTO.getDocument().getFileName());
					closeFolderInput.setArchiveFormatCloseFolderInput(closeFolderDTO.getDocument().getArchiveFormat());

					if(closeFolderDTO.getDocument().getObject() !=null){
						control.checkMandatoryFields(closeFolderDTO.getDocument().getObject().getCompress(), conf.getCompressAbsent(), missingDatas);
						control.checkMandatoryFields(closeFolderDTO.getDocument().getObject().getEncoding(), conf.getEncodingAbsent(), missingDatas);
						control.checkMandatoryFields(closeFolderDTO.getDocument().getObject().getData(), conf.getDataAbsent(), missingDatas);

						closeFolderInput.setEncodingCloseFolderInput(closeFolderDTO.getDocument().getObject().getEncoding());
						closeFolderInput.setDataCloseFolderInput(closeFolderDTO.getDocument().getObject().getData());
						closeFolderInput.setCompressCloseFolderInput(closeFolderDTO.getDocument().getObject().getCompress());
					}else{
						control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
						control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
						control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
					}
				}else{
					control.checkMandatoryFields(NULLVALUE, conf.getFilenameAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getArchiveformatAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
				}


				/**
				 * controles sur le format des données
				 *
				 */
				control.checkFormatMimeType(closeFolderDTO.getMimeType(), formatErrors);
				control.checkFormatDate(closeFolderDTO.getArchivingReferenceDate(),"archivingReferenceDate");
				if(!StringUtils.isEmpty(control.checkFormatDate(closeFolderDTO.getArchivingReferenceDate(),"archivingReferenceDate"))){
					formatErrors.add(control.checkFormatDate(closeFolderDTO.getArchivingReferenceDate(),"archivingReferenceDate"));
				}
				control.checkFormatDocumentTypeId(closeFolderDTO.getDocumentTypeId(), formatErrors);

				SmcResponseError smcResponseError = builderResponse.getResponseSmcError(formatErrors, null, missingDatas,null);

				if(smcResponseError !=null && !CollectionUtils.isEmpty(smcResponseError.getErrors())){
					return new ResponseEntity (smcResponseError,HttpStatus.BAD_REQUEST);
				}else{
					closeFolderInput.setCallingUserCloseFolderInput(closeFolderDTO.getCallingUser());

					closeFolderInput.setIdContestationSmcCloseFolderInput(closeFolderDTO.getIdContestationSmc());
					closeFolderInput.setListedocumentId(closeFolderDTO.getDocsIdsGDN());

					closeFolderInput.setArchivingReferenceDate(closeFolderDTO.getArchivingReferenceDate());

					closeFolderInput.setDocumentTypeIdCloseFolderInput(closeFolderDTO.getDocumentTypeId());
					closeFolderInput.setMimeTypeCloseFolderInput(closeFolderDTO.getMimeType());
					closeFolderInput.setTitreCloseFolderInput(closeFolderDTO.getTitre());


					String folderId = archivageManagement.closeFolder(closeFolderInput);
					return builderResponse.responseSuccess(folderId);

				}
			}else{

				control.checkMandatoryFields(NULLVALUE, conf.getListeIdDocsAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getArchivingreferencedateAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getDocumentTypeIdAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getMimetypeAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getTitreAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getFilenameAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getArchiveformatAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getIdContestationSmcAbsent(), missingDatas);

				return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatas))),HttpStatus.BAD_REQUEST);
			}

		} catch (ArchivingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeErreurServeurGdn(), conf.getErrorGeneriqueInterne(), Arrays.asList(e.getMessage())))),HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (MandatoryException e) {
			LOG.error(conf.getErrorGeneriqueAbsent(), e);
			/**
			 * donnée absente
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		} catch (FormatErrorException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée au mauvais format
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeFormatIncorrect(), conf.getErrorGeneriqueIncorect(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		} catch (DonneIncorectException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée incorecte
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeDonneIncorrect(), conf.getErrorGeneriqueIncorect(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));
		}


	}


	/**
	 * Supprimer un document du système d'archivage
	 * On verifie si il y'a des erreurs si il y'en a pas on retourne l'identifiant
	 * si non on retourne la liste d'erreurs
	 *
	 * @param documentId : l'id GDN du document à supprimer
	 * @param head : header
	 */
	@ApiOperation(value = "", nickname = "deleteDoc", notes = "Supprimer un document du système d'archivage", response = ArchivageResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Suppression effectuée.", response = ArchivageResponse.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class) })
	@RequestMapping(value="/document/delete/{documentId}", produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.DELETE)
	public ResponseEntity deleteDoc(@PathVariable(required =false) final String documentId,@RequestHeader(required =false) String callingUser,@RequestHeader(required =false) String idContestationSmc,@RequestHeader(required =false) String codeApplication,@RequestHeader(required =false) String canal){

		List<String> missingDatas = new ArrayList<String>();
		try{
			/**
			 * control des données
			 */
			control.checkMandatoryFields(idContestationSmc, conf.getIdContestationSmcAbsent(),missingDatas);
			control.checkMandatoryFields(documentId, conf.getDocumentIdAbsent(),missingDatas);
			control.checkMandatoryFields(callingUser, conf.getCallingUserAbsent(), missingDatas);
			control.checkMandatoryFields(canal , conf.getCanalAbsent(), missingDatas);
			control.checkMandatoryFields(codeApplication, conf.getCodeApplicationAbsent(), missingDatas);
			if(!CollectionUtils.isEmpty(missingDatas)){
				return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatas))
						),HttpStatus.BAD_REQUEST);
			}else{
				DeleteDocInput deleteDocInput = new DeleteDocInput();
				deleteDocInput.setCallingUserDeleteInput(callingUser);
				deleteDocInput.setIdContestationSmcDeleteInput(idContestationSmc);
				deleteDocInput.setCountryCodeDeleteInput(ADEFAULT.getLanguage());
				deleteDocInput.setLocaleCodeDeleteInput(ADEFAULT.getCountry());
				deleteDocInput.setDocumentIdDeleteInput(documentId);

				String folderId;

				folderId = archivageManagement.deleteDoc(deleteDocInput);

				return builderResponse.responseSuccess(folderId);

			}
		} catch (ArchivingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeErreurServeurGdn(), conf.getErrorGeneriqueInterne(), Arrays.asList(e.getMessage())))),HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (MandatoryException e) {
			LOG.error(conf.getErrorGeneriqueAbsent(), e);
			/**
			 * donnée absente
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));
		}
	}



	/**
	 * Recupère un document du système d'archivage
	 * On verifie si il y'a des erreurs si il y'e,n a pas on retourne l'identifiant
	 * si non on retourne une erreur
	 *
	 * @param head : la requette que doit envoyer smc
	 */
	@ApiOperation(value = "", nickname = "getDoc", notes = "Recupère un document du système d'archivage", response = ArchivageResponseGetDoc.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Opération effectuée.", response = ArchivageResponseGetDoc.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class), })
	@RequestMapping(value="/document/{documentId}",produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.GET)
	public ResponseEntity getDoc(@PathVariable(required=false) String documentId, @RequestHeader(required=false) String callingUser,@RequestParam(required=false) String idContestationSmc,@RequestHeader(required=false) String userType, @RequestHeader(required=false) HeaderSmc headerSmc){

		List<String> missingDatas = new ArrayList<String>();
		try {

			/**
			 * control des données
			 */
			control.checkMandatoryFields(documentId, conf.getDocumentIdAbsent(), missingDatas);
			control.checkMandatoryFields(callingUser, conf.getCallingUserAbsent(), missingDatas);
			control.checkMandatoryFields(idContestationSmc , conf.getIdContestationSmcAbsent(), missingDatas);
			control.checkMandatoryFields(userType , conf.getUsertypeAbsent(), missingDatas);

			if(headerSmc !=null){
				control.checkMandatoryFields(headerSmc.getCanal(),conf.getCanalAbsent(), missingDatas);
				control.checkMandatoryFields(headerSmc.getCodeApplication(),conf.getCodeApplicationAbsent(), missingDatas);
			}else{
				control.checkMandatoryFields(NULLVALUE,conf.getCanalAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE,conf.getCodeApplicationAbsent(), missingDatas);
			}

			if(!CollectionUtils.isEmpty(missingDatas)){
				return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatas))
						),HttpStatus.BAD_REQUEST);
			}else{
				DocInput getDocInput = new DocInput(
						callingUser,
						documentId,userType,
						idContestationSmc);

				DocOutput getDocOutput;

				getDocOutput = archivageManagement.getDoc(getDocInput);

				return new ResponseEntity<ArchivageResponseGetDoc>(new ArchivageResponseGetDoc(new Document(getDocOutput.getFileNameOutput(),
						getDocOutput.getArchiveFormatOutput(),
						new Objectsmc(getDocOutput.getCompressOutput(),
								getDocOutput.getEncodingOutput(),
								getDocOutput.getDataOutputOutput())
						)), HttpStatus.OK);
			}

		} catch (ArchivingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(), e);

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999",
							conf.getErrorGeneriqueInterne(),null));
		} catch (MandatoryException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), Arrays.asList(e.getMessage())))),HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));
		}



	}



	/**
	 * crée un nouveau document dans le système d'archivage
	 * On verifie si il y'a des erreurs si il y'en a pas on retourne l'identifiant
	 * si non on retourne une erreur
	 * @param newDocDTO
	 * @return
	 */
	@ApiOperation(value = "", nickname = "newDoc", notes = "crée un nouveau document dans le système d'archivage", response = ArchivageResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Opération effectuée.", response = ArchivageResponse.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class)})
	@RequestMapping(value = "/document/new",produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
	public ResponseEntity newDoc(@RequestBody(required =false) final NewDocDTO newDocDTO, @RequestHeader(required =false) String codeApplication,@RequestHeader(required =false) String canal) {
		List<String> missingDatas = new ArrayList<String>();
		List<String> formatErrors = new ArrayList<String>();
		NewDocInput newDocInput = new NewDocInput();

		try {
			newDocInput.setLocaleCodeNewDocInput(ADEFAULT.getLanguage());
			newDocInput.setCountryCodeNewDocInput(ADEFAULT.getCountry());


			control.checkMandatoryFields(canal,conf.getCanalAbsent(), missingDatas);
			control.checkMandatoryFields(codeApplication,conf.getCodeApplicationAbsent(), missingDatas);

			if(newDocDTO !=null){
				/**
				 * controle sur la présence des données
				 */
				control.checkMandatoryFields(newDocDTO.getIdContestationSmc(), conf.getIdContestationSmcAbsent(), missingDatas);
				control.checkMandatoryFields(newDocDTO.getCallingUser(), conf.getCallingUserAbsent(), missingDatas);
				control.checkMandatoryFields(newDocDTO.getDocumentTypeId(),conf.getDocumentTypeIdAbsent(), missingDatas);

				control.checkMandatoryFields(newDocDTO.getMimeType(), conf.getMimetypeAbsent(), missingDatas);
				control.checkMandatoryFields(newDocDTO.getTitre(), conf.getTitreAbsent(), missingDatas);
				/**
				 * controles sur le format des données
				 *
				 */
				control.checkFormatMimeType(newDocDTO.getMimeType(), formatErrors);
				control.checkFormatDocumentTypeId(newDocDTO.getDocumentTypeId(), formatErrors);


				newDocInput.setCallingUserNewDocInput(newDocDTO.getCallingUser());
				newDocInput.setIdContestationSmcNewDocInput(newDocDTO.getIdContestationSmc());
				newDocInput.setDocumentTypeIdNewDocInput(newDocDTO.getDocumentTypeId());
				newDocInput.setMimeTypeNewDocInput(newDocDTO.getMimeType());
				newDocInput.setTitreNewDocInput(newDocDTO.getTitre());

				if(newDocDTO.getDocument() !=null){
					control.checkMandatoryFields(newDocDTO.getDocument().getFileName(), conf.getFilenameAbsent(), missingDatas);
					control.checkMandatoryFields(newDocDTO.getDocument().getArchiveFormat(), conf.getArchiveformatAbsent(), missingDatas);
					newDocInput.setFileNameNewDocInput(newDocDTO.getDocument().getFileName());
					newDocInput.setArchiveFormatNewDocInput(newDocDTO.getDocument().getArchiveFormat());
					if(newDocDTO.getDocument().getObject() !=null){
						control.checkMandatoryFields(newDocDTO.getDocument().getObject().getCompress(), conf.getCompressAbsent(), missingDatas);
						control.checkMandatoryFields(newDocDTO.getDocument().getObject().getEncoding(), conf.getEncodingAbsent(), missingDatas);
						control.checkMandatoryFields(newDocDTO.getDocument().getObject().getData(), conf.getDataAbsent(), missingDatas);
						newDocInput.setEncodingNewDocInput(newDocDTO.getDocument().getObject().getEncoding());
						newDocInput.setDataNewDocInput(newDocDTO.getDocument().getObject().getData());
						newDocInput.setCompressNewDocInput(newDocDTO.getDocument().getObject().getCompress());
					}else{
						control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
						control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
						control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
					}
				}else{
					control.checkMandatoryFields(NULLVALUE, conf.getFilenameAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getArchiveformatAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
					control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
				}
			}else{

				control.checkMandatoryFields(NULLVALUE, conf.getIdContestationSmcAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getCallingUserAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE,conf.getDocumentTypeIdAbsent(), missingDatas);

				control.checkMandatoryFields(NULLVALUE, conf.getMimetypeAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getTitreAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getFilenameAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getArchiveformatAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getCompressAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getEncodingAbsent(), missingDatas);
				control.checkMandatoryFields(NULLVALUE, conf.getDataAbsent(), missingDatas);
			}

			SmcResponseError smcResponseError = builderResponse.getResponseSmcError(formatErrors, null, missingDatas,null);

			if(smcResponseError !=null && !CollectionUtils.isEmpty(smcResponseError.getErrors())){
				return new ResponseEntity (smcResponseError,HttpStatus.BAD_REQUEST);
			}else{

				String folderId;

				folderId = archivageManagement.newDoc(newDocInput);

				return new ResponseEntity<ArchivageResponse>(new ArchivageResponse(folderId), HttpStatus.CREATED);

			}


		} catch (ArchivingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeErreurServeurGdn(), conf.getErrorGeneriqueInterne(), Arrays.asList(e.getMessage())))),HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (MandatoryException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), Arrays.asList(e.getMessage())))),HttpStatus.BAD_REQUEST);
		} catch (FormatErrorException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée au mauvais format
			 */
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeFormatIncorrect(), conf.getErrorGeneriqueIncorect(), e.getErrors()))),HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));
		}




	}

	/**
	 * Purge un dossier dans le système d'archivage
	 * On verifie si il y'a des erreurs si il y'e,n a pas on retourne l'identifiant
	 * si non on retourne la liste d'erreurs
	 * @throws ContestationException
	 * @throws IOException
	 */
	@ApiOperation(value = "", nickname = "purgeFolder", notes = "Purge un dossier dans le système d'archivage", response = ArchivageResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Le dossier a été purgé.", response = ArchivageResponse.class),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcResponseError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcResponseError.class) })
	@RequestMapping(value = "/folder/purge",produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
	public ResponseEntity purgeFolder(@RequestBody(required=false) final PurgeFolderDTO purgeFolderDTO,@RequestHeader(required=false) String codeApplication,@RequestHeader(required=false) String canal ){
		PurgeFolderInput purgeFolderInput = new PurgeFolderInput();
		List<String> missingDatas = new ArrayList<String>();

		try {
			/**
			 * controle des données
			 */
			control.checkMandatoryFields(canal,conf.getCanalAbsent(), missingDatas);
			control.checkMandatoryFields(codeApplication,conf.getCodeApplicationAbsent(), missingDatas);


			if(purgeFolderDTO !=null){

				if(CollectionUtils.isEmpty(purgeFolderDTO.getListeIdContestations())){
					missingDatas.add(conf.getListeIdDocsAbsent());
				}
				purgeFolderInput.setListeIdContestationPurgeFolderInput(purgeFolderDTO.getListeIdContestations());
			}else{
				missingDatas.add(conf.getListeIdDocsAbsent());
			}

			if(!CollectionUtils.isEmpty(missingDatas)){
				return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(), conf.getErrorGeneriqueAbsent(), missingDatas))
						),HttpStatus.BAD_REQUEST);
			}else{

				String message;

				message = archivageManagement.purgeFolder(purgeFolderInput);


				return new ResponseEntity<ArchivageResponse>(new ArchivageResponse(message), HttpStatus.OK);

			}

		} catch (ContestationException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(),e);
			return new ResponseEntity (new SmcResponseError(Arrays.asList(new SmcApiError(conf.getCodeErreurServeurGdn(), conf.getErrorGeneriqueInterne(), Arrays.asList(e.getMessage())))),HttpStatus.BAD_REQUEST);
		}catch(Exception e){
			LOG.error(e.getMessage(), e);
			return ResponseEntity
					.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999", "Unexpected Technical error", Arrays.asList(e.getMessage())));
		}


	}



}