package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author c65344
 *
 */
@Entity
@Table(name = "PHRASE")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class PhraseEntity extends AbstractEntity<DefaultEntityId> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Column(name="index_phrase")
	private Integer indexPhrase;
	@Column(name="texte_phrase")
	private String textePhrase;

	/**
	 * @return the indexPhrase
	 */
	public Integer getIndexPhrase() {
		return indexPhrase;
	}


	/**
	 * @return the textePhrase
	 */
	public String getTextePhrase() {
		return textePhrase;
	}
	/**
	 * @param indexPhrase the indexPhrase to set
	 */
	public void setIndexPhrase(Integer indexPhrase) {
		this.indexPhrase = indexPhrase;
	}

	/**
	 * @param textePhrase the textePhrase to set
	 */
	public void setTextePhrase(String textePhrase) {
		this.textePhrase = textePhrase;
	}


}
