package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Information addtionnelle erreur
 */
public class AdditionalInformation   {
	@JsonProperty("attributeAdditionalInformation")
	private String attributeAdditionalInformation;

	/**
	 * @return the attributeAdditionalInformation
	 */
	public String getAttributeAdditionalInformation() {
		return attributeAdditionalInformation;
	}

	/**
	 * @param attributeAdditionalInformation the attributeAdditionalInformation to set
	 */
	public void setAttributeAdditionalInformation(
			String attributeAdditionalInformation) {
		this.attributeAdditionalInformation = attributeAdditionalInformation;
	}

}

