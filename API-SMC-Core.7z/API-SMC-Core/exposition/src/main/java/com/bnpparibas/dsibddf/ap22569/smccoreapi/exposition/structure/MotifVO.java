package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.ExigenceAjoutInformation;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 *
 *
 */
public class MotifVO {

	/**
	 * Saisie de la description des faits obligatoire, recommandée ou non obligatoire pour ce motif
	 */
	public enum TopMentionFactDescriptionEnum {
		obligatoire("obligatoire"),

		recommandee("recommandee"),

		facultatif("facultatif");

		@JsonCreator
		public static TopMentionFactDescriptionEnum fromValue(String text) {
			for (TopMentionFactDescriptionEnum b : TopMentionFactDescriptionEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}

		private String value;

		TopMentionFactDescriptionEnum(String value) {
			this.value = value;
		}

		@Override
		@JsonValue
		public String toString() {
			return String.valueOf(value);
		}
	}

	private String code;

	private String label;

	private String disclaimerText;

	private Boolean topCardCancelled;

	private TopMentionFactDescriptionEnum topMentionFactDescription;

	private Boolean topMentionRecognizedAmount;

	private ExigenceAjoutInformation exigenceAttachement;

	@Valid
	private List<MotifVOAssociatedDocuments> associatedDocuments;

	private String description;
	/**
	 *
	 * @param associatedDocumentsItem
	 * @return
	 */
	public MotifVO addAssociatedDocumentsItem(MotifVOAssociatedDocuments associatedDocumentsItem) {
		if (this.associatedDocuments == null) {
			this.associatedDocuments = new ArrayList<MotifVOAssociatedDocuments>();
		}
		this.associatedDocuments.add(associatedDocumentsItem);
		return this;
	}
	/**
	 *
	 * @param associatedDocuments
	 * @return
	 */
	public MotifVO associatedDocuments(List<MotifVOAssociatedDocuments> associatedDocuments) {
		this.associatedDocuments = associatedDocuments;
		return this;
	}
	/**
	 *
	 * @param code
	 * @return
	 */
	public MotifVO code(String code) {
		this.code = code;
		return this;
	}
	/**
	 *
	 * @param disclaimerText
	 * @return
	 */
	public MotifVO disclaimerText(String disclaimerText) {
		this.disclaimerText = disclaimerText;
		return this;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this.equals(o)) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		MotifVO motifVO = (MotifVO) o;
		return Objects.equals(this.code, motifVO.code) &&
				Objects.equals(this.label, motifVO.label) &&
				Objects.equals(this.disclaimerText, motifVO.disclaimerText) &&
				Objects.equals(this.topCardCancelled, motifVO.topCardCancelled) &&
				Objects.equals(this.topMentionFactDescription, motifVO.topMentionFactDescription) &&
				Objects.equals(this.topMentionRecognizedAmount, motifVO.topMentionRecognizedAmount) &&
				Objects.equals(this.associatedDocuments, motifVO.associatedDocuments);
	}

	/**
	 * Get associatedDocuments
	 *
	 * @return associatedDocuments
	 **/
	@ApiModelProperty(value = "")
	@Valid
	public List<MotifVOAssociatedDocuments> getAssociatedDocuments() {
		return associatedDocuments;
	}

	/**
	 * code du motif
	 *
	 * @return code
	 **/
	@ApiModelProperty(value = "code du motif")
	public String getCode() {
		return code;
	}

	/**
	 * le disclaimer affiché en bas de page que le client devrait reconnaître
	 *
	 * @return disclaimerText
	 **/
	@ApiModelProperty(value = "le disclaimer affiché en bas de page que le client devrait reconnaître")
	public String getDisclaimerText() {
		return disclaimerText;
	}

	public ExigenceAjoutInformation getExigenceAttachement() {
		return exigenceAttachement;
	}

	/**
	 * libellé du motif
	 *
	 * @return label
	 **/
	@ApiModelProperty(value = "libellé du motif")
	public String getLabel() {
		return label;
	}

	public Boolean getTopCardCancelled() {
		return topCardCancelled;
	}

	/**
	 * Saisie de la description des faits obligatoire, recommandée ou non obligatoire pour ce motif
	 *
	 * @return topMentionFactDescription
	 **/
	@ApiModelProperty(value = "Saisie de la description des faits obligatoire, recommandée ou non obligatoire pour ce motif")
	public TopMentionFactDescriptionEnum getTopMentionFactDescription() {
		return topMentionFactDescription;
	}
	/**
	 *
	 * @return
	 */
	public Boolean getTopMentionRecognizedAmount() {
		return topMentionRecognizedAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code, label, disclaimerText, topCardCancelled, topMentionFactDescription, topMentionRecognizedAmount, associatedDocuments);
	}

	/**
	 * opposition nécessaire ou non pour le motif
	 *
	 * @return topCardCancelled
	 **/
	@ApiModelProperty(value = "opposition nécessaire ou non pour le motif")
	public Boolean isTopCardCancelled() {
		return topCardCancelled;
	}

	/**
	 * affichage du montant à saisir
	 *
	 * @return topMentionRecognizedAmount
	 **/
	@ApiModelProperty(value = "affichage du montant à saisir")
	public Boolean isTopMentionRecognizedAmount() {
		return topMentionRecognizedAmount;
	}
	/**
	 *
	 * @param label
	 * @return
	 */
	public MotifVO label(String label) {
		this.label = label;
		return this;
	}
	/**
	 *
	 * @param associatedDocuments
	 */
	public void setAssociatedDocuments(List<MotifVOAssociatedDocuments> associatedDocuments) {
		this.associatedDocuments = associatedDocuments;
	}
	/**
	 *
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 *
	 * @param disclaimerText
	 */
	public void setDisclaimerText(String disclaimerText) {
		this.disclaimerText = disclaimerText;
	}
	/**
	 *
	 * @param exigenceAttachement
	 */
	public void setExigenceAttachement(ExigenceAjoutInformation exigenceAttachement) {
		this.exigenceAttachement = exigenceAttachement;
	}
	/**
	 *
	 * @param label
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 *
	 * @param topCardCancelled
	 */
	public void setTopCardCancelled(Boolean topCardCancelled) {
		this.topCardCancelled = topCardCancelled;
	}
	/**
	 *
	 * @param topMentionFactDescription
	 */
	public void setTopMentionFactDescription(TopMentionFactDescriptionEnum topMentionFactDescription) {
		this.topMentionFactDescription = topMentionFactDescription;
	}
	/**
	 *
	 * @param topMentionRecognizedAmount
	 */
	public void setTopMentionRecognizedAmount(Boolean topMentionRecognizedAmount) {
		this.topMentionRecognizedAmount = topMentionRecognizedAmount;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
	/**
	 *
	 * @param topCardCancelled
	 * @return
	 */
	public MotifVO topCardCancelled(Boolean topCardCancelled) {
		this.topCardCancelled = topCardCancelled;
		return this;
	}
	/**
	 *
	 * @param topMentionFactDescription
	 * @return
	 */
	public MotifVO topMentionFactDescription(TopMentionFactDescriptionEnum topMentionFactDescription) {
		this.topMentionFactDescription = topMentionFactDescription;
		return this;
	}
	/**
	 *
	 * @param topMentionRecognizedAmount
	 * @return
	 */
	public MotifVO topMentionRecognizedAmount(Boolean topMentionRecognizedAmount) {
		this.topMentionRecognizedAmount = topMentionRecognizedAmount;
		return this;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class MotifVO {\n");

		sb.append("    code: ").append(toIndentedString(code)).append("\n");
		sb.append("    label: ").append(toIndentedString(label)).append("\n");
		sb.append("    disclaimerText: ").append(toIndentedString(disclaimerText)).append("\n");
		sb.append("    topCardCancelled: ").append(toIndentedString(topCardCancelled)).append("\n");
		sb.append("    topMentionFactDescription: ").append(toIndentedString(topMentionFactDescription)).append("\n");
		sb.append("    topMentionRecognizedAmount: ").append(toIndentedString(topMentionRecognizedAmount)).append("\n");
		sb.append("    associatedDocuments: ").append(toIndentedString(associatedDocuments)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}
