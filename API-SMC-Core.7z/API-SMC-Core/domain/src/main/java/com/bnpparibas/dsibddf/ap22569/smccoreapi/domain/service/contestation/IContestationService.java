package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;

import java.util.List;

/**
 *
 *
 *
 */
public interface IContestationService {

	/** Consulter une contestation */
	Contestation consulterContestation(String referenceDossier) throws ContestationException;

	/** Creer un dossier de contestation dans SMC
	 *
	 * Parameter
	 *
	 */
	Contestation creerDossierContestation(ContestationSelfcareIn contestationSelfCare) throws ContestationValidationException, ContestationException;

	/**
	 * verifie la juridiction d'un document
	 * @param idGdn
	 * @param idTelematic
	 * @return
	 */
	boolean isAuthorized(String idGdn,String idTelematic);

	/**consulter contestation par son id interne
	 *
	 * @param idContestation
	 * @return
	 * @throws ContestationException
	 */
	Contestation recupererContestationByIdInterne(String idContestation) throws ContestationException;

	/** Consulter la liste des contestations client */
	List<Contestation> recupererContestationsClient(String identifiant,Integer offset,Integer limit) throws ContestationException;

	/** Récupérer la liste des motifs qui leurs sont associées
	 *
	 */
	List<MotifContestation> recupererMotifsContestation();

	/** Récupérer la liste des motifs qui leurs sont associées
	 *
	 */
	List<MotifContestation> recupererMotifsContestation(TypeOperation operationType);

	List<MotifContestation> recupererMotifsContestation(TypeOperation operationType, Boolean cardLost, Integer numberOfOperations) throws Exception;

	/**
	 * recupère le status d'une contestation a partir de son codeStatut
	 *
	 * @param codeStatut
	 * @return
	 */
	StatutDossierContestation recupererStatutDossier(String codeStatut) throws ContestationException, DonneIncorectException, MandatoryException;

	/** Reprendre Contestation
	 *
	 */
	void reprendreContestation();

	/** Sauvegarder une contestation à l'état brouillon dans la couche monétique
	 *
	 * @param contestationSelfCare
	 * @return
	 */
	Contestation sauvegarderContestation(ContestationSelfcareIn contestationSelfCare);

	/**
	 * modifie une contestation déja présent en base de donnée
	 *
	 * @param contestation
	 * @return
	 */
	Contestation updateContestation(Contestation contestation);
}
