package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;

@Entity
@Table(name = "DOCUMENT_ATTACHEMENT")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class DocumentAttacheEntity extends AbstractEntity<DefaultEntityId> {

	@Column(name = "ID_GDN", length = 36)
	private String idGDN;

	@Column(name = "id_attachment", length = 60)
	private String idAttachment;

	@Column(name = "nom_DOC", length = 200)
	private String nomDocument;

	@Column(name = "format", length = 10)
	private String formatDocument;

	@Column(name = "type_DOC_GDN", length = 15)
	private String typeDocGDN;

	@Column(name = "reference_dossier_smc", length = 50)
	private String referenceDossierSMC;

	@Column(name="IS_RECAP")
	private Boolean recap;

	@Column(name="status_attachment")
	@Enumerated(EnumType.STRING)
	private StatusAttachment statusAttachment;

	@Column
	private LocalDateTime lastDateOfsendToSmc;

	public String getFormatDocument() {
		return formatDocument;
	}

	/**
	 * @return the idAttachment
	 */
	public String getIdAttachment() {
		return idAttachment;
	}

	public String getIdGDN() {
		return idGDN;
	}

	/**
	 * @return the lastDateOfsendToSmc
	 */
	public LocalDateTime getLastDateOfsendToSmc() {
		return lastDateOfsendToSmc;
	}

	public String getNomDocument() {
		return nomDocument;
	}

	/**
	 * @return the recap
	 */
	public Boolean getRecap() {
		return recap;
	}

	public String getReferenceDossierSMC() {
		return referenceDossierSMC;
	}

	/**
	 * @return the statusAttachment
	 */
	public StatusAttachment getStatusAttachment() {
		return statusAttachment;
	}

	public String getTypeDocGDN() {
		return typeDocGDN;
	}



	public void setFormatDocument(String formatDocument) {
		this.formatDocument = formatDocument;
	}

	/**
	 * @param idAttachment the idAttachment to set
	 */
	public void setIdAttachment(String idAttachment) {
		this.idAttachment = idAttachment;
	}

	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}

	/**
	 * @param lastDateOfsendToSmc the lastDateOfsendToSmc to set
	 */
	public void setLastDateOfsendToSmc(LocalDateTime lastDateOfsendToSmc) {
		this.lastDateOfsendToSmc = lastDateOfsendToSmc;
	}

	public void setNomDocument(String nomDocument) {
		this.nomDocument = nomDocument;
	}

	/**
	 * @param recap the recap to set
	 */
	public void setRecap(Boolean recap) {
		this.recap = recap;
	}

	public void setReferenceDossierSMC(String referenceDossierSMC) {
		this.referenceDossierSMC = referenceDossierSMC;
	}

	/**
	 * @param statusAttachment the statusAttachment to set
	 */
	public void setStatusAttachment(StatusAttachment statusAttachment) {
		this.statusAttachment = statusAttachment;
	}

	public void setTypeDocGDN(String typeDocGDN) {
		this.typeDocGDN = typeDocGDN;
	}


}
