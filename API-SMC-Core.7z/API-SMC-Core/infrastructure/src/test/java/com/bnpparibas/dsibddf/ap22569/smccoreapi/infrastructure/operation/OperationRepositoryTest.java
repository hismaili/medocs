/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.operation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationException;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Fail;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;

/**
 * @author c65344
 *
 */
@RunWith(SpringRunner.class)
@EnableJpaRepositories
@DataJpaTest
@SpringBootTest
@ActiveProfiles({"local", "test"})
@Ignore
public class OperationRepositoryTest {



	@Configuration
	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure",
			"com.bnpparibas.dsibddf.ap22569.smctohmp.goal"
	}, lazyInit=true)
	static class TestConfig{

		@Value("${PASSWORD.HMP}")
		private String password;
		@Value("${USERNAME.HMP}")
		private String username;

		@Bean("simpleresttemplate")
		public RestTemplate restTemplate() throws CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, KeyManagementException {
			HttpClientBuilder clientBuilder = HttpClientBuilder.create();

			SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build();
			final SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
			Registry socketFactoryRegistry = RegistryBuilder.create().register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", socketFactory).build(); //$NON-NLS-1$ //$NON-NLS-2$
			PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
			clientBuilder.setConnectionManager(connectionManager).setSSLContext(sslContext).disableCookieManagement();

			HttpClient httpClient = clientBuilder.build();
			HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
			factory.setHttpClient(httpClient);



			final RestTemplate restTemplate = new RestTemplate(factory);
			restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(username, password));
			return restTemplate;
		}

	}
	private final static String IDTELEMATIC = "Id8000900t8Gn";


	private final static String USERID="odmph1852";

	private static final Logger LOG = LoggerFactory.getLogger(OperationRepositoryTest.class);
	private final static String NUMCARTE = "4974018305888915000";


	@Autowired
	private transient OperationRepository repository;

	@Autowired
	private transient OperationJpaRepository jparepository;
	/**
	 * recuperer des opérations 2 fois
	 */
	@Test
	public void getOperationTwice(){
		List<Operation> operations = testGetCardOperations();

		Assertions.assertThat(operations).isNotEmpty();

		operations.forEach(ope -> {

			Assertions.assertThat(ope).isNotNull();
			Assertions.assertThat(ope.getCodeOperation()).isNotNull();
			Assertions.assertThat(ope.getNomCommercant()).isNotEmpty();
			Assertions.assertThat(ope.getCodeOperation()).isNotEmpty();
			Assertions.assertThat(ope.getLibelleOperation()).isNotEmpty();
			Assertions.assertThat(ope.getSigneOperation()).isNotNull();
			Assertions.assertThat(ope.getDateOperation()).isNotNull();
			Assertions.assertThat(ope.getDateVente()).isNotNull();
			Assertions.assertThat(ope.getTypeOperation()).isNotNull();
			Assertions.assertThat(ope.getMontantOperation()).isNotNull();


		});
		operations = testGetCardOperations();

		Assertions.assertThat(operations).isNotEmpty();

		operations.forEach(ope -> {

			Assertions.assertThat(ope).isNotNull();
			Assertions.assertThat(ope.getCodeOperation()).isNotNull();
			Assertions.assertThat(ope.getNomCommercant()).isNotEmpty();
			Assertions.assertThat(ope.getCodeOperation()).isNotEmpty();
			Assertions.assertThat(ope.getLibelleOperation()).isNotEmpty();
			Assertions.assertThat(ope.getSigneOperation()).isNotNull();
			Assertions.assertThat(ope.getDateOperation()).isNotNull();
			Assertions.assertThat(ope.getDateVente()).isNotNull();
			Assertions.assertThat(ope.getTypeOperation()).isNotNull();
			Assertions.assertThat(ope.getMontantOperation()).isNotNull();


		});

	}

	/**
	 */

	private List<Operation> testGetCardOperations() {
		List<Operation> cardOperations = null;
		try {

			cardOperations = repository.getCardOperations(NUMCARTE, IDTELEMATIC,USERID);

			cardOperations.forEach(ope -> {
				Assertions.assertThat(ope).isNotNull();
				Assertions.assertThat(ope.getCodeOperation()).isNotNull();
				//Assertions.assertThat(ope.getNomCommercant()).isNotEmpty();
				Assertions.assertThat(ope.getCodeOperation()).isNotEmpty();
				//Assertions.assertThat(ope.getLibelleOperation()).isNotEmpty();
				//Assertions.assertThat(ope.getSigneOperation()).isNotNull();
				//Assertions.assertThat(ope.getDateOperation()).isNotNull();
				//Assertions.assertThat(ope.getDateVente()).isNotNull();
				//Assertions.assertThat(ope.getTypeOperation()).isNotNull();
				Assertions.assertThat(ope.getMontantOperation()).isNotNull();
			});


		} catch (OperationException e) {
			LOG.error(e.getMessage(),e);
			Fail.fail(e.getMessage(),e);
		}

		return cardOperations;
	}
	@Test
	public void workFlowOperationTmp() {
		List<Operation> operations = testGetCardOperations();

		operations.forEach(op -> {
			try {
				Operation operation = repository.getOperationByCodeOpe(op.getCodeOperation(),IDTELEMATIC,USERID);

				Assertions.assertThat(operation).isNotNull();
				Assertions.assertThat(operation.getCodeOperation()).isNotNull();
			} catch (OperationException e) {
				LOG.error(e.getMessage(),e);
				Fail.fail(e.getMessage(),e);
			}

		});

		repository.deleteOperationsTmp(IDTELEMATIC,USERID);

		List<OperationTmpEntity> operationTmps = jparepository.findByIdTelematicAndUserIdAndNumCarte(IDTELEMATIC, USERID, NUMCARTE);

		Assertions.assertThat(operationTmps).isEmpty();

		repository.deleteOperationsTmp(IDTELEMATIC,USERID);

	}
}



