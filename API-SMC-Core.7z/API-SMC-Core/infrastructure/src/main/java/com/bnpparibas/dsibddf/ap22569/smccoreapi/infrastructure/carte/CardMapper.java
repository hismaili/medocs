package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.AnonymizedCard;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;

public class CardMapper {

	public static AnonymizedCardEntity mapAnonymizedCard2Entity(AnonymizedCard anonymizedCard) {

		AnonymizedCardEntity anonymizedCardEntity = new AnonymizedCardEntity();
		anonymizedCardEntity.setCardId(anonymizedCard.getCardId());
		anonymizedCardEntity.setMaskedPan(anonymizedCard.getMaskedPan());
		CartePorteur carte = anonymizedCard.getCarte();
		anonymizedCardEntity.setPan(carte.getNumCarteInput());
		anonymizedCardEntity.setNumCompte(carte.getNumCompte());
		anonymizedCardEntity.setStatutCarte(carte.getStatutCarteInput());
		anonymizedCardEntity.setTypeProduit(carte.getTypeProduit());
		anonymizedCardEntity.setIkpi(carte.getIkpi());
		anonymizedCardEntity.setDateFinValidite(carte.getDateFinValiditeInput());
		anonymizedCardEntity.setDateOpposition(carte.getDatOppositionInput());
		anonymizedCardEntity.setDateCloture(carte.getDateColture());
		anonymizedCardEntity.setCodeMotifOpposition(carte.getCodeMotifOpposition());
		anonymizedCardEntity.setLibelleMotifOpposition(carte.getLibelleMotifOpposition());
		return anonymizedCardEntity;
	}

	public static AnonymizedCard mapAnonymizedCardEntity2AnonymizedCard(AnonymizedCardEntity anonymizedCardEntity) {
		AnonymizedCard anonymizedCard = new AnonymizedCard();
		anonymizedCard.setCardId(anonymizedCardEntity.getCardId());
		anonymizedCard.setMaskedPan(anonymizedCardEntity.getMaskedPan());
		CartePorteur carte = new CartePorteur();
		carte.setNumCarteInput(anonymizedCardEntity.getPan());
		carte.setNumCompte(anonymizedCardEntity.getNumCompte());
		carte.setStatutCarteInput(anonymizedCardEntity.getStatutCarte());
		carte.setTypeProduit(anonymizedCardEntity.getTypeProduit());
		carte.setIkpi(anonymizedCardEntity.getIkpi());
		carte.setDateFinValiditeInput(anonymizedCardEntity.getDateFinValidite());
		carte.setDatOppositionInput(anonymizedCardEntity.getDateOpposition());
		carte.setDateColture(anonymizedCardEntity.getDateCloture());
		carte.setCodeMotifOpposition(anonymizedCardEntity.getCodeMotifOpposition());
		carte.setLibelleMotifOpposition(anonymizedCardEntity.getLibelleMotifOpposition());
		anonymizedCard.setCarte(carte);
		return anonymizedCard;
	}
}
