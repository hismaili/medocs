/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation;

import java.math.BigDecimal;

/**
 * @author c65344
 *
 */
public class OperationTop {
	private String codeOperation;

	private String numDossier;

	private String numclient;


	private String numCarte;
	private String  dateContestation;

	private String  dateCreation;

	private String idQualifDossier;

	private String idNatureDossier;

	private String dossierSansAnalyseAuto;

	private BigDecimal montantOperation;

	private BigDecimal montantFrais;

	private String  codeDevise;

	private String libelleDevise;

	private String idReseau;

	private String natureOperation;

	private String typeOperation;

	private String dateDeVente;

	/**
	 * @return the codeDevise
	 */
	public String getCodeDevise() {
		return codeDevise;
	}

	/**
	 * @return the codeOperation
	 */
	public String getCodeOperation() {
		return codeOperation;
	}

	/**
	 * @return the dateContestation
	 */
	public String getDateContestation() {
		return dateContestation;
	}

	/**
	 * @return the dateCreation
	 */
	public String getDateCreation() {
		return dateCreation;
	}

	/**
	 * @return the dateDeVente
	 */
	public String getDateDeVente() {
		return dateDeVente;
	}

	/**
	 * @return the dossierSansAnalyseAuto
	 */
	public String getDossierSansAnalyseAuto() {
		return dossierSansAnalyseAuto;
	}

	/**
	 * @return the idNatureDossier
	 */
	public String getIdNatureDossier() {
		return idNatureDossier;
	}

	/**
	 * @return the idQualifDossier
	 */
	public String getIdQualifDossier() {
		return idQualifDossier;
	}

	/**
	 * @return the idReseau
	 */
	public String getIdReseau() {
		return idReseau;
	}

	/**
	 * @return the libelleDevise
	 */
	public String getLibelleDevise() {
		return libelleDevise;
	}

	/**
	 * @return the montantFrais
	 */
	public BigDecimal getMontantFrais() {
		return montantFrais;
	}

	/**
	 * @return the montantOperation
	 */
	public BigDecimal getMontantOperation() {
		return montantOperation;
	}

	/**
	 * @return the natureOperation
	 */
	public String getNatureOperation() {
		return natureOperation;
	}

	/**
	 * @return the numCarte
	 */
	public String getNumCarte() {
		return numCarte;
	}

	/**
	 * @return the numclient
	 */
	public String getNumclient() {
		return numclient;
	}

	/**
	 * @return the numDossier
	 */
	public String getNumDossier() {
		return numDossier;
	}

	/**
	 * @return the typeOperation
	 */
	public String getTypeOperation() {
		return typeOperation;
	}

	/**
	 * @param codeDevise the codeDevise to set
	 */
	public void setCodeDevise(String codeDevise) {
		this.codeDevise = codeDevise;
	}

	/**
	 * @param codeOperation the codeOperation to set
	 */
	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}

	/**
	 * @param dateContestation the dateContestation to set
	 */
	public void setDateContestation(String dateContestation) {
		this.dateContestation = dateContestation;
	}

	/**
	 * @param dateCreation the dateCreation to set
	 */
	public void setDateCreation(String dateCreation) {
		this.dateCreation = dateCreation;
	}

	/**
	 * @param dateDeVente the dateDeVente to set
	 */
	public void setDateDeVente(String dateDeVente) {
		this.dateDeVente = dateDeVente;
	}

	/**
	 * @param dossierSansAnalyseAuto the dossierSansAnalyseAuto to set
	 */
	public void setDossierSansAnalyseAuto(String dossierSansAnalyseAuto) {
		this.dossierSansAnalyseAuto = dossierSansAnalyseAuto;
	}

	/**
	 * @param idNatureDossier the idNatureDossier to set
	 */
	public void setIdNatureDossier(String idNatureDossier) {
		this.idNatureDossier = idNatureDossier;
	}

	/**
	 * @param idQualifDossier the idQualifDossier to set
	 */
	public void setIdQualifDossier(String idQualifDossier) {
		this.idQualifDossier = idQualifDossier;
	}

	/**
	 * @param idReseau the idReseau to set
	 */
	public void setIdReseau(String idReseau) {
		this.idReseau = idReseau;
	}

	/**
	 * @param libelleDevise the libelleDevise to set
	 */
	public void setLibelleDevise(String libelleDevise) {
		this.libelleDevise = libelleDevise;
	}

	/**
	 * @param montantFrais the montantFrais to set
	 */
	public void setMontantFrais(BigDecimal montantFrais) {
		this.montantFrais = montantFrais;
	}
	/**
	 * @param montantOperation the montantOperation to set
	 */
	public void setMontantOperation(BigDecimal montantOperation) {
		this.montantOperation = montantOperation;
	}
	/**
	 * @param natureOperation the natureOperation to set
	 */
	public void setNatureOperation(String natureOperation) {
		this.natureOperation = natureOperation;
	}
	/**
	 * @param numCarte the numCarte to set
	 */
	public void setNumCarte(String numCarte) {
		this.numCarte = numCarte;
	}

	/**
	 * @param numclient the numclient to set
	 */
	public void setNumclient(String numclient) {
		this.numclient = numclient;
	}
	/**
	 * @param numDossier the numDossier to set
	 */
	public void setNumDossier(String numDossier) {
		this.numDossier = numDossier;
	}

	/**
	 * @param typeOperation the typeOperation to set
	 */
	public void setTypeOperation(String typeOperation) {
		this.typeOperation = typeOperation;
	}

}
