package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;

import java.util.List;

/**
 * AttachmentInputData
 */
public class AttachmentDataInput   {

	private String fileIdSMC;


	private List<DocumentInput> documents;

	/**
	 * @return the documents
	 */
	public List<DocumentInput> getDocuments() {
		return documents;
	}

	/**
	 * @return the fileIdSMC
	 */
	public String getFileIdSMC() {
		return fileIdSMC;
	}

	/**
	 * @param documents the documents to set
	 */
	public void setDocuments(List<DocumentInput> documents) {
		this.documents = documents;
	}

	/**
	 * @param fileIdSMC the fileIdSMC to set
	 */
	public void setFileIdSMC(String fileIdSMC) {
		this.fileIdSMC = fileIdSMC;
	}

}

