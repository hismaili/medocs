package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.CardDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CardServicesManagementImpl implements ICardServicesManagement {

	@Autowired(required=false)
	private transient ICardService cardService;

	@Override
	public CardDTO getCardInfosWithMask(String cardId) throws CardException {
		final AnonymizedCard cardByCardId = this.cardService.getCardByCardId(cardId);
		CardDTO card = null;
		if(cardByCardId !=null){
			card= new CardDTO();
			final CartePorteur carte = cardByCardId.getCarte();
			card.setCancellationReason(carte.getCodeMotifOpposition());
			card.setCardCancellationDate(carte.getDatOppositionInput());
			card.setCardExpirationDate(carte.getDateFinValiditeInput());
			card.setCardHolderName(carte.getNomPorteur());
			card.setCardProductType(carte.getTypeProduit());
			card.setCardState(carte.getStatutCarteInput());
			card.setPan(carte.getNumCarteInput());
			card.setMaskedPan(cardByCardId.getMaskedPan());
		}

		return card;
	}

	@Override
	public List<AnonymizedCard> getCartesPorteur(List<String> ribs) throws CardException {
		return this.cardService.getCartesAnonymiseesPourCompte(ribs);
	}

	@Override
	public List<CartePorteur> getCartesPorteur(String iKpi) throws CardException {

		return cardService.getCartesPorteur(iKpi);
	}

	@Override
	public InfoCarte getInfoCarte(String pan) throws CardException {

		return cardService.getInfoCard(pan);
	}

}
