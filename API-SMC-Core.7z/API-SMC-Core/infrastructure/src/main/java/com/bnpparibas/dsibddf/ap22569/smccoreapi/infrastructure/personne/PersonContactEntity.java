/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.personne;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractEntity;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.DefaultEntityId;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "PERSON_CONTACT")
@GenericGenerator(name="SHORT_UUID_GENERATOR", strategy = "com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.EntityIdGenerator")
public class PersonContactEntity extends AbstractEntity<DefaultEntityId> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(length = 40)
	private String telematicId;

	@Column(length = 50)
	private String userId;
	@Column(length = 50)
	private String mailId;
	@Column(length = 50)
	private String phoneNumberId;
	@Column(length = 10)
	private String countryCode;
	@Column(length = 10)
	private String regionCode;

	@Column(length = 20)
	private String phoneNumber;
	@Column(length = 100)
	private String mailUserName;

	@Column(length = 100)
	private String mailDomain;
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @return the mailDomain
	 */
	public String getMailDomain() {
		return mailDomain;
	}

	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}
	/**
	 * @return the mailUserName
	 */
	public String getMailUserName() {
		return mailUserName;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @return the phoneNumberId
	 */
	public String getPhoneNumberId() {
		return phoneNumberId;
	}
	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	/**
	 * @return the telematicId
	 */
	public String getTelematicId() {
		return telematicId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @param mailDomain the mailDomain to set
	 */
	public void setMailDomain(String mailDomain) {
		this.mailDomain = mailDomain;
	}
	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	/**
	 * @param mailUserName the mailUserName to set
	 */
	public void setMailUserName(String mailUserName) {
		this.mailUserName = mailUserName;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @param phoneNumberId the phoneNumberId to set
	 */
	public void setPhoneNumberId(String phoneNumberId) {
		this.phoneNumberId = phoneNumberId;
	}
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	/**
	 * @param telematicId the telematicId to set
	 */
	public void setTelematicId(String telematicId) {
		this.telematicId = telematicId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}



}
