package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.Objects;

/**
 * CardVO
 */
public class CardVO   {
	@JsonProperty("cardId")
	private String cardId;

	@JsonProperty("cardExpirationDate")
	private LocalDate cardExpirationDate;

	@JsonProperty("cardCancellationDate")
	private LocalDate cardCancellationDate;

	@JsonProperty("cardState")
	private String cardState;

	@JsonProperty("maskedPan")
	private String maskedPan;

	@JsonProperty("cancellationReason")
	private String cancellationReason;

	@JsonProperty("cardProductType")
	private String cardProductType;

	@JsonProperty("cardHolderName")
	private String cardHolderName;
	/**
	 *
	 * @param cancellationReason
	 * @return
	 */
	public CardVO cancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
		return this;
	}
	/**
	 *
	 * @param cardCancellationDate
	 * @return
	 */
	public CardVO cardCancellationDate(LocalDate cardCancellationDate) {
		this.cardCancellationDate = cardCancellationDate;
		return this;
	}
	/**
	 *
	 * @param cardExpirationDate
	 * @return
	 */
	public CardVO cardExpirationDate(LocalDate cardExpirationDate) {
		this.cardExpirationDate = cardExpirationDate;
		return this;
	}
	/**
	 *
	 * @param cardHolderName
	 * @return
	 */
	public CardVO cardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
		return this;
	}
	/**
	 *
	 * @param cardId
	 * @return
	 */
	public CardVO cardId(String cardId) {
		this.cardId = cardId;
		return this;
	}
	/**
	 *
	 * @param cardProductType
	 * @return
	 */
	public CardVO cardProductType(String cardProductType) {
		this.cardProductType = cardProductType;
		return this;
	}
	/**
	 *
	 * @param cardState
	 * @return
	 */
	public CardVO cardState(String cardState) {
		this.cardState = cardState;
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CardVO cardVO = (CardVO) o;
		return Objects.equals(this.cardId, cardVO.cardId) &&
				Objects.equals(this.cardExpirationDate, cardVO.cardExpirationDate) &&
				Objects.equals(this.cardCancellationDate, cardVO.cardCancellationDate) &&
				Objects.equals(this.cardState, cardVO.cardState) &&
				Objects.equals(this.maskedPan, cardVO.maskedPan) &&
				Objects.equals(this.cancellationReason, cardVO.cancellationReason) &&
				Objects.equals(this.cardProductType, cardVO.cardProductType) &&
				Objects.equals(this.cardHolderName, cardVO.cardHolderName);
	}

	/**
	 * Motif d opposition vol, perte, fraude,….
	 *
	 * @return cancellationReason
	 **/
	@ApiModelProperty(value = "Motif d opposition vol, perte, fraude,….")
	public String getCancellationReason() {
		return cancellationReason;
	}

	/**
	 * date d oppposition au format aaaa-mm-jj
	 *
	 * @return cardCancellationDate
	 **/
	@ApiModelProperty(value = "date d oppposition au format aaaa-mm-jj")
	@Valid
	public LocalDate getCardCancellationDate() {
		return cardCancellationDate;
	}

	/**
	 * date fin de validité de la carte au format aaaa-mm-jj
	 *
	 * @return cardExpirationDate
	 **/
	@ApiModelProperty(value = "date fin de validité de la carte au format aaaa-mm-jj")

	@Valid

	public LocalDate getCardExpirationDate() {
		return cardExpirationDate;
	}

	/**
	 * Estampage de la carte
	 *
	 * @return cardHolderName
	 **/
	@ApiModelProperty(value = "Estampage de la carte")
	public String getCardHolderName() {
		return cardHolderName;
	}

	/**
	 * Get cardId
	 *
	 * @return cardId
	 **/
	@ApiModelProperty(value = "")
	public String getCardId() {
		return cardId;
	}

	/**
	 * Type de produit Visa premier, bleue, infinite,…
	 *
	 * @return cardProductType
	 **/
	@ApiModelProperty(value = "Type de produit Visa premier, bleue, infinite,…")


	public String getCardProductType() {
		return cardProductType;
	}

	/**
	 * Etat de la carte  Active, Clôturée, Opposée, Echue …
	 *
	 * @return cardState
	 **/
	@ApiModelProperty(value = "Etat de la carte  Active, Clôturée, Opposée, Echue …")


	public String getCardState() {
		return cardState;
	}

	/**
	 * numéro de carte masqué
	 *
	 * @return maskedPan
	 **/
	@ApiModelProperty(value = "numéro de carte masqué")


	public String getMaskedPan() {
		return maskedPan;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cardId, cardExpirationDate, cardCancellationDate, cardState, maskedPan, cancellationReason, cardProductType, cardHolderName);
	}
	/**
	 *
	 * @param maskedPan
	 * @return
	 */
	public CardVO maskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
		return this;
	}
	/**
	 *
	 * @param cancellationReason
	 */
	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}
	/**
	 *
	 * @param cardCancellationDate
	 */
	public void setCardCancellationDate(LocalDate cardCancellationDate) {
		this.cardCancellationDate = cardCancellationDate;
	}
	/**
	 *
	 * @param cardExpirationDate
	 */
	public void setCardExpirationDate(LocalDate cardExpirationDate) {
		this.cardExpirationDate = cardExpirationDate;
	}
	/**
	 *
	 * @param cardHolderName
	 */
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	/**
	 *
	 * @param cardId
	 */
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	/**
	 *
	 * @param cardProductType
	 */
	public void setCardProductType(String cardProductType) {
		this.cardProductType = cardProductType;
	}

	/**
	 *
	 * @param cardState
	 */
	public void setCardState(String cardState) {
		this.cardState = cardState;
	}
	/**
	 *
	 * @param maskedPan
	 */
	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class CardVO {\n");

		sb.append("    cardId: ").append(toIndentedString(cardId)).append("\n");
		sb.append("    cardExpirationDate: ").append(toIndentedString(cardExpirationDate)).append("\n");
		sb.append("    cardCancellationDate: ").append(toIndentedString(cardCancellationDate)).append("\n");
		sb.append("    cardState: ").append(toIndentedString(cardState)).append("\n");
		sb.append("    maskedPan: ").append(toIndentedString(maskedPan)).append("\n");
		sb.append("    cancellationReason: ").append(toIndentedString(cancellationReason)).append("\n");
		sb.append("    cardProductType: ").append(toIndentedString(cardProductType)).append("\n");
		sb.append("    cardHolderName: ").append(toIndentedString(cardHolderName)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}

