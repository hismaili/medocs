/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;

import java.util.List;


/**
 * @author c65344
 *
 */
public class ErrorOutput {

	private String label;
	private List<ErrorOut> errors;
	/**
	 * @return the errors
	 */
	public List<ErrorOut> getErrors() {
		return errors;
	}
	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<ErrorOut> errors) {
		this.errors = errors;
	}
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}



}
