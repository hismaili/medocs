package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.FormatErrorException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.SmcTechnicalException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import com.bnpparibas.dsibddf.ap22569.smctoeditique.model.structure.request.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author c65344
 *
 */
@Component
public class EditionMapper {

	@Autowired
	private transient ConfigInfrastructure conf;

	/**
	 * Converti RequestEditiqueInput en RequestEditique du service editique
	 *
	 * @param requestEditiqueInput
	 * @return RequestEditique
	 * @throws SmcTechnicalException
	 * @throws MandatoryException
	 * @throws FormatErrorException
	 */
	public RequestEditique map(RequestEditiqueInput request){
		RequestEditique reponse = null;

		SNEMAQUETTERequest snemaquette = new SNEMAQUETTERequest();
		SNEDESTRequest snedest = new SNEDESTRequest();
		BPFNERequest bpfne= new BPFNERequest();
		SNEEMETRequest sneemet= new SNEEMETRequest();
		SNEATTRRequest sneattr= new SNEATTRRequest();
		SNETECHRequest snetech= new SNETECHRequest();
		SNEDATARequest snedata=new SNEDATARequest();
		String reseau = null;


		if(request !=null){

			if(request.getDestinataire() !=null){
				snedest.setCtcvlte(request.getDestinataire().getCivilite());
				bpfne.setLvalcpstnadrp1(request.getDestinataire().getAdresse1());
				bpfne.setLvalcpstnadrp2(request.getDestinataire().getAdresse2());
				bpfne.setLvalcpstnadrp3(request.getDestinataire().getAdresse3());
				bpfne.setLvalcpstnadrp6(request.getDestinataire().getAdresse6());
			}

			Emeteur emeteur = request.getEmeteur();
			if(emeteur !=null){

				if(emeteur.isHelloBank()){
					reseau = conf.getBd();
					sneemet.setLvalcpstnadrp1(conf.getHelloBanque());
				}else{
					reseau =conf.getBddf();
					sneemet.setLvalcpstnadrp1(conf.getBnpParisBas());
				}

				if(emeteur.isMonaco()){
					sneemet.setLvalcpstnadrp2(conf.getAdresseMonaco2());
					sneemet.setLvalcpstnadrp3(conf.getAdresseMonaco3());
					sneemet.setLvalcpstnadrp5(conf.getAdresseMonaco5());
				}else{
					String adresse = emeteur.getAdresse();

					List<String> adresses =	Arrays.asList(adresse.split("\\,")); //$NON-NLS-1$

					int size =  adresses.size()-1;

					if(size >= 0){
						sneemet.setLvalcpstnadrp5(adresses.get(size));

						if((size-1) >=0){
							sneemet.setLvalcpstnadrp4(adresses.get(size-1));

							if((size-2) >=0){
								sneemet.setLvalcpstnadrp3(adresses.get(size-2));

								if((size-3) >=0){
									sneemet.setLvalcpstnadrp2(adresses.get(size-3));

								}

							}
						}
					}
				}

				sneemet.setIuoagce(emeteur.getCodeUoAgence());
				sneemet.setIuosucc(emeteur.getCodeUoSur());
				sneemet.setLadrtlmtqtel(emeteur.getTelephone());
			}
			/**
			 * remplissage de sneattr a partir de la conf
			 */
			sneattr.setCtype(conf.getCtype());
			sneattr.setLformat(conf.getLformat());
			sneattr.setClanguekpi(conf.getClanguekpi());
			sneattr.setSepialg(conf.getSepialg());
			sneattr.setSepiaml(conf.getSepiaml());
			sneattr.setDreftrait(request.getDateTraitement());

			/**
			 * snetech
			 * remplissage de la valeur typi a partir de la conf
			 */
			snetech.setTypi(conf.getTypi());



			BeanUtils.copyProperties(request, snedata);

			snedata.setNombreOperations(String.valueOf(request.getNombreOperations()));
			snedata.setDelaisReponse(String.valueOf(request.getDelaisReponse()));
			snedata.setTotalOperations(String.valueOf(request.getTotalOperations()));

			List<String> listPs = request.getPs();

			if(!CollectionUtils.isEmpty(listPs)){
				snedata.setTabPs(
						listPs.stream().map(ps -> {
							return new LigPsRequest(ps);
						}).collect(Collectors.toList()));
			}


			List<String> comments = request.getCommentaires();

			if(!CollectionUtils.isEmpty(comments)){
				snedata.setTabCommentaires(
						comments.stream().map(comment -> {
							return new LigCommentairesRequest(comment);
						}).collect(Collectors.toList()));
			}


			List<Paragraphe> paragraphes = request.getParagraphes();
			List<HeadRequest> headers = new ArrayList<HeadRequest>();

			if(!CollectionUtils.isEmpty(paragraphes)){

				paragraphes.stream().forEachOrdered(paragraphe ->{
					List<Phrase> phrases = paragraphe.getPhrase();

					if(!CollectionUtils.isEmpty(phrases)){
						phrases.stream().filter(phrase -> !StringUtils.isEmpty(phrase.getTextePhrase())).forEachOrdered(phrase -> {
							headers.add(new HeadRequest(phrase.getTextePhrase()));
						});
					}


				});

				snedata.setTabHeader(headers);
			}

			List<Operation> opeartions = request.getOperations();

			if(!CollectionUtils.isEmpty(opeartions)){
				snedata.setTabContest(
						opeartions.stream().map(operation -> {
							LigContestRequest contest = new LigContestRequest();
							BeanUtils.copyProperties(operation, contest);
							return contest;
						}).collect(Collectors.toList()));
			}

			Map<String,String> sneMaquettes = request.getSneMaquette();

			if(!CollectionUtils.isEmpty(sneMaquettes)){
				snemaquette.setRef(sneMaquettes.entrySet().stream().map(mp -> {
					return new REFRequest(mp.getKey(),mp.getValue());
				}).collect(Collectors.toList()));
			}

			List<String> descriptifFaits = request.getDescriptifFaits();
			if(!CollectionUtils.isEmpty(descriptifFaits)){
				snedata.setDescriptifs(descriptifFaits
						.stream()
						.map(descriptif -> new DescriptifFaitsRequest(descriptif))
						.collect(Collectors.toList()));
			}



			List<String> fichierJoints = request.getFichierJoints();
			if(!CollectionUtils.isEmpty(fichierJoints)){
				snedata.setFichiersJoin(
						fichierJoints
						.stream()
						.map(fichier -> new FichierJointRequest(fichier))
						.collect(Collectors.toList()));
			}

			List<OperationSelfCare1> operationSelfCare1 = request.getOperationSelfCare1();

			if(!CollectionUtils.isEmpty(operationSelfCare1)){
				snedata.setTabContestSelfcare1(
						operationSelfCare1
						.stream()
						.filter(opeSelf1 -> opeSelf1 !=null)
						.map(opeSelf1 -> {

							LigContest1Request ligContest1 = new LigContest1Request();

							BeanUtils.copyProperties(opeSelf1, ligContest1);

							return ligContest1;
						})
						.collect(Collectors.toList()));
			}

			List<OperationSelfCare2> operationSelfCare2 = request
					.getOperationSelfCare2();

			if (!CollectionUtils.isEmpty(operationSelfCare2)) {
				snedata.setTabContestSelfcare2(operationSelfCare2
						.stream()
						.filter(opeSelf2 -> opeSelf2 != null)
						.map(opeSelf2 -> {

							LigContest2Request ligContest2 = new LigContest2Request();

							BeanUtils.copyProperties(opeSelf2, ligContest2);

							return ligContest2;
						}).collect(Collectors.toList()));
			}

			reponse = new RequestEditique(conf.getIdoc(), snedest, bpfne, sneemet, sneattr, snetech, snemaquette, snedata,

					reseau,
					request.getCanal(),
					conf.getEnvironnement(),
					conf.getType(),
					conf.getFormatSortie(),
					conf.getApplication(),
					conf.getTransaction(),
					conf.getDescription(),
					conf.getTraceXml(),
					conf.getTraceLog(),
					conf.getPriorite());

			reponse.setSnemaquette(snemaquette);
		}

		return  reponse;
	}

}
