package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

public class CustomerContactInfos {

    private String telematicId;

    private String mailId;

    private String phoneNumberId;

    private String maskedMail;

    private String maskedPhoneNumber;

    public String getTelematicId() {
        return telematicId;
    }

    public void setTelematicId(String telematicId) {
        this.telematicId = telematicId;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public String getPhoneNumberId() {
        return phoneNumberId;
    }

    public void setPhoneNumberId(String phoneNumberId) {
        this.phoneNumberId = phoneNumberId;
    }

    public String getMaskedMail() {
        return maskedMail;
    }

    public void setMaskedMail(String maskedMail) {
        this.maskedMail = maskedMail;
    }

    public String getMaskedPhoneNumber() {
        return maskedPhoneNumber;
    }

    public void setMaskedPhoneNumber(String maskedPhoneNumber) {
        this.maskedPhoneNumber = maskedPhoneNumber;
    }
}
