package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import brave.Tracer;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.archivage.IArchivageManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.compte.AccountDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation.IOperationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.operation.OperationDTO;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.ArchivingException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.DocInput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage.DocOutput;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardExistException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.DonneIncorectException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.MandatoryException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.Operation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.OperationSign;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.operation.TypeOperation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.Document;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request.Objectsmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.*;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.OperationVO.OperationSignEnum;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.OperationVO.OperationType;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@Validated
@RequestMapping("/v1")
@Api(tags = { "Gestion des contestations monétiques" }, produces = "application/json")
//TODO déclarer tous les paramètres comme String et faire les validations de formats nécesaires
public class ContestationController implements DisputesApi {

	private static final String BROUILLON = "SC001";
	private static final String CREER = "SC002";
	private static final Logger LOG = LoggerFactory
			.getLogger(ContestationController.class);
	private static final String ERROR = "ERROR INTERNE DU SERVER";
	private static final String NULLVALUE = null;
	@Autowired
	private transient ConfigExposition conf;
	// @Autowired
	private final transient IContestationManagement contestationManagement;

	@Autowired
	private transient BuilderResponseSmc builderResponse;

	@Autowired
	private transient ControlBuilder control;

	@Autowired
	private transient Tracer tracer;

	@Autowired
	@Qualifier("i18nMessages")
	private transient MessageSource messageSource;

	@Autowired
	private transient IOperationManagement operationManagement;
	@Autowired
	private transient IArchivageManagement archivageManagement;

	public ContestationController(IContestationManagement contestationManagement) {
		this.contestationManagement = contestationManagement;
	}

	@RequestMapping(value = "/disputes/cards", produces = { "application/json" }, method = RequestMethod.GET)
	@Override
	public ResponseEntity accountsAttachedCards(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel,
			@RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
			@RequestParam(value = "limit", required = false, defaultValue = "10") Integer limit) {

		List<String> mandatoryFieldsError = new ArrayList<>();
		if (StringUtils.isEmpty(telematicId)) {
			mandatoryFieldsError.add("telematicId");
		}
		if (StringUtils.isEmpty(userId)) {
			mandatoryFieldsError.add("userId");
		}

		if (!CollectionUtils.isEmpty(mandatoryFieldsError)) {
			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données obligatoires non renseignées",
					mandatoryFieldsError);
			return ResponseEntity.badRequest().body(error);
		}

		try {
			List<AccountWithCardsDTO> accountsWithCards = this.contestationManagement
					.getUserAccountsAndCard(telematicId,userId);
			if (CollectionUtils.isEmpty(accountsWithCards)) {
				LOG.error("No account found for user : " + telematicId);
				final SmcApiError t = new SmcApiError("ERR.CMC.FUNC.703",
						"Aucun compte trouvé pour le client",
						Arrays.asList(telematicId));
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(t);
			} else {
				// Map AccountWithCardsDTO 2 AccountWithCards
				if (offset == null) {
					offset = 0;
				}
				if (limit == null) {
					limit = offset + 10;
				}

				if (accountsWithCards.size() < limit) {
					limit = accountsWithCards.size();
				}
				accountsWithCards = accountsWithCards.stream().sorted()
						.collect(Collectors.toList());
				List<AccountWithCards> accountsWithCardsVO = accountsWithCards
						.subList(offset, limit).stream().filter(ac -> !CollectionUtils.isEmpty(ac.getCards())).map(ac -> {
							AccountWithCards acVO = new AccountWithCards();
							AccountVO account = new AccountVO();
							final AccountDTO accountDTO = ac.getAccount();
							BeanUtils.copyProperties(accountDTO, account);
							acVO.setAccount(account);

							List<CardVO> cardsVO = null;
							List<CardDTO> cardsDTO = ac.getCards();
							if (!CollectionUtils.isEmpty(cardsDTO)) {
								cardsVO = cardsDTO.stream().map(crd -> {
									CardVO cardVO = new CardVO();
									BeanUtils.copyProperties(crd, cardVO);
									return cardVO;
								}).collect(Collectors.toList());
							}
							acVO.setCards(cardsVO);
							return acVO;
						}).collect(Collectors.toList());

				if(CollectionUtils.isEmpty(accountsWithCardsVO)){
					LOG.error("No account with card found for user : " + telematicId);
					final SmcApiError t = new SmcApiError("ERR.CMC.FUNC.703",
							"Aucun compte trouvé possédant des cartes pour le client",
							Arrays.asList(telematicId));
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body(t);
				}

				return ResponseEntity.ok(accountsWithCardsVO);
			}
		} catch (ContestationException | ContestationValidationException e) {
			LOG.error(e.getMessage(), e);
			// TODO split error codes by original system
			SmcApiError error = new SmcApiError("ERR.CMC.TECH.9xx",
					"Erreur Interne", Arrays.asList(e.getMessage()));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(error);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			SmcApiError error = new SmcApiError("ERR.CMC.TECH.999",
					"Erreur Interne", Arrays.asList(e.getMessage()));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(error);
		}

	}

	@RequestMapping(value = "/disputes/cards/{cardId}/operations", produces = { "application/json" }, method = RequestMethod.GET)
	@Override
	public ResponseEntity cardOperations(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel,
			@PathVariable(value="cardId", required = false) String cardId,
			@RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
			@RequestParam(value = "limit", required = false, defaultValue = "10") Integer limit) {

		List<String> mandatoryFieldsError = new ArrayList<>();
		if (StringUtils.isEmpty(cardId)) {
			mandatoryFieldsError.add("cardId");
		}

		if (StringUtils.isEmpty(telematicId)) {
			mandatoryFieldsError.add(conf.getTelematicIdAbsent());
		}
		if (StringUtils.isEmpty(userId)) {
			mandatoryFieldsError.add(conf.getUserIdAbsent());
		}

		if (!CollectionUtils.isEmpty(mandatoryFieldsError)) {
			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données obligatoires non renseignées",
					mandatoryFieldsError);
			return ResponseEntity.badRequest().body(error);
		}
		try {
			List<OperationDTO> operations = operationManagement
					.getCardOperations(cardId, telematicId,userId);
			if (CollectionUtils.isEmpty(operations)) {
				LOG.error("No operation found for card : " + cardId);
				final SmcApiError t = new SmcApiError("ERR.CMC.FUNC.703",
						"Aucune opération trouvée pour la carte ",
						Arrays.asList(cardId));
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(t);
			}

			List<OperationVO> operationList = operations.stream().map(op -> {
				OperationVO opVO = new OperationVO();
				opVO.setOperationCode(op.getCodeOperation());
				opVO.setOperationLabel(op.getLibelleOperation());
				opVO.setCurrencyOfOperation(op.getCurrencyOfOperation());
				opVO.setDateOfOperation(op.getDateOperation());
				opVO.setDateOfSale(op.getDateVente());
				opVO.setOperationAmount(op.getMontantOperation());

				opVO.setMerchantName(op.getNomCommercant());
				opVO.setDisputable(op.isDisputable());

				TypeOperation typeOperation = op.getTypeOperation();
				OperationSign signeOperation = op.getSigneOperation();
				if (signeOperation != null) {
					switch (signeOperation) {
					case MOINS:
						opVO.setOperationSign(OperationSignEnum.MOINS);

						break;
					case PLUS:
						opVO.setOperationSign(OperationSignEnum.PLUS);

						break;
					default:
						break;
					}

				}
				if (typeOperation != null) {
					switch (typeOperation) {
					case PAIEMENT:
						opVO.setOperationType(OperationType.PAIEMENT);

						break;
					case RETRAIT:
						opVO.setOperationType(OperationType.RETRAIT);

						break;
					default:
						break;
					}
				}

				return opVO;
			}).collect(Collectors.toList());
			return ResponseEntity.ok(operationList);

		} catch (ContestationException e) {
			LOG.error(e.getMessage(), e);
			SmcApiError error = new SmcApiError("ERR.CMC.TECH.999",
					"Erreur Interne", Arrays.asList(e.getMessage()));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(error);
		} catch (CardExistException e) {
			LOG.error(e.getMessage(), e);
			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données incorrectes", Arrays.asList(e.getMessage()));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(error);
		}
	}

	@Override
	@RequestMapping(value = "/disputes", produces = { "application/json" }, consumes = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity createDispute(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel,
			@RequestBody(required = false) DisputeData disputeData) {

		List<String> errorsDataMandatory = control.checkCreateDispute(
				disputeData, telematicId, userId, channel, applicationCode);

		if (!CollectionUtils.isEmpty(errorsDataMandatory)) {
			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données obligatoires non renseignées",
					errorsDataMandatory);
			return ResponseEntity.badRequest().body(error);
		} else {
			DisputeDataDTO dispute = new DisputeDataDTO();
			BeanUtils.copyProperties(disputeData, dispute);
			dispute.setNotifSMS(disputeData.isNotifSMS());
			dispute.setNotifMail(disputeData.isNotifMail());
			dispute.setNotifPush(disputeData.isNotifPush());
			dispute.setTopMailModified(disputeData.isTopMailModified());
			dispute.setTopPhoneNumberModified(disputeData
					.isTopPhoneNumberModified());
			final List<DisputeDataOperations> operations = disputeData
					.getOperations();
			if (!CollectionUtils.isEmpty(operations)) {
				dispute.setOperations(operations
						.stream()
						.map(op -> {
							DisputeDataOperationDTO opDTO = new DisputeDataOperationDTO();
							BeanUtils.copyProperties(op, opDTO);
							return opDTO;
						}).collect(Collectors.toList()));
			}
			final List<DisputeDataAttachedFiles> attachedFiles = disputeData
					.getAttachedFiles();
			if (!CollectionUtils.isEmpty(attachedFiles)) {
				dispute.setAttachedFiles(attachedFiles
						.stream()
						.map(af -> {
							DisputeDataAttachedFileDTO afDTO = new DisputeDataAttachedFileDTO();
							BeanUtils.copyProperties(af, afDTO);
							return afDTO;
						}).collect(Collectors.toList()));
			}

			dispute.setCustomerIKpi(userId);
			dispute.setTelematicId(telematicId);

			try {
				DisputeSummaryDTO disputeSummary = this.contestationManagement
						.createDispute(dispute);
				DisputeSummary summary = new DisputeSummary();
				BeanUtils.copyProperties(disputeSummary, summary);

				HttpStatus status = null;
				if (!StringUtils.isEmpty(summary.getDisputeFolderReference())) {// Le
					// dossier est créé dans SMC
					status = HttpStatus.CREATED;
				} else {// Le dossier n'a pas pu être créé dans SMC
					status = HttpStatus.ACCEPTED;
				}

				return ResponseEntity.status(status).body(summary);
			} catch (ContestationValidationException e) {
				LOG.error(e.getMessage(), e);
				SmcApiError error = new SmcApiError("", e.getMessage());
				if (!CollectionUtils.isEmpty(e.getErrors())) {
					List<String> details = new ArrayList<>();
					e.getErrors().stream().forEach(err -> {
						LOG.error(err.getLibelle());
						details.add(err.getLibelle());

					});
					error.setDetails(details);
				}
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(error);
			} catch (ContestationException e) {
				LOG.error(e.getMessage(), e);
				SmcApiError error = new SmcApiError("",conf.getErrorGeneriqueInterne());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(error);
			} catch (Exception e) {
				LOG.error(e.getMessage(), e);
				SmcApiError error = new SmcApiError("", e.getMessage());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(error);
			}

		}

	}

	@Override
	@RequestMapping(value = "/disputes/contacts", produces = { "application/json" }, method = RequestMethod.GET)
	public ResponseEntity customerContacts(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel) {

		List<String> mandatoryFieldsError = new ArrayList<>();
		if (StringUtils.isEmpty(telematicId)) {
			mandatoryFieldsError.add("telematicId");
		}
		if (StringUtils.isEmpty(userId)) {
			mandatoryFieldsError.add("userId");
		}

		if (!CollectionUtils.isEmpty(mandatoryFieldsError)) {
			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données obligatoires non renseignées",
					mandatoryFieldsError);
			return ResponseEntity.badRequest().body(error);
		} else {
			try {
				CustomerContactInfos customerContactInfos = this.contestationManagement
						.getCustomerContactInfos(telematicId, userId);
				CustomerContacts customerContacts = new CustomerContacts();
				if (customerContactInfos != null) {
					BeanUtils.copyProperties(customerContactInfos,
							customerContacts);
				} else {
					return ResponseEntity
							.status(HttpStatus.NOT_FOUND)
							.body(new SmcApiError(
									"ERR.CMC.FUNC.703", "Aucun contact utilisateur trouvé pour le client recherché")); //$NON-NLS-1$//$NON-NLS-2$
				}
				return ResponseEntity.ok().body(customerContacts);
			} catch (ContestationException e) {
				LOG.error(e.getMessage(), e);
				// TODO split error codes by original system
				SmcApiError error = new SmcApiError("ERR.CMC.TECH.9xx",
						"Erreur interne", Arrays.asList(e.getMessage()));
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(error);
			} catch (ContestationValidationException e) {
				LOG.error(e.getMessage(), e);
				// TODO split error codes by original system
				SmcApiError error = new SmcApiError("ERR.CMC.TECH.9xx",
						"Erreur interne", Arrays.asList(e.getMessage()));
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(error);
			}

		}
	}

	@Override
	@RequestMapping(value = "disputes/document/{documentId}", produces = { MediaType.APPLICATION_JSON_VALUE }, method = RequestMethod.GET)
	public ResponseEntity getDocument(
			@PathVariable(required = false) String documentId,
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel) {
		List<String> missingDatas = new ArrayList<String>();
		try {

			if (StringUtils.isEmpty(telematicId)) {
				missingDatas.add("telematicId");
			}
			if (StringUtils.isEmpty(userId)) {
				missingDatas.add("userId");
			}

			if (StringUtils.isEmpty(documentId)) {
				missingDatas.add("documentId");
			}


			if (!CollectionUtils.isEmpty(missingDatas)) {
				SmcApiError error = new SmcApiError(
						"ERR.CMC.FUNC.700",
						"Une ou plusieurs données obligatoires non renseignées",
						missingDatas);
				return ResponseEntity.badRequest().body(error);
			} else {
				DocInput docInput = new DocInput(telematicId, documentId,
						conf.getUserTypeSelfCare());

				DocOutput getDocOutput;


				boolean authorized = contestationManagement.isAuthorized(documentId, telematicId);

				if(authorized){
					getDocOutput = archivageManagement.getDoc(docInput);

					return new ResponseEntity<ArchivageResponseGetDoc>(
							new ArchivageResponseGetDoc(new Document(
									getDocOutput.getFileNameOutput(),
									getDocOutput.getArchiveFormatOutput(),
									new Objectsmc(getDocOutput.getCompressOutput(),
											getDocOutput.getEncodingOutput(),
											getDocOutput.getDataOutputOutput()))),
											HttpStatus.OK);
				}else{

					SmcApiError error = new SmcApiError(null,
							"L'utilisateur n'est pas autorisé à recupérer ce document",
							null);
					return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
				}

			}

		} catch (ArchivingException e) {
			/**
			 * Erreur interne du serveur
			 */
			LOG.error(e.getMessage(), e);

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999",
							conf.getErrorGeneriqueInterne(),null));
		} catch (MandatoryException e) {
			/**
			 * Erreur technique
			 */
			LOG.error(e.getMessage(), e);
			return new ResponseEntity(new SmcResponseError(
					Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(),
							conf.getErrorGeneriqueAbsent(), Arrays.asList(e
									.getMessage())))), HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999",
							"Unexpected Technical error", Arrays.asList(e
									.getMessage())));
		}

	}

	private String getMessage(String messageKey) {
		String messageValue = messageSource.getMessage(
				messageKey, null, null);
		if (StringUtils.isEmpty(messageValue)) {
			LOG.error("Texte introuvable : " + messageKey);
			messageValue = "";
		}
		return messageValue;
	}

	private DisputeDetails mapToContestationDetails(Contestation contestation) {
		DisputeDetails disputeDetails = new DisputeDetails();

		disputeDetails.setFactsSummary(contestation.getDescription());
		disputeDetails.setDisputedAmount(contestation.getMontantConteste());
		disputeDetails.setRecognizedAmount(contestation
				.getMontantReconnuPorteur());
		// TODO check not null
		disputeDetails.setReason(messageSource.getMessage(contestation
				.getMotif().getLibelle(), null, null));
		disputeDetails.setDisputeFolderReference(contestation
				.getNumDossierSMC());
		// TODO disputeDetails.setCreationDate(contestation.get);

		if (contestation != null
				&& contestation.getDernierStatutDossier() != null) {

			disputeDetails.setCurrentStatus(contestation
					.getDernierStatutDossier().getLibelleStatut());
		}

		List<DocumentAttache> documentAttaches = contestation
				.getDocumentAttaches();

		if (!CollectionUtils.isEmpty(documentAttaches)) {
			disputeDetails
			.setAttachedDocuments(documentAttaches
					.stream()
					.map(documentAttache -> {
						DisputeDetailsAttachedDocuments attachedDoc = new DisputeDetailsAttachedDocuments();
						attachedDoc.setIdGed(documentAttache.getIdGDN());
						attachedDoc.setFileName(documentAttache
								.getNomDocument());
						attachedDoc.setFormatDoc(documentAttache
								.getFormatDocument());
						attachedDoc.setTypeDoc(documentAttache
								.getTypeDocGDN());

						attachedDoc.setRecap(documentAttache.getRecap());
						return attachedDoc;
					}).collect(Collectors.toList()));
		}
		List<Operation> operations = contestation.getOperations();
		if (!CollectionUtils.isEmpty(operations)) {
			disputeDetails.setAttachedOperations(operations
					.stream()
					.map(operation -> {
						OperationVO operationVo = new OperationVO();
						final TypeOperation typeOperation = operation
								.getTypeOperation();

						if(typeOperation !=null){
							switch (typeOperation) {
							case PAIEMENT:
								operationVo.setOperationType(OperationType.PAIEMENT);

								break;
							case RETRAIT:
								operationVo.setOperationType(OperationType.RETRAIT);

								break;
							default:
								break;
							}
						}


						operationVo.setCurrencyOfOperation(operation
								.getDeviseOperation());
						operationVo.setDateOfOperation(operation
								.getDateOperation());
						operationVo.setDateOfSale(operation.getDateVente());
						operationVo.setMerchantName(operation
								.getNomCommercant());
						operationVo.setOperationAmount(operation
								.getMontantOperation());
						operationVo.setOperationCode(operation
								.getCodeOperation());
						OperationSign signeOperation = operation.getSigneOperation();
						if(signeOperation !=null){
							switch (signeOperation) {
							case MOINS:
								operationVo.setOperationSign(OperationSignEnum.MOINS);

								break;
							case PLUS:
								operationVo.setOperationSign(OperationSignEnum.PLUS);

								break;
							default:
								break;
							}
						}


						operationVo.setRecognizedAmount(operation.getMontantReconnu());
						operationVo.setOperationLabel(operation.getLibelleOperation());
						return operationVo;
					}).collect(Collectors.toList()));
		}
		disputeDetails.setDisputeInternalIdentifier(contestation
				.getIdContestation());

		CartePorteur carte = contestation.getCarte();
		if (carte != null) {
			disputeDetails.setCardCancellationDate(carte
					.getDatOppositionInput());
			disputeDetails.setCardType(carte.getTypeProduit());
			// TODO récupérer les informations du porteur
			// disputeDetails.setCardholderFirstName(carte.get);
			disputeDetails.setMaskedPan(carte.getNumCarteInput());
		}
		disputeDetails.setCreationDate(contestation.getDateDeCreationDossier());
		return disputeDetails;
	}

	@Override
	@RequestMapping(value = "/disputes/reasons", produces = { "application/json;charset=UTF-8" }, method = RequestMethod.GET)
	public ResponseEntity reasons(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel,
			String typeOperation, Boolean cardLost, Integer numberOfOperations) {
		try {
			// Validate inputs
			SmcApiError error = null;
			// validate mandatory fields
			List<String> mandatoryFields = new ArrayList<>();
			if (typeOperation == null) {
				mandatoryFields.add("type operation");
			}
			if (cardLost == null) {
				mandatoryFields.add("Carte perdue/vloée : oui/non");
			}
			if (numberOfOperations == null) {
				mandatoryFields.add("nombre d'opérations sélectionnées");
			}
			if (StringUtils.isEmpty(telematicId)) {
				mandatoryFields.add("telematicId");
			}
			if (StringUtils.isEmpty(userId)) {
				mandatoryFields.add("userId");
			}

			if (!CollectionUtils.isEmpty(mandatoryFields)) {
				error = new SmcApiError("ERR.CMC.FUNC.700",
						"Données obligatoires manquantes", mandatoryFields);
				return ResponseEntity.badRequest().body(error);

			}
			// validate fields format
			List<String> badFormat = new ArrayList<>();
			TypeOperationVO operationType = null;
			try {
				typeOperation = typeOperation.toUpperCase();
				operationType = TypeOperationVO.valueOf(typeOperation);
			} catch (IllegalArgumentException e) {
				LOG.error(e.getMessage(), e);
				badFormat
				.add(String
						.format("le type d'opération envoyé [%s] n'est pas valide. Les valeurs possibles sont %s",
								typeOperation, Arrays.asList(TypeOperationVO.values())));
			}
			if (numberOfOperations != null && numberOfOperations <= 0 ) {
				badFormat
				.add("Le nombre d'opérations est invalide. Au moins une opération devrait être sélectionnée");
			}

			if (!CollectionUtils.isEmpty(badFormat)) {
				error = new SmcApiError("ERR.CMC.FUNC.701",
						"Format de donnée incorrect", badFormat);
				return ResponseEntity.badRequest().body(error);

			}

			TypeOperation operationType1 = null;
			switch (operationType) {
			case PAIEMENT:
				operationType1 = TypeOperation.PAIEMENT;
				break;
			case RETRAIT:
				operationType1 = TypeOperation.RETRAIT;
				break;
			case MIXTE:
				operationType1 = TypeOperation.LESDEUX;
				break;
			}

			final List<MotifContestation> allMotifs = this.contestationManagement
					.getMotifsApplicables(operationType1, cardLost,
							numberOfOperations);
			if (CollectionUtils.isEmpty(allMotifs)) {
				LOG.error("No data found for inputs : typeOperation = "
						+ typeOperation + " and cardLost = " + cardLost);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
						new SmcApiError("ERR.FUNC.CMC.944", "No data found."));
			}
			List<MotifVO> motifsVO = allMotifs
					.stream()
					.map(motifContestation -> {
						MotifVO motifVO = new MotifVO();
						BeanUtils.copyProperties(motifContestation, motifVO);
						motifVO.setLabel(getMessage(motifContestation.getLibelle()));

						motifVO.setDisclaimerText(getMessage(motifContestation.getDisclaimerText()));

						motifVO.setDescription(getMessage(motifContestation.getDescription()));

						final ExigenceAjoutInformation topMentionFactDescription = motifContestation
								.getTopMentionFactDescription();
						if (topMentionFactDescription != null) {
							motifVO.setTopMentionFactDescription(MotifVO.TopMentionFactDescriptionEnum
									.valueOf(topMentionFactDescription.name()));
						}
						List<DocumentJustificatif> documentsAssocies = motifContestation
								.getDocumentAssocies();
						if (!CollectionUtils.isEmpty(documentsAssocies)) {
							List<MotifVOAssociatedDocuments> attachments = documentsAssocies
									.stream()
									.map(docAssocie -> {
										MotifVOAssociatedDocuments docAssVO = new MotifVOAssociatedDocuments();
										docAssVO.setDocType(docAssocie
												.getTypeDocGDN());
										docAssVO.setFileType(docAssocie
												.getLabelJustificatif());
										return docAssVO;
									}).collect(Collectors.toList());
							motifVO.setAssociatedDocuments(attachments);
						}
						motifVO.setExigenceAttachement(motifContestation
								.getExigenceAttachement());
						return motifVO;
					}).collect(Collectors.toList());
			return ResponseEntity.status(HttpStatus.OK).body(motifsVO);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999",
							"Unexpected Technical error", Arrays.asList(e
									.getMessage())));
		}
	}

	@Override
	@RequestMapping(value = "/disputes", produces = { "application/json" }, method = RequestMethod.GET)
	public ResponseEntity searchDisputes(
			@RequestHeader(value = "xB3TraceId", required = false) String xB3TraceId,
			@RequestHeader(value = "xB3SpanId", required = false) String xB3SpanId,
			@RequestHeader(value = "telematicId", required = false) String telematicId,
			@RequestHeader(value = "userId", required = false) String userId,
			@RequestHeader(value = "applicationCode", required = false) String applicationCode,
			@RequestHeader(value = "channel", required = false) String channel,
			@RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
			@RequestParam(value = "limit", required = false, defaultValue = "10") Integer limit,
			@RequestParam(value = "disputeReference", required = false) String disputeReference,
			@RequestParam(value = "identifiantInterne", required = false) String identifiantInterne,
			@RequestParam(value = "disputeStatus", required = false) String disputeStatus) {
		List<String> missingDatas = new ArrayList<String>();
		List<String> formatErrors = new ArrayList<String>();
		ContestationDetailsResponse contestationDetailsResponse = new ContestationDetailsResponse();

		try {
			control.checkMandatoryFields(telematicId,
					conf.getTelematicIdAbsent(), missingDatas);
			control.checkMandatoryFields(userId, conf.getMessageIkpiAbsent(),
					missingDatas);
			/*control.checkMandatoryFields(applicationCode,
					conf.getCodeApplicationAbsent(), missingDatas);
			control.checkMandatoryFields(channel, conf.getCanalAbsent(),
					missingDatas);*/

			SmcResponseError smcResponseError = builderResponse
					.getResponseSmcError(formatErrors, null, missingDatas, null);

			if (smcResponseError != null
					&& !CollectionUtils.isEmpty(smcResponseError.getErrors())) {
				return new ResponseEntity(smcResponseError,
						HttpStatus.BAD_REQUEST);
			} else {
				if (identifiantInterne != null && !identifiantInterne.isEmpty()) {
					Contestation contestation = contestationManagement
							.consulterContestationParIdInterne(identifiantInterne);
					DisputeDetails disputeDetails = mapToContestationDetails(contestation);
					contestationDetailsResponse.setContestation(disputeDetails);
					return new ResponseEntity<ContestationDetailsResponse>(
							contestationDetailsResponse, HttpStatus.OK);
				} else if (disputeReference != null) {

					if (StringUtils.isEmpty(disputeStatus)) {
						return new ResponseEntity<SmcResponseError>(
								new SmcResponseError(
										Arrays.asList(new SmcApiError(
												conf.getCodeAbsentDonne(),
												conf.getErrorGeneriqueAbsent(),
												Arrays.asList(conf
														.getMessageDisputStatusAbsent())))),
														HttpStatus.BAD_REQUEST);
					} else {

						if (BROUILLON.equals(disputeStatus)
								|| CREER.equals(disputeStatus)) {
							return new ResponseEntity<SmcResponseError>(
									new SmcResponseError(
											Arrays.asList(new SmcApiError(
													conf.getCodeDonneIncorrect(),
													conf.getErrorGeneriqueIncorect(),
													Arrays.asList(conf
															.getMessageDisputStatusIncorrect())))),
															HttpStatus.BAD_REQUEST);
						} else {
							Contestation contestation = contestationManagement
									.consulterContestation(disputeReference,
											disputeStatus);
							DisputeDetails disputeDetails = mapToContestationDetails(contestation);
							contestationDetailsResponse
							.setContestation(disputeDetails);
							return new ResponseEntity<ContestationDetailsResponse>(
									contestationDetailsResponse, HttpStatus.OK);
						}
					}
				} else {
					List<DisputeDetails> disputeDetails = null;

					List<Contestation> contestations = contestationManagement
							.getHistoriqueContestations(telematicId, offset,
									limit);
					if (contestations != null) {
						disputeDetails = contestations
								.stream()
								.map(contestation -> mapToContestationDetails(contestation))
								.collect(Collectors.toList());
					}
					HistoriqueContestationsResponse historiqueContestationsResponse = new HistoriqueContestationsResponse();
					historiqueContestationsResponse
					.setContestations(disputeDetails);

					return new ResponseEntity<HistoriqueContestationsResponse>(
							historiqueContestationsResponse, HttpStatus.OK);
				}
			}
		} catch (ContestationException e) {
			/**
			 *
			 */
			LOG.error(e.getMessage(), e);
			return new ResponseEntity(new SmcResponseError(
					Arrays.asList(new SmcApiError(conf
							.getCodeErreurServiceContestation(),e.getMessage(), null))),
							HttpStatus.BAD_REQUEST);
		} catch (MandatoryException e) {
			LOG.error(conf.getErrorGeneriqueAbsent(), e);
			/**
			 * donnée absente
			 */
			return new ResponseEntity(new SmcResponseError(
					Arrays.asList(new SmcApiError(conf.getCodeAbsentDonne(),
							conf.getErrorGeneriqueAbsent(), e.getErrors()))),
							HttpStatus.BAD_REQUEST);
		} catch (DonneIncorectException e) {
			LOG.error(conf.getErrorGeneriqueIncorect(), e);
			/**
			 * donnée incorecte
			 */
			return new ResponseEntity(new SmcResponseError(
					Arrays.asList(new SmcApiError(conf.getCodeDonneIncorrect(),
							conf.getErrorGeneriqueIncorect(), e.getErrors()))),
							HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new SmcApiError("ERR.FUNC.CMC.999",
							"Unexpected Technical error", Arrays.asList(e
									.getMessage())));

		}

	}

}
