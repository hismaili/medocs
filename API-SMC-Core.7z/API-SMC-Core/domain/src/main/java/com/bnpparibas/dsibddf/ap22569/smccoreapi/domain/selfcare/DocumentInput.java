package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;



/**
 * Document
 */
public class DocumentInput   {

	private String idGed;


	private String documentType;


	private String documentName;


	/**
	 *
	 */
	public DocumentInput() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param idGed
	 * @param documentType
	 * @param documentName
	 */
	public DocumentInput(String idGed, String documentType, String documentName) {
		this.idGed = idGed;
		this.documentType = documentType;
		this.documentName = documentName;
	}


	/**
	 * @return the documentName
	 */
	public String getDocumentName() {
		return documentName;
	}


	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}


	/**
	 * @return the idGed
	 */
	public String getIdGed() {
		return idGed;
	}


	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}


	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}


	/**
	 * @param idGed the idGed to set
	 */
	public void setIdGed(String idGed) {
		this.idGed = idGed;
	}


}

