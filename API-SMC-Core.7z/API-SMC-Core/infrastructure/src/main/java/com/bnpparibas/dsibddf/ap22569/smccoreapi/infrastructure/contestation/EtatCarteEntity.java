package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.contestation;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons.AbstractAuditableEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EtatCarteEntity extends AbstractAuditableEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(length=25)
	private String codeEtat;

	@Column
	private String libelleEtat;

	/**
	 *
	 */
	public EtatCarteEntity() {
		super();

	}

	/**
	 * @param codeEtat
	 * @param libelleEtat
	 */
	public EtatCarteEntity(String codeEtat, String libelleEtat) {
		this.codeEtat = codeEtat;
		this.libelleEtat = libelleEtat;
	}

    public String getCodeEtat() {
		return codeEtat;
	}

    public String getLibelleEtat() {
		return libelleEtat;
	}

	/**
	 * @param codeEtat the codeEtat to set
	 */
	public void setCodeEtat(String codeEtat) {
		this.codeEtat = codeEtat;
	}

	/**
	 * @param libelleEtat the libelleEtat to set
	 */
	public void setLibelleEtat(String libelleEtat) {
		this.libelleEtat = libelleEtat;
	}
}
