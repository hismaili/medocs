/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.notification.batch.model;


/**
 * @author c65344
 *
 */
public class NotificationFileMetadata {
	private String idFileNotification;
	private String numSeqHeader;
	private String dateFluxHeader;
	private Integer recordNumber;
	private String fileName;
	/**
	 *
	 */
	public NotificationFileMetadata() {
		super();

	}
	/**
	 * @param idFileNotification
	 * @param numSeqHeader
	 * @param dateFluxHeader
	 */
	public NotificationFileMetadata(String idFileNotification, String numSeqHeader,
									String dateFluxHeader) {
		this.idFileNotification = idFileNotification;
		this.numSeqHeader = numSeqHeader;
		this.dateFluxHeader = dateFluxHeader;
	}
	/**
	 * @return the dateFluxHeader
	 */
	public String getDateFluxHeader() {
		return dateFluxHeader;
	}
	/**
	 * @return the idFileNotification
	 */
	public String getIdFileNotification() {
		return idFileNotification;
	}
	/**
	 * @return the numSeqHeader
	 */
	public String getNumSeqHeader() {
		return numSeqHeader;
	}
	/**
	 * @param dateFluxHeader the dateFluxHeader to set
	 */
	public void setDateFluxHeader(String dateFluxHeader) {
		this.dateFluxHeader = dateFluxHeader;
	}
	/**
	 * @param idFileNotification the idFileNotification to set
	 */
	public void setIdFileNotification(String idFileNotification) {
		this.idFileNotification = idFileNotification;
	}
	/**
	 * @param numSeqHeader the numSeqHeader to set
	 */
	public void setNumSeqHeader(String numSeqHeader) {
		this.numSeqHeader = numSeqHeader;
	}

	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
