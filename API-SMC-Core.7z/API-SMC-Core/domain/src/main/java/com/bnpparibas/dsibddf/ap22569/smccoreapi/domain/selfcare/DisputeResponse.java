package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.selfcare;


/**
 * DisputeFile
 */
public class DisputeResponse   {

	private String fileIdSMC;

	private StatusCodeResponse statusCodeResponse;

	/**
	 * @return the fileIdSMC
	 */
	public String getFileIdSMC() {
		return fileIdSMC;
	}

	/**
	 * @return the statusCodeResponse
	 */
	public StatusCodeResponse getStatusCodeResponse() {
		return statusCodeResponse;
	}

	/**
	 * @param fileIdSMC the fileIdSMC to set
	 */
	public void setFileIdSMC(String fileIdSMC) {
		this.fileIdSMC = fileIdSMC;
	}

	/**
	 * @param statusCodeResponse the statusCodeResponse to set
	 */
	public void setStatusCodeResponse(StatusCodeResponse statusCodeResponse) {
		this.statusCodeResponse = statusCodeResponse;
	}



}

