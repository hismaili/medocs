package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

/**
 * CustomerContacts
 */
public class CustomerContacts   {

  @JsonProperty("mailId")
  private String mailId;

  @JsonProperty("phoneNumberId")
  private String phoneNumberId;

  @JsonProperty("maskedMail")
  private String maskedMail;

  @JsonProperty("maskedPhoneNumber")
  private String maskedPhoneNumber;

  /**
   * identifiant télématique du client
   * @return telematicId
  **/

  public CustomerContacts mailId(String mailId) {
    this.mailId = mailId;
    return this;
  }

  /**
   * identifiant du mail
   * @return mailId
  **/
  @ApiModelProperty(value = "identifiant du mail")


  public String getMailId() {
    return mailId;
  }

  public void setMailId(String mailId) {
    this.mailId = mailId;
  }

  public CustomerContacts phoneNumberId(String phoneNumberId) {
    this.phoneNumberId = phoneNumberId;
    return this;
  }

  /**
   * identifiant du numéro de téléphone masqué
   * @return phoneNumberId
  **/
  @ApiModelProperty(value = "identifiant du numéro de téléphone masqué")


  public String getPhoneNumberId() {
    return phoneNumberId;
  }

  public void setPhoneNumberId(String phoneNumberId) {
    this.phoneNumberId = phoneNumberId;
  }

  public CustomerContacts maskedMail(String maskedMail) {
    this.maskedMail = maskedMail;
    return this;
  }

  /**
   * l adresse mail de contact du client
   * @return maskedMail
  **/
  @ApiModelProperty(value = "l adresse mail de contact du client")


  public String getMaskedMail() {
    return maskedMail;
  }

  public void setMaskedMail(String maskedMail) {
    this.maskedMail = maskedMail;
  }

  public CustomerContacts maskedPhoneNumber(String maskedPhoneNumber) {
    this.maskedPhoneNumber = maskedPhoneNumber;
    return this;
  }

  /**
   * numéro de téléphone de contact du client
   * @return maskedPhoneNumber
  **/
  @ApiModelProperty(value = "numéro de téléphone de contact du client")


  public String getMaskedPhoneNumber() {
    return maskedPhoneNumber;
  }

  public void setMaskedPhoneNumber(String maskedPhoneNumber) {
    this.maskedPhoneNumber = maskedPhoneNumber;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CustomerContacts customerContacts = (CustomerContacts) o;
    return Objects.equals(this.mailId, customerContacts.mailId) &&
        Objects.equals(this.phoneNumberId, customerContacts.phoneNumberId) &&
        Objects.equals(this.maskedMail, customerContacts.maskedMail) &&
        Objects.equals(this.maskedPhoneNumber, customerContacts.maskedPhoneNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(mailId, phoneNumberId, maskedMail, maskedPhoneNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CustomerContacts {\n");
    
    sb.append("    mailId: ").append(toIndentedString(mailId)).append("\n");
    sb.append("    phoneNumberId: ").append(toIndentedString(phoneNumberId)).append("\n");
    sb.append("    maskedMail: ").append(toIndentedString(maskedMail)).append("\n");
    sb.append("    maskedPhoneNumber: ").append(toIndentedString(maskedPhoneNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

