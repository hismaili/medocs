package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.selfcare;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Errors
 */
public class Errors   {
	@JsonProperty("code")
	private String code;

	@JsonProperty("message")
	private String message;

	@JsonProperty("attribute")
	private String attribute;

	@JsonProperty("additionalInformation")
	private AdditionalInformation additionalInformation;

	/**
	 * @return the additionalInformation
	 */
	public AdditionalInformation getAdditionalInformation() {
		return additionalInformation;
	}

	/**
	 * @return the attribute
	 */
	public String getAttribute() {
		return attribute;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param additionalInformation the additionalInformation to set
	 */
	public void setAdditionalInformation(AdditionalInformation additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	/**
	 * @param attribute the attribute to set
	 */
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}


}

