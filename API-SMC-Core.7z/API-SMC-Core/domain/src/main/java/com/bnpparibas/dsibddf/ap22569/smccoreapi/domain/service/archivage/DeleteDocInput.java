package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.archivage;


/**
 *
 * @author c65344
 *
 */
public class DeleteDocInput {
	private String callingUserDeleteInput;
	private String callingApplicationDeleteInput;
	private String localeCodeDeleteInput;
	private String countryCodeDeleteInput;
	private String documentIdDeleteInput;
	private String idContestationSmcDeleteInput;
	private String numCarteBancaireDeleteInput;

	public DeleteDocInput() {
		super();

	}

	/**
	 * @param callingUserDeleteInput
	 * @param callingApplicationDeleteInput
	 * @param localeCodeDeleteInput
	 * @param countryCodeDeleteInput
	 * @param documentIdDeleteInput
	 * @param idContestationSmcDeleteInput
	 * @param numCarteBancaireDeleteInput
	 */
	public DeleteDocInput(String callingUserDeleteInput,
			String callingApplicationDeleteInput, String localeCodeDeleteInput,
			String countryCodeDeleteInput, String documentIdDeleteInput,
			String idContestationSmcDeleteInput,
			String numCarteBancaireDeleteInput) {
		this.callingUserDeleteInput = callingUserDeleteInput;
		this.callingApplicationDeleteInput = callingApplicationDeleteInput;
		this.localeCodeDeleteInput = localeCodeDeleteInput;
		this.countryCodeDeleteInput = countryCodeDeleteInput;
		this.documentIdDeleteInput = documentIdDeleteInput;
		this.idContestationSmcDeleteInput = idContestationSmcDeleteInput;
		this.numCarteBancaireDeleteInput = numCarteBancaireDeleteInput;
	}

	/**
	 * @return the callingApplicationDeleteInput
	 */
	public String getCallingApplicationDeleteInput() {
		return callingApplicationDeleteInput;
	}

	/**
	 * @return the callingUserDeleteInput
	 */
	public String getCallingUserDeleteInput() {
		return callingUserDeleteInput;
	}

	/**
	 * @return the countryCodeDeleteInput
	 */
	public String getCountryCodeDeleteInput() {
		return countryCodeDeleteInput;
	}

	/**
	 * @return the documentIdDeleteInput
	 */
	public String getDocumentIdDeleteInput() {
		return documentIdDeleteInput;
	}

	/**
	 * @return the idContestationSmcDeleteInput
	 */
	public String getIdContestationSmcDeleteInput() {
		return idContestationSmcDeleteInput;
	}

	/**
	 * @return the localeCodeDeleteInput
	 */
	public String getLocaleCodeDeleteInput() {
		return localeCodeDeleteInput;
	}

	/**
	 * @return the numCarteBancaireDeleteInput
	 */
	public String getNumCarteBancaireDeleteInput() {
		return numCarteBancaireDeleteInput;
	}

	/**
	 * @param callingApplicationDeleteInput the callingApplicationDeleteInput to set
	 */
	public void setCallingApplicationDeleteInput(
			String callingApplicationDeleteInput) {
		this.callingApplicationDeleteInput = callingApplicationDeleteInput;
	}

	/**
	 * @param callingUserDeleteInput the callingUserDeleteInput to set
	 */
	public void setCallingUserDeleteInput(String callingUserDeleteInput) {
		this.callingUserDeleteInput = callingUserDeleteInput;
	}

	/**
	 * @param countryCodeDeleteInput the countryCodeDeleteInput to set
	 */
	public void setCountryCodeDeleteInput(String countryCodeDeleteInput) {
		this.countryCodeDeleteInput = countryCodeDeleteInput;
	}

	/**
	 * @param documentIdDeleteInput the documentIdDeleteInput to set
	 */
	public void setDocumentIdDeleteInput(String documentIdDeleteInput) {
		this.documentIdDeleteInput = documentIdDeleteInput;
	}

	/**
	 * @param idContestationSmcDeleteInput the idContestationSmcDeleteInput to set
	 */
	public void setIdContestationSmcDeleteInput(String idContestationSmcDeleteInput) {
		this.idContestationSmcDeleteInput = idContestationSmcDeleteInput;
	}

	/**
	 * @param localeCodeDeleteInput the localeCodeDeleteInput to set
	 */
	public void setLocaleCodeDeleteInput(String localeCodeDeleteInput) {
		this.localeCodeDeleteInput = localeCodeDeleteInput;
	}

	/**
	 * @param numCarteBancaireDeleteInput the numCarteBancaireDeleteInput to set
	 */
	public void setNumCarteBancaireDeleteInput(String numCarteBancaireDeleteInput) {
		this.numCarteBancaireDeleteInput = numCarteBancaireDeleteInput;
	}


}
