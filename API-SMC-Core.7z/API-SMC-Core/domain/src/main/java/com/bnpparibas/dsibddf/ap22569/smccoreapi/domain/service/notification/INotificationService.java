/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification;

import java.util.List;

/**
 * @author c65344
 *
 */
public interface INotificationService {

	/**
	 * enregistre L'ensemble des notifications en base de donnée
	 * @param notification
	 * @throws NotificationException
	 */
	void saveNotification(Notification notification) throws NotificationException;

	void saveNotificationFileHeader(NotificationInfoFile infoFileHeader) throws NotificationException;

	void saveNotificationFileFooter(NotificationInfoFile infoFileFooter) throws NotificationException;

    List<Notification> getPendingNotifications() throws NotificationException;

    void flagEventAsSucceeded(String notificationId) throws NotificationException;

    NotificationInfoFile getLastTreatedFile(String dateflux) throws NotificationException;

	NotificationInfoFile getFileBySequenceNumber(String dateflux, String currentSequenceNumber) throws NotificationException;

	void flagNotificationFileTreatmentAsSucceeded(NotificationInfoFile infoFile) throws NotificationException;

	void flagNotificationFileTreatmentAsFailed(NotificationInfoFile infoFile) throws NotificationException;
}
