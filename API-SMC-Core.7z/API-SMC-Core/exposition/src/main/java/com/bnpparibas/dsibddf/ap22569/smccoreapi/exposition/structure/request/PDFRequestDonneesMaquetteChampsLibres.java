package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * PDFRequestDonneesMaquetteChampsLibres
 */
public class PDFRequestDonneesMaquetteChampsLibres   {
	@ApiModelProperty(value = "indexParagraphe")
	private Integer indexParagraphe ;

	@ApiModelProperty(value = "phrases")
	private List<PDFRequestDonneesMaquettePhrases> phrases ;

	/**
	 *
	 */
	public PDFRequestDonneesMaquetteChampsLibres() {
		super();

	}

	/**
	 * @param indexParagraphe
	 * @param phrases
	 */
	public PDFRequestDonneesMaquetteChampsLibres(Integer indexParagraphe,
			List<PDFRequestDonneesMaquettePhrases> phrases) {
		this.indexParagraphe = indexParagraphe;
		this.phrases = phrases;
	}

	/**
	 * @return the indexParagraphe
	 */
	public Integer getIndexParagraphe() {
		return indexParagraphe;
	}

	/**
	 * @return the phrases
	 */
	public List<PDFRequestDonneesMaquettePhrases> getPhrases() {
		return phrases;
	}

	/**
	 * @param indexParagraphe the indexParagraphe to set
	 */
	public void setIndexParagraphe(Integer indexParagraphe) {
		this.indexParagraphe = indexParagraphe;
	}

	/**
	 * @param phrases the phrases to set
	 */
	public void setPhrases(List<PDFRequestDonneesMaquettePhrases> phrases) {
		this.phrases = phrases;
	}


}

