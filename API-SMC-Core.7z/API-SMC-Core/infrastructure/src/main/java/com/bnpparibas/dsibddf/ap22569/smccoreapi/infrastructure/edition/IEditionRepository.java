package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface IEditionRepository extends JpaRepository<EditionEntity,String>{

	/**
	 * recupère les documents
	 */
	List<EditionEntity> findByStatus(Status status);


	@Query("SELECT max(e.numSequence) FROM EditionEntity e")
	int getMaxNumSequence();

}
