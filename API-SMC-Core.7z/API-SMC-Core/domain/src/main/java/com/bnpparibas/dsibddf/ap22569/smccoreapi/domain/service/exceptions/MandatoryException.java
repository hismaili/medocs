/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.List;

/**
 * @author c65344
 *
 */
public class MandatoryException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1857889580052494800L;
	private List<String> errors;

	private List<String> errorsUI;

	/**
	 *
	 */
	public MandatoryException() {
		super();

	}

	/**
	 * @param errors
	 */
	public MandatoryException(String message, List<String> errors) {
		super(message);
		this.errors = errors;
	}

	/**
	 * @param errors
	 */
	public MandatoryException(List<String> errors) {
		this.errors = errors;
	}

	/**
	 * @param errors
	 * @param errorsUI
	 */
	public MandatoryException(List<String> errors, List<String> errorsUI) {
		this.errors = errors;
		this.errorsUI = errorsUI;
	}

	/**
	 * @param message
	 */
	public MandatoryException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public MandatoryException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param cause
	 */
	public MandatoryException(Throwable cause) {
		super(cause);

	}

	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}

	/**
	 * @return the errorsUI
	 */
	public List<String> getErrorsUI() {
		return errorsUI;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	/**
	 * @param errorsUI the errorsUI to set
	 */
	public void setErrorsUI(List<String> errorsUI) {
		this.errorsUI = errorsUI;
	}
}
