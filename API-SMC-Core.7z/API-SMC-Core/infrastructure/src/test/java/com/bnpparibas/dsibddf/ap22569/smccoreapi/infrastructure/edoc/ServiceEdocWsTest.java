/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration.ConfigInfrastructure;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Fail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * @author c65344
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles({"local","test"})
public class ServiceEdocWsTest {
	@Configuration
	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration",
	"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc"})
	static class TestConfig{
		@Bean("simpleresttemplate")
		public RestTemplate restTemplate() {
			return new RestTemplate();
		}
	}

	private static final Logger LOG = LoggerFactory.getLogger(ServiceEdocWsTest.class);
	@Autowired
	private ServiceEdocWs edoc;



	@Autowired
	private ConfigInfrastructure conf;

	/**
	 * @throws java.lang.Exception
	 */
	private String getIdAttachment() throws Exception {
		HttpHeaders header = new HttpHeaders();

		header.set("Accept", "application/json");
		header.add("media", conf.getMediaEdoc());
		header.add("channel", conf.getChannelEdoc());
		header.add("userId", conf.getUserIdEdoc());
		header.setContentType(MediaType.MULTIPART_FORM_DATA);
		LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<>();

		map.add("file", new ClassPathResource("/Test.pdf"));

		HttpEntity<LinkedMultiValueMap<String, Object>> request = new    HttpEntity<LinkedMultiValueMap<String, Object>>(
				map, header);


		String url =conf.getUrlPostEdoc();

		TestRestTemplate restTemplate = new TestRestTemplate();

		ResponseEntity<ResponseEdocOutput> response = restTemplate.exchange(
				url, HttpMethod.POST, request,
				ResponseEdocOutput.class);

		LOG.info(response.toString());
		Assertions.assertThat(response).isNotNull();
		HttpStatus statusCode = response.getStatusCode();
		Assertions.assertThat(statusCode).isNotNull();
		Assertions.assertThat(statusCode.is2xxSuccessful()).isNotNull();
		ResponseEdocOutput body = response.getBody();
		Assertions.assertThat(body).isNotNull();
		String idAttachment = body.getIdAttachment();
		Assertions.assertThat(idAttachment).isNotEmpty();
		LOG.info("L'id attachement creer par Edoc est :"+idAttachment);


		return idAttachment;
	}

	@Test
	public void testGetIdGnBadRequest() {

		String idGn = edoc.getIdGn("579273c3-edd6-4ba7-bfcf-291425390657"); //$NON-NLS-1$
		Assertions.assertThat(idGn).isNull();
	}

	/**
	 * Test method for {@link com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.edoc.ServiceEdocWs#getIdGn(java.lang.String)}.
	 * @throws Exception
	 */
	@Test
	public void testGetIdGnSuccess(){

		String idGn;
		try {
			String idAttachment = getIdAttachment();
			idGn = edoc.getIdGn(idAttachment);
			LOG.info("L'id Gdn envoyer par Edoc est :"+idGn);
			Assertions.assertThat(idGn).isNotEmpty();
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
			Fail.fail(e.getMessage(),e);
		}

	}

}
