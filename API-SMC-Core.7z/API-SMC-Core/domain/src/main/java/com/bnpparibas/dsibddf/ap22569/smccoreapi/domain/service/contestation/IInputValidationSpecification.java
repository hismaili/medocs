package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation;

public interface IInputValidationSpecification<T> {

    boolean isSatisfiedBy(T candidate);

    boolean and(IInputValidationSpecification specification);

    boolean or(IInputValidationSpecification specification);

    boolean not(IInputValidationSpecification specification);
}
