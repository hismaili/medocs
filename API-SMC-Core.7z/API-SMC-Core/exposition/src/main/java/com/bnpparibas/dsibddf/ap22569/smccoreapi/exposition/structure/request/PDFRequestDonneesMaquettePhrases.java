package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * PDFRequestDonneesMaquettePhrases
 */
public class PDFRequestDonneesMaquettePhrases   {
	@ApiModelProperty(value = "indexPhrase")
	private Integer indexPhrase;

	@ApiModelProperty(value = "textPhrase")
	private String textPhrase;

	/**
	 *
	 */
	public PDFRequestDonneesMaquettePhrases() {
		super();

	}

	/**
	 * @param indexPhrase
	 * @param textPhrase
	 */
	public PDFRequestDonneesMaquettePhrases(Integer indexPhrase,
			String textPhrase) {
		this.indexPhrase = indexPhrase;
		this.textPhrase = textPhrase;
	}

	/**
	 * @return the indexPhrase
	 */
	public Integer getIndexPhrase() {
		return indexPhrase;
	}

	/**
	 * @return the textPhrase
	 */
	public String getTextPhrase() {
		return textPhrase;
	}

	/**
	 * @param indexPhrase the indexPhrase to set
	 */
	public void setIndexPhrase(Integer indexPhrase) {
		this.indexPhrase = indexPhrase;
	}

	/**
	 * @param textPhrase the textPhrase to set
	 */
	public void setTextPhrase(String textPhrase) {
		this.textPhrase = textPhrase;
	}



}

