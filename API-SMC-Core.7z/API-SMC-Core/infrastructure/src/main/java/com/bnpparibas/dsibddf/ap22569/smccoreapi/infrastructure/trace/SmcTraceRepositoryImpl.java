package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.trace;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.ISmcTraceRepository;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.trace.SmcTrace;
import org.springframework.stereotype.Repository;

@Repository
public class SmcTraceRepositoryImpl implements ISmcTraceRepository {

    private transient SmcTraceJpaRepository traceJpaRepository;

    public SmcTraceRepositoryImpl(SmcTraceJpaRepository traceJpaRepository) {
        super();
        this.traceJpaRepository = traceJpaRepository;
    }

    @Override
    public void createTrace(SmcTrace smcTrace) {
        traceJpaRepository.save(SmcTraceMapper.mapModelEntityToJpaEntity(smcTrace));
    }
}
