package com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.api;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.Arrays;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import brave.Tracer;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.IContestationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation.IDisputeSelfCareManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.contestation.Contestation;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions.ContestationValidationException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.BuilderResponseSmc;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.ConfigExposition;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.ControlBuilder;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.exposition.structure.response.SmcApiError;


@RequestMapping("/v1/cosmo")
@RestController
@Validated
@Api(tags = {"Gestion des services interne de cosmo"})
public class DisputeHelpController {

	private static final Logger LOG = LoggerFactory.getLogger(DisputeHelpController.class);
	private static final Locale ADEFAULT = Locale.getDefault();
	private static final String STRING = " : ";
	private static final String VALUE = "NOT EMPTY"; //$NON-NLS-1$
	private static final String ERROR = "ERREUR INTERNE DU SERVEUR"; //$NON-NLS-1$

	private static final String NULLVALUE = null;
	@Autowired
	private transient ControlBuilder control;
	@Autowired
	private transient Tracer tracer;

	@Autowired
	private transient BuilderResponseSmc builderResponse;


	@Autowired
	private final transient IDisputeSelfCareManagement disputeSelfCareManagement;

	@Autowired
	private final transient IContestationManagement contestationManagement;

	@Autowired
	private transient ConfigExposition conf;


	/**
	 *
	 * @param archivageManagement
	 */
	public DisputeHelpController(IDisputeSelfCareManagement disputeSelfCareManagement,IContestationManagement contestationManagement) {
		this.disputeSelfCareManagement = disputeSelfCareManagement;
		this.contestationManagement = contestationManagement;
	}

	/**
	 * Ferme un dossier du système d'archivage
	 *
	 * @param closeFolderDTO
	 * @param head : header http
	 * @return
	 */
	@ApiOperation(value = "", nickname = "generate-recap", notes = "Génère un recapitulatif selfcare et l'envoi à smc")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Géneration effectuée"),
			@ApiResponse(code = 400, message = "Donnée obligatoire manquante, Format de donnée incorrect, etc ...", response = SmcApiError.class),
			@ApiResponse(code = 404, message = "Aucune contestation trouvé avec cet id", response = SmcApiError.class),
			@ApiResponse(code = 406, message = "Aucun numéro de dossier n'est associé à cette contestation", response = SmcApiError.class),
			@ApiResponse(code = 500, message = "Erreur interne du server", response = SmcApiError.class)})
	@RequestMapping(value = "/generate/recap/{idContestation}" ,produces = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.PUT)
	public ResponseEntity generateRecap(@PathVariable(value="idContestation", required = false) String idContestation){


		if(StringUtils.isEmpty(idContestation)){

			SmcApiError error = new SmcApiError("ERR.CMC.FUNC.700",
					"Une ou plusieurs données obligatoires non renseignées",
					Arrays.asList("La donnée idContestation est obligatoire"));
			return ResponseEntity.badRequest().body(error);
		}

		try {
			Contestation contestation = contestationManagement.consulterContestationParIdInterne(idContestation);

			if(contestation == null){
				final SmcApiError t = new SmcApiError("",
						"Aucune contestation trouvé avec cet id",
						Arrays.asList(idContestation));

				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(t);
			}


			if(StringUtils.isEmpty(contestation.getNumDossierSMC())){
				final SmcApiError t = new SmcApiError("",
						"Aucun numéro de dossier n'est associé à cette contestation",
						Arrays.asList(idContestation));
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(t);
			}


			disputeSelfCareManagement.generateAndSaveRecap(contestation);

			return new ResponseEntity<>(HttpStatus.CREATED);

		} catch (ContestationException | ContestationValidationException e) {
			LOG.error(e.getMessage(), e);
			SmcApiError error = new SmcApiError("ERR.CMC.TECH.9xx",
					"Erreur Interne", Arrays.asList(e.getMessage()));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(error);
		}

	}

}
