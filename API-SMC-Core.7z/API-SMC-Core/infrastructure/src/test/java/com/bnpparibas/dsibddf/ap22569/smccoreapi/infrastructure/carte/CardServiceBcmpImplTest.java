package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CardException;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.CartePorteur;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.carte.ICardRepository;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Fail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
@ActiveProfiles({"local", "test"})
public class CardServiceBcmpImplTest {

	@Configuration
	@ComponentScan(basePackages = {"com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.carte",
			"com.bnpparibas.dsibddf.ap22569.smctobcmp","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.commons","com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.configuration"
	}, lazyInit=true)
	static class TestConfig{
		@Bean("simpleresttemplate")
		public RestTemplate restTemplate() {
			return new RestTemplate();
		}
	}

	//TODO creer un mock de carte pour ne pas invoquer le webservice à chaque fois


	private static final Logger LOG = LoggerFactory.getLogger(CardServiceBcmpImplTest.class);


	@Autowired
	private transient ICardRepository cardServices;


	@Test
	public void testGetCartesPorteur() {
		List<CartePorteur> cartesPorteur;
		try {
			cartesPorteur = cardServices.getCartesPorteur("2289627126");
			Assertions.assertThat(cartesPorteur).isNotNull().isNotEmpty();
			Assertions.assertThat(cartesPorteur.size()).isEqualTo(5);
			cartesPorteur = cardServices.getCartesPorteur("3865814351");
			Assertions.assertThat(cartesPorteur).isNotNull().isNotEmpty();
			Assertions.assertThat(cartesPorteur.size()).isEqualTo(3);
			cartesPorteur = cardServices.getCartesPorteur("3610838481");
			Assertions.assertThat(cartesPorteur).isNotNull().isNotEmpty();
			Assertions.assertThat(cartesPorteur.size()).isEqualTo(1);
		} catch (CardException e) {
			LOG.error(e.getMessage(), e);
			//fail(e.getMessage());
		}

	}

	@Test
	public void testGetInfoCard() throws CardException {
		try {
			Assertions.assertThat(cardServices.getInfoCard("0004974074205030660")).isNotNull();
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
			Fail.fail(e.getMessage(),e);
		}

	}

}
