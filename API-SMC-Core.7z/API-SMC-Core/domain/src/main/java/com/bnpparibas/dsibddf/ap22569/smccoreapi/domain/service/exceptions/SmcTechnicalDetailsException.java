/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.exceptions;

import java.util.List;
import java.util.Map;

/**
 * @author c65344
 *
 */
public class SmcTechnicalDetailsException extends Exception{

	private Map<List<String>,List<String>> errors;

	/**
	 *
	 */
	public SmcTechnicalDetailsException() {
		super();

	}

	/**
	 * @param errors
	 */
	public SmcTechnicalDetailsException(Map<List<String>, List<String>> errors) {
		this.errors = errors;
	}

	/**
	 * @param message
	 */
	public SmcTechnicalDetailsException(String message) {
		super(message);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public SmcTechnicalDetailsException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public SmcTechnicalDetailsException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	/**
	 * @param cause
	 */
	public SmcTechnicalDetailsException(Throwable cause) {
		super(cause);

	}

	/**
	 * @return the errors
	 */
	public Map<List<String>, List<String>> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(Map<List<String>, List<String>> errors) {
		this.errors = errors;
	}

}
