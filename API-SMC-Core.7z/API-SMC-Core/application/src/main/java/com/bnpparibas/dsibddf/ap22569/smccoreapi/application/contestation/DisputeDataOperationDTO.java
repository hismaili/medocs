package com.bnpparibas.dsibddf.ap22569.smccoreapi.application.contestation;

import java.math.BigDecimal;

public class DisputeDataOperationDTO {

    private String codeOperation;

    private BigDecimal recognizedAmount;

    public String getCodeOperation() {
        return codeOperation;
    }

    public void setCodeOperation(String codeOperation) {
        this.codeOperation = codeOperation;
    }

    public BigDecimal getRecognizedAmount() {
        return recognizedAmount;
    }

    public void setRecognizedAmount(BigDecimal recognizedAmount) {
        this.recognizedAmount = recognizedAmount;
    }
}
