package com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.edition;

import java.util.List;

/**
 *
 * @author c65344
 *
 */
public class Paragraphe {
	private Integer indexparagraphe;

	private List<Phrase> phrase;


	/**
	 *
	 */
	public Paragraphe() {
		super();
	}


	/**
	 * @param indexparagraphe
	 */
	public Paragraphe(Integer indexparagraphe) {
		this.indexparagraphe = indexparagraphe;
	}


	/**
	 * @param indexparagraphe
	 * @param phrase
	 */
	public Paragraphe(Integer indexparagraphe, List<Phrase> phrase) {
		this.indexparagraphe = indexparagraphe;
		this.phrase = phrase;
	}


	/**
	 * @param phrase
	 */
	public Paragraphe(List<Phrase> phrase) {
		this.phrase = phrase;
	}


	/**
	 * @return the indexparagraphe
	 */
	public Integer getIndexparagraphe() {
		return indexparagraphe;
	}


	/**
	 * @return the phrase
	 */
	public List<Phrase> getPhrase() {
		return phrase;
	}


	/**
	 * @param indexparagraphe the indexparagraphe to set
	 */
	public void setIndexparagraphe(Integer indexparagraphe) {
		this.indexparagraphe = indexparagraphe;
	}


	/**
	 * @param phrase the phrase to set
	 */
	public void setPhrase(List<Phrase> phrase) {
		this.phrase = phrase;
	}




}
