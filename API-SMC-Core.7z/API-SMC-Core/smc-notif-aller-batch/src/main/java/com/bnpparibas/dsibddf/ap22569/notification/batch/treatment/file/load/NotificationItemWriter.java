
package com.bnpparibas.dsibddf.ap22569.notification.batch.treatment.file.load;

import com.bnpparibas.dsibddf.ap22569.smccoreapi.application.notification.INotificationManagement;
import com.bnpparibas.dsibddf.ap22569.smccoreapi.domain.service.notification.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;


/**
 * @author c65344
 *
 */
@Component
public class NotificationItemWriter implements ItemWriter<Notification> {

	private static final Logger LOG = LoggerFactory.getLogger(NotificationItemWriter.class);

	@Autowired
	private transient INotificationManagement notificationManagement;

	@Override
	public void write(List<? extends Notification> arg0) throws Exception {

		if(!CollectionUtils.isEmpty(arg0)){

			for(Notification notif : arg0){
				LOG.info(notif.toString());
				if(notif !=null){
					notificationManagement.saveNotification(notif);
				}

			}
		}

	}

}