/**
 *
 */
package com.bnpparibas.dsibddf.ap22569.smccoreapi.infrastructure.notification;

import javax.persistence.*;

/**
 * @author c65344
 *
 */
@Entity
@Table(name = "NOTIFICATION_FILE")
public class NotificationFileEntity{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id_file")
	private String idFileNotification;

	@Column(name = "date_flux_header")
	private String dateFluxHeader;

	@Column(name = "numero_sequence_journee")
	private String numSeqHeader;

	@Column
	private Integer recordNumber;

	@Column(length = 50)
	private String fileName;

	@Column
	@Enumerated(EnumType.STRING)
	private FileTreatmentStatus treatmentStatus = FileTreatmentStatus.IN_PROGRESS;

	/**
	 * @return the dateFluxHeader
	 */
	public String getDateFluxHeader() {
		return dateFluxHeader;
	}

	/**
	 * @return the idFileNotification
	 */
	public String getIdFileNotification() {
		return idFileNotification;
	}

	/**
	 * @return the numSeqHeader
	 */
	public String getNumSeqHeader() {
		return numSeqHeader;
	}

	/**
	 * @param dateFluxHeader the dateFluxHeader to set
	 */
	public void setDateFluxHeader(String dateFluxHeader) {
		this.dateFluxHeader = dateFluxHeader;
	}

	/**
	 * @param idFileNotification the idFileNotification to set
	 */
	public void setIdFileNotification(String idFileNotification) {
		this.idFileNotification = idFileNotification;
	}

	/**
	 * @param numSeqHeader the numSeqHeader to set
	 */
	public void setNumSeqHeader(String numSeqHeader) {
		this.numSeqHeader = numSeqHeader;
	}

	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public FileTreatmentStatus getTreatmentStatus() {
		return treatmentStatus;
	}

	public void setTreatmentStatus(FileTreatmentStatus treatmentStatus) {
		this.treatmentStatus = treatmentStatus;
	}
}
